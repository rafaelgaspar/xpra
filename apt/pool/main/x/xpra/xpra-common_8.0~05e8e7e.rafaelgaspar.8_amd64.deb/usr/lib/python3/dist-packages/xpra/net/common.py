# This file is part of Xpra.
# Copyright (C) 2013 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import sys
import struct
import threading
from typing import Any, TypeAlias
from collections.abc import Callable, Sequence

from xpra.exit_codes import ExitCode
from xpra.net.compression import Compressed, Compressible, LargeStructure
from xpra.common import noop, SizedBuffer
from xpra.net.constants import ConnectionMessage
from xpra.os_util import LINUX, WIN32, OSX
from xpra.config import InitExit
from xpra.util.parsing import str_to_bool
from xpra.util.system import platform_name
from xpra.util.str_fn import std, csv, single_line, truncate
from xpra.util.objects import typedict
from xpra.util.str_fn import repr_ellipsized
from xpra.util.env import envint, envbool

LOG_HELLO: bool = envbool("XPRA_LOG_HELLO", False)
# also accept v7 peers, which may use the legacy packets and capabilities with their own older peers:
# they switch to the modern ones for us, but we still need a few workarounds for them:
# * a bigger `hello` packet (see `SocketProtocol`)
# * `mmap` and `scroll` draw packets with the pixel data overloaded (see `WindowDraw`)
BACKWARDS_COMPATIBLE = envbool("XPRA_BACKWARDS_COMPATIBLE", True)
# the minimum protocol version we are willing to accept from the peer,
# exposed as the "protocol-version" capability so that the peer can bail out early:
MIN_PROTOCOL_VERSION: tuple[int, ...] = (7, 0) if BACKWARDS_COMPATIBLE else (8, 0)
# peers that don't expose their minimum protocol version are treated as:
DEFAULT_PROTOCOL_VERSION: tuple[int, ...] = (7, 0)
# the remote codec clients and the encoder server only use the modern packet type names,
# so they cannot talk to v7 peers, even when we are `BACKWARDS_COMPATIBLE`:
REMOTE_CODEC_PROTOCOL_VERSION: tuple[int, ...] = (8, 0)
FULL_INFO: int = envint("XPRA_FULL_INFO", 1)
assert FULL_INFO >= 0
# the packet types we accept as datagrams (advertised as `datagram-packet-types`),
# these must be self-contained and tolerate loss and re-ordering:
DATAGRAM_ACCEPT_PACKET_TYPES: tuple[str, ...] = tuple(x.strip() for x in os.environ.get(
    "XPRA_DATAGRAM_ACCEPT_PACKET_TYPES",
    "audio-data,window-draw-fragment",
).split(",") if x.strip())
# QUIC is always encrypted using TLS, and xpra's own encryption is not compatible with datagrams:
QUIC_ENCRYPTION_ERROR = "encryption cannot be used with quic connections, which are already encrypted"


def is_quic(conn) -> bool:
    return getattr(conn, "socktype_wrapped", "") == "quic"


logger = None


def get_logger():
    # no locking needed,
    # creating an extra logger is not a problem
    global logger
    if logger is None:
        from xpra.log import Logger
        logger = Logger("network")
    return logger


HttpResponse: TypeAlias = tuple[int, dict, bytes]

PacketElementTypes: tuple[type, ...] = (
    tuple, list, dict, int, bool, str, bytes, memoryview,
    Compressible, Compressed, LargeStructure,
)
PacketElement: TypeAlias = (
    tuple | list | dict | int | bool | str | bytes | memoryview | Compressible | Compressed | LargeStructure
)


class Packet(Sequence):
    __slots__ = ["data"]

    def __init__(self, packet_type: str, *data: PacketElement):
        if not isinstance(packet_type, str):
            raise TypeError("packet type is not a string: %s" % (type(packet_type), ))
        for i, x in enumerate(data):
            if not isinstance(x, PacketElementTypes):
                raise TypeError("invalid packet element %r at index %i of packet %r" % (type(x), i + 1, packet_type))
        self.data = tuple([packet_type] + list(data))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i):
        return self.data[i]

    def __str__(self):
        return str(self.data[0])

    def __repr__(self):
        return repr(self.data)

    def get_type(self) -> str:
        return str(self.data[0])

    def check_len(self, min_size: int, max_size: int = 0) -> None:
        size = len(self.data)
        if size < min_size:
            raise ValueError(f"{self.get_type()!r} packet has {size} items, minimum is {min_size}")
        if max_size and size > max_size:
            raise ValueError(f"{self.get_type()!r} packet has {size} items, maximum is {max_size}")

    @staticmethod
    def _check_size(value, max_size: int, datatype: str) -> None:
        if max_size and len(value) > max_size:
            raise ValueError(f"{datatype} is too large: {len(value)} items, maximum is {max_size}")

    @staticmethod
    def _check_not_int(value, datatype: str) -> None:
        # `bytes(n)` allocates `n` zero bytes, before any size check:
        if isinstance(value, int) and not isinstance(value, bool):
            raise TypeError(f"expected a {datatype} but got an integer")

    def get_wid(self, i=1) -> int:
        v = int(self.data[i])
        if v < -1 or v >= 2**48:
            raise ValueError(f"invalid window id value {v!r}")
        return v

    def get_bool(self, i: int) -> bool:
        return bool(self.data[i])

    def get_i8(self, i: int) -> int:
        v = int(self.data[i])
        if v < -2**7 or v >= 2**7:
            raise ValueError(f"invalid i8 value {v!r}")
        return v

    def get_u8(self, i: int) -> int:
        v = int(self.data[i])
        if v < 0 or v >= 2**8:
            raise ValueError(f"invalid u8 value {v!r}")
        return v

    def get_i16(self, i: int) -> int:
        v = int(self.data[i])
        if v < -2**15 or v >= 2**15:
            raise ValueError(f"invalid i16 value {v!r}")
        return v

    def get_u16(self, i: int) -> int:
        v = int(self.data[i])
        if v < 0 or v >= 2**16:
            raise ValueError(f"invalid u16 value {v!r}")
        return v

    def get_i32(self, i: int) -> int:
        v = int(self.data[i])
        if v < -2**31 or v >= 2**31:
            raise ValueError(f"invalid i32 value {v!r}")
        return v

    def get_u32(self, i: int) -> int:
        v = int(self.data[i])
        if v < 0 or v >= 2**32:
            raise ValueError(f"invalid u32 value {v!r}")
        return v

    def get_i64(self, i: int) -> int:
        v = int(self.data[i])
        if v < -2**63 or v >= 2**63:
            raise ValueError(f"invalid i64 value {v!r}")
        return v

    def get_u64(self, i: int) -> int:
        v = int(self.data[i])
        if v < 0 or v >= 2**64:
            raise ValueError(f"invalid u64 value {v!r}")
        return v

    def get_str(self, i: int, max_size: int = 0) -> str:
        v = self.data[i]
        if isinstance(v, bytes):
            v = v.decode("utf8")
        else:
            v = str(v)
        self._check_size(v, max_size, "string")
        return v

    def get_bytes(self, i: int, max_size: int = 0) -> bytes:
        v = self.data[i]
        if not isinstance(v, bytes):
            if v == "":
                v = b""
            else:
                self._check_not_int(v, "byte string")
                v = bytes(v)
        self._check_size(v, max_size, "byte string")
        return v

    def get_buffer(self, i: int, max_size: int = 0) -> SizedBuffer:
        v = self.data[i]
        if not isinstance(v, (memoryview, bytes, bytearray)):
            # the html5 client sends strings when we expect a buffer...
            if isinstance(v, str):
                v = v.encode("utf8")
            else:
                self._check_not_int(v, "buffer")
                v = bytes(v)
        self._check_size(v, max_size, "buffer")
        return v

    def get_dict(self, i: int, max_items: int = 0) -> dict:
        v = self.data[i]
        if isinstance(v, dict):
            self._check_size(v, max_items, "dictionary")
            return v
        raise TypeError("expected dictionary at index %i but got a %s" % (i, type(v)))

    def get_strs(self, i: int, max_items: int = 0, max_item_size: int = 0) -> Sequence[str]:
        v = self.data[i]
        if isinstance(v, (list, tuple)):
            self._check_size(v, max_items, "string sequence")
            values = tuple(x.decode("utf8") if isinstance(x, bytes) else str(x) for x in v)
            if max_item_size:
                for value in values:
                    self._check_size(value, max_item_size, "string sequence item")
            return values
        raise TypeError("expected a sequence at index %i but got a %s" % (i, type(v)))

    def get_bytes_seq(self, i: int, max_items: int = 0, max_item_size: int = 0) -> Sequence[bytes]:
        v = self.data[i]
        if isinstance(v, (list, tuple)):
            self._check_size(v, max_items, "byte string sequence")
            for x in v:
                self._check_not_int(x, "byte string sequence item")
            values = tuple(bytes(x) for x in v)
            if max_item_size:
                for value in values:
                    self._check_size(value, max_item_size, "byte string sequence item")
            return values
        raise TypeError("expected a sequence at index %i but got a %s" % (i, type(v)))

    def get_ints(self, i: int, max_items: int = 0) -> Sequence[int]:
        v = self.data[i]
        if isinstance(v, (list, tuple)):
            self._check_size(v, max_items, "integer sequence")
            try:
                return tuple(int(x) for x in v)
            except OverflowError:
                # ie: `int(float("inf"))`
                raise ValueError(f"invalid value in integer sequence at index {i}") from None
        raise TypeError("expected a sequence at index %i but got a %s" % (i, type(v)))

    def get_coordinates(self, i: int) -> Sequence[int]:
        # pointer positions can be negative: left of or above the primary monitor,
        # or outside the window for window-relative positions (ie: while dragging)
        values = self.get_ints(i)
        for value in values:
            if abs(value) >= 2**16:
                raise ValueError(f"invalid coordinate {value!r}")
        return values


PacketHandlerType: TypeAlias = Callable[[Any, Packet], None]
ClientPacketHandlerType: TypeAlias = Callable[[Packet], None]
ServerPacketHandlerType: TypeAlias = PacketHandlerType

# the attribute `packet_handler` stores its `PacketHandlerSpec` under:
PACKET_HANDLER_ATTR = "_packet_handler_spec"


class PacketHandlerSpec:
    """
    How a method decorated with `packet_handler` gets registered.
    This is also where the packet validation will be declared.
    """
    __slots__ = ("packet_types", "main_thread", "early", "enabled", "manual")

    def __init__(self, packet_types: tuple[str, ...], main_thread=False, early=False,
                 enabled: Callable[[Any], bool] | None = None, manual=False):
        self.packet_types = packet_types
        self.main_thread = main_thread
        self.early = early
        self.enabled = enabled
        self.manual = manual

    def __repr__(self):
        return f"PacketHandlerSpec{self.packet_types}"


def packet_handler(*packet_types: str, main_thread=False, early=False,
                   enabled: Callable[[Any], bool] | None = None, manual=False) -> Callable:
    """
    Declares a method as the handler for the given packet types (full packet type names),
    the method is registered automatically by `register_packet_handlers` (see `xpra.net.dispatch`):
    * `main_thread`: the handler must be called from the main thread
    * `early`: (client only) register the handler before authentication
    * `enabled`: predicate called with the instance at registration time, the handler is only registered if true
    * `manual`: the handler is registered explicitly, ie: in a pre-authentication "default" table,
      or only at runtime: the decorator only documents it
    The function is returned unchanged: there is no wrapper and no extra cost per call.
    """
    if not packet_types:
        raise ValueError("packet_handler needs at least one packet type")
    spec = PacketHandlerSpec(tuple(packet_types), main_thread, early, enabled, manual)

    def decorator(fn: Callable) -> Callable:
        setattr(fn, PACKET_HANDLER_ATTR, spec)
        return fn
    return decorator


NetPacketType: TypeAlias = tuple[int, int, int, SizedBuffer]


class ConnectionClosedException(Exception):
    pass


class MmapPointerError(ValueError):
    """
    The peer has stored an invalid pointer in the shared control header.
    This should never happen with a well behaved peer,
    so the connection should be terminated.
    """


def no_packet() -> tuple[Packet, bool, bool]:
    return Packet("closed"), False, False


def get_log_packets(exclude=False) -> Sequence[str]:
    lp = os.environ.get("XPRA_LOG_PACKETS", "")
    if not lp:
        return ()
    pt = []
    for x in lp.split(","):
        if x.startswith("-") == exclude:
            pt.append(x[int(exclude):])
    return tuple(pt)


def _may_log_packet(sending, packet_type, packet) -> None:
    if LOG_PACKET_TYPE:
        get_logger().info("%s %s (thread=%s)", "sending  " if sending else "receiving", packet_type,
                          threading.current_thread())
    if LOG_PACKETS or NOLOG_PACKETS:
        if packet_type in NOLOG_PACKETS:
            return
        if packet_type in LOG_PACKETS or "*" in LOG_PACKETS:
            s = str(packet)
            if len(s) > PACKET_LOG_MAX_SIZE:
                s = repr_ellipsized(s, PACKET_LOG_MAX_SIZE)
            get_logger().info(s)


LOG_PACKETS: Sequence[str] = ()
NOLOG_PACKETS: Sequence[str] = ()
LOG_PACKET_TYPE: bool = False
PACKET_LOG_MAX_SIZE: int = 500

may_log_packet: Callable = noop


def get_peercred(sock) -> tuple[int, int, int] | None:
    log = get_logger()
    if LINUX:
        import socket
        SO_PEERCRED = 17
        try:
            creds = sock.getsockopt(socket.SOL_SOCKET, SO_PEERCRED, struct.calcsize(b'3i'))
            pid, uid, gid = struct.unpack(b'3i', creds)
            log("peer: %s", (pid, uid, gid))
            return pid, uid, gid
        except OSError as e:
            log("getsockopt", exc_info=True)
            log.error(f"Error getting peer credentials: {e}")
            return None
    elif OSX or sys.platform.lower().find("bsd") >= 0:
        try:
            from xpra.platform.bsd.peercred import get_peer_cred
        except ImportError:
            log("get_peercred(%s)", sock, exc_info=True)
            log.warn("Warning: peercred module was not found")
            return None
        try:
            uid, gid = get_peer_cred(sock.fileno())
            return 0, uid, gid
        except OSError as e:
            log("get_peercred(%s)", sock, exc_info=True)
            log.error("Error: peercred error: %s", e)
    return None


def proc_net_addr(family, addr) -> str:
    """
        Formats an address the way `/proc/net/{tcp,udp}{,6}` does:
        the IP is shown as 32-bit words in host byte order, followed by the port,
        both in uppercase hexadecimal. ie: "0100007F:1F90" for 127.0.0.1:8080
    """
    import socket
    ip = str(addr[0]).split("%", 1)[0]  # strip the scope id: "fe80::1%eth0"
    port = int(addr[1])
    packed = socket.inet_pton(family, ip)
    if sys.byteorder == "little":
        packed = b"".join(packed[i:i + 4][::-1] for i in range(0, len(packed), 4))
    return "%s:%04X" % (packed.hex().upper(), port)


def proc_net_addr_keys(addr) -> tuple[str, str]:
    """
        Returns the `/proc/net` representation of this address
        for the IPv4 and IPv6 files respectively (either one may be empty):
        an IPv4 peer can be using an IPv6 socket with a v4 mapped address
        (and it is then listed in the IPv6 file), and vice versa.
    """
    import socket
    ip = str(addr[0]).split("%", 1)[0]
    if ip.count(":") == 0:
        v4 = proc_net_addr(socket.AF_INET, addr)
        v6 = proc_net_addr(socket.AF_INET6, (f"::ffff:{ip}", addr[1]))
    else:
        v4 = ""
        v6 = proc_net_addr(socket.AF_INET6, addr)
        if ip.lower().startswith("::ffff:") and ip.count(".") == 3:
            v4 = proc_net_addr(socket.AF_INET, (ip[len("::ffff:"):], addr[1]))
    return v4, v6


def find_proc_net_uid(filename: str, local_key: str, remote_key: str) -> int:
    # ie: "  1: 0100007F:1F90 0100007F:B4CE 01 00000000:00000000 00:00000000 00000000  1000 ..."
    #      sl  local_address  rem_address   st tx_queue:rx_queue  tr:when   retrnsmt   uid
    log = get_logger()
    try:
        with open(filename, encoding="latin1") as f:
            for line in f:
                fields = line.split()
                if len(fields) < 8 or fields[1] != local_key or fields[2] != remote_key:
                    continue
                try:
                    return int(fields[7])
                except ValueError:
                    log(f"find_proc_net_uid: invalid uid field in {line!r}")
                    return -1
    except OSError as e:
        log(f"find_proc_net_uid({filename!r}, ..) {e}")
    return -1


def get_proc_net_uid(sock) -> int:
    """
        Finds the uid owning the other end of a network socket, or -1.
        `/proc/net/{tcp,udp}{,6}` list every socket in our network namespace
        with the uid of the user it belongs to.
        The peer's entry, if the peer is on this host, is the mirror image of ours:
        our remote address is its local address and vice versa.
        Matching this full 4-tuple is what proves that the peer really is local -
        no other host can own a socket in our network namespace.
        (this also covers hosts connecting to themselves without using the loopback interface)
    """
    if not LINUX:
        return -1
    log = get_logger()
    import socket
    try:
        family = sock.family
        if family not in (socket.AF_INET, socket.AF_INET6):
            return -1
        local = sock.getsockname()
        remote = sock.getpeername()
        dgram = sock.type == socket.SOCK_DGRAM
    except (OSError, AttributeError) as e:
        log(f"get_proc_net_uid({sock}) {e}")
        return -1
    # the peer's socket has our addresses the other way around:
    local4, local6 = proc_net_addr_keys(remote)
    remote4, remote6 = proc_net_addr_keys(local)
    proto = "udp" if dgram else "tcp"
    for filename, local_key, remote_key in (
        (f"/proc/net/{proto}", local4, remote4),
        (f"/proc/net/{proto}6", local6, remote6),
    ):
        if not local_key or not remote_key:
            continue
        uid = find_proc_net_uid(filename, local_key, remote_key)
        log("find_proc_net_uid(%r, %r, %r)=%i", filename, local_key, remote_key, uid)
        if uid >= 0:
            return uid
    return -1


def get_peer_uid(sock) -> int:
    """
        Returns the uid of the user owning the other end of this socket, or -1.
        A value of -1 does not prove that the peer is remote:
        the lookup is only implemented for unix domain sockets (all platforms)
        and for local network sockets on Linux.
    """
    if WIN32:
        return -1
    import socket
    try:
        family = sock.family
    except AttributeError:
        return -1
    if family == socket.AF_UNIX:
        cred = get_peercred(sock)
        return cred[1] if cred else -1
    return get_proc_net_uid(sock)


def get_peercred_info(s) -> dict[str, int]:
    try:
        cred = get_peercred(s)
    except OSError:
        cred = {}
    if not cred:
        return {}
    info: dict[str, int] = {
        "uid": cred[1],
        "gid": cred[2],
    }
    pid = cred[0]
    if pid > 0:
        info["pid"] = pid
    return info


def is_request_allowed(proto, request="info", default=True) -> bool:
    try:
        options = proto._conn.options
        req_option = options.get(request, default)
    except AttributeError:
        return default
    r = str_to_bool(req_option, default)
    if request == "exec":
        # The immediate-launch alias must not bypass existing run restrictions.
        r = r and str_to_bool(options.get("run", default), default)
    elif request == "windowshot":
        r = r and str_to_bool(options.get("screenshot", default), default)
    get_logger().debug(f"is_request_allowed%s={r}", (proto, request, default))
    return r


def parse_thread_getloadavg() -> bool:
    """
    Whether the ping handlers can call `getloadavg()`, they run on the network parse thread.
    Call this before that thread is started, ie: at startup from the main thread.
    """
    try:
        from xpra.seccomp.parse import blocks_getloadavg
    except ImportError:
        return True
    return not blocks_getloadavg()


def init() -> None:
    # no locking needed here,
    # this can be executed more than once in parallel without causing problems
    global LOG_PACKETS, NOLOG_PACKETS, LOG_PACKET_TYPE, PACKET_LOG_MAX_SIZE
    LOG_PACKETS = get_log_packets()
    NOLOG_PACKETS = get_log_packets(True)
    LOG_PACKET_TYPE = envbool("XPRA_LOG_PACKET_TYPE", False)
    PACKET_LOG_MAX_SIZE = envint("XPRA_PACKET_LOG_MAX_SIZE", 500)

    global may_log_packet
    if LOG_PACKETS or NOLOG_PACKETS or LOG_PACKET_TYPE:
        may_log_packet = _may_log_packet
    else:
        may_log_packet = noop


init()


def get_ssh_port() -> int:
    port = envint("XPRA_SSH_PORT", 0)
    if 0 < port < 2**16:
        return port
    # on Linux, we can run "ssh -T | grep port"
    # but this usually requires root permissions to access /etc/ssh/sshd_config
    if WIN32:
        return 0
    return 22


def has_websocket_handler() -> bool:
    try:
        from xpra.net.websockets.handler import WebSocketRequestHandler
        if not WebSocketRequestHandler:
            # cythonized code can bind None for missing imports
            raise ImportError("WebSocketRequestHandler")
        return True
    except ImportError:
        get_logger().debug("importing WebSocketRequestHandler", exc_info=True)
    return False


def verify_hyperv_available() -> None:
    try:
        import socket
        s = socket.socket(socket.AF_HYPERV, socket.SOCK_STREAM, socket.HV_PROTOCOL_RAW)
    except (AttributeError, OSError) as e:
        raise InitExit(ExitCode.UNSUPPORTED,
                       f"hyperv sockets are not supported on this platform: {e}") from None
    else:
        s.close()


def open_html_url(html: str = "open", mode: str = "tcp", bind: str = "127.0.0.1") -> None:
    from xpra.log import Logger
    log = Logger("http", "network")
    log("open_html_url%s", (html, mode, bind))
    from urllib.parse import urlsplit
    result = urlsplit(f"//{bind}")
    host = result.hostname
    if host in ("0.0.0.0", "*"):
        host = "localhost"
    elif host == "::":
        host = "::1"
    from xpra.net.constants import DEFAULT_PORTS
    port = result.port or DEFAULT_PORTS.get(mode)
    ssl = mode in ("wss", "ssl")
    url = "https" if ssl else "http"
    url += f"://{host}"
    if (ssl and port != 443) or (not ssl and port != 80):
        url += f":{port}"
    url += "/"
    from subprocess import Popen, SubprocessError
    from xpra.util.env import get_saved_env

    def exec_open(*cmd) -> None:
        log(f"exec_open{cmd}")
        proc = Popen(args=cmd, env=get_saved_env())
        from xpra.util.child_reaper import get_child_reaper
        get_child_reaper().add_process(proc, "open-html5-client", " ".join(cmd), True, True)

    def webbrowser_open() -> None:
        log.info(f"opening html5 client using URL {url!r}")
        from xpra.os_util import POSIX, OSX
        if POSIX and not OSX:
            saved_env = get_saved_env()
            if not (saved_env.get("DISPLAY") or saved_env.get("WAYLAND_DISPLAY")):
                log.warn(" no display, cannot open a browser window")
                return
            # run using a subprocess,
            # so we can specify the environment:
            # (which will run it against the correct X11 display!)
            try:
                exec_open(f"python{sys.version_info.major}", "-m", "webbrowser", "-t", url)
            except SubprocessError:
                log("failed exec_open:", exc_info=True)
            else:
                return
        import webbrowser
        webbrowser.open_new_tab(url)

    if html.lower() not in ("open", "connect"):
        # is a command?
        from xpra.util.io import which
        if open_cmd := which(html):
            log.info(f"opening html5 client using {html!r} at URL {url!r}")
            exec_open(open_cmd, url)
            return
        # fall through to webbrowser:
        log.warn(f"Warning: {html!r} is not a valid command")
    webbrowser_open()


def print_proxy_caps(caps: typedict) -> None:
    proxy = caps.get("proxy")
    if not proxy:
        return
    if isinstance(proxy, dict):
        pcaps = typedict(proxy)
        prefix = ""
    else:
        pcaps = caps
        prefix = "proxy."
    proxy_hostname = pcaps.strget(f"{prefix}hostname")
    proxy_platform = pcaps.strget(f"{prefix}platform")
    proxy_release = pcaps.strget(f"{prefix}platform.release")
    proxy_version = pcaps.strget(f"{prefix}version")
    proxy_version = pcaps.strget(f"{prefix}build.version", proxy_version)
    proxy_distro = pcaps.strget(f"{prefix}linux_distribution")
    msg = "via: %s proxy version %s" % (
        platform_name(proxy_platform, proxy_distro or proxy_release),
        std(proxy_version or "unknown")
    )
    if proxy_hostname:
        msg += " on '%s'" % std(proxy_hostname)
    get_logger().info(msg)


# convenience method
def disconnect_is_an_error(reason) -> bool:
    rstr = str(reason)
    return rstr.find("error") >= 0 or (rstr.find("timeout") >= 0 and rstr != ConnectionMessage.IDLE_TIMEOUT.value)


# the disconnection messages we accept from the peer:
MAX_DISCONNECT_MESSAGES = 8
MAX_DISCONNECT_MESSAGE = 256


def connection_close_info(packet: Packet) -> tuple[str, ...]:
    """
    The reason and messages of a `connection-close` packet, as single lines:
    we log them and the client shows them in a notification.
    """
    return tuple(truncate(single_line(str(x)), MAX_DISCONNECT_MESSAGE) for x in packet[1:1 + MAX_DISCONNECT_MESSAGES])


def pretty_socket(s) -> str:
    try:
        if isinstance(s, bytes):
            if len(s) >= 2 and s[0] == 0:
                return "@" + s[1:].decode("latin1")
            return s.decode("latin1")
        if isinstance(s, str):
            if s and s[0] == "\0":
                return "@" + s[1:]
            return s
        if len(s) == 2:
            if str(s[0]).find(":") >= 0:
                # IPv6
                return "[%s]:%s" % (s[0], s[1])
            return "%s:%s" % (s[0], s[1])
        if len(s) == 4:
            return csv(str(x) for x in s)
    except (ValueError, TypeError):
        pass
    return str(s)

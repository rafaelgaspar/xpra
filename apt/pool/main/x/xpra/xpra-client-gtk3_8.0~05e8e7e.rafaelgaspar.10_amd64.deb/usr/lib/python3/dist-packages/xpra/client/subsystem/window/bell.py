# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any

from xpra.net.common import Packet, packet_handler
from xpra.net.packet_type import BELL_SET, WINDOW_BELL
from xpra.util.objects import typedict
from xpra.client.base.stub import StubClientSubsystem
from xpra.log import Logger

log = Logger("window")


class WindowBell(StubClientSubsystem):
    """
    Bell forwarding. Part of the `window` subsystem, which owns the
    "bell-toggled" signal (see `WindowManagerClient`): peers subscribe with
    `get_subsystem("window").connect("bell-toggled", handler)`.
    """
    __slots__ = ()
    # these mixins are all composed into a single `WindowClient` instance,
    # which is the subsystem registered as `window`: declaring the prefix here
    # too keeps each mixin usable (and testable) on its own
    PREFIX = "window"
    SLOT_NAMES = ("bell_enabled", "client_supports_bell", "server_bell")

    def __init__(self):
        if not hasattr(self, "client"):
            StubClientSubsystem.__init__(self)
        self.client_supports_bell: bool = False
        self.server_bell: bool = False
        self.bell_enabled: bool = False

    def init(self, opts) -> None:
        self.client_supports_bell = opts.bell
        self.on_server_setting_changed("bell", self.server_bell_changed)

    def server_bell_changed(self, _setting: str, value) -> None:
        self.server_bell = bool(value)

    def set_bell_enabled(self, enabled: bool) -> None:
        # toggle bell forwarding, tell the server, and let peers (ie: the tray
        # menu checkbox) sync via the "bell-toggled" signal:
        if not (self.server_bell and self.client_supports_bell):
            return
        if enabled == self.bell_enabled:
            return
        self.bell_enabled = enabled
        self.send(BELL_SET, enabled)
        self.emit("bell-toggled")

    def get_caps(self) -> dict[str, Any]:
        return {
            "bell": self.client_supports_bell,
        }

    def parse_server_capabilities(self, c: typedict) -> bool:
        self.server_bell = c.boolget("bell")  # added in 0.5, default to True!
        self.bell_enabled = self.server_bell and self.client_supports_bell
        return True

    @packet_handler(WINDOW_BELL, main_thread=True)
    def _process_bell(self, packet: Packet) -> None:
        if not self.bell_enabled:
            return
        wid = packet.get_wid()
        device = packet.get_u16(2)
        percent = packet.get_i8(3)
        pitch = packet.get_i32(4)
        duration = packet.get_i32(5)
        bell_class = packet.get_u32(6)
        bell_id = packet.get_u32(7)
        bell_name = packet.get_str(8)
        window = self.get_window(wid)
        self.client.window_bell(window, device, percent, pitch, duration, bell_class, bell_id, bell_name)

    def window_bell(self, window, device: int, percent: int, pitch: int, duration: int, bell_class,
                    bell_id: int, bell_name: str) -> None:
        raise NotImplementedError()

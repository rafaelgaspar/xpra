# This file is part of Xpra.
# Copyright (C) 2024 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

"""
Webcam client window: receives and displays compressed webcam frames forwarded
by an xpra server when v4l2 is unavailable.  Connects back to the server as a
regular client with only the `webcam-client` capability set so that the server
creates a minimal `ClientConnection` for it.
"""

import uuid
from typing import Any

from xpra.common import SizedBuffer
from xpra.net.common import Packet, packet_handler
from xpra.net.webcam_packet import parse_webcam_frame_packet, check_webcam_frame
from xpra.os_util import gi_import
from xpra.gtk.pixbuf import load_pixbuf
from xpra.exit_codes import ExitCode, ExitValue
from xpra.client.base.gobject import GObjectClientAdapter
from xpra.client.base.client import XpraClientBase
from xpra.net.packet_type import STARTUP_COMPLETE, WEBCAM_FRAME, WEBCAM_STOP
from xpra.log import Logger
from xpra.util.str_fn import memoryview_to_bytes

log = Logger("webcam")

Gtk = gi_import("Gtk")
Gdk = gi_import("Gdk")
GdkPixbuf = gi_import("GdkPixbuf")
GLib = gi_import("GLib")


def check_encoded_size(encoding: str, data: bytes, width: int, height: int) -> None:
    """Verify the encoded dimensions without decoding the image pixels."""
    from xpra.codecs.pillow.decoder import open_only
    with open_only(data, (encoding, )) as img:
        if img.size != (width, height):
            raise ValueError(f"image is {img.size[0]}x{img.size[1]}, expected {width}x{height}")


def get_pixbuf(encoding: str, data: bytes, width: int, height: int):
    try:
        check_encoded_size(encoding, data, width, height)
    except Exception as e:
        log.error("Error loading %r webcam frame: %s", encoding, e)
        return None
    try:
        pixbuf = load_pixbuf(data, (encoding, ))
    except Exception as e:
        log("get_pixbuf(%s, %i bytes) error: %s", encoding, len(data), e)
        return get_pillow_pixbuf(encoding, data, width, height)
    if pixbuf and (pixbuf.get_width(), pixbuf.get_height()) != (width, height):
        log.error("Error: %r webcam frame is %ix%i, expected %ix%i",
                  encoding, pixbuf.get_width(), pixbuf.get_height(), width, height)
        return None
    return pixbuf


def get_pillow_pixbuf(encoding: str, data: bytes, width: int, height: int):
    try:
        from xpra.codecs.pillow.decoder import open_only
        img = open_only(data, (encoding, ))
        # only the header has been parsed so far:
        if img.size != (width, height):
            raise ValueError(f"image is {img.size[0]}x{img.size[1]}, expected {width}x{height}")
        img = img.convert("RGBA")
        w, h = img.size
        raw = GLib.Bytes.new(img.tobytes())
        return GdkPixbuf.Pixbuf.new_from_bytes(raw, GdkPixbuf.Colorspace.RGB, True, 8, w, h, w * 4)
    except Exception as e:
        log.error("Error loading %r webcam frame: %s", encoding, e)
        return None


class WebcamClient(GObjectClientAdapter, XpraClientBase):
    """
    Minimal xpra client that connects back to the server, authenticates with
    a one-time token, and displays incoming webcam frames in a GTK window.
    """
    def __init__(self, display_desc: dict[str, Any]) -> None:
        GObjectClientAdapter.__init__(self)
        XpraClientBase.__init__(self)
        self.client_type = "webcam"
        # use a unique uuid so the sharing subsystem doesn't treat us
        # as a reconnection of the regular client (which would kick it off):
        self.uuid = uuid.uuid4().hex
        self._device_no: int = int(display_desc.get("device", 0))
        self._pixbuf = None

        self._window = Gtk.Window(title=f"Webcam (device {self._device_no})")
        self._window.set_default_size(640, 480)
        self._window.connect("delete-event", self._on_close)
        self._area = Gtk.DrawingArea()
        self._area.connect("draw", self._on_draw)
        self._area.set_app_paintable(True)
        self._window.add(self._area)
        self._window.show_all()

    def init(self, opts) -> None:
        XpraClientBase.init(self, opts)

    def run(self) -> ExitValue:
        XpraClientBase.run(self)
        return GObjectClientAdapter.run(self)

    def make_protocol(self, conn):
        proto = super().make_protocol(conn)
        proto.large_packets.append(WEBCAM_FRAME)
        return proto

    def make_hello(self) -> dict[str, Any]:
        caps = super().make_hello()
        caps["webcam-client"] = {"device": self._device_no}
        return caps

    @packet_handler(STARTUP_COMPLETE, main_thread=True)
    def _process_startup_complete(self, _packet: Packet) -> None:
        log("startup-complete")

    # ------------------------------------------------------------------
    # Packet handlers — dispatched on the GLib main loop by XpraClientBase

    @packet_handler(WEBCAM_FRAME, main_thread=True)
    def _process_webcam_frame(self, packet: Packet) -> None:
        frame = parse_webcam_frame_packet(packet)
        log("webcam frame: %s %ix%i", frame.encoding, frame.width, frame.height)
        # the server forwards the compressed frames, mmap frames are re-compressed:
        if error := check_webcam_frame(frame, ("png", "jpeg", "webp")):
            log.error("Error: invalid webcam frame %i", frame.frame_no)
            log.error(" %s", error)
            return
        try:
            self._update_frame(frame.encoding, frame.data, frame.width, frame.height)
        except Exception as e:
            log.error("Error processing webcam frame: %s", e)

    @packet_handler(WEBCAM_STOP, main_thread=True)
    def _process_webcam_stop(self, _packet) -> None:
        log.info("webcam forwarding stopped by server")
        self.quit(ExitCode.OK)

    # ------------------------------------------------------------------
    # GTK window

    def _on_close(self, _window, _event) -> bool:
        self.quit(ExitCode.OK)
        return False

    def _update_frame(self, encoding: str, data: SizedBuffer, width: int, height: int) -> None:
        self._pixbuf = get_pixbuf(encoding, memoryview_to_bytes(data), width, height)
        if self._pixbuf:
            w, h = self._pixbuf.get_width(), self._pixbuf.get_height()
            self._window.resize(w, h)
            self._area.queue_draw()

    def _on_draw(self, _widget, ctx) -> None:
        if pixbuf := self._pixbuf:
            Gdk.cairo_set_source_pixbuf(ctx, pixbuf, 0, 0)
            ctx.paint()


def run_webcam_client(options, args: list[str], cmdline: list[str]) -> ExitValue:
    from xpra.client.base.features import set_client_features
    from xpra.scripts.parsing import parse_display_name
    from xpra.scripts.clients import basic_client_features, connect_to_server, do_run_client
    set_client_features(options)
    basic_client_features()
    display_desc = parse_display_name(options, args[0], cmdline)
    app = WebcamClient(display_desc)
    app.init(options)
    connect_to_server(app, display_desc, options)
    return do_run_client(app)

#!/usr/bin/env python3
# This file is part of Xpra.
# Copyright (C) 2024 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from PyQt6.QtCore import Qt, QPoint, QEvent
from PyQt6.QtGui import QImage, QPixmap, QPainter, QKeyEvent
from PyQt6.QtWidgets import QMainWindow, QLabel, QSizePolicy

from xpra.constants import MoveResize
from xpra.net.common import BACKWARDS_COMPATIBLE
from xpra.net.packet_type import POINTER_BUTTON, WINDOW_MAP, WINDOW_CLOSE, WINDOW_CONFIGURE, POINTER_MOTION
from xpra.client.qt6.keys import key_names
from xpra.client.gui.window_title import window_title_str
from xpra.client.gui.simple_pointer import split_position
from xpra.log import Logger

log = Logger()


def get_pointer_position(event) -> tuple[int, int, int, int]:
    glo_pos = event.globalPosition()
    pos = event.position()
    return round(glo_pos.x()), round(glo_pos.y()), round(pos.x()), round(pos.y())


def get_event_pos(event) -> tuple[int, int]:
    pos = event.pos()
    return round(pos.x()), round(pos.y())


def get_modifiers(event: QKeyEvent) -> list[str]:
    modifiers = []
    mods = event.modifiers()
    for value, name in {
        Qt.KeyboardModifier.ShiftModifier: "shift",
        Qt.KeyboardModifier.ControlModifier: "control",
        Qt.KeyboardModifier.AltModifier: "alt",
        Qt.KeyboardModifier.MetaModifier: "meta",
        # Qt.KeyboardModifier.KeypadModifier: "numlock",
        # Qt.KeyboardModifier.KeypadModifier: "group",
    }.items():
        if mods & value:
            modifiers.append(name)
    return modifiers


class DrawingArea(QLabel):

    def __init__(self, client, wid):
        super().__init__()
        self.client = client
        self.send = client.send
        self.wid = wid
        self.seq = 0

    def mouseMoveEvent(self, event) -> None:
        pos, props = split_position(get_pointer_position(event))
        self.send(POINTER_MOTION, -1, self.seq, self.wid, pos, props)
        self.seq += 1

    def send_mouse_button_event(self, event, pressed=True) -> None:
        button = {
            Qt.MouseButton.LeftButton: 1,
            Qt.MouseButton.MiddleButton: 2,
            Qt.MouseButton.RightButton: 3,
            Qt.MouseButton.BackButton: 8,
            Qt.MouseButton.ForwardButton: 9,
        }.get(event.button(), -1)
        if button < 0:
            return
        pos, props = split_position(get_pointer_position(event))
        self.send(POINTER_BUTTON, -1, self.seq, self.wid, button, pressed, pos, props)
        self.seq += 1

    def mousePressEvent(self, event) -> None:
        self.send_mouse_button_event(event, True)

    def mouseReleaseEvent(self, event) -> None:
        self.send_mouse_button_event(event, False)

    def mouseDoubleClickEvent(self, event) -> None:
        # Qt sends: press, release, double-click, release
        # so the double-click is just the second press:
        self.send_mouse_button_event(event, True)

    def wheelEvent(self, event) -> None:
        pos, props = split_position(get_pointer_position(event))
        # (`pixelDelta()` is only set by high resolution devices, not by mouse wheels)
        delta = event.angleDelta()
        # sent as clicks of the wheel buttons: 4 and 5 for up and down, 6 and 7 for left and right
        for button, value in ((4, delta.y()), (6, delta.x())):
            if value:
                if value < 0:
                    button += 1
                self.send(POINTER_BUTTON, -1, self.seq, self.wid, button, True, pos, props)
                self.send(POINTER_BUTTON, -1, self.seq, self.wid, button, False, pos, props)
                self.seq += 1


class ClientWindow(QMainWindow):
    def __init__(self, client, wid: int, x: int, y: int, w: int, h: int, metadata: dict):
        super().__init__()
        self.client = client
        self.send = client.send
        self.wid = wid
        self.metadata = metadata
        if metadata.get("override-redirect"):
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window | Qt.WindowType.X11BypassWindowManagerHint)
        self.setWindowTitle(window_title_str(metadata.get("title", "")))
        self.label = DrawingArea(client, wid)
        self.label.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding))
        self.label.setMinimumSize(1, 1)
        self.canvas = QPixmap(w, h)
        self.canvas.fill(Qt.GlobalColor.white)
        self.label.setPixmap(self.canvas)
        self.setCentralWidget(self.label)
        self.move(x, y)
        self.resize(w, h)
        self.label.setMouseTracking(True)
        # self.setFixedSize(w, h)
        self.installEventFilter(self)

    def get_canvas_size(self) -> tuple[int, int]:
        size = self.label.size()
        return size.width(), size.height()

    def eventFilter(self, obj, event) -> bool:
        etype = event.type()
        if etype == QEvent.Type.WindowDeactivate:
            self.client.update_focus(0)
        elif etype == QEvent.Type.WindowActivate:
            self.client.update_focus(self.wid)
        elif etype == QEvent.Type.Show:
            x = self.pos().x() + self.label.pos().x()
            y = self.pos().y() + self.label.pos().y()
            w, h = self.get_canvas_size()
            if not self.metadata.get("override-redirect"):
                self.send(WINDOW_MAP, self.wid, x, y, w, h, {}, {})
        elif etype == QEvent.Type.Hide:
            log("hidden - iconified?")
        elif etype == QEvent.Type.Move:
            x, y = get_event_pos(event)
            x += self.label.pos().x()
            y += self.label.pos().y()
            w, h = self.get_canvas_size()
            self.send(WINDOW_CONFIGURE, self.wid, {
                "geometry": (x, y, w, h),
            })
        elif etype == QEvent.Type.WindowStateChange:
            new_state = self.windowState()
            old_state = event.oldState()
            changes = {}
            for mask, name in {
                Qt.WindowState.WindowMinimized: "iconified",
                Qt.WindowState.WindowMaximized: "maximized",
                Qt.WindowState.WindowFullScreen: "fullscreen",
                Qt.WindowState.WindowActive: "focused",
            }.items():
                if new_state & mask != old_state & mask:
                    changes[name] = bool(new_state & mask)
            log(f"state changes: {changes}")
            if changes:
                self.send(WINDOW_CONFIGURE, self.wid, {
                    "state": changes,
                })
        elif etype == QEvent.Type.Resize:
            size = event.size()
            x = self.pos().x() + self.label.pos().x()
            y = self.pos().y() + self.label.pos().y()
            w = size.width()
            h = size.height()
            self.send(WINDOW_CONFIGURE, self.wid, {
                "geometry": (x, y, w, h),
            })
            old_pixmap = self.canvas
            self.canvas = QPixmap(w, h)
            self.canvas.fill(Qt.GlobalColor.white)
            painter = QPainter(self.canvas)
            painter.drawPixmap(0, 0, old_pixmap)
            painter.end()
            self.label.setPixmap(self.canvas)
        log(f"{obj}: {event} {event.type().name}")
        return False

    def has_toplevel_focus(self) -> bool:
        return self.isActiveWindow()

    def present(self) -> None:
        self.show()
        self.raise_()
        self.activateWindow()

    def initiate_moveresize(self, x_root: int, y_root: int, direction: int, button: int, source_indication: int) -> None:
        log("initiate_moveresize%s", (x_root, y_root, direction, button, source_indication))
        win = self.windowHandle()
        if not win:
            log.warn("Warning: no window handle for initiate-moveresize")
            return
        if direction in (MoveResize.MOVE, MoveResize.MOVE_KEYBOARD):
            win.startSystemMove()
            return
        edges = {
            MoveResize.SIZE_TOPLEFT: Qt.Edge.TopEdge | Qt.Edge.LeftEdge,
            MoveResize.SIZE_TOP: Qt.Edge.TopEdge,
            MoveResize.SIZE_TOPRIGHT: Qt.Edge.TopEdge | Qt.Edge.RightEdge,
            MoveResize.SIZE_RIGHT: Qt.Edge.RightEdge,
            MoveResize.SIZE_BOTTOMRIGHT: Qt.Edge.BottomEdge | Qt.Edge.RightEdge,
            MoveResize.SIZE_BOTTOM: Qt.Edge.BottomEdge,
            MoveResize.SIZE_BOTTOMLEFT: Qt.Edge.BottomEdge | Qt.Edge.LeftEdge,
            MoveResize.SIZE_LEFT: Qt.Edge.LeftEdge,
        }.get(direction)
        if edges is None:
            log("ignoring unsupported initiate-moveresize direction %s", direction)
            return
        win.startSystemResize(edges)

    def restack(self, other_window, above: int = 0) -> None:
        # Qt only exposes global raise/lower for top-level windows,
        # there is no API to stack relative to a specific sibling:
        if above:
            self.raise_()
        else:
            self.lower()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        self.send_key_event(event, True)

    def keyReleaseEvent(self, event: QKeyEvent) -> None:
        self.send_key_event(event, False)

    def closeEvent(self, event) -> None:
        log(f"close: {event}")
        self.send(WINDOW_CLOSE, self.wid)
        event.ignore()

    def send_key_event(self, event, pressed=True) -> None:
        keyval = event.key()
        name = key_names.get(keyval, event.text())
        keycode = event.nativeScanCode()
        string = event.text()
        modifiers = get_modifiers(event)
        native_modifiers = event.nativeModifiers()
        vk = event.nativeVirtualKey()
        log(f"key: {name!r}, {keyval=}, {keycode=}, {modifiers=} {native_modifiers=}, {vk=}")
        if BACKWARDS_COMPATIBLE:
            group = 0
            self.send("key-action", self.wid, name, pressed, modifiers, keyval, string, keycode, group)
        else:
            self.send("keyboard-event", self.wid, name, pressed, {
                "modifiers": modifiers,
                "keyval": keyval,
                "string": string,
                "keycode": keycode,
                "backend": "qt",
            })

    def draw(self, x, y, w, h, coding, data, stride) -> None:
        if coding in ("png", "jpeg", "webp"):
            from xpra.codecs.pillow.decoder import open_only
            img = open_only(data, (coding, ))
            if img.mode == "RGBA":
                coding = "rgb32"
                stride = w * 4
            else:
                assert img.mode == "RGB"
                coding = "rgb24"
                stride = w * 3
            data = img.tobytes("raw", img.mode)
        assert coding in ("rgb24", "rgb32")
        fmt = QImage.Format.Format_RGB888 if coding == "rgb24" else QImage.Format.Format_ARGB32_Premultiplied
        image = QImage(data, w, h, stride, fmt)
        canvas = self.label.pixmap()
        painter = QPainter(canvas)
        point = QPoint(x, y)
        painter.drawImage(point, image)
        painter.end()
        self.label.setPixmap(canvas)

# This file is part of Xpra.
# Copyright (C) 2026 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any

from xpra.codecs.image import ImageWrapper
from xpra.net.common import BACKWARDS_COMPATIBLE
from xpra.os_util import gi_import
from xpra.wayland.server.models.frame import FrameCallbackModel

GObject = gi_import("GObject")


class SubsurfaceWindow(FrameCallbackModel):
    """Minimal window-like facade so a WindowSource can be constructed for a
    wayland subsurface. The subsurface is not a window in its own right: it
    has no title, no parent/transient relationship the client cares about,
    and content-type is intentionally left unset so `content_guesser` decides
    from the pixel stream (a video subsurface should not inherit its parent
    GTK frame's "text" content-type)."""

    __gproperties__ = {
        # the child's own `wl_surface` and the display to flush: a subsurface has its own
        # frame callbacks, which only `frame_done` on this surface can answer
        "surface": (GObject.TYPE_PYOBJECT, "the wayland Subsurface object", "",
                    GObject.ParamFlags.READABLE),
        "display": (GObject.TYPE_PYOBJECT, "the wayland Display object", "",
                    GObject.ParamFlags.READABLE),
        "depth": (GObject.TYPE_INT, "bit depth", "", -1, 64, -1, GObject.ParamFlags.READABLE),
        "has-alpha": (GObject.TYPE_BOOLEAN, "alpha channel", "", False, GObject.ParamFlags.READABLE),
        "frame-has-alpha": (GObject.TYPE_BOOLEAN, "alpha channel of the current buffer", "",
                            True, GObject.ParamFlags.READABLE),
    }

    _property_names = ["depth", "has-alpha"]
    _dynamic_property_names: list[str] = []
    # a subsurface has its own buffer, so its transparency is its own:
    # the canonical use for one is an opaque video plane inside a parent
    # which is only translucent for its shadow and rounded corners
    _internal_property_names: list[str] = ["frame-has-alpha"]
    _MODELTYPE = "WaylandSubsurface"

    def __init__(self, width: int, height: int, has_alpha: bool = True, depth: int = 32,
                 surface=None, display=None):
        super().__init__()
        self._width = width
        self._height = height
        self._image: ImageWrapper | None = None
        self._internal_set_property("surface", surface)
        self._internal_set_property("display", display)
        self._internal_set_property("depth", depth)
        self._internal_set_property("has-alpha", has_alpha)
        self._setup_done = True
        self._managed = True

    def unmanage(self, exiting=False) -> None:
        # there is no `unmanaged` signal to emit: the subsystem drops the facade directly
        self._managed = False
        self.cancel_damage_frame_timer()
        self.cancel_empty_ack_timer()
        self._internal_set_property("surface", None)
        super().unmanage(exiting)

    def set_image(self, image: ImageWrapper) -> None:
        self._image = image
        # publish the alpha the buffer really has, so that an opaque subsurface
        # can be encoded as video even if its parent window is translucent:
        self._updateprop("frame-has-alpha", "A" in image.get_pixel_format())

    def update_dimensions(self, width: int, height: int) -> None:
        self._width = width
        self._height = height

    def get_dimensions(self) -> tuple[int, int]:
        return self._width, self._height

    def get_geometry(self) -> tuple[int, int, int, int]:
        return 0, 0, self._width, self._height

    def get_image(self, x: int, y: int, width: int, height: int) -> ImageWrapper | None:
        image = self._image
        if image is None:
            return None
        if x == 0 and y == 0 and width == self._width and height == self._height:
            return image
        # Viewport-scaled subsurfaces deliberately keep a native-size image
        # while exposing logical dimensions. Partial logical damage needs
        # proportional source mapping; for now callers send full subsurface
        # damage, so return the native image as the conservative fallback.
        if image.get_width() != self._width or image.get_height() != self._height:
            return image
        iw = min(width, self._width - x)
        ih = min(height, self._height - y)
        return image.get_sub_image(x, y, iw, ih)

    def get(self, name: str, default_value: Any = None) -> Any:
        if BACKWARDS_COMPATIBLE and name == "content-type":
            return ""
        if name == "content-types":
            return ()
        if name == "opaque-region":
            return ()
        return super().get(name, default_value)

    def is_OR(self) -> bool:
        return False

    def is_tray(self) -> bool:
        return False

    def is_shadow(self) -> bool:
        return False

# This file is part of Xpra.
# Copyright (C) 2025 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any

from xpra.util.gobject import one_arg_signal
from xpra.codecs.image import ImageWrapper
from xpra.wayland.server.models.frame import FrameCallbackModel
from xpra.os_util import gi_import
from xpra.log import Logger

log = Logger("wayland", "window")

GObject = gi_import("GObject")


class Window(FrameCallbackModel):
    __gproperties__ = {
        "display": (
            GObject.TYPE_PYOBJECT,
            "The wayland Display object", "",
            GObject.ParamFlags.READABLE,
        ),
        "surface": (
            GObject.TYPE_PYOBJECT,
            "The wayland Surface object", "",
            GObject.ParamFlags.READABLE,
        ),
        "geometry": (
            GObject.TYPE_PYOBJECT,
            "current coordinates (x, y, w, h) for the window", "",
            GObject.ParamFlags.READABLE,
        ),
        "decorations": (
            GObject.TYPE_BOOLEAN,
            "Should the window be decorated?", "",
            False,
            GObject.ParamFlags.READABLE,
        ),
        "depth": (
            GObject.TYPE_INT,
            "window bit depth", "",
            -1, 64, -1,
            GObject.ParamFlags.READABLE,
        ),
        "colourspace": (
            GObject.TYPE_PYOBJECT,
            "the colourspace the surface is tagged with (wp_color_management_surface_v1)", "",
            GObject.ParamFlags.READABLE,
        ),
        "content-types": (
            GObject.TYPE_PYOBJECT,
            "Content hints from wp_content_type_v1", "",
            GObject.ParamFlags.READABLE,
        ),
        "has-alpha": (
            GObject.TYPE_BOOLEAN,
            "Does the window use transparency", "",
            False,
            GObject.ParamFlags.READABLE,
        ),
        "frame-has-alpha": (
            GObject.TYPE_BOOLEAN,
            "Does the buffer the client has committed have an alpha channel", "",
            True,
            GObject.ParamFlags.READABLE,
        ),
        "opaque-region": (
            GObject.TYPE_PYOBJECT,
            "Compositor can assume that there is no transparency for this region", "",
            GObject.ParamFlags.READABLE,
        ),
        "client-machine": (
            GObject.TYPE_PYOBJECT,
            "Host where client process is running", "",
            GObject.ParamFlags.READABLE,
        ),
        "pid": (
            GObject.TYPE_INT,
            "PID of owning process", "",
            -1, 2147483647, -1,
            GObject.ParamFlags.READABLE,
        ),
        "title": (
            GObject.TYPE_PYOBJECT,
            "Window title", "",
            GObject.ParamFlags.READABLE,
        ),
        "app-id": (
            GObject.TYPE_PYOBJECT,
            "Window app id", "",
            GObject.ParamFlags.READABLE,
        ),
        "parent": (
            GObject.TYPE_PYOBJECT,
            "wid of the parent toplevel (xdg_toplevel.set_parent), 0 if none", "",
            GObject.ParamFlags.READABLE,
        ),
        "transient-for": (
            GObject.TYPE_PYOBJECT,
            "wid of the transient parent window, 0 if none", "",
            GObject.ParamFlags.READABLE,
        ),
        "relative-position": (
            GObject.TYPE_PYOBJECT,
            "current coordinates relative to the parent window", "",
            GObject.ParamFlags.READABLE,
        ),
        "override-redirect": (
            GObject.TYPE_BOOLEAN,
            "Is this an unmanaged override-redirect style window", "",
            False,
            GObject.ParamFlags.READABLE,
        ),
        "window-type": (
            GObject.TYPE_PYOBJECT,
            "Window type hints", "",
            GObject.ParamFlags.READABLE,
        ),
        "role": (
            GObject.TYPE_PYOBJECT,
            "The window's role (ICCCM session management)", "",
            GObject.ParamFlags.READABLE,
        ),
        "command": (
            GObject.TYPE_PYOBJECT,
            "Command used to start or restart the client", "",
            GObject.ParamFlags.READABLE,
        ),
        "iconic": (
            GObject.TYPE_BOOLEAN,
            "ICCCM 'iconic' state -- any sort of 'not on desktop'.", "",
            True,
            GObject.ParamFlags.READWRITE,
        ),
        "maximized": (
            GObject.TYPE_BOOLEAN,
            "Is the window maximized", "",
            False,
            GObject.ParamFlags.READWRITE,
        ),
        "fullscreen": (
            GObject.TYPE_BOOLEAN,
            "Is the window maximized", "",
            False,
            GObject.ParamFlags.READWRITE,
        ),
        "image": (
            GObject.TYPE_PYOBJECT,
            "ImageWrapper of the surface pixels", "",
            GObject.ParamFlags.READABLE,
        ),
    }

    __gsignals__ = {
        # signals we emit:
        "unmanaged": one_arg_signal,
        "initiate-moveresize": one_arg_signal,
        "grab": one_arg_signal,
        "ungrab": one_arg_signal,
        "bell": one_arg_signal,
        "client-contents-changed": one_arg_signal,
        "motion": one_arg_signal,
    }

    # things that we expose:
    _property_names = [
        "depth", "has-alpha", "opaque-region", "decorations", "colourspace", "content-types",
        "client-machine", "pid",
        "title", "role", "app-id",
        "command",
        "parent", "transient-for", "relative-position",
        "override-redirect", "window-type",
        "iconic", "maximized", "fullscreen",
    ]
    # exposed and changing (should be watched for notify signals):
    _dynamic_property_names = [
        "title", "app-id", "command", "colourspace", "opaque-region",
        "content-types",
        "parent", "transient-for", "relative-position",
        "iconic", "maximized", "fullscreen",
    ]
    # should not be exported to the clients:
    # `has-alpha` is the capability the client creates its visual and backing from,
    # so it must not follow the buffers: a surface can commit an opaque one and still
    # gain a translucent subsurface later, which the client paints into that backing
    _internal_property_names = ["frame-has-alpha"]
    _MODELTYPE = "Wayland"

    def __init__(self, props: dict[str, Any]):
        super().__init__()
        for key, prop in props.items():
            self._internal_set_property(key, prop)

    def __repr__(self) -> str:  # pylint: disable=arguments-differ
        surface = self._gproperties.get("surface", None)
        wid = getattr(surface, "wid", 0)
        return "WaylandWindow(%#x)" % wid

    def setup(self) -> None:
        self._managed = True
        self._setup_done = True

    def unmanage(self, exiting=False) -> None:
        if self._managed:
            self.emit("unmanaged", exiting)

    def do_unmanaged(self, _wm_exiting: bool) -> None:
        if not self._managed:
            return
        self._managed = False
        self.cancel_damage_frame_timer()
        self.cancel_empty_ack_timer()
        self.managed_disconnect()

    def get_image(self, x: int, y: int, width: int, height: int) -> ImageWrapper:
        image = self._gproperties["image"]
        w, h = self._gproperties["geometry"][2:4]
        if x >= w or y >= h:
            raise ValueError("invalid position %ix%i for window of size %ix%i" % (x, y, w, h))
        if x == 0 and y == 0 and width == w and height == h:
            return image
        iw = min(width, w - x)
        ih = min(height, h - y)
        return image.get_sub_image(x, y, iw, ih)

    def get_dimensions(self) -> tuple[int, int]:
        # just extracts the size from the geometry:
        return self._gproperties["geometry"][2:4]

    def get_geometry(self) -> tuple[int, int, int, int]:
        return self._gproperties["geometry"]

    ################################
    # Actions
    ################################

    def hide(self):
        """ this is not exposed to the windows """

    def show(self):
        """ this is not exposed to the windows """

    def raise_window(self) -> None:
        """ no-op: windows are unaware of their stacking status """

    def set_active(self) -> None:
        """ this is not available under Wayland? """

    @staticmethod
    def request_close() -> None:
        log.warn("Warning: close-request not implemented yet for Wayland")

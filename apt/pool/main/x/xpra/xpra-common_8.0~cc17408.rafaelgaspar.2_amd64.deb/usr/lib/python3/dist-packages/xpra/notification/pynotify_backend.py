#!/usr/bin/env python3
# This file is part of Xpra.
# Copyright (C) 2011 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import sys
from collections.abc import Sequence
from typing import Any
import notify2

from xpra.common import noop
from xpra.notification.base import NotifierBase, NID
from xpra.notification.common import IconData


def close_notify(nid: NID) -> None:
    if n := PyNotifyNotifier.CACHE.pop(int(nid), None):
        n.close()


class PyNotifyNotifier(NotifierBase):
    CACHE: dict[int, Any] = {}

    def __init__(self, closed_cb=noop, action_cb=noop):
        super().__init__(closed_cb, action_cb)
        if not notify2.is_initted():
            notify2.init("Xpra", "glib")

    def show_notify(self, dbus_id: str, tray, nid: NID,
                    app_name: str, replaces_nid: NID, app_icon: str,
                    summary: str, body: str, actions: Sequence[str], hints: dict, expire_timeout: int,
                    icon: IconData | None) -> None:
        if not self.dbus_check(dbus_id):
            return
        icon_string = self.get_icon_string(nid, app_icon, icon, hints)
        n = notify2.Notification(summary, body, icon_string)
        PyNotifyNotifier.CACHE[int(nid)] = n
        n.set_urgency(notify2.URGENCY_LOW)
        n.set_timeout(expire_timeout)
        n.show()
        if icon_string:
            def notification_closed(*_args):
                self.clean_notification(int(nid))

            n.connect("closed", notification_closed)

    def clean_notification(self, nid: int) -> None:
        PyNotifyNotifier.CACHE.pop(nid, None)
        super().clean_notification(nid)


def main(args):
    from xpra.os_util import gi_import
    from xpra.gtk.util import gtk_main
    Gtk = gi_import("Gtk")
    GLib = gi_import("GLib")
    summary = "Summary"
    body = "Body..."
    if len(args) > 1:
        summary = args[1]
    if len(args) > 2:
        body = args[2]

    def show() -> bool:
        nid = 1
        n = PyNotifyNotifier()
        n.show_notify("", None, nid, "Test", 0, "", summary, body,
                      ["0", "Hello", "1", "Bye"], {}, 0, None)
        GLib.timeout_add(5000, close_notify, nid)
        return False

    GLib.idle_add(show)
    GLib.timeout_add(20000, Gtk.main_quit)
    gtk_main()


if __name__ == "__main__":
    main(sys.argv)

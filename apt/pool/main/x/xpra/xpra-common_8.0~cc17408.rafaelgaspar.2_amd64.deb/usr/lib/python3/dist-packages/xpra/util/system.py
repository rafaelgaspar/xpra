#!/usr/bin/env python3
# This file is part of Xpra.
# Copyright (C) 2013 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import re
import sys
import signal
from typing import Any, TYPE_CHECKING, NoReturn
from collections.abc import Mapping, Sequence

from xpra.os_util import POSIX, LINUX, OSX, WIN32, force_quit

if TYPE_CHECKING:
    from subprocess import Popen
from xpra.util.env import get_saved_env, envbool
from xpra.util.io import load_binary_file, get_util_logger, info

SIGNAMES: dict[int, str] = {}
for signame in (sig for sig in dir(signal) if sig.startswith("SIG") and not sig.startswith("SIG_")):
    try:
        SIGNAMES[int(getattr(signal, signame))] = signame
    except ValueError:
        pass


def deadly_signal(signum, _frame=None) -> NoReturn:
    signame = SIGNAMES.get(signum, signum)
    info(f"got deadly signal {signame}, exiting\n")
    # This works fine in tests, but for some reason if I use it here, then I
    # get bizarre behavior where the signal handler runs, and then I get a
    # KeyboardException (?!?), and the KeyboardException is handled normally
    # and exits the program (causing the cleanup handlers to be run again):
    # signal.signal(signum, signal.SIG_DFL)
    # kill(os.getpid(), signum)
    force_quit(128 + int(signum))


def set_proc_title(title: str) -> None:
    try:
        import setproctitle  # pylint: disable=import-outside-toplevel
        setproctitle.setproctitle(title)  # @UndefinedVariable pylint: disable=c-extension-no-member
    except ImportError as e:
        get_util_logger().debug("setproctitle is not installed: %s", e)


def stop_proc(proc: "Popen", what="subprocess") -> None:
    if not proc:
        return
    r = proc.poll()
    log = get_util_logger()
    log("stop_proc(%s, %s) exit code=%s", proc, what, r)
    if r is not None:
        # already ended
        return
    try:
        proc.terminate()
    except OSError:
        log("failed to stop %s %s", what, proc, exc_info=True)


def is_child_alive(proc: "Popen | None") -> bool:
    return proc is not None and proc.poll() is None


def is_own_child(pid: int) -> bool:
    """
    A child that we have not reaped yet cannot have had its pid recycled,
    so this tells us that `pid` still refers to the process we started.
    Only implemented using `/proc`, returns False on other platforms.
    """
    try:
        with open(f"/proc/{pid}/stat", "rb") as f:
            stat = f.read()
    except OSError:
        return False
    # the command name may contain spaces or parentheses, the ppid is the 2nd field after it:
    fields = stat[stat.rfind(b")") + 2:].split()
    try:
        return int(fields[1]) == os.getpid()
    except (IndexError, ValueError):
        return False


def no_idle(fn, *args, **kwargs) -> None:
    fn(*args, **kwargs)


def register_SIGUSR_signals(idle_add=no_idle) -> None:
    if os.name != "posix":
        return
    from xpra.util.pysystem import dump_gc_frames
    from xpra.util.pysystem import dump_all_frames

    def sigusr1(*_args) -> None:
        log = get_util_logger().info
        log("SIGUSR1")
        idle_add(dump_all_frames, log)

    def sigusr2(*_args) -> None:
        log = get_util_logger().info
        log("SIGUSR2")
        idle_add(dump_gc_frames, log)

    signal.signal(signal.SIGUSR1, sigusr1)
    signal.signal(signal.SIGUSR2, sigusr2)


def is_VirtualBox() -> bool:
    if os.name != "nt":
        # detection not supported yet
        return False
    # try to detect VirtualBox:
    # based on the code found here:
    # http://spth.virii.lu/eof2/articles/WarGame/vboxdetect.html
    try:
        from ctypes import cdll
        if cdll.LoadLibrary("VBoxHook.dll"):
            # "VirtualBox is present (VBoxHook.dll)
            return True
    except (ImportError, OSError):
        pass
    try:
        with open("\\\\.\\VBoxMiniRdrDN"):
            # "VirtualBox is present (VBoxMiniRdrDN)"
            return True
    except Exception as e:
        import errno
        if e.args[0] == errno.EACCES:
            # "VirtualBox is present (VBoxMiniRdrDN)"
            return True
    return False


def get_platform_icon_name(platform: str) -> str:
    for p, i in {
        "win32": "win32",
        "darwin": "macos",
        "linux": "linux",
        "freebsd": "freebsd",
        "openbsd": "openbsd",
    }.items():
        if platform.startswith(p):
            return i
    return ""


def is_Wayland(env: Mapping | None = None) -> bool:
    return _is_Wayland(get_saved_env() if env is None else env)


def _is_Wayland(env: Mapping) -> bool:
    backend = env.get("GDK_BACKEND", "")
    if backend == "wayland":
        return True
    return backend != "x11" and (
        bool(env.get("WAYLAND_DISPLAY")) or env.get("XDG_SESSION_TYPE") == "wayland"
    )


def is_distribution_variant(variant="Debian") -> bool:
    if not POSIX:
        return False
    try:
        v = load_os_release_file()
        return any(line.find(variant) >= 0 for line in v.splitlines() if line.startswith("NAME="))
    except Exception:
        pass
    try:
        d = get_linux_distribution()[0]
        if d == variant:
            return True
        if variant == "RedHat" and d.startswith(variant):
            return True
    except Exception:
        pass
    return False


def get_distribution_version_id() -> str:
    if not POSIX:
        return ""
    try:
        v = load_os_release_file()
        for line in v.splitlines():
            if line.startswith("VERSION_ID="):
                return line.split("=", 1)[1].strip('"')
    except Exception:
        pass
    return ""


os_release_file_data: str | None = None


def load_os_release_file() -> str:
    global os_release_file_data
    if os_release_file_data is None:
        try:
            os_release_file_data = load_binary_file("/etc/os-release").decode() or ""
        except (OSError, UnicodeDecodeError):  # pragma: no cover
            os_release_file_data = ""
    return os_release_file_data


def is_Ubuntu() -> bool:
    return is_distribution_variant("Ubuntu")


def is_LinuxMint() -> bool:
    return is_distribution_variant("Linux Mint")


def is_Debian() -> bool:
    return is_distribution_variant("Debian")


def is_DEB() -> bool:
    return is_Debian() or is_Ubuntu() or is_LinuxMint()


def is_DEB_Xdummy_safe() -> bool:
    """
    Older Debian and Ubuntu releases could interfere with other X11 sessions when using Xdummy,
    see ticket #2834. This is assumed to be fixed from Debian trixie and Ubuntu resolute onwards.
    Derivatives (ie: Linux Mint) are not detected and keep using Xvfb.
    """
    version_id = get_distribution_version_id()
    if is_Ubuntu():
        min_version = (26, 4)
    elif is_Debian():
        if not version_id:
            # testing and sid do not set `VERSION_ID`:
            return True
        min_version = (13, )
    else:
        return False
    try:
        return tuple(int(x) for x in version_id.split(".")) >= min_version
    except ValueError:
        return False


def is_RPM() -> bool:
    return any(is_distribution_variant(x) for x in (
        "Fedora", "RedHat", "AlmaLinux", "Rocky Linux", "CentOS", "openSUSE", "Oracle Linux",
    ))


def is_Arch() -> bool:
    if not POSIX:
        return False
    try:
        v = load_os_release_file()
        if not v:
            return False
        os_release = {}
        for line in v.splitlines():
            if not line or "=" not in line:
                continue
            k, vstr = line.split("=", 1)
            os_release[k] = vstr.strip().strip('"')
        distro_id = os_release.get("ID", "").lower()
        if distro_id in ("arch", "manjaro"):
            return True
        id_like = os_release.get("ID_LIKE", "").lower().split()
        return any(x in id_like for x in ("arch", "archlinux"))
    except Exception:
        pass
    return is_distribution_variant("Arch") or is_distribution_variant("Manjaro")


_linux_distribution = ("", "", "")


def get_linux_distribution() -> tuple[str, str, str]:
    global _linux_distribution
    if LINUX and _linux_distribution == ("", "", ""):
        # linux_distribution is deprecated in Python 3.5,
        # and it causes warnings,
        # so we use our own code first:
        cmd = ["lsb_release", "-a"]
        try:
            from subprocess import Popen, PIPE
            p = Popen(cmd, stdout=PIPE, stderr=PIPE, universal_newlines=True)
            out = p.communicate()[0]
            assert p.returncode == 0 and out
        except Exception:
            try:
                import platform
                _linux_distribution = platform.linux_distribution()  # pylint: disable=deprecated-method, no-member
            except Exception:
                _linux_distribution = ("unknown", "unknown", "unknown")
        else:
            d = {}
            for line in out.splitlines():
                parts = line.rstrip("\n\r").split(":", 1)
                if len(parts) == 2:
                    d[parts[0].lower().replace(" ", "_")] = parts[1].strip()
            _linux_distribution = (
                d.get("distributor_id", "unknown"),
                d.get("release", "unknown"),
                d.get("codename", "unknown"),
            )
    return _linux_distribution


def is_unity() -> bool:
    d = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
    return d.find("unity") >= 0 or d.find("ubuntu") >= 0


def is_gnome() -> bool:
    if os.environ.get("XDG_SESSION_DESKTOP", "").split("-", 1)[0] in ("i3", "ubuntu",):
        # "i3-gnome" is not really gnome... ie: the systray does work!
        return False
    return os.environ.get("XDG_CURRENT_DESKTOP", "").lower().find("gnome") >= 0


def is_kde() -> bool:
    return os.environ.get("XDG_CURRENT_DESKTOP", "").lower().find("kde") >= 0


def get_loaded_kernel_modules(*modlist):
    loaded = []
    if LINUX and os.path.exists("/sys/module"):
        for mod in modlist:
            if os.path.exists(f"/sys/module/{mod}"):  # pragma: no cover
                loaded.append(mod)
    return loaded


def is_WSL() -> bool:
    if not POSIX:
        return False
    for f in ("/proc/sys/kernel/osrelease", "/proc/version"):
        if r := load_binary_file(f):
            return r.find(b"Microsoft") >= 0
    return False


def get_generic_os_name() -> str:
    for k, v in {
        "linux": "Linux",
        "darwin": "MacOS",
        "win": "MS Windows",
        "freebsd": "FreeBSD",
        "openbsd": "OpenBSD",
    }.items():
        if sys.platform.startswith(k):
            return v
    return sys.platform  # pragma: no cover


def is_X11() -> bool:
    if envbool("XPRA_NOX11", False):
        get_util_logger().debug("is_X11() XPRA_NOX11 is set")
        return False
    try:
        from xpra import x11
        if not x11:
            # cythonized code can bind None for missing imports
            raise ImportError("xpra.x11")
    except ImportError:
        get_util_logger().debug("failed to load x11 bindings", backtrace=True)
        # x11 is not installed, so assume it isn't used
        return False
    gdk_backend = os.environ.get("GDK_BACKEND", "")
    if gdk_backend in ("x11", "wayland"):
        get_util_logger().debug(f"is_X11() GDK_BACKEND={gdk_backend}")
        return gdk_backend == "x11"
    if envbool("XPRA_GTK", False):
        try:
            from xpra.x11.gtk.bindings import is_X11_Display
            return is_X11_Display()
        except ImportError:
            get_util_logger().debug("failed to load gtk x11 bindings", exc_info=True)
    if OSX or WIN32:
        return False
    try:
        from xpra.x11.bindings.xwayland import isX11, isxwayland
    except ImportError as e:
        get_util_logger().debug("is_X11() xwayland bindings missing: %s", e)
        return True
    # `isxwayland()` also returns `False` when there is no X11 display to query at all,
    # so we must first make sure that we can actually open one:
    if not isX11():
        get_util_logger().debug("is_X11() no X11 display can be opened")
        return False
    return not isxwayland()


def nn(x) -> str:
    if x is None:
        return ""
    return str(x)


def get_env_info() -> dict[str, str]:
    filtered_env = os.environ.copy()
    if filtered_env.get('XPRA_PASSWORD'):
        filtered_env['XPRA_PASSWORD'] = "*****"
    if filtered_env.get('XPRA_ENCRYPTION_KEY'):
        filtered_env['XPRA_ENCRYPTION_KEY'] = "*****"
    return filtered_env


def getloadavg() -> tuple[int, int, int]:
    if POSIX:
        return tuple(int(v) for v in os.getloadavg())
    if WIN32:
        try:
            import psutil
            return tuple(int(v) for v in psutil.getloadavg())
        except ImportError:
            pass
    return 0, 0, 0


def get_sysconfig_info() -> dict[str, Any]:
    import sysconfig
    sysinfo: dict[str, Any] = {}
    log = get_util_logger()
    for attr in (
            "platform",
            "python-version",
            "config-vars",
            "paths",
    ):
        fn = "get_" + attr.replace("-", "_")
        if getter := getattr(sysconfig, fn, None):
            try:
                # noinspection calling-non-callable
                sysinfo[attr] = getter()  # pylint: disable=not-callable
            except ModuleNotFoundError:
                log("sysconfig.%s", fn, exc_info=True)
                if attr == "config-vars" and WIN32:
                    continue
                log.warn("Warning: failed to collect %s sysconfig information", attr)
            except Exception:
                log.error("Error calling sysconfig.%s", fn, exc_info=True)
    return sysinfo


def is_free_threaded() -> bool:
    import sysconfig
    if sysconfig.get_config_var("Py_GIL_DISABLED") == 1:
        return True
    # For runtime check in Python 3.13+
    if hasattr(sys, "_is_gil_enabled"):
        return not sys._is_gil_enabled()
    return False


def platform_release(release: str) -> str:
    log = get_util_logger()
    if WIN32:
        from xpra.platform.win32 import os_name
        return os_name or release.replace("Server", "-Server")  # ie: "2025Server" -> "2025-Server"
    if OSX:
        systemversion_plist = "/System/Library/CoreServices/SystemVersion.plist"
        try:
            import plistlib
            with open(systemversion_plist, "rb") as f:
                pl = plistlib.load(f)
            return pl['ProductUserVisibleVersion']
        except Exception as e:
            log.debug("platform_release(%s)", release, exc_info=True)
            log.warn("Warning: failed to get release information")
            log.warn(f" from {systemversion_plist}:")
            log.warn(f" {e}")
    return release


def platform_name(sys_platform=sys.platform, release="") -> str:
    if not sys_platform:
        return "unknown"
    platforms = {
        "win32": "Microsoft Windows",
        "cygwin": "Windows/Cygwin",
        "linux.*": "Linux",
        "darwin": "Mac OS X",
        "freebsd.*": "FreeBSD",
        "openbsd.*": "OpenBSD",
        "os2": "OS/2",
    }

    def rel(v) -> str:
        if isinstance(release, (tuple, list)):
            values = [v] + list(release)
        else:
            values = []
            if not release.startswith(v):
                values.append(v)
            values.append(release)
        return " ".join(str(x) for x in values if x and x not in ("", "unknown", "n/a"))

    for k, v in platforms.items():
        regexp = re.compile(k)
        if regexp.match(sys_platform):
            return rel(v)
    return rel(sys_platform)


def get_processor_name() -> str:
    import platform
    sysname = platform.system()
    if sysname == "Windows":
        return platform.processor()
    if sysname == "Darwin":
        from xpra.util.env import OSEnvContext
        from subprocess import check_output
        with OSEnvContext():
            os.environ['PATH'] = os.environ['PATH'] + os.pathsep + '/usr/sbin'
            command = ["sysctl", "-n", "machdep.cpu.brand_string"]
            return check_output(command, text=True).strip()
    if sysname == "Linux":
        with open("/proc/cpuinfo", encoding="latin1") as f:
            data = f.read()
        import re
        for line in data.split("\n"):
            if "model name" in line:
                return re.sub(".*model name.*:", "", line, count=1).strip()
    return platform.processor()


def can_use_fakescreenfps() -> bool:
    from xpra.util.system import is_distribution_variant, get_distribution_version_id
    if is_distribution_variant("Fedora"):
        return True
    if is_distribution_variant("Debian"):
        return True
    if any(is_distribution_variant(x) for x in (
        "RedHat", "AlmaLinux", "RockyLinux", "OracleLinux",
    )):
        return get_distribution_version_id() == "10"
    # not sure:
    return False


def get_run_info(subcommand="server") -> Sequence[str]:
    from xpra.os_util import POSIX
    from xpra.util.version import full_version_str, get_platform_info
    from xpra.util.system import platform_name
    from xpra.log import Logger
    log = Logger("util")
    run_info = [f"xpra {subcommand} version {full_version_str()}"]
    try:
        pinfo = get_platform_info()
        osinfo = " on " + platform_name(sys.platform,
                                        pinfo.get("linux_distribution") or pinfo.get("sysrelease", ""))
    except OSError:
        pinfo = {}
        log("platform name error:", exc_info=True)
        osinfo = ""
    if POSIX:
        uid = os.getuid()
        gid = os.getgid()
        try:
            import pwd
            import grp

            user = pwd.getpwuid(uid)[0]
            group = grp.getgrgid(gid)[0]
            run_info.append(f" {uid=} ({user}), {gid=} ({group})")
        except (TypeError, KeyError):
            log("failed to get user and group information", exc_info=True)
            run_info.append(f" {uid=}, {gid=}")
    run_info.append(" running with pid %s%s" % (os.getpid(), osinfo))
    from xpra.net.common import FULL_INFO
    vinfo = ".".join(str(x) for x in sys.version_info[:FULL_INFO + 1])
    if arch := pinfo.get("machine", ""):
        vinfo += f" {arch}"
    if is_free_threaded():
        vinfo += " free-threaded"
    run_info.append(f" {sys.implementation.name} {vinfo}")
    if mem_bytes := get_mem_size():
        LOW_MEM_LIMIT = 1024 * 1024 * 1024
        if mem_bytes and mem_bytes <= LOW_MEM_LIMIT:
            log.warn("Warning: only %iMB total system memory available", mem_bytes // (1024 ** 2))
            log.warn(" this may not be sufficient")
        else:
            run_info.append(" with %.1fGB of system memory" % (mem_bytes / (1024.0 ** 3)))
    return run_info


def get_mem_size() -> int:
    try:
        mem_bytes = 0
        if hasattr(os, "sysconf"):
            mem_bytes = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
        if not mem_bytes and WIN32:
            from xpra.platform.win32.info import get_total_physical_memory
            mem_bytes = get_total_physical_memory()
        return mem_bytes
    except OSError:
        from xpra.log import Logger
        log = Logger("util")
        log("init_memcheck", exc_info=True)
    return 0

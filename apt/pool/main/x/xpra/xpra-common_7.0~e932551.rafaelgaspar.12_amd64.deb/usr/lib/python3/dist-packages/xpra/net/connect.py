# This file is part of Xpra.
# Copyright (C) 2025 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import socket
import time
from time import monotonic
from typing import Any

from xpra.common import noop, noerr
from xpra.exit_codes import ExitCode
from xpra.log import Logger
from xpra.net.bytestreams import SOCKET_TIMEOUT, SocketConnection, VSOCK_TIMEOUT
from xpra.net.common import verify_hyperv_available
from xpra.net.constants import DEFAULT_PORTS, ABSTRACT_SOCKET_PREFIX, AUTO_ABSTRACT_SOCKET
from xpra.os_util import WIN32
from xpra.scripts.config import InitException, InitExit
from xpra.util.parsing import TRUE_OPTIONS
from xpra.scripts.picker import CONNECT_TIMEOUT
from xpra.util.objects import typedict


def debug(msg: str, *args) -> None:
    from xpra.log import Logger
    Logger("network").debug(msg, *args)


def connect_to_ssh(display_desc: dict[str, Any], debug_cb=noop, ssh_fail_cb=noop):
    """
    Open an ssh tunnel and return a connection wrapping it.

    `debug_cb(message)` is called with progress messages during connection setup, so UI clients
    can surface them (e.g. the GTK launcher displays them in its status area).

    `ssh_fail_cb(message)` is the side-channel for *asynchronous* tunnel failures: when the ssh
    subprocess dies after the initial connect, the failure is detected by a read/write on the
    network I/O thread (see `xpra.net.ssh.exec_client.abort_test`) and cannot be raised back to
    whoever called `connect_to_ssh`. The callback lets GUI clients surface the error in their
    own UI; the default `noop` is fine for CLI clients that rely on the `log.error` output.
    Synchronous failures during connect are still raised normally.
    """
    if display_desc.get("is_asyncssh", False):
        from xpra.net.ssh.asyncssh.client import connect_to
        conn = connect_to(display_desc)
    elif display_desc.get("is_paramiko", False):
        from xpra.net.ssh.paramiko.client import connect_to
        conn = connect_to(display_desc)
    else:
        from xpra.net.ssh import exec_client
        conn = exec_client.connect_to(display_desc, debug_cb, ssh_fail_cb)
    dtype = display_desc["type"]
    if dtype == "vnc+ssh":
        conn.socktype = "vnc"
        conn.socktype_wrapped = "ssh"
    return conn


def connect_to_namedpipe(display_desc: dict[str, Any]):
    pipe_name = display_desc["named-pipe"]
    if not WIN32:
        raise InitException("named pipes are only supported on MS Windows")
    import errno
    from xpra.platform.win32.dotxpra import PIPE_PATH, PIPE_ROOT
    from xpra.platform.win32.namedpipes.connection import NamedPipeConnection, connect_to_namedpipe
    if pipe_name.startswith(PIPE_ROOT):
        # absolute pipe path already specified
        path = pipe_name
    else:
        path = PIPE_PATH + pipe_name
    try:
        pipe_handle = connect_to_namedpipe(path)
    except Exception as e:
        try:
            if e.args[0] == errno.ENOENT:
                raise InitException(f"the named pipe {pipe_name!r} does not exist: {e}") from None
        except AttributeError:
            pass
        raise InitException(f"failed to connect to the named pipe {pipe_name!r}:\n {e}") from None
    timeout = display_desc.get("timeout", SOCKET_TIMEOUT)
    conn = NamedPipeConnection(pipe_name, pipe_handle, {})
    conn.timeout = timeout
    conn.target = f"namedpipe://{pipe_name}/"
    return conn


def connect_to_vsock(display_desc: dict[str, Any]):
    cid, iport = display_desc["vsock"]
    from xpra.net.vsock.vsock import (  # pylint: disable=no-name-in-module
        connect_vsocket,
        CID_TYPES, CID_ANY, PORT_ANY,
    )
    sock = connect_vsocket(cid=cid, port=iport)
    sock.settimeout(None)
    conn = SocketConnection(sock, "local", "host", (CID_TYPES.get(cid, cid), iport), "vsock")
    conn.timeout = VSOCK_TIMEOUT
    conn.target = "vsock://%s:%s" % (
        "any" if cid == CID_ANY else cid,
        "any" if iport == PORT_ANY else iport,
    )
    return conn


def connect_to_hyperv(display_desc: dict[str, Any]):
    vmid, service = display_desc["hyperv"]
    verify_hyperv_available()
    sock = socket.socket(socket.AF_HYPERV, socket.SOCK_STREAM, socket.HV_PROTOCOL_RAW)
    sock.connect((vmid, service))
    sock.settimeout(None)
    conn = SocketConnection(sock, "local", "host", (vmid, service), "hyperv")
    conn.timeout = VSOCK_TIMEOUT
    conn.target = f"hyperv://{vmid}.{service}"
    return conn


def connect_to_quic(display_desc: dict[str, Any]):
    desc = typedict(display_desc)
    dtype = desc.strget("type")
    host = desc.strget("host")
    port = desc.intget("port")
    path = "/" + desc.strget("display", "")
    ssl_options = typedict(desc.dictget("ssl-options"))
    ssl_server_verify_mode = ssl_options.strget("server-verify-mode")
    ssl_ca_certs = ssl_options.strget("ca-certs")
    ssl_cert = ssl_options.strget("cert")
    ssl_key = ssl_options.strget("key")
    ssl_key_password = ssl_options.strget("key-password")
    ssl_server_name = ssl_options.strget("server-hostname")
    try:
        from xpra.net.quic.client import quic_connect, WebSocketClient, WebTransportClient, FAST_OPEN
        import aioquic
        if not aioquic:
            # cythonized code can bind None for missing imports
            raise ImportError("aioquic")
    except ImportError as e:
        raise InitExit(ExitCode.SOCKET_CREATION_ERROR, f"cannot use quic sockets: {e}") from None
    fast_open = bool(display_desc.get("fast-open", FAST_OPEN))
    ssl_args = (ssl_cert, ssl_key, ssl_key_password, ssl_ca_certs, ssl_server_verify_mode, ssl_server_name)
    client_class = WebTransportClient if dtype == "wt" else WebSocketClient
    conn = quic_connect(host, port, path, fast_open, *ssl_args, client_class=client_class)
    return conn


def connect_to_tcp(display_desc: dict[str, Any]):
    dtype = display_desc["type"]
    display_name = display_desc["display_name"]
    timeout = display_desc.get("timeout", SOCKET_TIMEOUT)
    sock = retry_socket_connect(display_desc)
    try:
        # use non-blocking until the connection is finalized
        sock.settimeout(0.1)
        conn = SocketConnection(sock, sock.getsockname(), sock.getpeername(), display_name,
                                dtype, socket_options=display_desc)

        if dtype in ("ssl", "wss"):
            raw_sock = sock
            from xpra.net.tls.socket import ssl_handshake, ssl_wrap_socket
            # convert option names to function arguments:
            ssl_options = {k.replace("-", "_"): v for k, v in display_desc.get("ssl-options", {}).items()}
            # advertise `http/1.1` for `wss` so that a server listening on a multi-protocol socket (ie: `tcp`)
            # can tell from the `ClientHello` that this is a websocket connection,
            # instead of having to wait for our http upgrade request after the handshake:
            alpn_protocols = ("http/1.1", ) if dtype == "wss" else ()
            try:
                sock = ssl_wrap_socket(sock, alpn_protocols, **ssl_options)
            except ValueError as e:
                raise InitExit(ExitCode.SSL_FAILURE, f"ssl setup failed: {e}")
            if not sock:
                raw_sock.close()
                raise RuntimeError(f"failed to wrap socket {raw_sock} as {dtype!r}")
            ssl_handshake(sock, timeout)
            # The read and write threads share this single OpenSSL object, which is not
            # safe for concurrent use. Wrap it in an `SSLSocketConnection`, which serializes
            # the SSL calls (issue #4918): a plain `SocketConnection` lets the two threads
            # call `SSL_read` and `SSL_write` at the same time, corrupting the record stream
            # - typically the client's first packet (the `hello`) is silently dropped, the
            # server then times out the login and the connection fails intermittently.
            from xpra.net.tls.connection import SSLSocketConnection
            conn = SSLSocketConnection(sock, conn.local, conn.remote, conn.endpoint, dtype,
                                       socket_options=display_desc)
            conn.timeout = timeout

        # wrap in a websocket:
        if dtype in ("ws", "wss"):
            host = display_desc["host"]
            port = display_desc.get("port", 0)
            # do the websocket upgrade and switch to binary
            try:
                from xpra.net.websockets.common import client_upgrade, MAX_READ_TIME, MAX_WRITE_TIME
            except ImportError as e:  # pragma: no cover
                raise InitExit(ExitCode.UNSUPPORTED, f"cannot handle websocket connection: {e}") from None
            else:
                display_path = display_desc_to_display_path(display_desc)
                # without a deadline, the socket timeouts are retried for as long as the connection is active,
                # so a server that never responds would block us forever:
                conn.deadline = monotonic() + MAX_WRITE_TIME + MAX_READ_TIME
                try:
                    client_upgrade(conn.read, conn.write, host, port, display_path)
                finally:
                    conn.deadline = 0
        conn.target = get_host_target_string(display_desc)
        return conn
    except BaseException:
        # don't leak the socket when we fail to setup the connection,
        # `sock` is the wrapped ssl socket if we got that far:
        if sock:
            try:
                sock.close()
            except OSError as e:
                debug("failed to close %s: %s", sock, e)
        raise


def connect_to_socket(display_desc: dict[str, Any]):
    if not hasattr(socket, "AF_UNIX"):  # pragma: no cover
        raise InitExit(ExitCode.UNSUPPORTED, "unix domain sockets are not available on this operating system")

    sockpath = ""
    sock = None
    timeout = display_desc.get("timeout", SOCKET_TIMEOUT)
    display_name = display_desc["display_name"]
    abstract = AUTO_ABSTRACT_SOCKET and display_desc.get("abstract-socket", True)
    if display_name and not display_desc.get("socket_path") and abstract:
        # see if we can just connect to the abstract socket if one exists:
        from xpra.platform.dotxpra import strip_display_prefix
        sockpath = "@" + ABSTRACT_SOCKET_PREFIX + strip_display_prefix(display_name)
        actual_path = "\0" + sockpath[1:] if sockpath.startswith("@") else sockpath
        sock = socket.socket(socket.AF_UNIX)
        sock.settimeout(1.0)
        try:
            sock.connect(actual_path)
        except OSError:
            debug(f"failed to connect to abstract socket {sockpath}")
            noerr(sock.close)
            sock = None
    if not sock:
        from xpra.scripts.picker import get_sockpath
        sockpath = get_sockpath(display_desc, timeout=timeout)
        display_desc["socket_path"] = sockpath
        actual_path = "\0" + ABSTRACT_SOCKET_PREFIX + sockpath[1:] if sockpath.startswith("@") else sockpath
        sock = socket.socket(socket.AF_UNIX)
        sock.settimeout(timeout)
        start = monotonic()
        while monotonic() - start < timeout:
            try:
                sock.connect(actual_path)
                break
            except ConnectionRefusedError as e:
                elapsed = monotonic() - start
                debug("%s, retrying %i < %i", e, elapsed, timeout)
                time.sleep(0.5)
                continue
            except Exception as e:
                debug(f"failed to connect using {sock.connect}({sockpath})")
                noerr(sock.close)
                raise InitExit(ExitCode.CONNECTION_FAILED, f"failed to connect to {sockpath!r}:\n {e}") from None
    try:
        sock.settimeout(None)
        conn = SocketConnection(sock, sock.getsockname(), sock.getpeername(), display_name, "socket")
        # the peer's address is the path the server bound to, which may not exist in our mount namespace,
        # ie: a socket bind mounted in a container:
        conn.filename = sockpath
        conn.timeout = timeout
        target = "socket://"
        username = display_desc.get("username")
        if username:
            target += f"{username}@"
        target += sockpath
        conn.target = target
        return conn
    except OSError:
        noerr(sock.close)
        raise


def connect_to(display_desc: dict[str, Any], debug_cb=noop, ssh_fail_cb=noop):
    dtype = display_desc["type"]
    if dtype in ("ssh", "vnc+ssh"):
        return connect_to_ssh(display_desc, debug_cb, ssh_fail_cb)
    if dtype == "socket":
        return connect_to_socket(display_desc)
    if dtype == "named-pipe":  # pragma: no cover
        return connect_to_namedpipe(display_desc)
    if dtype == "vsock":
        return connect_to_vsock(display_desc)
    if dtype == "hyperv":
        return connect_to_hyperv(display_desc)
    if dtype == "wsl":
        from xpra.net import wsl
        return wsl.connect_to(display_desc, debug_cb, ssh_fail_cb)
    if dtype in ("quic", "wt"):
        return connect_to_quic(display_desc)
    if dtype in ("tcp", "ssl", "ws", "wss", "vnc"):
        return connect_to_tcp(display_desc)
    raise InitException(f"unsupported display type: {dtype}")


def get_host_target_string(display_desc: dict, port_key="port", prefix="") -> str:
    dtype = display_desc["type"]
    username = display_desc.get(prefix + "username", "")
    host = display_desc[prefix + "host"]
    try:
        port = int(display_desc.get(prefix + port_key, 0))
        if not 0 < port < 2 ** 16:
            port = 0
    except (ValueError, TypeError):
        port = 0
    display = display_desc.get(prefix + "display", "")
    return host_target_string(dtype, username, host, port, display)


def host_target_string(dtype: str, username: str, host: str, port: int, display: str = "") -> str:
    target = f"{dtype}://"
    if username:
        target += f"{username}@"
    target += host
    default_port = DEFAULT_PORTS.get(dtype, 0)
    if port and port != default_port:
        target += f":{port}"
    if display and display.startswith(":"):
        display = display[1:]
    target += "/%s" % (display or "")
    return target


def display_desc_to_uri(display_desc: dict[str, Any]) -> str:
    props = typedict(display_desc)
    dtype = props.strget("type")
    if not dtype:
        raise InitException("missing display type")
    if dtype == "wsl":
        from xpra.net.wsl import wsl_target_string
        return wsl_target_string(props.strget("distribution"), props.strget("username"), props.strget("display"))
    uri = f"{dtype}://"
    username = props.strget("username")
    if username:
        uri += username
    if "password" in props:
        uri += ":" + props.strget("password")
    if username or "password" in display_desc:
        uri += "@"
    if dtype in ("ssh", "tcp", "ssl", "ws", "wss", "quic"):
        # TODO: re-add 'proxy_host' arguments here
        host = props.strget("host")
        if not host:
            raise InitException("missing host from display parameters")
        uri += host
        port = props.intget("port")
        if port and port != DEFAULT_PORTS.get(dtype, 0):
            assert port is not None
            uri += f":{port:d}"
        elif dtype == "vsock":
            cid, iport = display_desc["vsock"]
            uri += f"{cid}:{iport}"
        elif dtype == "hyperv":
            vmid, service = display_desc["hyperv"]
            uri += f"{vmid}:{service}"
    else:
        raise NotImplementedError(f"{dtype} is not implemented yet")
    uri += "/" + display_desc_to_display_path(display_desc)
    return uri


def display_desc_to_display_path(display_desc: dict[str, Any]) -> str:
    uri = ""
    path = display_desc.get("path", "")
    if path:
        uri += path
    display = display_desc.get("display", "")
    if display:
        if path:
            uri += "#"
        uri += display.lstrip(":")
    options_str = display_desc.get("options_str", "")
    if options_str:
        uri += f"?{options_str}"
    return uri


def retry_socket_connect(options: dict):
    host = options["host"]
    port = options["port"]
    dtype = options["type"]
    if "proxy-host" in options:
        return proxy_connect(options)
    from xpra.net.socket_util import socket_connect
    start = monotonic()
    retry = options.get("retry", True) in TRUE_OPTIONS
    quiet = options.get("quiet", False)
    retry_count = 0
    timeout = options.get("timeout", CONNECT_TIMEOUT)
    while True:
        sock = socket_connect(host, port, timeout=timeout)
        if sock:
            return sock
        if not retry:
            break
        if monotonic() - start >= timeout:
            break
        if not quiet and retry_count == 0:
            log = Logger("network")
            log.info("")
            log.info(f"failed to connect to {dtype}://{host}:{port}/")
            log.info(f" retrying for {timeout} seconds")
            log.info("")
        retry_count += 1
        time.sleep(1)
    raise InitExit(ExitCode.CONNECTION_FAILED, f"failed to connect to {dtype} socket {host}:{port}")


def proxy_connect(options: dict):
    # if is_debug_enabled("proxy"):
    # log = logging.getLogger(__name__)
    try:
        # noinspection PyPackageRequirements
        import socks
    except ImportError as e:
        raise ValueError(f"cannot connect via a proxy: {e}") from None
    to = typedict(options)
    ptype = to.strget("proxy-type")
    proxy_type = {
        "SOCKS5": socks.SOCKS5,
        "SOCKS4": socks.SOCKS4,
        "HTTP": socks.HTTP,
    }.get(ptype, socks.SOCKS5)
    if not proxy_type:
        raise InitExit(ExitCode.UNSUPPORTED, f"unsupported proxy type {ptype!r}")
    proxy_host = to.strget("proxy-host")
    proxy_port = to.intget("proxy-port", 1080)
    rdns = to.boolget("proxy-rdns", True)
    username = to.strget("proxy-username")
    password = to.strget("proxy-password")
    timeout = to.intget("timeout", CONNECT_TIMEOUT)
    sock = socks.socksocket()
    sock.set_proxy(proxy_type, proxy_host, proxy_port, rdns, username, password)
    sock.settimeout(timeout)
    # the destination, which the proxy connects to for us:
    try:
        sock.connect((to.strget("host"), to.intget("port")))
    except BaseException:
        sock.close()
        raise
    return sock

# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from xpra.client.base.stub import StubClientSubsystem
from xpra.net.common import Packet
from xpra.util.thread import start_thread
from xpra.util.objects import typedict
from xpra.exit_codes import ExitCode
from xpra.scripts.config import InitExit
from xpra.log import Logger

log = Logger("ssl")


class SSLUpgrade(StubClientSubsystem):
    """
    Adds ability to upgrade connections to ssl
    """
    __slots__ = ()
    PREFIX = "ssl-upgrade"

    def get_caps(self) -> dict[str, bool]:
        return {"ssl-upgrade": True}

    def parse_server_capabilities(self, c: typedict) -> bool:  # pylint: disable=unused-argument
        self.remove_packet_handlers("ssl-upgrade")
        return True

    def _process_ssl_upgrade(self, packet: Packet) -> None:
        ssl_attrs = typedict(packet.get_dict(1))
        start_thread(self.ssl_upgrade, "ssl-upgrade", True, args=(ssl_attrs,))

    def ssl_upgrade(self, ssl_attrs: typedict) -> None:
        # send ssl-upgrade request!
        log(f"ssl-upgrade({ssl_attrs})")
        conn = self.client._protocol._conn
        socktype = conn.socktype
        new_socktype = {"tcp": "ssl", "ws": "wss"}.get(socktype)
        if not new_socktype:
            raise ValueError(f"cannot upgrade {socktype} to ssl")
        log.info(f"upgrading {conn} to {new_socktype}")
        self.send("ssl-upgrade", {})
        from xpra.net.tls.socket import ssl_handshake, ssl_wrap_socket
        from xpra.net.tls.file import get_ssl_attributes
        from xpra.net.tls.common import SSL_UPGRADE_DEFAULTS
        # the "ssl-options" from `get_ssl_options` already default to `SSL_UPGRADE_DEFAULTS`:
        overrides = dict(SSL_UPGRADE_DEFAULTS)
        overrides.update(conn.options.get("ssl-options", {}))
        ssl_options = get_ssl_attributes(None, False, overrides)
        kwargs = {k.replace("-", "_"): v for k, v in ssl_options.items()}
        # wait for the 'ssl-upgrade' packet to be sent...
        # this should be done by watching the IO and formatting threads instead
        import time
        time.sleep(1)

        def read_callback(packet) -> None:
            if packet:
                log.error("Error: received another packet during ssl socket upgrade:")
                log.error(" %s", packet)
                self.quit(ExitCode.INTERNAL_ERROR)

        conn = self.client._protocol.steal_connection(read_callback)
        if not self.client._protocol.wait_for_io_threads_exit(1):
            log.error("Error: failed to terminate network threads for ssl upgrade")
            self.quit(ExitCode.INTERNAL_ERROR)
            # noinspection PyUnreachableCode
            return
        ssl_sock = None
        try:
            ssl_sock = ssl_wrap_socket(conn._socket, **kwargs)
            if not ssl_sock:
                # `None` means the server closed the connection during the TLS setup:
                raise InitExit(ExitCode.SSL_FAILURE, "the connection was closed")
            ssl_handshake(ssl_sock)
        except Exception as e:
            log("ssl_upgrade(%s)", ssl_attrs, exc_info=True)
            log.error("Error: ssl upgrade failed")
            log.estr(e)
            # once wrapped, the ssl socket owns the file descriptor:
            (ssl_sock or conn).close()
            self.quit(e.status if isinstance(e, InitExit) else ExitCode.SSL_FAILURE)
            return
        log("ssl handshake complete")
        from xpra.net.tls.connection import SSLSocketConnection
        ssl_conn = SSLSocketConnection(ssl_sock, conn.local, conn.remote, conn.endpoint, new_socktype)
        # `make_protocol` sets `self.client._protocol` itself:
        protocol = self.client.make_protocol(ssl_conn)
        protocol.start()

    def init_packet_handlers(self) -> None:
        self.add_packets("ssl-upgrade")

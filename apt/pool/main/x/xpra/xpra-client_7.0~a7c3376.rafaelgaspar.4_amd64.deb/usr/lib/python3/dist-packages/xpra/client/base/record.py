# This file is part of Xpra.
# Copyright (C) 2026 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import json
import os.path
from time import monotonic, time
from typing import Any
from collections.abc import Mapping, Sequence

from xpra.client.base.gobject import GObjectClientAdapter
from xpra.client.base.command import XpraClientBase
from xpra.exit_codes import ExitValue
from xpra.net.common import Packet, BACKWARDS_COMPATIBLE
from xpra.net.packet_type import WINDOW_REFRESH, WINDOW_DRAW_ACK, WINDOW_STACKING
from xpra.platform.paths import initial_cwd
from xpra.util.env import envint
from xpra.util.objects import typedict
from xpra.os_util import gi_import
from xpra.log import Logger

log = Logger("client", "encoding")
focuslog = Logger("client", "focus")

GLib = gi_import("GLib")

REFRESH = envint("XPRA_RECORD_REFRESH", 10)
SYNC_GAP = envint("XPRA_SYNC_GAP", 1)

NO_GEOMETRY = (0, 0, 0, 0)

# window types which never take the keyboard focus when they are mapped:
NO_FOCUS_WINDOW_TYPES = (
    "DESKTOP", "DOCK", "SPLASH", "MENU", "DROPDOWN_MENU", "POPUP_MENU",
    "TOOLTIP", "NOTIFICATION", "COMBO", "DND",
)
# metadata flags which prevent a window from taking the focus:
NO_FOCUS_FLAGS = ("override-redirect", "tray", "below", "iconic", "shaded")


def can_focus(metadata: typedict) -> bool:
    """
    Should this window take the keyboard focus when it is mapped?
    The server does not tell us, so this is a heuristic:
    windows that are kept below, unmapped or of a type that never
    receives input are assumed not to steal the focus.
    """
    if any(metadata.boolget(flag) for flag in NO_FOCUS_FLAGS):
        return False
    window_types = metadata.strtupleget("window-type")
    return not any(wt in NO_FOCUS_WINDOW_TYPES for wt in window_types)


def save_json(path: str, data: dict) -> None:
    def tostr(obj) -> str:
        # this should not happen: binary data is saved as separate blob files,
        # but a lossy event is still better than a hole in the event sequence:
        log.warn("Warning: cannot serialize %s value, saving it as a string", type(obj))
        return str(obj)
    try:
        text = json.dumps(data, default=tostr)
    except (TypeError, ValueError):
        log.error("Error writing %r to %r", data, path, exc_info=True)
        return
    with open(path, "w") as f:
        f.write(text)


# InfoRequest?
# ClipboardClient, KeyboardClient, PointerClient, NotificationClient, Encodings -> emulate it
# TrayClient -> use custom tray instead


class WindowModel:

    def __init__(self, wid: int, geom: tuple[int, int, int, int], override_redirect: bool,
                 directory: str, start: float):
        self.wid = wid
        self.override_redirect = override_redirect
        self.metadata = {}
        self.cursor_data = ()
        self.geometry = geom
        self.directory = directory
        self.event_no = 0
        self.start = start
        self.sync_timer = 0
        # does this window have the keyboard focus? (see `RecordClient.set_focused`)
        self.focused = False
        # does this window hold the pointer grab? (see `RecordClient.set_grabbed`)
        self.grabbed = False
        # session-wide bottom-to-top window order, copied into every sync point
        self.stacking: tuple[int, ...] = ()
        if not os.path.exists(directory):
            os.mkdir(directory, 0o755)

    def update_metadata(self, metadata) -> None:
        self.metadata.update(metadata)

    def extract_blobs(self, data: Mapping) -> dict:
        """
        json cannot store binary data, so it is saved as a separate file
        named after the event and the key it was found in
        (ie: `encoding` in `draw` packets or `pixels` in `cursor_data` packets).
        `sync` events embed the cursor data, so nested dictionaries are
        parsed too - and since those dictionaries are shared with the other
        windows, a copy is returned rather than modifying them in place.
        """
        filtered: dict[str, Any] = {}
        for key, value in data.items():
            if isinstance(value, (bytes, memoryview)):
                path = os.path.join(self.directory, f"{self.event_no}.{key}")
                with open(path, "wb") as f:
                    f.write(bytes(value))
            elif isinstance(value, Mapping):
                filtered[key] = self.extract_blobs(value)
            else:
                filtered[key] = value
        return filtered

    def record(self, event: str, **kwargs) -> None:
        data = {
            "event": event,
            "wid": self.wid,
            "timestamp": int((monotonic() - self.start) * 1000),
            "time": int(time() * 1000),
            "index": self.event_no,
        }
        # binary data is stored in separate files,
        # everything else is added to the dictionary:
        data.update(self.extract_blobs(kwargs))
        path = os.path.join(self.directory, f"{self.event_no}.json")
        save_json(path, data)
        (focuslog if event == "stacking" else log)("recorded: %s : %r", event, data)
        self.event_no += 1
        if event == "destroy":
            self.cancel_sync_timer()
        elif event != "sync":
            self.schedule_sync()

    def schedule_sync(self) -> None:
        if not self.sync_timer:
            self.sync_timer = GLib.timeout_add(SYNC_GAP * 1000, self.record_sync)

    def cancel_sync_timer(self) -> None:
        if st := self.sync_timer:
            self.sync_timer = 0
            GLib.source_remove(st)

    def record_sync(self) -> bool:
        self.sync_timer = 0
        kwargs: dict[str, Any] = {
            "metadata": self.metadata,
            "cursor-data": self.cursor_data,
            "focused": self.focused,
            "grabbed": self.grabbed,
            "stacking": self.stacking,
        }
        if self.geometry != NO_GEOMETRY:
            kwargs["geometry"] = self.geometry
        self.record("sync", **kwargs)
        return False


class RecordClient(GObjectClientAdapter, XpraClientBase):

    @staticmethod
    def get_subsystem_classes() -> dict[str, type]:
        # `mmap` and `ping` are GUI-level subsystems, not part of the base
        # subsystems, but this client wants them composed too:
        classes = dict(XpraClientBase.get_subsystem_classes())
        from xpra.client.base import features
        if features.mmap:
            from xpra.client.subsystem.mmap import MmapClient
            classes[MmapClient.PREFIX] = MmapClient
        if features.ping:
            from xpra.client.subsystem.ping import PingClient
            classes[PingClient.PREFIX] = PingClient
        return classes

    def __init__(self, options):
        GObjectClientAdapter.__init__(self)
        XpraClientBase.__init__(self)
        self.client_type = "recorder"
        self.windows = options.windows
        self._id_to_window: dict[int, Any] = {}
        self.encodings: Sequence[str] = ("png", "webp", "jpeg")
        self.encoding_options = {}
        self.record_directory = os.path.join(initial_cwd, "record")
        self.sequence = 0
        self.refresh_needed: set[int] = set()
        self.refresh_timer = 0
        self.start = monotonic()
        # the window which currently has the keyboard focus, 0 for none:
        self.focused = 0
        # the window which currently holds the pointer grab, 0 for none:
        self.grabbed = 0
        # session-wide bottom-to-top window order:
        self.stacking: tuple[int, ...] = ()

    def init(self, opts) -> None:
        super().init(opts)
        if opts.encoding and opts.encoding not in self.encodings:
            self.encodings = tuple(list(self.encodings) + [opts.encoding])
        self.encoding_options = {
            "options": self.encodings,
            "core": self.encodings,
            "setting": opts.encoding,
        }
        for attr, value in {
            "quality": opts.quality,
            "min-quality": opts.min_quality,
            "speed": opts.speed,
            "min-speed": opts.min_speed,
        }.items():
            if value > 0:
                self.encoding_options[attr] = value
        self.install_signal_handlers()

    def run(self) -> ExitValue:
        if not os.path.exists(self.record_directory):
            os.mkdir(self.record_directory, 0o755)
        XpraClientBase.run(self)
        return super().run()

    def cleanup(self):
        self.cancel_refresh()
        super().cleanup()

    def cancel_refresh(self) -> None:
        if rt := self.refresh_timer:
            self.refresh_timer = 0
            self.source_remove(rt)

    def client_toolkit(self) -> str:
        return "offscreen-recorder"

    def make_hello(self) -> dict[str, Any]:
        # Include the base subsystem capabilities, in particular the packet
        # encoders and compressors needed to complete protocol negotiation.
        caps = super().make_hello()
        if self.windows:
            window_caps = {
                "enabled": True, "record": True, "restack": True,
                "sync-position": True, "sync-focus": True, "sync-stacking": True,
                # we want to know when a window grabs the pointer, see `_process_window_grab`:
                "grabs": True,
            }
            caps.update({
                "window": window_caps,
                "encoding": self.encoding_options,
                "share": True,
                "keyboard": {"record": True, "input": False},
                "cursor": {"encodings": ("png", ), "backwards-compatible": False},
                "pointer": {"record": True},
                "clipboard": {"record": True},
                "display": {"record": True},
                # notifications are recorded too:
                "notification": True,
            })
            if BACKWARDS_COMPATIBLE:
                # older servers read these from the plural namespace:
                caps["windows"] = window_caps
                caps["notifications"] = {"enabled": True}
        return caps

    def _process_startup_complete(self, _packet: Packet) -> None:
        self.refresh_timer = self.timeout_add(REFRESH * 1000, self.request_refresh)
        self.get_desktop_window()

    def get_desktop_window(self) -> WindowModel:
        """
        The "desktop" window records the session-wide events.
        It is created on demand because some of these events
        can arrive before `startup-complete`, ie: notifications.
        """
        wid = 0
        if window := self.get_window(wid):
            return window
        directory = os.path.join(self.record_directory, "%x" % wid)
        if not os.path.exists(directory):
            os.mkdir(directory, 0o755)
        window = WindowModel(wid, NO_GEOMETRY, False, directory, self.start)
        window.stacking = self.stacking
        window.record("new", stacking=self.stacking)
        self._id_to_window[wid] = window
        return window

    def print_server_info(self, c: typedict) -> None:
        log.info("recording from:")
        super().print_server_info(c)

    def request_refresh(self) -> bool:
        quality = 100
        options = {"refresh-now": True}
        client_properties = {}
        for wid in tuple(self.refresh_needed):
            self.send(WINDOW_REFRESH, wid, 0, quality, options, client_properties)
        self.refresh_needed = set()
        return True

    def _process_encoding_set(self, packet: Packet) -> None:
        encodings = typedict(packet.get_dict(1)).dictget("encodings").get("core", ())
        common = tuple(set(self.encodings) & set(encodings))
        log("server encodings=%s, common=%s", encodings, common)

    def get_window(self, wid: int) -> WindowModel | None:
        return self._id_to_window.get(wid)

    def set_focused(self, wid: int) -> None:
        """
        Update the window which has the keyboard focus.
        The focus state is saved at sync points, so both the window losing
        the focus and the one gaining it must record a new one.
        """
        if self.focused == wid:
            return
        log("set_focused(%#x) previous focus: %#x", wid, self.focused)
        if self.focused > 0 and (window := self.get_window(self.focused)):
            window.focused = False
            window.schedule_sync()
        self.focused = wid
        if wid > 0 and (window := self.get_window(wid)):
            window.focused = True
            window.schedule_sync()

    def set_grabbed(self, wid: int) -> None:
        """
        Update the window which holds the pointer grab.
        The grab is global to the session: at most one window can hold it,
        and the state is saved at sync points, so both the window losing
        the grab and the one taking it must record a new one.
        """
        if self.grabbed == wid:
            return
        log("set_grabbed(%#x) previous grab: %#x", wid, self.grabbed)
        if self.grabbed > 0 and (window := self.get_window(self.grabbed)):
            window.grabbed = False
            window.schedule_sync()
        self.grabbed = wid
        if wid > 0 and (window := self.get_window(wid)):
            window.grabbed = True
            window.schedule_sync()

    def _process_window_create(self, packet: Packet) -> None:
        self._process_new_common(packet, False)

    def _process_new_override_redirect(self, packet: Packet) -> None:
        assert BACKWARDS_COMPATIBLE
        self._process_new_common(packet, True)

    def _process_new_common(self, packet: Packet, override_redirect: bool):
        wid = packet.get_wid()
        x = packet.get_i16(2)
        y = packet.get_i16(3)
        w = packet.get_u16(4)
        h = packet.get_u16(5)
        assert 0 <= w < 32768 and 0 <= h < 32768
        metadata = typedict(packet.get_dict(6))
        # newer versions use metadata only:
        override_redirect |= metadata.boolget("override-redirect", False)
        metadata["override_redirect"] = override_redirect
        if wid in self._id_to_window:
            raise ValueError("we already have a window %#x: %s" % (wid, self.get_window(wid)))
        if w < 1 or h < 1:
            log.error("Error: window %#x dimensions %ix%i are invalid", wid, w, h)
            w, h = 1, 1
        rel_pos = metadata.inttupleget("relative-position")
        parent = metadata.intget("parent")
        log("relative-position=%s (parent=%s)", rel_pos, parent)
        if parent and rel_pos:
            if pwin := self._id_to_window.get(parent):
                x = pwin.geometry[0] + rel_pos[0]
                y = pwin.geometry[1] + rel_pos[1]
                log("relative position(%s)=%s", rel_pos, (x, y))
        geom = (x, y, w, h)
        directory = os.path.join(self.record_directory, "%x" % wid)
        if not os.path.exists(directory):
            os.mkdir(directory, 0o755)
        window = WindowModel(wid, geom, override_redirect, directory, self.start)
        window.stacking = self.stacking
        window.update_metadata(metadata)
        self._id_to_window[wid] = window
        # new windows usually steal the focus:
        if can_focus(metadata):
            self.set_focused(wid)
        # `new` events are sync points, so they must carry the focus and grab state too:
        window.record("new", geometry=(x, y, w, h), metadata=metadata,
                      focused=window.focused, grabbed=window.grabbed, stacking=self.stacking)

    def _process_window_initiate_moveresize(self, packet: Packet) -> None:
        # should not be received!
        pass

    def _process_window_metadata(self, packet: Packet) -> None:
        wid = packet.get_wid()
        metadata = packet.get_dict(2)
        if window := self.get_window(wid):
            window.update_metadata(metadata)
            if self.focused == wid and typedict(metadata).boolget("iconic"):
                # an iconified window cannot keep the focus:
                self.set_focused(0)
            window.record("metadata", metadata=metadata)

    def _process_window_move_resize(self, packet: Packet) -> None:
        wid = packet.get_wid()
        x = packet.get_i16(2)
        y = packet.get_i16(3)
        w = packet.get_u16(4)
        h = packet.get_u16(5)
        if window := self.get_window(wid):
            window.geometry = (x, y, w, h)
            window.record("move-resize", geometry=(x, y, w, h))

    def _process_window_resized(self, packet: Packet) -> None:
        wid = packet.get_wid()
        w = packet.get_u32(2)
        h = packet.get_u32(3)
        if window := self.get_window(wid):
            x, y = window.geometry[:2]
            window.geometry = (x, y, w, h)
            window.record("resize", size=(w, h))

    def _process_window_raise(self, packet: Packet) -> None:
        wid = packet.get_wid()
        if window := self.get_window(wid):
            # the server only raises windows that gained the focus
            # (see the `sync-focus` capability):
            self.set_focused(wid)
            window.record("raise")

    def _process_window_restack(self, packet: Packet) -> None:
        wid = packet.get_wid()
        detail = packet.get_i16(2)
        other_wid = packet.get_wid(3)
        if window := self.get_window(wid):
            if detail == 0 and not other_wid:
                # raised to the top of the stack:
                self.set_focused(wid)
            elif detail != 0 and self.focused == wid:
                # lowered: it cannot have the focus any more
                self.set_focused(0)
            window.record("restack", detail=detail, other=other_wid)

    def _process_window_stacking(self, packet: Packet) -> None:
        stacking = packet.get_ints(1)
        focuslog("process_window_stacking(%s)", stacking)
        self.stacking = stacking
        for window in self._id_to_window.values():
            window.stacking = stacking
        if desktop := self.get_window(0):
            desktop.record("stacking", stacking=stacking)

    def _process_window_destroy(self, packet: Packet) -> None:
        wid = packet.get_wid()
        if window := self.get_window(wid):
            assert window is not None
            del self._id_to_window[wid]
            if self.focused == wid:
                # we don't know which window gets the focus next:
                self.set_focused(0)
            if self.grabbed == wid:
                # the X11 server releases the grab when the window goes away:
                self.set_grabbed(0)
            window.record("destroy")

    def _process_window_grab(self, packet: Packet) -> None:
        wid = packet.get_wid()
        window = self.get_window(wid)
        if not window:
            log.warn("Warning: window %#x not found!", wid)
            return
        self.set_grabbed(wid)
        window.record("grab")

    def _process_window_ungrab(self, packet: Packet) -> None:
        wid = packet.get_wid()
        if wid <= 0:
            # the `ungrab` control command sends -1 to ungrab all the clients:
            wid = self.grabbed
        window = self.get_window(wid)
        self.set_grabbed(0)
        if window:
            window.record("ungrab")

    def _process_window_draw(self, packet: Packet) -> None:
        wid = packet.get_wid()
        window = self.get_window(wid)
        if not window:
            log.warn("Warning: window %#x not found!", wid)
            return
        x = packet.get_i16(2)
        y = packet.get_i16(3)
        width = packet.get_u16(4)
        height = packet.get_u16(5)
        coding = packet.get_str(6)
        # mmap can send a tuple, otherwise it's a buffer, see #4496:
        if BACKWARDS_COMPATIBLE:
            data = packet[7]
        elif coding in ("mmap", "scroll") and not isinstance(packet[7], (bytes, bytearray, memoryview)):
            # backwards compatible servers duplicate the `chunks` / `scroll` options here:
            data = b""
        else:
            data = packet.get_buffer(7)
        packet_sequence = packet.get_u64(8)
        rowstride = packet.get_u32(9)
        options = {}
        if len(packet) > 10:
            options = packet.get_dict(10)
        log("record: %ix%i %s update", width, height, coding)
        kwargs = {
            "geometry": (x, y, width, height),
            "encoding": coding,
            "packet_sequence": packet_sequence,
            "options": options,
            coding: data,
        }
        if rowstride:
            kwargs["rowstride"] = rowstride
        window.record("draw", **kwargs)
        decode_time = 0
        message = ""
        self.send(WINDOW_DRAW_ACK, packet_sequence, wid, width, height, decode_time, message)
        if x != 0 or y != 0 or (width, height) != window.geometry[2:4] or options.get("quality", 100) != 100:
            self.refresh_needed.add(wid)

    def _process_notification_show(self, packet: Packet) -> None:
        nid = packet.get_u64(2)
        app_name = packet.get_str(3)
        replaces_nid = packet.get_u64(4)
        summary = packet.get_str(6)
        body = packet.get_str(7)
        expire_timeout = packet.get_i64(8)
        # ie: "Recording denied"
        log.warn("Warning: %s", summary)
        for line in body.splitlines():
            log.warn(" %s", line)
        self.get_desktop_window().record("notification", nid=nid, app_name=app_name, replaces_nid=replaces_nid,
                                         summary=summary, body=body, expire_timeout=expire_timeout)

    def _process_notification_close(self, packet: Packet) -> None:
        nid = packet.get_u64(1)
        self.get_desktop_window().record("notification-close", nid=nid)

    def _process_window_eos(self, packet: Packet) -> None:
        """ safe to ignore - we don't have streams to replay """

    def _process_keyboard_record(self, packet: Packet) -> None:
        wid = packet.get_wid()
        window = self.get_window(wid)
        if not window:
            log.warn("Warning: window %#x not found!", wid)
            return
        record = packet.get_dict(2)
        if record:
            window.record("key", key=record)

    def _process_clipboard_record(self, packet: Packet) -> None:
        # example packet:
        # 'clipboard-record', 'client', 'clipboard-contents', 6, 'CLIPBOARD', 'UTF8_STRING', 8, 'bytes', b'foo', 0
        window = self.get_desktop_window()
        subpacket_type = packet.get_str(2)
        record = list(packet[1:])
        kwargs: dict[str, Any] = {
            "record": record,
        }
        if subpacket_type == "clipboard-contents" and isinstance(record[7], bytes):
            kwargs["contents"] = record[7]
            record[7] = ''
        window.record("clipboard", **kwargs)

    def _process_window_bell(self, packet: Packet) -> None:
        wid = packet.get_wid()
        window = self.get_window(wid)
        if not window:
            log.warn("Warning: window %#x not found!", wid)
            return
        device = packet.get_u16(2)
        percent = packet.get_i8(3)
        pitch = packet.get_i32(4)
        duration = packet.get_i32(5)
        bell_class = packet.get_u32(6)
        bell_id = packet.get_u32(7)
        bell_name = packet.get_str(8)
        window.record("bell", device=device, percent=percent, pitch=pitch, duration=duration,
                      bell_class=bell_class, bell_id=bell_id, bell_name=bell_name)

    def _process_cursor_default(self, _packet: Packet) -> None:
        for window in self._id_to_window.values():
            window.cursor_data = {}
            window.record("cursor-default")

    def _process_cursor_data(self, packet: Packet) -> None:
        encoding = packet.get_str(1)
        w = packet.get_u16(2)
        h = packet.get_u16(3)
        xhot = packet.get_u16(4)
        yhot = packet.get_u16(5)
        serial = packet.get_u64(6)
        pixels = packet.get_bytes(7)
        name = packet.get_str(8)
        cursor_data = {
            "encoding": encoding,
            "w": w,
            "h": h,
            "xhot": xhot,
            "yhot": yhot,
            "serial": serial,
            encoding: pixels,
            "name": name,
        }
        for window in self._id_to_window.values():
            window.cursor_data = cursor_data
            window.record("cursor-data", **cursor_data)

    def _process_pointer_position(self, packet: Packet) -> None:
        wid = packet.get_wid()
        window = self.get_window(wid)
        if not window:
            log.warn("Warning: window %#x not found!", wid)
            return
        x = packet.get_i16(2)
        y = packet.get_i16(3)
        if len(packet) >= 6:
            rx = packet.get_i16(4)
            ry = packet.get_i16(5)
        else:
            rx, ry = -1, -1
        window.record("pointer-motion", position=(x, y, rx, ry))

    def _process_pointer_motion(self, packet: Packet) -> None:
        device_id = packet.get_i64(1)
        seq = packet.get_u64(2)
        wid = packet.get_wid(3)
        pdata = packet.get_ints(4)
        props = packet.get_dict(5)
        x, y = pdata[:2]
        rx, ry = pdata[2:4] if len(pdata) >= 4 else (-1, -1)
        window = self.get_window(wid)
        if not window:
            log.warn("Warning: window %#x not found!", wid)
            return
        window.record("pointer-motion", position=(x, y, rx, ry), device_id=device_id, sequence=seq, props=props)

    def _process_pointer_button(self, packet: Packet) -> None:
        device_id = packet.get_i64(1)
        seq = packet.get_u64(2)
        wid = packet.get_wid(3)
        button = packet.get_u8(4)
        pressed = packet.get_bool(5)
        pointer = packet.get_ints(6)
        props = packet.get_dict(7)
        window = self.get_window(wid)
        if not window:
            log.warn("Warning: window %#x not found!", wid)
            return
        window.record("pointer-button", position=pointer, device_id=device_id, sequence=seq, props=props,
                      button=button, pressed=pressed)

    def _process_pointer_wheel(self, packet: Packet) -> None:
        wid = packet.get_wid()
        button = packet.get_u8(2)
        distance = packet.get_i64(3)
        pointer = packet.get_ints(4)
        modifiers = packet.get_strs(5)
        window = self.get_window(wid)
        if not window:
            log.warn("Warning: window %#x not found!", wid)
            return
        window.record("pointer-wheel", position=pointer, button=button, distance=distance, modifiers=tuple(modifiers))

    def init_authenticated_packet_handlers(self) -> None:
        super().init_authenticated_packet_handlers()
        # all the handlers record events to files, which the parse thread's seccomp filter does not allow,
        # running them all on the main thread also preserves the order of the events:
        self.add_packets("startup-complete", "encoding-set", main_thread=True)
        self.add_legacy_alias("encodings", "encoding-set")
        if BACKWARDS_COMPATIBLE:
            self.add_packets("new-override-redirect", main_thread=True)
            self.add_legacy_alias("raise-window", "window-raise")
            self.add_legacy_alias("new-window", "window-create")
            self.add_legacy_alias("restack-window", "window-restack")
            self.add_legacy_alias("initiate-moveresize", "window-initiate-moveresize")
            self.add_legacy_alias("lost-window", "window-destroy")
            self.add_legacy_alias("configure-override-redirect", "window-move-resize")
            self.add_legacy_alias("draw", "window-draw")
            self.add_legacy_alias("bell", "window-bell")
            self.add_legacy_alias("eos", "window-eos")
            self.add_legacy_alias("pointer-grab", "window-grab")
            self.add_legacy_alias("pointer-ungrab", "window-ungrab")
        self.add_packets(
            "window-create",
            "window-raise",
            "window-restack",
            WINDOW_STACKING,
            "window-initiate-moveresize",
            "window-move-resize",
            "window-resized",
            "window-metadata",
            "window-destroy",
            "window-grab",
            "window-ungrab",
            "window-draw",
            "window-bell",
            "window-eos",
            "keyboard-record",
            "cursor-data",
            "cursor-default",
            "pointer-position",
            "pointer-button",
            "pointer-motion",
            "pointer-wheel",
            "clipboard-record",
            "notification-show",
            "notification-close",
            main_thread=True,
        )
        self.add_legacy_alias("notify_show", "notification-show")
        self.add_legacy_alias("notify_close", "notification-close")

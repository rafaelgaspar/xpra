# This file is part of Xpra.
# Copyright (C) 2019 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from xpra.util.str_fn import csv
from xpra.x11.error import xswallow

from xpra.x11.bindings.window import X11WindowBindings


def get_wintitle(xid: int) -> str:
    X11Window = X11WindowBindings()
    with xswallow:
        data = X11Window.XGetWindowProperty(xid, "WM_NAME", "STRING")
        if data:
            return data.decode("latin1")
    with xswallow:
        data = X11Window.XGetWindowProperty(xid, "_NET_WM_NAME", "UTF8_STRING")
        if data:
            return data.decode("utf8")
    return ""


def get_wininfo(xid: int) -> str:
    if not xid:
        # `XNone` is a valid state, it means "no window":
        # asking the server about it only costs us a `BadWindow` for each
        # property we look up, and a pid which belongs to somebody else
        return "None"
    wininfo = [f"xid={xid:x}"]
    try:
        from xpra.x11.bindings.res import ResBindings
        XRes = ResBindings()
    except ImportError:
        pass
    else:
        if XRes.check_xres():
            with xswallow:
                pid = XRes.get_pid(xid)
                if pid:
                    wininfo.append(f"pid={pid}")
    title = get_wintitle(xid)
    if title:
        wininfo.insert(0, repr(title))
        return csv(wininfo)
    while xid:
        title = get_wintitle(xid)
        if title:
            wininfo.append(f"child of {title!r}")
            return csv(wininfo)
        parent = 0
        with xswallow:
            X11Window = X11WindowBindings()
            parent = X11Window.getParent(xid)
        xid = parent
    return csv(wininfo)


class WinInfo:
    """
    `get_wininfo()` costs a handful of round trips to the X11 server,
    so defer it until the log message it belongs to is actually formatted
    """
    __slots__ = ("xid", )

    def __init__(self, xid: int):
        self.xid = xid

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return get_wininfo(self.xid)

# This file is part of Xpra.
# Copyright (C) 2019 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any, Final
from collections.abc import Callable

from xpra.common import noop
from xpra.os_util import gi_import
from xpra.util.gobject import one_arg_signal
from xpra.x11.common import X11Event
from xpra.x11.error import xsync, xlog
from xpra.x11.prop import prop_set
from xpra.x11.dispatch import add_event_receiver, remove_event_receiver
from xpra.x11.selection.common import (
    xatoms_to_strings, strings_to_xatoms, xfixes_selection_input,
    x11_event_loop_running, gtk_event_window,
)
from xpra.clipboard.timeout import ClipboardTimeoutHelper
from xpra.log import Logger

GObject = gi_import("GObject")

log = Logger("x11", "clipboard")


IGNORED_PROPERTIES = (
    "_NET_WM_NAME", "WM_NAME", "_NET_WM_ICON_NAME", "WM_ICON_NAME",
    "WM_PROTOCOLS", "WM_NORMAL_HINTS", "WM_CLIENT_MACHINE", "WM_LOCALE_NAME",
    "_NET_WM_PID", "WM_CLIENT_LEADER", "_NET_WM_USER_TIME_WINDOW",
    # `get_server_time` leaves the deletion of this one behind:
    "XPRA_TIMESTAMP_PROP",
)
IGNORED_MESSAGES = (
    "_GTK_LOAD_ICONTHEMES",
)


def init_event_window(gtk_filter: bool) -> int:
    from xpra.x11.bindings.core import constants
    from xpra.x11.bindings.window import X11WindowBindings
    X11Window = X11WindowBindings()
    InputOnly: Final[int] = constants["InputOnly"]
    PropertyChangeMask: Final[int] = constants["PropertyChangeMask"]
    rxid = X11Window.get_root_xid()
    event_mask = PropertyChangeMask
    if gtk_filter:
        # this one is for gtk rather than for us: its event filter returns
        # `GDK_FILTER_CONTINUE`, so gtk also processes every xfixes selection event we ask
        # for, and resolves the screen through its own lookup of this window - a lookup
        # which returns NULL once it has forgotten it, and a NULL screen is dereferenced
        # unchecked. Without a `DestroyNotify` gtk only forgets this window when its
        # wrapper is garbage collected, at a time unrelated to the event queue.
        event_mask |= constants["StructureNotifyMask"]
    xid = X11Window.CreateWindow(rxid, -1, -1, event_mask=event_mask, inputoutput=InputOnly)
    prop_set(xid, "WM_TITLE", "latin1", "Xpra-Clipboard")
    log(f"init_event_window()={xid=}")
    return xid


def remove_event_window(xid: int) -> None:
    with xlog:
        from xpra.x11.bindings.window import X11WindowBindings
        X11Window = X11WindowBindings()
        # X11Window.Unmap(xid)
        X11Window.DestroyWindow(xid)


class X11Clipboard(ClipboardTimeoutHelper, GObject.GObject):
    # handle signals from the X11 bindings,
    # and dispatch them to the proxy handling the selection specified:
    __gsignals__ = {
        "x11-client-message-event": one_arg_signal,
        "x11-selection-request": one_arg_signal,
        "x11-selection-clear": one_arg_signal,
        "x11-selection-notify": one_arg_signal,
        "x11-property-notify-event": one_arg_signal,
        "x11-xfixes-selection-notify-event": one_arg_signal,
    }

    def __init__(self, send_packet_cb: Callable, progress_cb=noop, **kwargs):
        GObject.GObject.__init__(self)
        self.gtk_filter = False
        # gtk's wrapper for `event_window_xid`, which only exists to keep gtk's own
        # lookup of that window working - nothing here ever uses it, see `init_event_window`:
        self.gtk_event_window = None
        # this also decides whether gtk is going to be processing our events:
        self.init_gtk_filter()
        with xsync:
            self.event_window_xid = init_event_window(self.gtk_filter)
            add_event_receiver(self.event_window_xid, self)
            if self.gtk_filter:
                # gtk must know about this window before we use it, and must keep knowing:
                self.gtk_event_window = gtk_event_window(self.event_window_xid)
        super().__init__(send_packet_cb, progress_cb, **kwargs)

    def init_gtk_filter(self) -> None:
        # X11 events only reach the receivers registered above if something routes them
        # to `xpra.x11.dispatch`: without that we would never see a selection owner change
        # or a conversion property notify. There are two routers:
        # servers pump the events themselves from `x11.bindings.loop`,
        # and gtk clients get them from the shared GDK event filter.
        if x11_event_loop_running():
            return
        try:
            from xpra.x11.gtk.bindings import init_x11_filter
        except ImportError:
            # a process which cannot load the gtk bindings is not using them for routing
            log("init_gtk_filter()", exc_info=True)
            return
        # the filter is shared and reference counted, so take a reference of our own
        # rather than relying on another subsystem (xsettings, window stacking, xi2..)
        # happening to be enabled and holding one for us.
        # A successful call holds a reference even when the filter was already installed:
        init_x11_filter()
        self.gtk_filter = True

    def __repr__(self):
        return "X11Clipboard"

    def init_proxies(self, selections) -> None:
        # batch-intern the selection atoms in a single round-trip,
        # so that creating a proxy for each one below is served from the cache:
        with xsync:
            from xpra.x11.bindings.core import X11CoreBindings
            X11CoreBindings().intern_atoms(tuple(selections))
        super().init_proxies(selections)

    def cleanup_window(self) -> None:
        if xid := self.event_window_xid:
            self.event_window_xid = 0
            remove_event_receiver(xid, self)
            remove_event_window(xid)

    def cleanup_gtk_filter(self) -> None:
        if self.gtk_filter:
            self.gtk_filter = False
            from xpra.x11.gtk.bindings import cleanup_x11_filter
            cleanup_x11_filter()

    def cleanup(self) -> None:
        ClipboardTimeoutHelper.cleanup(self)
        self.cleanup_window()
        self.cleanup_gtk_filter()

    def make_proxy(self, selection):
        from xpra.x11.selection.proxy import ClipboardProxy
        xid = self.event_window_xid
        proxy = ClipboardProxy(xid, selection)
        proxy.set_want_targets(self.proxy_want_targets(selection))
        proxy.set_direction(self.can_send, self.can_receive)
        proxy.connect("send-clipboard-token", self._send_clipboard_token_handler)
        proxy.connect("send-clipboard-request", self._send_clipboard_request_handler)
        xfixes_selection_input(xid, selection)
        return proxy

    ############################################################################
    # X11 event handlers:
    # we dispatch them to the proxy handling the selection specified
    ############################################################################
    def do_x11_selection_request(self, event: X11Event) -> None:
        log("do_x11_selection_request(%s)", event)
        if proxy := self._get_proxy(event.selection):
            proxy.do_selection_request_event(event)

    def do_x11_selection_clear(self, event: X11Event) -> None:
        log("do_x11_selection_clear(%s)", event)
        if proxy := self._get_proxy(event.selection):
            proxy.do_selection_clear_event(event)

    def do_x11_selection_notify(self, event: X11Event) -> None:
        # the answer to one of our own `XConvertSelection` calls:
        log("do_x11_selection_notify(%s)", event)
        if proxy := self._get_proxy(event.selection):
            proxy.do_conversion_notify_event(event)

    def do_x11_xfixes_selection_notify_event(self, event: X11Event) -> None:
        log("do_x11_xfixes_selection_notify_event(%s)", event)
        if proxy := self._get_proxy(event.selection):
            proxy.do_selection_notify_event(event)

    def do_x11_client_message_event(self, event: X11Event) -> None:
        message_type = event.message_type
        if message_type in IGNORED_MESSAGES:
            log("ignored clipboard client message: %s", message_type)
            return
        log.info(f"Unexpected X11 message received by clipboard window {event.window:x}")
        log.info(f" {event}")

    def do_x11_property_notify_event(self, event: X11Event) -> None:
        if event.atom in IGNORED_PROPERTIES:
            # these properties are populated by GTK when we create the window,
            # no need to log them
            return
        log("do_x11_property_notify_event(%s)", event)
        # ie: atom=PRIMARY-TARGETS
        # ie: atom=PRIMARY-VALUE
        parts = event.atom.split("-", 1)
        if len(parts) != 2:
            return
        selection = parts[0]  # ie: PRIMARY
        # target = parts[1]           # ie: VALUE
        if proxy := self._get_proxy(selection):
            proxy.do_property_notify(event)

    ############################################################################
    # x11 specific munging support:
    ############################################################################

    def _munge_raw_selection_to_wire(self, target, dtype, dformat, data) -> tuple[str, Any]:
        if dformat == 32 and dtype in ("ATOM", "ATOM_PAIR"):
            return "atoms", self.remote_targets(xatoms_to_strings(data))
        return super()._munge_raw_selection_to_wire(target, dtype, dformat, data)

    def _munge_wire_selection_to_raw(self, encoding, dtype, dformat, data) -> bytes | str:
        if encoding == "atoms":
            return strings_to_xatoms(self.local_targets(data))
        return super()._munge_wire_selection_to_raw(encoding, dtype, dformat, data)


GObject.type_register(X11Clipboard)

# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from typing import Any
from subprocess import Popen
from collections.abc import Sequence

from xpra.os_util import POSIX
from xpra.server.source.display import DisplayConnection
from xpra.util.env import envint, envbool, first_time
from xpra.util.version import XPRA_VERSION
from xpra.x11.error import xlog, xsync, xswallow, XError
from xpra.exit_codes import ExitCode
from xpra.util.system import is_X11
from xpra.scripts.config import FALSE_OPTIONS, InitExit
from xpra.net.common import Packet, BACKWARDS_COMPATIBLE
from xpra.common import may_notify_client
from xpra.constants import MAX_WINDOW_SIZE, NotificationID
from xpra.util.rectangle import rectangle
from xpra.util.screen import combine_monitor_layouts, monitors_bounding_box
from xpra.util.parsing import (
    parse_resolutions, parse_env_resolutions, get_refresh_rate_for_value,
    adjust_monitor_refresh_rate,
)
from xpra.x11.xroot_props import root_set, root_get, root_del
from xpra.server.subsystem.display import DisplayManager
from xpra.log import Logger

log = Logger("screen")
grablog = Logger("server", "grab")
sharinglog = Logger("sharing")

DUMMY_WIDTH_HEIGHT_MM = envbool("XPRA_DUMMY_WIDTH_HEIGHT_MM", True)
DUMMY_MONITORS = envbool("XPRA_DUMMY_MONITORS", True)


def x11_ungrab() -> None:
    grablog("X11_ungrab")
    with xsync:
        from xpra.x11.bindings.core import X11CoreBindings
        core = X11CoreBindings()
        core.UngrabKeyboard()
        core.UngrabPointer()


def check_xvfb(xvfb: Popen | None, timeout=0, command=()) -> bool:
    if xvfb is None:
        return True
    assert POSIX
    from xpra.x11.vfb_util import check_xvfb_process
    return check_xvfb_process(xvfb, timeout=timeout, command=command)


def _get_root_int(prop: str) -> int:
    with xsync:
        return root_get(prop, "u32") or 0


def _set_root_int(prop: str = "_XPRA_RANDR_EXACT_SIZE", i: int = 0) -> None:
    with xsync:
        root_set(prop, "u32", i)


def get_root_size() -> tuple[int, int]:
    with xsync:
        from xpra.x11.bindings.window import X11WindowBindings
        X11Window = X11WindowBindings()
        return X11Window.get_root_size()


def get_display_pid() -> int:
    # perhaps this is an upgrade from an older version?
    # try harder to find the pid:
    try:
        return _get_root_int("XPRA_XVFB_PID") or _get_root_int("_XPRA_SERVER_PID") or 0
    except RuntimeError:
        return 0


def save_server_pid() -> None:
    root_set("XPRA_SERVER_PID", "u32", os.getpid())


def save_server_mode(session_type: str) -> None:
    root_set("XPRA_SERVER_MODE", "latin1", session_type)


def save_server_version():
    if BACKWARDS_COMPATIBLE:
        root_set("XPRA_SERVER", "latin1", XPRA_VERSION)
    root_set("XPRA_SERVER_VERSION", "latin1", XPRA_VERSION)


def log_randr_warning(msg="no randr bindings", error="") -> None:
    log.warn("Warning: %s", msg)
    if error:
        log.warn(error)
    log.warn(" the virtual display cannot be configured properly")


def monitor_geometries(monitors: dict[int, Any]) -> dict[int, Any]:
    """ just the geometry of each monitor, so we can log a layout without the full definitions """
    return {index: mdef.get("geometry") for index, mdef in monitors.items()}


class X11DisplayManager(DisplayManager):
    __slots__ = (
        "default_resolution", "display_pid", "initial_resolutions", "mirror_client_layout", "randr",
        "randr_exact_size", "randr_sizes_added", "xvfb", "xvfb_cmd",
    )
    toggle_features = ("randr",)
    SHARING_LAYOUT_SUPPORTED = True
    """
    Mixin for servers that handle displays.
    """

    def __init__(self, server=None):
        DisplayManager.__init__(self, server)
        self.xvfb: Popen | None = None
        self.xvfb_cmd: tuple[str, ...] = ()
        self.display_pid: int = 0
        self.randr_sizes_added: list[tuple[int, int]] = []
        self.initial_resolutions: Sequence[tuple[int, int, int]] = ()
        self.randr = False
        self.randr_exact_size = False
        self.antialias: dict[str, Any] = {}
        self.original_desktop_display = None
        # Default screen resolution for `get_default_initial_res`. The empty
        # string means "fall back to whatever `parse_env_resolutions` picks"
        # (currently 7680x4320, the 8K seamless default). Desktop-style
        # variants override this in their `__init__` to a more modest size
        # (e.g. 1920x1080) because a fixed virtual monitor is intended to
        # match a real display rather than serve as a giant canvas that
        # the client can sub-rect into.
        self.default_resolution: str = ""
        # When True, `set_screen_size` first tries to mirror the connected
        # client's monitor layout via RandR 1.6 instead of resizing the
        # screen. Seamless servers want this; desktop / monitor servers
        # explicitly disable it because their virtual monitors are sized
        # by the user, not by the client's hardware.
        self.mirror_client_layout: bool = True

    def set_vfb_startup_state(self, state) -> None:
        self.xvfb = state.xvfb
        self.xvfb_cmd = state.xvfb_cmd
        self.display_pid = state.xvfb_pid
        self.publish_vfb_pid(state.xvfb_pid)
        self.check_xvfb()

    @staticmethod
    def publish_vfb_pid(pid: int) -> None:
        os.environ["XVFB_PID"] = str(pid)

    def init(self, opts) -> None:
        self.init_display_pid()
        DisplayManager.init(self, opts)
        onoff = sizes = opts.resize_display
        if opts.resize_display.find(":") > 0:
            # ie: "off:1080p"
            onoff, sizes = opts.resize_display.split(":", 1)
        try:
            res = parse_resolutions(sizes, opts.refresh_rate)
            self.initial_resolutions = res if res is not None else self.get_default_initial_res()
        except ValueError:
            self.initial_resolutions = self.get_default_initial_res()
        log("initial_resolutions(%s, %s)=%s", sizes, opts.refresh_rate, self.initial_resolutions)
        self.randr = onoff.lower() not in FALSE_OPTIONS
        self.randr_exact_size = False
        self.check_xvfb()

    def get_wm_name(self) -> str:
        from xpra.x11.common import get_wm_name as x11_get_wm_name
        with xsync:
            return x11_get_wm_name() or ""

    def get_display_name(self) -> str:
        from xpra.x11.bindings.display_source import get_display_name as x11_get_display_name
        return x11_get_display_name() or super().get_display_name()

    def get_default_initial_res(self) -> Sequence[tuple[int, int, int]]:
        # `default_resolution` is set by the variant (empty = seamless 8K default).
        kwargs = {"default_refresh_rate": self.refresh_rate}
        if self.default_resolution:
            kwargs["default_res"] = self.default_resolution
        return parse_env_resolutions(**kwargs)

    def get_server_features(self, source) -> dict[str, Any]:
        caps = DisplayManager.get_server_features(self, source)
        caps |= {
            "resize_screen": self.randr,
            "resize_exact": self.randr_exact_size,
            "force_ungrab": True,
        }
        if self.randr:
            sizes = self.get_all_screen_sizes()
            if len(sizes) > 1:
                caps["screen-sizes"] = sizes
        return caps

    def check_vfb_process(self, timeout=0) -> bool:
        return check_xvfb(self.xvfb, timeout=timeout, command=self.xvfb_cmd)

    def check_xvfb(self, timeout=0) -> None:
        if not self.check_vfb_process(timeout):
            raise InitExit(ExitCode.NO_DISPLAY, "xvfb process has terminated")

    def setup(self) -> None:
        self.check_xvfb()
        from xpra.scripts.server import verify_display
        if not verify_display(xvfb=self.xvfb, display_name=self.display):
            raise InitExit(ExitCode.NO_DISPLAY, f"unable to access display {self.display!r}")
        if sf := self.get_subsystem("session-files"):
            sf.session_files.extend((
                "xvfb.pid",
                "xauthority",
                "Xorg.log",
                "Xorg.log.old",
                "xorg.conf.d/*",
                "xorg.conf.d",
            ))
        DisplayManager.setup(self)
        if not self.display_pid:
            self.display_pid = get_display_pid()
        if self.randr and self.init_randr():
            self.set_initial_resolution()
        self.verify_sharing_layout()
        self.server.connect("client-exited", self.client_exited)
        with xsync:
            save_server_pid()
            save_server_mode(self.server.session_type)
            save_server_version()

    def init_randr(self) -> bool:
        from xpra.x11.error import xlog
        try:
            from xpra.x11.bindings.randr import RandRBindings
        except ImportError as e:
            self.randr = False
            log_randr_warning("no randr bindings", str(e))
            return False
        with xlog:
            RandR = RandRBindings()
            if not RandR.has_randr():
                log_randr_warning("randr extension is not available")
                self.randr = False
                return False
            # check the property first,
            # because we may be inheriting this display,
            # in which case the screen sizes list may be longer than 1
            eprop = _get_root_int("_XPRA_RANDR_EXACT_SIZE")
            log("_XPRA_RANDR_EXACT_SIZE=%s", eprop)
            self.randr_exact_size = eprop == 1 or RandR.get_version() >= (1, 6)
            if not self.randr_exact_size:
                # ugly hackish way of detecting Xvfb with randr,
                # assume that it has only one resolution pre-defined:
                sizes = RandR.get_xrr_screen_sizes()
                if len(sizes) == 1:
                    self.randr_exact_size = True
                    _set_root_int("_XPRA_RANDR_EXACT_SIZE",1)
                elif not sizes:
                    # xwayland?
                    self.randr = False
                    self.randr_exact_size = False
            if self.randr_exact_size and not RandR.is_vfb():
                # never add modes to the outputs of a real GPU:
                log("not a virtual display, limiting resolutions to the existing modes")
                self.randr_exact_size = False
            log(f"randr enabled: {self.randr}, exact size={self.randr_exact_size}")
            if not self.randr:
                log.warn("Warning: no X11 RandR support on %r", os.environ.get("DISPLAY", ""))
        return self.randr

    def set_initial_resolution(self) -> None:
        log(f"set_initial_resolution() randr={self.randr}, initial_resolutions={self.initial_resolutions}")
        if self.randr and self.initial_resolutions and is_X11():
            from xpra.x11.error import xlog
            from xpra.x11.vfb_util import set_initial_resolution
            dpi = self.dpi or self.default_dpi
            resolutions = self.initial_resolutions
            with xlog:
                set_initial_resolution(resolutions, dpi)

    def init_display_pid(self) -> None:
        pid = envint("XVFB_PID", 0)
        if not pid:
            log.info("xvfb pid not found")
            pid = self.display_pid
        else:
            log.info(f"xvfb pid {pid}")
        self.display_pid = pid

    def late_cleanup(self, stop=True) -> None:
        with xswallow:
            root_del("XPRA_SERVER_PID")
            root_del("XPRA_SERVER_VERSION")
            if BACKWARDS_COMPATIBLE:
                root_del("XPRA_SERVER")
            if stop:
                root_del("XPRA_SERVER_MODE")
                root_del("_XPRA_RANDR_EXACT_SIZE")
        if stop and POSIX:
            self.kill_display()
        elif self.display_pid:
            log.info("not cleaning up Xvfb %i", self.display_pid)

    def kill_display(self) -> None:
        if not self.display_pid:
            log("unable to kill display: no display pid")
            return
        from xpra.x11.vfb_util import kill_xvfb
        kill_xvfb(self.display_pid)

    # noinspection unreachable-code
    def get_display_bit_depth(self) -> int:
        with xlog:
            from xpra.x11.bindings.window import X11WindowBindings
            X11Window = X11WindowBindings()
            rxid = X11Window.get_root_xid()
            return X11Window.get_depth(rxid)
        return 0

    def get_refresh_rate_for_value(self, invalue) -> int:
        return get_refresh_rate_for_value(self.refresh_rate, invalue)

    def get_info(self, proto) -> dict[str, Any]:
        info = DisplayManager.get_info(self, proto)
        dinfo = info["display"]
        dinfo["randr"] = self.randr
        try:
            from xpra.x11.composite import CompositeHelper
            dinfo["xshm"] = CompositeHelper.XShmEnabled
        except (ImportError, ValueError) as e:
            log("no composite: %s", e)
        try:
            from xpra.x11.bindings.shm import get_shm_info
            dinfo["xshm-attached"] = get_shm_info()
        except ImportError:
            pass
        if self.display_pid:
            dinfo["pid"] = self.display_pid
            try:
                from xpra.util.meminfo import get_mem_info
                dinfo["memory"] = get_mem_info(self.display_pid)
            except Exception as e:
                log("failed to collect vfb memory info: %s", e)
        return info

    def get_ui_info(self, proto, **kwargs) -> dict[str, Any]:
        info = DisplayManager.get_ui_info(self, proto, **kwargs)
        # randr:
        if self.randr:
            with xlog:
                if sizes := self.get_all_screen_sizes():
                    info["randr"] = {
                        "": True,
                        "options": tuple(reversed(sorted(sizes))),
                        "exact": self.randr_exact_size,
                    }
        return info

    ######################################################################
    # display / screen / root window:
    def get_display_size(self) -> tuple[int, int]:
        if self.randr:
            with xsync:
                from xpra.x11.bindings.randr import RandRBindings
                return RandRBindings().get_screen_size()
        return get_root_size()

    def get_all_screen_sizes(self) -> Sequence[tuple[int, int]]:
        # workaround for #2910: the resolutions we add are not seen by XRRSizes!
        # so we keep track of the ones we have added ourselves:
        try:
            from xpra.x11.bindings.randr import RandRBindings
        except ImportError:
            return (get_root_size(), )
        sizes = list(RandRBindings().get_xrr_screen_sizes())
        for w, h in self.randr_sizes_added:
            if (w, h) not in sizes:
                sizes.append((w, h))
        return tuple(sizes)

    def get_max_screen_size(self) -> tuple[int, int]:
        max_w, max_h = get_root_size()
        if self.randr:
            sizes = self.get_all_screen_sizes()
            if len(sizes) >= 1:
                for w, h in sizes:
                    max_w = max(max_w, w)
                    max_h = max(max_h, h)
            if max_w > MAX_WINDOW_SIZE or max_h > MAX_WINDOW_SIZE:
                log.warn("Warning: maximum screen size is very large: %sx%s", max_w, max_h)
                log.warn(" you may encounter window sizing problems")
            log("get_max_screen_size()=%s", (max_w, max_h))
        return max_w, max_h

    def configure_best_screen_size(self) -> tuple[int, int]:
        # return ServerBase.set_best_screen_size(self)
        """ sets the screen size to use the largest width and height used by any of the clients,
            or, with `sharing=combine`, the size needed to hold all of them side by side """
        root_w, root_h = get_root_size()
        if not self.randr:
            return root_w, root_h
        if self.sharing_layout:
            w, h = self.get_combined_screen_size()
            if w <= 0 or h <= 0:
                sharinglog("no combined screen size yet, keeping %ix%i", root_w, root_h)
                return root_w, root_h
            return self.server.set_screen_size(w, h)
        from xpra.server.source.display import DisplayConnection
        display_clients = self.get_sources_by_type(DisplayConnection)
        max_w, max_h = 0, 0
        min_w, min_h = 16384, 16384
        client_sizes = {}
        for ss in display_clients:
            client_size = ss.desktop_size
            if client_size != (0, 0):
                w, h = client_size
                max_w = max(max_w, w)
                max_h = max(max_h, h)
                if w > 0:
                    min_w = min(min_w, w)
                if h > 0:
                    min_h = min(min_h, h)
                client_sizes[ss] = client_size
        if len(client_sizes) > 1:
            log.info("screen used by %i clients, mirrored:", len(client_sizes))
            for ss, (w, h) in client_sizes.items():
                nmonitors = len(ss.get_monitor_definitions() or {})
                log.info("* client %i: %ix%i with %i monitor%s, uuid %s",
                         ss.counter, w, h, nmonitors, "s" * (nmonitors != 1), ss.uuid)
            log.info(" using the largest width and height: %ix%i", max_w, max_h)
        log("current server resolution is %ix%i", root_w, root_h)
        log("maximum client resolution is %ix%i", max_w, max_h)
        log("minimum client resolution is %ix%i", min_w, min_h)
        w, h = max_w, max_h
        log("using %ix%i", w, h)
        if w <= 0 or h <= 0:
            # invalid - use fallback
            return root_w, root_h
        # variant-overridable on the server (e.g. SeamlessServer.set_screen_size wraps this):
        return self.server.set_screen_size(w, h)

    def get_best_screen_size(self, desired_w: int, desired_h: int):
        r = self.do_get_best_screen_size(desired_w, desired_h)
        log("get_best_screen_size%s=%s", (desired_w, desired_h), r)
        return r

    def do_get_best_screen_size(self, desired_w: int, desired_h: int):
        if not self.randr:
            return desired_w, desired_h
        screen_sizes = self.get_all_screen_sizes()
        if (desired_w, desired_h) in screen_sizes:
            return desired_w, desired_h
        if self.randr_exact_size:
            try:
                with xsync:
                    from xpra.x11.bindings.randr import RandRBindings
                    if RandRBindings().add_screen_size(desired_w, desired_h):
                        # we have to wait a little bit
                        # to make sure that everything sees the new resolution
                        # (ideally this method would be split in two and this would be a callback)
                        self.randr_sizes_added.append((desired_w, desired_h))
                        import time
                        time.sleep(0.5)
                        return desired_w, desired_h
            except XError as e:
                log("add_screen_size(%s, %s)", desired_w, desired_h, exc_info=True)
                log.warn("Warning: failed to add resolution %ix%i:", desired_w, desired_h)
                log.warn(" %s", e)
            # re-query:
            screen_sizes = self.get_all_screen_sizes()
        # try to find the best screen size to resize to:
        closest = {}
        for w, h in screen_sizes:
            distance = abs(desired_w * desired_h - w * h)
            closest[distance] = (w, h)
        if not closest:
            log.warn("Warning: no matching resolution found for %sx%s", desired_w, desired_h)
            root_w, root_h = get_root_size()
            return root_w, root_h
        min_dist = sorted(closest.keys())[0]
        new_size = closest[min_dist]
        log("best %s resolution for client(%sx%s) is: %s", desired_w, desired_h, new_size)
        w, h = new_size
        return w, h

    def set_screen_size(self, desired_w: int, desired_h: int):
        log("set_screen_size%s", (desired_w, desired_h))
        # clamp any pre-existing windows to the new screen bounds:
        # (not when combining displays: the clients come and go, and moving
        #  their windows around every time would be more disruptive than helpful)
        window_sub = self.get_subsystem("window")
        if window_sub:
            if self.sharing_layout:
                sharinglog("not clamping windows to %ix%i: the display is shared as %r",
                           desired_w, desired_h, self.sharing_layout)
            else:
                window_sub.clamp_windows_to_screen(desired_w, desired_h)
        # RandR 1.6 fast-path: mirror the client's monitor layout exactly
        # when the dummy driver supports it (seamless servers only - see
        # `mirror_client_layout`). Falls through to standard screen-size
        # resize if the conditions aren't met.
        if self.mirror_client_layout and DUMMY_MONITORS and self.randr and self.randr_exact_size:
            with xlog:
                from xpra.x11.bindings.randr import RandRBindings
                d16 = RandRBindings().is_dummy16()
            log("set_screen_size%s randr=%s, randr_exact_size=%s, is_dummy16()=%s",
                (desired_w, desired_h), self.randr, self.randr_exact_size, d16)
            if d16 and self.mirror_client_monitor_layout():
                return desired_w, desired_h
        root_w, root_h = get_root_size()
        if not self.randr:
            return root_w, root_h
        if desired_w == root_w and desired_h == root_h:
            return root_w, root_h  # unlikely: perfect match already!
        # clients may supply "xdpi" and "ydpi" (v0.15 onwards), or just "dpi", or nothing...
        xdpi = self.xdpi or self.dpi
        ydpi = self.ydpi or self.dpi
        log("set_screen_size(%s, %s) xdpi=%s, ydpi=%s",
            desired_w, desired_h, xdpi, ydpi)
        wmm, hmm = 0, 0
        if xdpi <= 0 or ydpi <= 0:
            # use some sane defaults: either the command line option, or fallback to 96
            # (96 is better than nothing, because we do want to set the dpi
            # to avoid Xdummy setting a crazy dpi from the virtual screen dimensions)
            xdpi = self.default_dpi or 96
            ydpi = self.default_dpi or 96
            # find the "physical" screen dimensions, so we can calculate the required dpi
            # (and do this before changing the resolution)
            client_w, client_h = 0, 0
            sss = self.get_sources_by_type(DisplayConnection)
            for ss in sss:
                screen_sizes = getattr(ss, "screen_sizes", ())
                for s in screen_sizes:
                    if len(s) >= 10:
                        # (display_name, width, height, width_mm, height_mm, monitors,
                        # work_x, work_y, work_width, work_height)
                        client_w = max(client_w, s[1])
                        client_h = max(client_h, s[2])
                        wmm = max(wmm, s[3])
                        hmm = max(hmm, s[4])
            if wmm > 0 and hmm > 0 and client_w > 0 and client_h > 0:
                # calculate "real" dpi:
                xdpi = round(client_w * 25.4 / wmm)
                ydpi = round(client_h * 25.4 / hmm)
                log("calculated DPI: %s x %s (from w: %s / %s, h: %s / %s)",
                    xdpi, ydpi, client_w, wmm, client_h, hmm)
        self.set_physical_size(desired_w, desired_h, xdpi, ydpi, wmm, hmm)

        from xpra.x11.bindings.randr import RandRBindings
        # try to find the best screen size to resize to:
        w, h = self.get_best_screen_size(desired_w, desired_h)

        if w == root_w and h == root_h:
            log.info("best resolution matching %sx%s is unchanged: %sx%s", desired_w, desired_h, w, h)
            return root_w, root_h
        with log.trap_error("Error: failed to set new resolution"):
            with xsync:
                RandRBindings().get_screen_size()
            # Xdummy with randr 1.2:
            log("using XRRSetScreenConfigAndRate with %ix%i", w, h)
            with xsync:
                RandRBindings().set_screen_size(w, h)
            if self.randr_exact_size:
                # Xvfb with randr > 1.2: the resolution has been added
                # we can use XRRSetScreenSize:
                wmm = round(w * 25.4 / xdpi)
                hmm = round(h * 25.4 / ydpi)
                try:
                    with xsync:
                        RandRBindings().xrr_set_screen_size(w, h, wmm, hmm)
                except XError:
                    log("XRRSetScreenSize failed", exc_info=True)
            log("calling RandR.get_screen_size()")
            with xsync:
                root_w, root_h = RandRBindings().get_screen_size()
            log("RandR.get_screen_size()=%s,%s", root_w, root_h)
            log("RandR.get_vrefresh()=%s", RandRBindings().get_vrefresh())
            if root_w != w or root_h != h:
                log.warn("Warning: tried to set resolution to %ix%i", w, h)
                log.warn(" and ended up with %ix%i", root_w, root_h)
            else:
                msg = f"server virtual display now set to {root_w}x{root_h}"
                if desired_w != root_w or desired_h != root_h:
                    msg += f" (best match for {desired_w}x{desired_h})"
                log.info(msg)

            # show dpi via idle_add so server has time to change the screen size (mm)
            self.idle_add(self.show_dpi, xdpi, ydpi)
        return root_w, root_h

    def set_physical_size(self, width: int, height: int, xdpi: int, ydpi: int, wmm=0, hmm=0) -> None:
        if wmm == 0 or hmm == 0:
            wmm = round(width * 25.4 / xdpi)
            hmm = round(height * 25.4 / ydpi)
            log(f"display dimensions for dpi {xdpi}x{ydpi} and resolution {width}x{height} is {wmm}x{hmm}")
        if DUMMY_WIDTH_HEIGHT_MM and self.randr:
            from xpra.x11.bindings.randr import RandRBindings
            # FIXME: we assume there is only one output:
            output = 0
            with xsync:
                RandRBindings().set_output_int_property(output, "WIDTH_MM", wmm)
                RandRBindings().set_output_int_property(output, "HEIGHT_MM", hmm)
        log("set_dpi(%i, %i)", xdpi, ydpi)
        # variant-overridable on the server (e.g. SeamlessServer.set_dpi):
        self.server.set_dpi(xdpi, ydpi)

    def apply_dpi(self) -> None:
        root_w, root_h = get_root_size()
        self.set_physical_size(root_w, root_h, self.xdpi, self.ydpi)

    def show_dpi(self, xdpi: int, ydpi: int):
        root_w, root_h = get_root_size()
        from xpra.x11.bindings.randr import RandRBindings
        wmm, hmm = RandRBindings().get_screen_size_mm()  # ie: (1280, 1024)
        log("RandR.get_screen_size_mm=%s,%s", wmm, hmm)
        actual_xdpi = round(root_w * 25.4 / wmm)
        actual_ydpi = round(root_h * 25.4 / hmm)
        log("actual DPI calculated from display dimensions %ix%i and resolution %ix%i: %ix%i",
            wmm, hmm, root_w, root_h, actual_xdpi, actual_ydpi)
        if abs(actual_xdpi - xdpi) <= 1 and abs(actual_ydpi - ydpi) <= 1:
            log.info("DPI set to %s x %s", actual_xdpi, actual_ydpi)
            log("wanted: %s x %s", xdpi, ydpi)
        else:
            # should this be a warning:
            log_fn = log.info
            maxdelta = max(abs(actual_xdpi - xdpi), abs(actual_ydpi - ydpi))
            if maxdelta >= 10:
                log_fn = log.warn
            messages = [
                f"DPI set to {actual_xdpi} x {actual_ydpi} (wanted {xdpi} x {ydpi})",
            ]
            if maxdelta >= 10:
                messages.append("you may experience scaling problems, such as huge or small fonts, etc")
                messages.append("to fix this issue, try the dpi switch, or use a patched Xorg dummy driver")
                self.notify_dpi_warning("\n".join(messages))
            for i, message in enumerate(messages):
                log_fn("%s%s", ["", " "][i > 0], message)

    ######################################################################
    # `sharing=combine`: give each client its own area of the virtual display

    def verify_sharing_layout(self) -> None:
        """ `sharing=combine` needs a display we can re-configure with RandR 1.6
            (the clients that cannot use it are checked as they connect, see `get_client_monitor_layouts`) """
        if not self.sharing_layout:
            return
        if not self.mirror_client_layout:
            self.disable_sharing_layout("this session uses a fixed virtual display")
            return
        if not self.randr or not self.randr_exact_size:
            self.disable_sharing_layout("this display cannot be resized with RandR")
            return
        if not DUMMY_MONITORS:
            self.disable_sharing_layout("monitor emulation is disabled")
            return
        with xlog:
            from xpra.x11.bindings.randr import RandRBindings
            if not RandRBindings().is_dummy16():
                self.disable_sharing_layout("this display does not support RandR 1.6 monitors")
        if self.sharing_layout:
            sharinglog("sharing layout %r can be used on this display", self.sharing_layout)

    def client_exited(self, _server, _source) -> None:
        # the areas of the remaining clients have to be re-assigned:
        # (the source has already been removed from the server's sources)
        if not self.sharing_layout:
            return
        # this signal fires from the network thread,
        # but re-configuring the display requires the UI thread:
        self.idle_add(self.recombine_display)

    def recombine_display(self) -> None:
        if not self.sharing_layout:
            return
        if not self.get_sources_by_type(DisplayConnection):
            # nobody left to re-assign the display to
            sharinglog("recombine_display() no display clients left")
            return
        sharinglog("recombine_display() re-configuring the combined display")
        w, h = self.configure_best_screen_size()
        if w > 0 and h > 0:
            self.set_desktop_geometry_attributes(w, h)
        self.send_updated_screen_size()

    def get_client_monitor_layouts(self) -> tuple[list, list[dict[int, Any]]]:
        """ the monitor definitions of each display client, with their own (0, 0) origin,
            skipping the clients that cannot be given an area of their own """
        sources: list = []
        layouts: list[dict[int, Any]] = []
        for ss in self.get_sources_by_type(DisplayConnection):
            if not ss.monitor_relative:
                # we would not be able to map the absolute positions it sends back onto its area,
                # so it is not given one and sees the whole display instead:
                if first_time(f"sharing-not-monitor-relative-{ss.uuid}"):
                    sharinglog.warn("Warning: client %i does not send monitor relative coordinates", ss.counter)
                    sharinglog.warn(" it will see the whole display instead of an area of its own")
                continue
            mdef = ss.get_normalized_monitor_definitions()
            if not mdef:
                # a client that does not tell us about its monitors
                # still gets an area matching its display:
                w, h = ss.desktop_size
                if w <= 0 or h <= 0:
                    sharinglog("no monitors and no desktop size for %s", ss)
                    continue
                sharinglog("client %i did not send any monitors, using its %ix%i display size",
                           ss.counter, w, h)
                mdef = {0: {"name": f"client{ss.counter}", "geometry": (0, 0, w, h)}}
            sharinglog("client %i monitors: %s", ss.counter, monitor_geometries(mdef))
            sources.append(ss)
            layouts.append(mdef)
        return sources, layouts

    def combine_client_monitor_layout(self) -> dict[int, Any]:
        """ place every client's monitors side by side and give each client its own area,
            falling back to sharing the display as usual if we cannot """
        try:
            return self.do_combine_client_monitor_layout()
        except Exception:
            sharinglog("combine_client_monitor_layout()", exc_info=True)
            sharinglog.error("Error: failed to combine the displays of the connected clients")
            self.clear_display_areas()
            return {}

    def do_combine_client_monitor_layout(self) -> dict[int, Any]:
        from xpra.x11.bindings.randr import RandRBindings
        randr = RandRBindings()
        sources, layouts = self.get_client_monitor_layouts()
        vertical = self.sharing_layout.endswith("-vertical")
        mdef, areas = combine_monitor_layouts(layouts, vertical)
        sharinglog("combining %i client layouts %s: monitors=%s, areas=%s",
                   len(layouts), "vertically" if vertical else "horizontally",
                   monitor_geometries(mdef), areas)
        if not mdef:
            sharinglog("no monitors to combine")
            self.clear_display_areas()
            return {}
        self.log_combined_layout(sources, layouts, areas, mdef, vertical)
        with xsync:
            crtcs = randr.get_crtc_count()
        if len(mdef) > crtcs:
            sharinglog.warn("Warning: cannot combine the displays of %i clients", len(sources))
            sharinglog.warn(" %i monitors were requested but this display only has %i", len(mdef), crtcs)
            self.clear_display_areas()
            return {}
        mdef = adjust_monitor_refresh_rate(self.refresh_rate, mdef)
        with xlog:
            if not randr.set_crtc_config(mdef):
                sharinglog.warn("Warning: failed to configure the combined display")
                self.clear_display_areas()
                return {}
        self.assign_display_areas(sources, areas)
        return mdef

    @staticmethod
    def log_combined_layout(sources: Sequence, layouts: Sequence, areas: Sequence, mdef: dict[int, Any], vertical: bool) -> None:
        """ show how the combined display is calculated from the display of each client """
        nclients = len(sources)
        # a single client gets the whole display, there is nothing to explain:
        log_fn = log.info if nclients > 1 else sharinglog
        log_fn("screen used by %i client%s, combined %s:",
               nclients, "s" * (nclients != 1), "vertically" if vertical else "horizontally")
        for ss, monitors, (x, y, w, h) in zip(sources, layouts, areas):
            log_fn("* client %i: %ix%i with %i monitor%s, placed at %i,%i",
                   ss.counter, w, h, len(monitors), "s" * (len(monitors) != 1), x, y)
        w, h = monitors_bounding_box(mdef)
        how = "the tallest height and the sum of the widths"
        if vertical:
            how = "the widest width and the sum of the heights"
        log_fn(" using %s: %ix%i with %i monitor%s", how, w, h, len(mdef), "s" * (len(mdef) != 1))

    def clear_display_areas(self) -> None:
        self.assign_display_areas()

    def assign_display_areas(self, sources: Sequence = (), areas: Sequence = ()) -> None:
        """ give each client its own area of the virtual display,
            every client that has not been given one shares the whole display as usual """
        assigned = dict(zip(sources, areas))
        sharinglog("assign_display_areas(%s, %s)", sources, areas)
        for ss in self.get_sources_by_type(DisplayConnection):
            area = assigned.get(ss)
            if not area or area[2] <= 0 or area[3] <= 0:
                sharinglog("client %i shares the whole display", ss.counter)
                ss.set_display_area(None)
                continue
            x, y, w, h = area
            if ss.get_display_origin() == (x, y) and ss.get_display_area_size() == (w, h):
                sharinglog("client %i keeps its %ix%i area at %i,%i", ss.counter, w, h, x, y)
                continue
            ss.set_display_area(rectangle(x, y, w, h))
            log.info("client %i uses %ix%i of the display at %i,%i", ss.counter, w, h, x, y)
        # the windows may now be on a different client's area:
        if window_sub := self.get_subsystem("window"):
            window_sub.update_windows_visibility()

    def get_combined_screen_size(self) -> tuple[int, int]:
        """ the size needed to hold every client's monitors, placed side by side """
        _, layouts = self.get_client_monitor_layouts()
        mdef = combine_monitor_layouts(layouts, self.sharing_layout.endswith("-vertical"))[0]
        size = monitors_bounding_box(mdef)
        sharinglog("get_combined_screen_size()=%s from %i client layouts", size, len(layouts))
        return size

    def mirror_client_monitor_layout(self) -> dict[int, Any]:
        if not self.randr:
            return {}
        from xpra.x11.bindings.randr import RandRBindings
        with xsync:
            if not RandRBindings().is_dummy16():
                raise RuntimeError("cannot match monitor layout without RandR 1.6")
        if self.sharing_layout:
            return self.combine_client_monitor_layout()
        # if we have a single display client,
        # see if we can emulate its monitor geometry exactly
        from xpra.server.source.display import DisplayConnection
        display_clients = self.get_sources_by_type(DisplayConnection)
        log("%i display clients: %s", len(display_clients), display_clients)
        if len(display_clients) != 1:
            return {}
        ss = display_clients[0]
        mdef = ss.get_monitor_definitions()
        if not BACKWARDS_COMPATIBLE:
            mdef = ss.get_normalized_monitor_definitions()
        if not mdef:
            return {}
        log(f"monitor definition from client {ss}: {mdef}")
        mdef = adjust_monitor_refresh_rate(self.refresh_rate, mdef)
        log("refresh-rate adjusted using %s: %s", self.refresh_rate, mdef)
        with xlog:
            RandRBindings().set_crtc_config(mdef)
        return mdef

    def notify_dpi_warning(self, body: str) -> None:
        display_sources = self.get_sources_by_type(DisplayConnection)
        if len(display_sources) == 1:
            ss = display_sources[0]
            if first_time("DPI-warning-%s" % ss.uuid):
                may_notify_client(ss, NotificationID.DPI, "DPI Issue", body, icon_name="font")

    ################################################################
    # display-ungrab:

    # noinspection method-may-be-static
    def _process_ungrab(self, proto, _packet: Packet) -> None:
        # ignore the window id: wid = packet.get_wid()
        grablog("display ungrab from %s", proto)
        if self.is_readonly(proto):
            return
        x11_ungrab()

    @staticmethod
    def x11_ungrab():
        x11_ungrab()

    # noinspection PyMethodMayBeStatic
    def init_packet_handlers(self) -> None:
        DisplayManager.init_packet_handlers(self)
        self.add_packets("display-ungrab", main_thread=True)
        if BACKWARDS_COMPATIBLE:
            self.add_legacy_alias("force-ungrab", "display-ungrab")

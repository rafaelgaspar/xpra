# This file is part of Xpra.
# Copyright (C) 2025 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import struct
from typing import Sequence, Any, Final

from xpra.util.env import envbool
from xpra.os_util import gi_import
from xpra.clipboard.common import ClipboardCallback, env_timeout
from xpra.clipboard.targets import must_discard_extra, must_discard, TEXT_TARGETS
from xpra.clipboard.proxy import ClipboardProxyCore, filter_data
from xpra.util.env import first_time
from xpra.util.gobject import one_arg_signal, n_arg_signal
from xpra.util.str_fn import Ellipsizer, bytestostr, csv, memoryview_to_bytes
from xpra.x11.selection.common import xatoms_to_strings, strings_to_xatoms
from xpra.x11.bindings.core import constants
from xpra.x11.bindings.window import PropertyError, X11WindowBindings
from xpra.x11.common import X11Event
from xpra.x11.error import xsync, XError
from xpra.x11.info import get_wininfo, WinInfo
from xpra.log import Logger

GObject = gi_import("GObject")
GLib = gi_import("GLib")

log = Logger("x11", "clipboard")

CONVERT_TIMEOUT = env_timeout("CONVERT", 100)
# once the owner has started an incremental transfer, the whole of it must complete within:
INCR_TIMEOUT = env_timeout("INCR", 1000, max_time=60000)

X11Window = X11WindowBindings()
CurrentTime: Final[int] = constants["CurrentTime"]
StructureNotifyMask: Final[int] = constants["StructureNotifyMask"]

MAX_DATA_SIZE: int = 4 * 1024 * 1024
RECLAIM = envbool("XPRA_CLIPBOARD_RECLAIM", True)
BLOCKLISTED_CLIPBOARD_CLIENTS: list[str] = os.environ.get(
    "XPRA_BLOCKLISTED_CLIPBOARD_CLIENTS",
    "clipit,Software,gnome-shell"
).split(",")
log("BLOCKLISTED_CLIPBOARD_CLIENTS=%s", BLOCKLISTED_CLIPBOARD_CLIENTS)
DEFAULT_TRANSLATED_TARGETS: str = "#".join(
    (
        "text/plain;charset=utf-8:UTF8_STRING,text/plain,public.utf8-plain-text",
        "TEXT:text/plain,text/plain;charset=utf-8,UTF8_STRING,public.utf8-plain-text",
        "STRING:text/plain,text/plain;charset=utf-8,UTF8_STRING,public.utf8-plain-text",
        "UTF8_STRING:text/plain;charset=utf-8,text/plain,public.utf8-plain-text",
        "GTK_TEXT_BUFFER_CONTENTS:UTF8_STRING,text/plain,public.utf8-plain-text",
    )
)


def parse_translated_targets(v: str) -> dict[str, list[str]]:
    trans: dict[str, list[str]] = {}
    # we can't use ";" or "/" as separators
    # because those are used in mime-types,
    # and we use "," and ":" ourselves..
    for entry in v.split("#"):
        parts = entry.split(":", 1)
        if len(parts) != 2:
            log.warn("Warning: invalid clipboard translated target:")
            log.warn(f" {entry!r}")
            continue
        src_target = parts[0]
        dst_targets = parts[1].split(",")
        trans[src_target] = dst_targets
    return trans


TRANSLATED_TARGETS = parse_translated_targets(os.environ.get(
    "XPRA_CLIPBOARD_TRANSLATED_TARGETS",
    DEFAULT_TRANSLATED_TARGETS)
)
log("TRANSLATED_TARGETS=%s", TRANSLATED_TARGETS)


class IncrTransfer:
    """
    The state of one incremental transfer.
    The owner delivers it one chunk at a time on the property the conversion named,
    which is also what tells two concurrent transfers apart
    """
    __slots__ = ("size", "dtype", "chunks", "timer")

    def __init__(self, size: int):
        self.size = size
        self.dtype = ""
        self.chunks: list[bytes] = []
        self.timer = 0

    def __repr__(self):
        return f"IncrTransfer({self.size} bytes as {self.dtype!r})"


class ClipboardProxy(ClipboardProxyCore, GObject.GObject):
    __gsignals__ = {
        "x11-client-message-event": one_arg_signal,
        "x11-selection-request": one_arg_signal,
        "x11-selection-clear": one_arg_signal,
        "x11-property-notify-event": one_arg_signal,
        "x11-xfixes-selection-notify-event": one_arg_signal,
        #
        "send-clipboard-token": one_arg_signal,
        "send-clipboard-request": n_arg_signal(2),
    }

    def __init__(self, xid: int, selection="CLIPBOARD"):
        ClipboardProxyCore.__init__(self, selection)
        GObject.GObject.__init__(self)
        self.xid: int = xid
        self.owned: bool = False
        self._want_targets: bool = False
        self.remote_requests: dict[str, list[tuple[int, str, str, float]]] = {}
        self.local_requests: dict[str, dict[int, tuple[int, ClipboardCallback, int]]] = {}
        self.local_request_counter: int = 0
        self.targets: Sequence[str] = ()
        self.target_data: dict[str, tuple[str, int, Any]] = {}
        self._targets_owner: int = 0
        self.incr_transfers: dict[str, IncrTransfer] = {}
        self._selection_generation: int = 0

    def __repr__(self):
        return f"X11ClipboardProxy({self._selection})"

    def cleanup(self) -> None:
        log("%s.cleanup()", self)
        # give up selection:
        # (disabled because this crashes GTK3 on exit)
        # if self.owned:
        #    self.owned = False
        #    with xswallow:
        #        X11Window.XSetSelectionOwner(0, self._selection)
        # empty replies for all pending requests,
        # this will also cancel any pending timers:
        for target in tuple(self.remote_requests):
            self.got_contents(target)
        for target in tuple(self.local_requests):
            self.got_local_contents(target)
        for atom in tuple(self.incr_transfers):
            self.cancel_incr_transfer(atom)

    def got_token(self, targets, target_data=None, claim=True, synchronous_client=False) -> None:
        # any token we have scheduled but not sent yet is left alone:
        # it belongs to a local owner change the peer has not heard about,
        # and this token was sent before the peer could know about it.
        # `do_emit_token` re-checks the selection owner when it fires,
        # so it turns into a no-op by itself if we claim the selection here
        if not self._enabled:
            return
        self._got_token_events += 1
        log("got token, selection=%s, targets=%s, target data=%s, claim=%s, can-receive=%s",
            self._selection, targets, Ellipsizer(target_data), claim, self._can_receive)
        if claim:
            self._have_token = True
        if self._can_receive:
            if target_data:
                # ensure we also expose the targets in the target_data:
                # ie: {'UTF8_STRING': ('UTF8_STRING', 8, b'foobar')}
                targets = list(targets) + list(target_data.keys())
            self.targets = tuple(bytestostr(x) for x in (targets or ()))
            self.target_data = target_data or {}
            self._targets_owner = self.xid
            if targets and claim:
                xatoms = strings_to_xatoms(targets)
                self.got_contents("TARGETS", "ATOM", 32, xatoms)
            if target_data and synchronous_client and claim:
                targets = target_data.keys()
                text_targets = tuple(x for x in targets if x in TEXT_TARGETS)
                if text_targets:
                    target = text_targets[0]
                    dtype, dformat, data = target_data.get(target)
                    dtype = bytestostr(dtype)
                    self.got_contents(target, dtype, dformat, data)
        if self._can_receive and claim:
            # the remote end now owns the clipboard,
            # which invalidates any local token collection still in progress:
            self._selection_generation += 1
            self.claim()

    def claim(self) -> None:
        time = 0
        try:
            with xsync:
                owner = X11Window.XGetSelectionOwner(self._selection)
                self.owned = owner == self.xid
                if RECLAIM or not self.owned:
                    setsel = X11Window.XSetSelectionOwner(self.xid, self._selection, time)
                    owner = X11Window.XGetSelectionOwner(self._selection)
                    self.owned = owner == self.xid
                    log("claim_selection: set selection owner returned %s, owner=%#x, owned=%s",
                        setsel, owner, self.owned)
                else:
                    log("we already owned the %r selection", self._selection)
                if not self.owned:
                    log.warn("Warning: we failed to get ownership of the '%s' clipboard selection", self._selection)
                    return
                # send announcement:
                log("claim_selection: sending message to root window")
                from xpra.x11.bindings.core import get_root_xid
                root_xid = get_root_xid()
                event_mask = StructureNotifyMask
                X11Window.sendClientMessage(root_xid, root_xid, False, event_mask, "MANAGER",
                                            time or CurrentTime, self._selection, self.xid)
                log(f"claim_selection {self._selection} done")
        except Exception:
            log("failed to claim selection '%s'", self._selection, exc_info=True)
            raise

    def do_x11_client_message_event(self, event: X11Event) -> None:
        if event.message_type == "_GTK_LOAD_ICONTHEMES":
            # ignore this crap
            return
        log.info(f"Unexpected X11 message received by clipboard window {event.window:x}")
        log.info(f" {event}")

    ############################################################################
    # forward local requests to the remote clipboard:
    ############################################################################
    def do_selection_request_event(self, event) -> None:
        # an app is requesting clipboard data from us
        log("do_selection_request_event(%s)", event)
        requestor = event.requestor
        if not requestor:
            log.warn("Warning: clipboard selection request without a window, dropped")
            return
        # the blocklist below matches against this, so it cannot be deferred
        # the way the debug-only call sites can:
        wininfo = get_wininfo(requestor)
        prop = event.property
        target = str(event.target)
        log("clipboard request for %s from window %s, target=%s, prop=%s",
            self._selection, wininfo, target, prop)
        if not target:
            log.warn("Warning: ignoring clipboard request without a TARGET")
            log.warn(" coming from %s", wininfo)
            return
        if not prop:
            log.warn("Warning: ignoring clipboard request without a property")
            log.warn(" coming from %s", wininfo)
            return

        def nodata() -> None:
            self.set_selection_response(requestor, target, prop, "STRING", 8, b"", time=event.time)

        if not self._enabled:
            nodata()
            return
        blocklisted = tuple(client for client in BLOCKLISTED_CLIPBOARD_CLIENTS if client in wininfo)
        if blocklisted:
            if first_time(f"clipboard-blocklisted:{blocklisted}"):
                log.warn("receiving clipboard requests from blocklisted client:")
                log.warn(f" {wininfo},")
                log.warn(" all further requests will be silently ignored")
            log("responding with nodata for blocklisted client '%s'", wininfo)
            return
        if not self.owned:
            log.warn("Warning: clipboard selection request received,")
            log.warn(" coming from %s", wininfo)
            log.warn(" but we don't own the selection,")
            log.warn(" sending an empty reply")
            nodata()
            return
        if not self._can_receive:
            log.warn("Warning: clipboard selection request received,")
            log.warn(" coming from %s", wininfo)
            log.warn(" but receiving remote data is disabled,")
            log.warn(" sending an empty reply")
            nodata()
            return
        if must_discard(target):
            log.info("clipboard %s rejecting request for invalid target '%s'", self._selection, target)
            log.info(" coming from %s", wininfo)
            nodata()
            return

        if target == "TARGETS":
            if self.targets:
                log("using existing TARGETS value as response: %s", self.targets)
                xatoms = strings_to_xatoms(self.targets)
                self.set_selection_response(requestor, target, prop, "ATOM", 32, xatoms, event.time)
                return
            if "TARGETS" not in self.remote_requests:
                self.emit("send-clipboard-request", self._selection, "TARGETS")
            # when appending, the time may not be honoured
            # and we may reply with data from an older request
            self.remote_requests.setdefault("TARGETS", []).append((requestor, target, prop, event.time))
            return

        req_target = target
        if self.targets and target not in self.targets:
            translated_targets = TRANSLATED_TARGETS.get(target, ())
            can_translate = tuple(x for x in translated_targets if x in self.targets)
            log_fn = log.debug
            if not can_translate and first_time(f"client-{wininfo}-invalidtarget-{target}"):
                log_fn = log.info
            log_fn(f"client {wininfo} is requesting an unknown target: {target!r}")
            if can_translate:
                req_target = can_translate[0]
                log_fn(f" using {req_target!r} instead")
            else:
                log_fn(" valid targets: %s", csv(self.targets))
                if must_discard_extra(target):
                    log_fn(" dropping the request")
                    nodata()
                    return

        target_data = self.target_data.get(req_target)
        if target_data and self._have_token:
            # we have it already
            dtype, dformat, data = target_data
            dtype = bytestostr(dtype)
            log("setting target data for '%s': %s, %s, %s (%s)",
                target, dtype, dformat, Ellipsizer(data), type(data))
            self.set_selection_response(requestor, target, prop, dtype, dformat, data, event.time)
            return

        if waiting := self.remote_requests.setdefault(req_target, []):
            log("already waiting for '%s' remote request: %s", req_target, waiting)
        else:
            self.emit("send-clipboard-request", self._selection, req_target)
        waiting.append((requestor, target, prop, event.time))

    def set_selection_response(self, requestor: int, target: str, prop: str, dtype: str, dformat: int,
                               data, time: float = 0.0) -> None:
        log("set_selection_response(%s, %s, %s, %s, %s, %r, %i)",
            requestor, target, prop, dtype, dformat, Ellipsizer(data), time)
        # answer the selection request:
        if not prop:
            log.warn("Warning: cannot set clipboard response")
            log.warn(" property is unset for requestor %s", get_wininfo(requestor))
            return
        try:
            with xsync:
                if data is not None:
                    X11Window.XChangeProperty(requestor, prop, dtype, dformat, memoryview_to_bytes(data))
                else:
                    # maybe even delete the property?
                    # X11Window.XDeleteProperty(xid, prop)
                    prop = ""
                X11Window.sendSelectionNotify(requestor, self._selection, target, prop, time)
        except XError as e:
            log("failed to set selection", exc_info=True)
            log.warn(f"Warning: failed to set selection for target {target!r}")
            log.warn(" on requestor %s", get_wininfo(requestor))
            log.warn(f" property {prop!r}")
            log.warn(f" {e}")

    def got_contents(self, target: str, dtype: str = "", dformat: int = 0, data=None) -> None:
        # if this is the special target 'TARGETS', cache the result:
        if target == "TARGETS" and dtype == "ATOM" and dformat == 32:
            self.targets = xatoms_to_strings(data)
            self._targets_owner = self.xid
        # the remote peer sent us a response,
        # find all the pending requests for this target
        # and give them the response they are waiting for:
        pending = self.remote_requests.pop(target, [])
        log("got_contents%s pending=%s",
            (target, dtype, dformat, Ellipsizer(data)), csv(pending))
        for requestor, actual_target, prop, time in pending:
            if log.is_debug_enabled():
                log("setting response %s: %s as '%s' on property '%s' of window %s as %s",
                    type(data), Ellipsizer(data), actual_target, prop, get_wininfo(requestor), dtype)
            if actual_target != target and dtype == target:
                dtype = actual_target
            self.set_selection_response(requestor, actual_target, prop, dtype, dformat, data, time)

    ############################################################################
    # local clipboard events, which may or may not be sent to the remote end
    ############################################################################
    def do_selection_notify_event(self, event) -> None:
        owned = self.owned
        xid = 0
        if event.owner:
            xid = event.owner
        self.owned = bool(xid) and xid == self.xid
        log("do_selection_notify_event(%s) owned=%s, was %s (owner=%#x, xid=%#x), enabled=%s, can-send=%s",
            event, self.owned, owned, xid, self.xid, self._enabled, self._can_send)
        if not self._enabled:
            return
        if self.owned or not self._can_send or xid == 0:
            return
        self.do_owner_changed()
        self.schedule_emit_token()

    def do_emit_token(self) -> bool:
        # we collect the targets (and contents for greedy clients) here,
        # *after* the back-off delay, so that we send the latest clipboard state:
        generation = self._selection_generation
        with xsync:
            owner = X11Window.XGetSelectionOwner(self._selection)
        if owner == self.xid:
            log("not emitting token for %s: the selection contains remote data", self._selection)
            return False
        if owner != self._targets_owner:
            self.targets = ()
            self.target_data = {}
            self._targets_owner = 0
        if not (self._want_targets or self._greedy_client):
            self.emit("send-clipboard-token", {"targets": (), "data": {}})
            return True

        # we need the targets, and the target data for greedy clients:

        def send_token_with_targets() -> None:
            if generation != self._selection_generation:
                return
            self.emit("send-clipboard-token", {"targets": tuple(self.targets), "data": {}})

        def with_targets(otargets: Sequence[str]) -> None:
            if not self._greedy_client:
                send_token_with_targets()
                return
            targets = self.get_eager_targets(otargets)
            log(f"get_eager_targets({otargets})={targets}")
            if not targets:
                send_token_with_targets()
                return

            def got_target_data(target_data) -> None:
                if generation != self._selection_generation:
                    return
                self.emit("send-clipboard-token", {
                    "targets": tuple(otargets),
                    "data": target_data,
                })

            self.collect_contents(targets, got_target_data)

        if self.targets:
            with_targets(self.targets)
            return True

        def got_targets(dtype: str, dformat: int, data: Any) -> None:
            if generation != self._selection_generation:
                return
            with xsync:
                current_owner = X11Window.XGetSelectionOwner(self._selection)
            if current_owner != owner:
                return
            if not dtype:
                log("get targets failed, so we don't own the clipboard any more")
                # don't emit the token:
                return
            assert dtype == "ATOM" and dformat == 32
            self.targets = xatoms_to_strings(data)
            self._targets_owner = owner
            log("got_targets: %s", self.targets)
            with_targets(self.targets)

        self.get_contents("TARGETS", got_targets)
        return True

    def choose_targets(self, targets) -> Sequence[str]:
        return self.get_eager_targets(targets)

    def do_selection_clear_event(self, event) -> None:
        log("do_x11_selection_clear(%s) was owned=%s", event, self.owned)
        if not self._enabled:
            return
        self.owned = False
        self.do_owner_changed()

    def do_owner_changed(self) -> None:
        log("do_owner_changed()")
        self._selection_generation += 1
        self.target_data = {}
        self.targets = ()
        self._targets_owner = 0
        super().do_owner_changed()

    def get_contents(self, target: str, got_contents: ClipboardCallback) -> None:
        log("get_contents(%s, %s) owned=%s, have-token=%s",
            target, got_contents, self.owned, self._have_token)
        with xsync:
            owner = X11Window.XGetSelectionOwner(self._selection)
        self.owned = owner == self.xid
        if target == "TARGETS":
            if self.targets and self._targets_owner == owner:
                xatoms = strings_to_xatoms(self.targets)
                got_contents("ATOM", 32, xatoms)
                return
        else:
            if self._targets_owner == owner and (target_data := self.target_data.get(target)):
                dtype, dformat, value = target_data
                got_contents(dtype, dformat, value)
                return
        prop = f"{self._selection}-{target}"
        with xsync:
            owner = X11Window.XGetSelectionOwner(self._selection)
            self.owned = owner == self.xid
            if self.owned:
                # we are the clipboard owner!
                log("we are the %s selection owner, using empty reply", self._selection)
                got_contents("", 0, b"")
                return
            # ICCCM: a conversion request should carry the timestamp of whatever caused it.
            # We have no such event - the peer asked for this over the network - so take the
            # server's own idea of the time. An owner is entitled to refuse a request from
            # outside the period it has owned the selection, and `CurrentTime` also tells us
            # nothing about which request an answer belongs to.
            request_time = X11Window.get_server_time(self.xid)
            request_id = self.local_request_counter
            self.local_request_counter += 1
            timer = GLib.timeout_add(CONVERT_TIMEOUT, self.timeout_get_contents, target, request_id)
            self.local_requests.setdefault(target, {})[request_id] = (timer, got_contents, request_time)
            log("requesting local XConvertSelection from %s as '%s' into '%s' at %s",
                WinInfo(owner), target, prop, request_time)
            X11Window.ConvertSelection(self._selection, target, prop, self.xid, time=request_time)

    def timeout_get_contents(self, target: str, request_id: int) -> None:
        try:
            target_requests = self.local_requests.get(target)
            if target_requests is None:
                return
            timer, got_contents, _request_time = target_requests.pop(request_id)
            if not target_requests:
                del self.local_requests[target]
        except KeyError:
            return
        GLib.source_remove(timer)
        log.warn("Warning: %s selection request for '%s' timed out", self._selection, target)
        log.warn(" request %i", request_id)
        if target not in self.local_requests:
            # nobody is waiting for the rest of the data:
            self.cancel_incr_transfer(f"{self._selection}-{target}")
        self.no_contents(target, got_contents)

    @staticmethod
    def no_contents(target: str, got_contents: ClipboardCallback) -> None:
        if target == "TARGETS":
            got_contents("ATOM", 32, b"")
        else:
            got_contents("", 0, b"")

    def extend_request_timers(self, target: str, timeout: int) -> None:
        # the owner has answered, `CONVERT_TIMEOUT` is too short for the data to follow:
        target_requests = self.local_requests.get(target, {})
        for request_id, (timer, got_contents, request_time) in tuple(target_requests.items()):
            GLib.source_remove(timer)
            timer = GLib.timeout_add(timeout, self.timeout_get_contents, target, request_id)
            target_requests[request_id] = (timer, got_contents, request_time)

    def take_local_request(self, target: str, request_time: int) -> tuple:
        # the timestamp is what tells two conversions of the same target apart:
        # should the server ever hand out the same one twice, the older request
        # is the one which gets the answer
        target_requests = self.local_requests.get(target, {})
        for request_id, request in tuple(target_requests.items()):
            if request[2] != request_time:
                continue
            del target_requests[request_id]
            if not target_requests:
                del self.local_requests[target]
            return request
        return ()

    def do_conversion_notify_event(self, event: X11Event) -> None:
        log("do_conversion_notify_event(%s)", event)
        if not self._enabled or event.requestor != self.xid or event.selection != self._selection:
            return
        if event.property:
            # a conversion which succeeded is collected from the property it names,
            # see `do_property_notify`
            return
        # `property=None` is the owner - or the X server, when there is no owner -
        # telling us that this representation is not available. Without it, the request
        # could only ever end in `timeout_get_contents` and its warning.
        target = str(event.target)
        request = self.take_local_request(target, event.time)
        if not request:
            log("no %r request made at %s is still waiting for an answer", target, event.time)
            return
        timer, got_contents, _request_time = request
        GLib.source_remove(timer)
        log("%s conversion to %r was refused", self._selection, target)
        self.no_contents(target, got_contents)

    def do_property_notify(self, event) -> None:
        log("do_property_notify(%s)", event)
        if not self._enabled:
            return
        # ie: atom="PRIMARY-TARGETS", atom="PRIMARY-STRING"
        atom = event.atom
        parts = atom.split("-", 1)
        assert len(parts) == 2
        # selection = parts[0]        # ie: PRIMARY
        target = parts[1]  # ie: VALUE
        # only the chunks written to this very property belong to its transfer:
        # any other conversion running at the same time has a property of its own
        incr = self.incr_transfers.get(atom)
        try:
            with xsync:
                dtype, dformat = X11Window.GetWindowPropertyType(self.xid, atom, True)
                data = X11Window.XGetWindowProperty(self.xid, atom, dtype, buffer_size=MAX_DATA_SIZE, incr=True)
                # all the code below deals with INCRemental transfers:
                if dtype == "INCR" and incr is None:
                    # start of an incremental transfer, extract the size
                    assert dformat == 32
                    size = struct.unpack("@L", data)[0]
                    log("incremental clipboard data of size %s on %r", size, atom)
                    self.incr_transfers[atom] = IncrTransfer(size)
                    self.reschedule_incr_timer(atom)
                    self.extend_request_timers(target, INCR_TIMEOUT)
                    X11Window.XDeleteProperty(self.xid, atom)
                    return
                if incr is not None:
                    # incremental is now in progress:
                    if not incr.dtype:
                        incr.dtype = dtype
                    elif incr.dtype != dtype:
                        log.error("Error: invalid change of data type")
                        log.error(" from %s to %s", incr.dtype, dtype)
                        self.cancel_incr_transfer(atom)
                        return
                    if data:
                        log("got incremental data: %i bytes", len(data))
                        incr.chunks.append(data)
                        self.reschedule_incr_timer(atom)
                        X11Window.XDeleteProperty(self.xid, atom)
                        return
                    data = b"".join(incr.chunks)
                    log("got incremental data termination, total size=%i bytes", len(data))
                    self.cancel_incr_transfer(atom)
                    self.got_local_contents(target, dtype, dformat, data)
                    return
        except PropertyError:
            log("do_property_notify() property '%s' is gone?", atom, exc_info=True)
            return
        log("%s=%s (%s : %s)", atom, Ellipsizer(data), dtype, dformat)
        if target == "TARGETS":
            self.targets = xatoms_to_strings(data or b"")
        self.got_local_contents(target, dtype, dformat, data)

    def got_local_contents(self, target: str, dtype="", dformat: int = 8, data=b"") -> None:
        data = filter_data(dtype, dformat, data)
        target_requests = self.local_requests.pop(target, {})
        for timer, got_contents, _request_time in target_requests.values():
            if log.is_debug_enabled():
                log("got_local_contents: calling %s%s",
                    got_contents, (dtype, dformat, Ellipsizer(data)))
            GLib.source_remove(timer)
            got_contents(dtype, dformat, data)

    def reschedule_incr_timer(self, atom: str) -> None:
        incr = self.incr_transfers.get(atom)
        if incr is None:
            return
        if idt := incr.timer:
            incr.timer = 0
            GLib.source_remove(idt)
        incr.timer = GLib.timeout_add(1 * 1000, self.incr_transfer_timeout, atom)

    def cancel_incr_transfer(self, atom: str) -> None:
        incr = self.incr_transfers.pop(atom, None)
        if incr and incr.timer:
            idt = incr.timer
            incr.timer = 0
            GLib.source_remove(idt)

    def incr_transfer_timeout(self, atom: str) -> None:
        log.warn("Warning: incremental data timeout for %r", atom)
        # this is the timer firing, so it must not be removed again:
        incr = self.incr_transfers.pop(atom, None)
        if incr:
            incr.timer = 0
        # the data is never going to arrive, so don't leave the requests waiting for it:
        target = atom.split("-", 1)[1]
        for timer, got_contents, _request_time in self.local_requests.pop(target, {}).values():
            GLib.source_remove(timer)
            self.no_contents(target, got_contents)


GObject.type_register(ClipboardProxy)

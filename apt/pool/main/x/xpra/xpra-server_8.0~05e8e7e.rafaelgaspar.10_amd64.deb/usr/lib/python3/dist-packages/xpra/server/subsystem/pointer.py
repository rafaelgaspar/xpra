# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.
# pylint: disable-msg=E1101

from typing import Any
from collections.abc import Sequence

from xpra.server.drag_scroll import DragScrollTracker
from xpra.server.source.pointer import PointerConnection
from xpra.util.env import envbool
from xpra.util.objects import typedict
from xpra.net.common import Packet, PacketElement, packet_handler
from xpra.server.subsystem.stub import StubSubsystem
from xpra.net.packet_type import POINTER_BUTTON, POINTER_MOTION, POINTER_WHEEL
from xpra.log import Logger

log = Logger("pointer")

INPUT_SEQ_NO = envbool("XPRA_INPUT_SEQ_NO", False)
ALWAYS_NOTIFY_MOTION = envbool("XPRA_ALWAYS_NOTIFY_MOTION", False)


class PointerManager(StubSubsystem):
    """
    Subsystem for servers that handle pointer devices (mouse, etc).

    Packet handlers parse the client's events and funnel them into just two
    pipeline methods, `process_mouse_common` and `process_pointer_button`,
    which are not meant to be overridden.  Backends customise behaviour
    through these hooks instead:

        `_adjust_pointer`     resolve the event to a window, clamp or offset
        `get_pointer_target`  turn the client position into device coordinates
        `_move_pointer`       hand the position to the pointer device
        `button_action`       hand the click to the pointer device
        `_update_modifiers`   apply the modifier mask sent with the event

    The first two return coordinates (or `None` to drop the event) and must
    not have side effects on the device; the last three are terminal and must
    never call back into the pipeline.
    """
    __slots__ = (
        "_drag_scroll", "buttons_pressed", "double_click_distance", "double_click_time", "input_devices",
        "input_devices_data", "last_mouse_user", "pointer_device", "pointer_device_map",
        "pointer_sequence", "touchpad_device",
    )
    PREFIX = "pointer"
    # skip `_move_pointer` when the device is already at the target position?
    # (backends whose devices need every event to record their own state say `False`)
    SKIP_REDUNDANT_MOVES = True

    def __init__(self, server=None):
        StubSubsystem.__init__(self, server)
        self.input_devices = "auto"
        self.input_devices_data = {}
        self.pointer_sequence = {}
        self.last_mouse_user = ""
        self.pointer_device_map: dict = {}
        self.pointer_device = None
        self.touchpad_device = None
        self.buttons_pressed: dict[int, set[int]] = {}
        self.double_click_time = -1
        self.double_click_distance = -1, -1
        self._drag_scroll = DragScrollTracker(self.server.subsystems.get("window") if self.server else None, self.get_pointer_window_position)

    def init(self, opts) -> None:
        self.input_devices = opts.input_devices

    def setup(self) -> None:
        self.pointer_device = self.make_pointer_device()
        if not self.pointer_device:
            log.warn("Warning: no pointer device available, using NoPointerDevice")
            from xpra.pointer.nopointer import NoPointerDevice
            self.pointer_device = NoPointerDevice()
        log("pointer_device=%s", self.pointer_device)
        self.server.connect("client-exited", self.unpress_all_buttons)

    def cleanup(self) -> None:
        self.unpress_all_buttons()

    def make_pointer_device(self):
        from xpra.platform.pointer import get_pointer_device
        return get_pointer_device()

    def get_pointer_position(self) -> tuple[int, int]:
        from xpra.platform.pointer import get_position
        try:
            return get_position()
        except NotImplementedError:
            return 0, 0

    def get_info(self, _proto) -> dict[str, Any]:
        info = {
            "double-click": {
                "time": self.double_click_time,
                "distance": self.double_click_distance,
            },
        }
        return {PointerManager.PREFIX: info}

    def add_new_client(self, ss, c: typedict) -> None:
        from xpra.server.source.pointer import PointerConnection
        if self.get_sources_by_type(PointerConnection, ss):
            self.double_click_time = -1
            self.double_click_distance = -1, -1
        else:
            pointer = typedict(c.dictget("pointer"))
            self.double_click_time = pointer.intget("double_click.time", -1)
            self.double_click_distance = pointer.intpair("double_click.distance", (-1, -1))
        log("double-click time=%s, distance=%s", self.double_click_time, self.double_click_distance)

    def update_touchpad_size(self, *_args) -> None:
        if td := self.touchpad_device:
            # the DisplayManager subsystem is what emits this signal:
            display = self.get_subsystem("display")
            if display is None:
                return
            root_w, root_h = display.get_display_size()
            td.root_w = root_w
            td.root_h = root_h

    def get_server_features(self, _source=None) -> dict[str, Any]:
        return {
            "input-devices": self.input_devices,
            "pointer.relative": True,  # assumed available in 5.0.3
            "pointer.optional": True,
            # the pointer device can inject fractional wheel motion:
            "wheel.precise": self.pointer_device.has_precise_wheel(),
            # ..and if it cannot, we emulate it with discrete button events,
            # so clients can always send us `pointer-wheel` packets:
            "wheel.emulation": True,
            "touchpad-device": bool(self.touchpad_device),
        }

    def _adjust_pointer(self, proto, device_id, wid: int, pointer):
        # the window may not be mapped at the same location by the client:
        ss = self.get_server_source(proto)
        if not hasattr(ss, "update_mouse"):
            return pointer
        window_sub = self.get_subsystem("window")
        if window_sub is None:
            return pointer
        window = window_sub.get_window(wid)
        if ss and window:
            if ws := ss.get_window_source(wid):
                mapped_at = ws.mapped_at
                pos = window_sub.get_window_position(window)
                if mapped_at and pos:
                    wx, wy = pos
                    cx, cy = mapped_at[:2]
                    if wx != cx or wy != cy:
                        dx, dy = wx - cx, wy - cy
                        if dx != 0 or dy != 0:
                            px, py = pointer[:2]
                            ax, ay = px + dx, py + dy
                            log(
                                "client %2i: server window position: %12s, client window position: %24s, pointer=%s, adjusted: %s",
                                # noqa: E501
                                ss.counter, pos, mapped_at, pointer, (ax, ay))
                            return [ax, ay] + list(pointer[2:])
        return pointer

    def process_mouse_common(self, proto, device_id: int, wid: int, opointer, props=None):
        """
        Move the pointer where the client asked us to.
        Returns the adjusted pointer position, or `None` if the event was dropped.
        """
        log("process_mouse_common%s", (proto, device_id, wid, opointer, props))
        if self.is_readonly(proto):
            return None
        pointer = self._adjust_pointer(proto, device_id, wid, opointer)
        if not pointer:
            return None
        target = self.get_pointer_target(proto, wid, pointer, props)
        if not target:
            return None
        if self.SKIP_REDUNDANT_MOVES and self.input_devices != "xi" \
                and self.get_pointer_device(device_id).get_position() == target:
            log("pointer already at %s", target)
        else:
            self._move_pointer(device_id, wid, target, props)
        seq = self.pointer_sequence.get(device_id, 0)
        self.may_record_pointer_event("pointer-motion", device_id, seq, wid, pointer, props or {},
                                      exclude=self.get_server_source(proto))
        return pointer

    def may_record_pointer_event(self, packet_type: str, *data: PacketElement, exclude=None) -> None:
        """ forward this event to all the clients which have pointer synchronization enabled,
            except for `exclude`, which is usually the client the event originates from.
        """
        pointer_sources = self.get_sources_by_type(PointerConnection)
        for ss in pointer_sources:
            if ss.pointer_sync and ss is not exclude:
                ss.send_async(packet_type, *data)

    @packet_handler(POINTER_BUTTON, main_thread=True)
    def _process_button(self, proto, packet: Packet) -> None:
        log("process_pointer_button(%s, %s)", proto, packet)
        if self.is_readonly(proto):
            return
        ss = self.get_server_source(proto)
        if not hasattr(ss, "update_mouse"):
            return
        ss.user_event("pointer-button")
        self.last_mouse_user = ss.uuid
        self.server.set_ui_driver(ss)
        device_id = packet.get_i64(1)
        seq = packet.get_u64(2)
        wid = packet.get_wid(3)
        button = packet.get_u8(4)
        pressed = packet.get_bool(5)
        pointer = packet.get_coordinates(6)
        props = packet.get_dict(7)
        if device_id >= 0:
            # highest_seq = self.pointer_sequence.get(device_id, 0)
            # if INPUT_SEQ_NO and 0<=seq<=highest_seq:
            #    log(f"dropped outdated sequence {seq}, latest is {highest_seq}")
            #    return
            self.pointer_sequence[device_id] = seq
        self.process_pointer_button(proto, device_id, wid, button, pressed, pointer, props)

    def may_move_pointer(self, ss) -> bool:
        """ only the client driving the session can move the pointer,
            unless it has an area of the display of its own (`sharing=combine`) """
        ui_driver = self.server.ui_driver
        if not ui_driver or ui_driver == ss.uuid:
            return True
        if getattr(ss, "display_area", None) is None:
            return False
        if self.buttons_pressed:
            # don't move the pointer away from the ui driver while it is dragging:
            log("not moving the pointer for %s: buttons %s are pressed", ss, self.buttons_pressed)
            return False
        return True

    def _motion_signaled(self, model, event) -> None:
        log("motion_signaled(%s, %s) last mouse user=%s", model, event, self.last_mouse_user)
        # find the window model for this gdk window:
        window_sub = self.get_subsystem("window")
        if window_sub is None:
            return
        wid = window_sub.get_wid(model)
        if not wid:
            return
        pointer_sources = self.get_sources_by_type(PointerConnection)
        for ss in pointer_sources:
            if ALWAYS_NOTIFY_MOTION or self.last_mouse_user is None or self.last_mouse_user != ss.uuid:
                ss.update_mouse(wid, event.x_root, event.y_root, event.x, event.y)

    def get_pointer_device(self, deviceid: int):
        # log("get_pointer_device(%i) input_devices_data=%s", deviceid, self.input_devices_data)
        if self.input_devices_data:
            if device_data := self.input_devices_data.get(deviceid):
                log("get_pointer_device(%i) device=%s", deviceid, device_data.get("name"))
        device = self.pointer_device_map.get(deviceid) or self.pointer_device
        return device

    @staticmethod
    def get_pointer_window_position(pos, props=None) -> tuple[int, int] | None:
        """Return window-relative coordinates from properties or a legacy tuple."""
        relative = (props or {}).get("window-position")
        if isinstance(relative, (tuple, list)) and len(relative) == 2:
            try:
                return int(relative[0]), int(relative[1])
            except (TypeError, ValueError):
                pass
        if len(pos) >= 4:
            return int(pos[2]), int(pos[3])
        return None

    def _get_pointer_abs_coordinates(self, wid: int, pos, props=None) -> tuple[int, int]:
        # simple absolute coordinates
        x, y = pos[:2]
        if relative := self.get_pointer_window_position(pos, props):
            window_sub = self.get_subsystem("window")
            if window_sub is not None:
                # relative coordinates
                if model := window_sub.get_window(wid):
                    rx, ry = relative
                    geom = model.get_geometry()
                    x = geom[0] + rx
                    y = geom[1] + ry
                    log("_get_pointer_abs_coordinates(%i, %s)=%s window geometry=%s", wid, pos, (x, y), geom)
        return x, y

    def get_pointer_target(self, proto, wid: int, pos, props=None) -> tuple[int, int]:
        return self._get_pointer_abs_coordinates(wid, pos, props)

    def _move_pointer(self, device_id: int, wid: int, pos, props=None) -> None:
        # `pos` has already been resolved by `get_pointer_target`,
        # except when we are called directly by the dbus or rfb servers
        # (in which case it is already in absolute coordinates)
        self.device_move_pointer(device_id, wid, pos[:2], props or {})

    def device_move_pointer(self, device_id: int, wid: int, pos, props: dict):
        device = self.get_pointer_device(device_id)
        x, y = pos
        log("move_pointer(%s, %s, %s) device=%s, position=%s", wid, pos, device_id, device, (x, y))
        try:
            device.move_pointer(x, y, props)
        except Exception as e:
            log.error("Error: failed to move the pointer to %sx%s using %s", x, y, device)
            log.estr(e)

    def _update_modifiers(self, proto, wid: int, modifiers: Sequence[str]) -> None:
        if self.is_readonly(proto):
            return
        if ss := self.get_server_source(proto):
            if self.server.ui_driver and self.server.ui_driver != ss.uuid:
                return
            if hasattr(ss, "keyboard_config"):
                modifiers = [x for x in modifiers if x]
                ss.make_keymask_match(modifiers)
            window_sub = self.get_subsystem("window")
            if window_sub is not None and wid == window_sub.get_focus():
                ss.user_event("focus-changed")

    def process_pointer_button(self, proto, device_id: int, wid: int, button: int, pressed: bool,
                               pointer, props: dict) -> None:
        """
        Move the pointer to where the click happened, then click.
        """
        if "modifiers" in props:
            self._update_modifiers(proto, wid, props.get("modifiers", ()))
        self._drag_scroll.record_button(wid, button, pressed, pointer, props)
        pointer_props = {
            key: props[key] for key in ("window-position", "monitor") if key in props
        }
        if self.process_mouse_common(proto, device_id, wid, pointer, pointer_props):
            # Pointer motion is still useful if a window disappears between
            # the client sending the event and the server processing it, but
            # a click must never be delivered to whichever window is now
            # under that position.  ``wid == 0`` is the root/global target.
            window_sub = self.get_subsystem("window")
            if wid > 0 and window_sub is not None and not window_sub.get_window(wid):
                # Do let through a matching release for a button we already
                # injected: dropping it would leave the pointer device's
                # button state stuck down.
                buttons = self.buttons_pressed.get(device_id, ())
                if pressed or button not in buttons:
                    log("dropping pointer button event for invalid window id: %s", wid)
                    return
            seq = self.pointer_sequence.get(device_id, 0)
            self.may_record_pointer_event("pointer-button", device_id, seq, wid, button, pressed, pointer, {},
                                          exclude=self.get_server_source(proto))
            self.button_action(device_id, wid, button, pressed, props)

    def button_action(self, device_id: int, wid: int, button: int, pressed: bool, props: dict) -> None:
        device = self.get_pointer_device(device_id)
        assert device, "pointer device %s not found" % device_id
        if button in (4, 5) and wid:
            self.record_wheel_event(wid, button)
        log("%s%s", device.click, (button, pressed, props))
        device.click(button, pressed, props)
        self._update_button_state(device_id, button, pressed)

    def _update_button_state(self, device_id: int, button: int, pressed: bool) -> None:
        if pressed:
            self.buttons_pressed.setdefault(device_id, set()).add(button)
        elif buttons := self.buttons_pressed.get(device_id):
            buttons.discard(button)
            if not buttons:
                self.buttons_pressed.pop(device_id, None)

    def unpress_all_buttons(self, *_args) -> None:
        buttons_pressed = self.buttons_pressed
        self.buttons_pressed = {}
        self._drag_scroll.clear()
        for device_id, buttons in buttons_pressed.items():
            for button in buttons:
                with log.trap_error("Error releasing pointer button %i on device %i", button, device_id):
                    self.button_action(device_id, 0, button, False, {})

    @packet_handler(POINTER_MOTION, main_thread=True)
    def _process_motion(self, proto, packet: Packet) -> None:
        # v5 packet format
        log("_process_motion(%s, %s) readonly=%s, ui_driver=%s",
            proto, packet, self.is_readonly(proto), self.server.ui_driver)
        if self.is_readonly(proto):
            return
        ss = self.get_server_source(proto)
        if not hasattr(ss, "update_mouse"):
            return
        device_id = packet.get_i64(1)
        seq = packet.get_u64(2)
        wid = packet.get_wid(3)
        pdata = packet.get_coordinates(4)
        props = packet.get_dict(5)
        if device_id >= 0:
            highest_seq = self.pointer_sequence.get(device_id, 0)
            if INPUT_SEQ_NO and 0 <= seq <= highest_seq:
                log(f"dropped outdated sequence {seq}, latest is {highest_seq}")
                return
            self.pointer_sequence[device_id] = seq
        pointer = pdata[:2]
        ss.mouse_last_relative_position = self.get_pointer_window_position(pdata, props) or (-1, -1)
        ss.mouse_last_position = pointer
        if not self.may_move_pointer(ss):
            return
        ss.user_event("pointer")
        self.last_mouse_user = ss.uuid
        if self.process_mouse_common(proto, device_id, wid, pdata, props):
            modifiers = props.get("modifiers")
            if modifiers is not None:
                self._update_modifiers(proto, wid, modifiers)
        self._drag_scroll.maybe_record_drag_scroll(wid, pdata)

    @packet_handler(POINTER_WHEEL, main_thread=True)
    def _process_wheel(self, proto, packet: Packet) -> None:
        if self.is_readonly(proto):
            return
        ss = self.get_server_source(proto)
        if not ss:
            return
        wid = packet.get_wid()
        button = packet.get_u8(2)
        distance = packet.get_i64(3)
        pointer = packet.get_coordinates(4)
        modifiers = packet.get_strs(5)
        # buttons = packet.get_ints(6)
        device_id = -1
        props = packet.get_dict(7) if len(packet) >= 8 and isinstance(packet[7], dict) else {}
        self.record_wheel_event(wid, button)
        if self.process_mouse_common(proto, device_id, wid, pointer, props):
            self.last_mouse_user = ss.uuid
            self._update_modifiers(proto, wid, modifiers)
            self.may_record_pointer_event("pointer-wheel", wid, button, distance, tuple(pointer), tuple(modifiers),
                                          exclude=ss)
            self.wheel_motion(ss, device_id, wid, button, distance / 1000.0, props)

    def wheel_motion(self, ss, device_id: int, wid: int, button: int, distance: float, props: dict) -> None:
        """
        Apply a fractional wheel `distance` (in wheel clicks) to the pointer device.
        Devices which cannot do this natively get discrete button events instead,
        which is what the clients used to emulate on their side.
        """
        device = self.get_pointer_device(device_id)
        if device.has_precise_wheel():
            device.wheel_motion(button, distance)
            return
        # clients scale the distance to wheel clicks using their own scroll speed
        # settings and send us the result, older ones leave us to use the distance:
        scaled = props.get("scaled-distance")
        clicks = scaled / 1000.0 if isinstance(scaled, int) else distance
        steps = ss.wheel_steps(button, clicks)
        log("wheel_motion%s emulated with %i clicks of button %i",
            (ss, device_id, wid, button, distance, props), steps, button)
        for _ in range(steps):
            for pressed in (True, False):
                self.button_action(device_id, wid, button, pressed, props)

    def record_wheel_event(self, wid: int, button: int) -> None:
        """ this may be used as a compression hint """
        log("recording scroll event for button %i", button)
        window_sub = self.get_subsystem("window")
        if window_sub is None:
            return
        for ss in window_sub.window_sources():
            ss.record_scroll_event(wid)

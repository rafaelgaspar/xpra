# This file is part of Xpra.
# Copyright (C) 2011 Serviware (Arthur Huillet, <ahuillet@serviware.com>)
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from math import sqrt
from typing import Any
from time import sleep, monotonic
from collections.abc import Sequence

from xpra.os_util import gi_import
from xpra.net.common import FULL_INFO, BACKWARDS_COMPATIBLE
from xpra.net.constants import TCP_SOCKTYPES
from xpra.net.packet_type import ENCODING_SET
from xpra.server.common import may_update_bandwidth_limits, wants_windows, validate_rgb_formats
from xpra.server.source.stub import StubClientConnection
from xpra.server.window import batch_config
from xpra.server.core import ClientException
from xpra.codecs.video import getVideoHelper
from xpra.net.compression import use
from xpra.util.background_worker import add_work_item
from xpra.util.objects import typedict
from xpra.util.str_fn import csv
from xpra.util.env import envint
from xpra.log import Logger

GLib = gi_import("GLib")

log = Logger("encoding")
proxylog = Logger("proxy")
statslog = Logger("stats")

MIN_PIXEL_RECALCULATE = envint("XPRA_MIN_PIXEL_RECALCULATE", 2000)


def parse_batch_int(value, varname: str, default: int) -> int:
    if value is not None:
        try:
            return int(value)
        except (TypeError, ValueError):
            log.error("Error: invalid value %r for batch option %s", value, varname)
    return default


class EncodingsConnection(StubClientConnection):
    """
    Store information about the client's support for encodings.
    Runs the encode thread.
    """
    PREFIX = "encoding"

    @classmethod
    def is_needed(cls, caps: typedict) -> bool:
        return bool(caps.dictget("encoding")) or wants_windows(caps)

    def init_state(self) -> None:
        # contains default values, some of which may be supplied by the client:
        self.default_batch_config = batch_config.DamageBatchConfig()
        self.global_batch_config = self.default_batch_config.clone()  # global batch config

        self.encoding = ""  # the default encoding for all windows
        self.encodings: Sequence[str] = ()  # all the encodings supported by the client
        self.core_encodings: Sequence[str] = ()
        self.full_csc_modes = dict()
        self.window_icon_encodings: Sequence[str] = ()
        self.rgb_formats: Sequence[str] = ("RGB",)
        self.encoding_options = typedict()
        self.icons_encoding_options = typedict()
        self.default_encoding_options = typedict()
        self.auto_refresh_delay: int = 0

        self.lz4 = use("lz4")

        # for managing the recalculate_delays work:
        self.calculate_window_pixels: dict[int, int] = {}
        self.calculate_window_ids: set[int] = set()
        self.calculate_timer = 0
        self.calculate_last_time: float = 0

        self.video_helper = getVideoHelper()
        self.cuda_device_context = None

    def init_from(self, _protocol, server) -> None:
        self.get_capture_adapter_luid = server.get_capture_adapter_luid
        # `EncodingServer` is the standalone subsystem instance:
        enc = server.subsystems["encoding"]
        self.server_core_encodings = enc.core_encodings
        self.server_encodings = enc.encodings
        self.default_encoding = enc.default_encoding
        self.scaling_control = enc.scaling_control
        self.default_quality = enc.default_quality
        self.default_min_quality = enc.default_min_quality
        self.default_speed = enc.default_speed
        self.default_min_speed = enc.default_min_speed

    def reinit_encodings(self, encoding_subsystem) -> None:
        self.server_core_encodings = encoding_subsystem.core_encodings
        self.server_encodings = encoding_subsystem.encodings
        # If this client connected before nvenc finished loading, CUDA context allocation
        # was skipped in parse_encoding_caps. Allocate it now if still missing.
        if not self.cuda_device_context and self.wants_cuda_device():
            self.allocate_cuda_device_context()
        for ws in self.all_window_sources():
            # Propagate cuda context to any window sources created before it was available.
            if self.cuda_device_context and not ws.cuda_device_context:
                ws.cuda_device_context = self.cuda_device_context
            # window sources copy the encodings when they are created,
            # and those which already existed before the client sent its `encoding-config`
            # (ie: shadow windows) would otherwise never get the client's video decoders:
            ws.server_core_encodings = self.server_core_encodings
            ws.encodings = self.encodings
            ws.core_encodings = self.core_encodings
            ws.rgb_formats = self.rgb_formats

    def cleanup(self) -> None:
        self.cancel_recalculate_timer()
        # the video encoders are using the cuda context, and they are only cleaned up
        # when the window subsystem is - which happens after this one,
        # so this can only be freed at the very end.
        # this is queued unconditionally because a context can still be allocated
        # after this point (ie: `reinit_encodings` when the codecs finish loading),
        # `free_cuda_device_context` is the one checking if there is anything to free:
        self.call_in_encode_thread_at_end(self.free_cuda_device_context)

    def free_cuda_device_context(self) -> None:
        if cdd := self.cuda_device_context:
            self.cuda_device_context = None
            cdd.free()

    def all_window_sources(self) -> tuple:
        # we can't assume that the window mixin is loaded:
        window_sources = getattr(self, "window_sources", {})
        return tuple(window_sources.values())

    def get_caps(self) -> dict[str, str | int]:
        return {
            "auto_refresh_delay": self.auto_refresh_delay,
            "encoding": self.encoding,
        }

    def threaded_init_complete(self, encoding_subsystem) -> None:
        if not self.hello_sent:
            # hello has not been sent yet; the source will be picked up by add_new_client once it is
            return
        # by now, all the codecs have been initialized
        d = encoding_subsystem.get_encoding_info()
        if FULL_INFO > 1:
            from xpra.codecs.loader import codec_versions
            # codec_versions: dict[str, tuple[Any, ...]] = {}
            for codec, version in codec_versions.items():
                d[codec] = {"version": version}
        video = {}
        for encoding in self.video_helper.get_encodings():
            especs = self.video_helper.get_encoder_specs(encoding)
            ecaps = {}
            for csc, specs in especs.items():
                ecaps[csc] = tuple(spec.to_dict("codec_class") for spec in specs)
            if ecaps:
                video[encoding] = ecaps
        log(f"video specs={video}")
        self.send_async(ENCODING_SET, {"encodings": d, "video": video})
        # only print encoding info when not using mmap:
        mmap_write_area = getattr(self, "mmap_write_area", None)
        if not mmap_write_area or not mmap_write_area.enabled:
            self.print_encoding_info()

    def recalculate_delays(self) -> None:
        """ calls update_averages() on `ServerSource.statistics` (`GlobalStatistics`)
            and `WindowSource.statistics` (`WindowPerformanceStatistics`) for each window id in calculate_window_ids,
            this runs in the worker thread.
        """
        self.calculate_timer = 0
        if self.is_closed():
            return
        now = monotonic()
        self.calculate_last_time = now
        p = self.protocol
        if not p or p.is_closed():
            return
        conn = p._conn
        if not conn:
            return
        # we can't assume that 'self' is a full ClientConnection object:
        if stats := getattr(self, "statistics", None):
            stats.bytes_sent.append((now, conn.output_bytecount))
            if control := getattr(conn, "congestion_control", None):
                # QUIC publishes snapshots on the asyncio thread. Reading one
                # here never inspects its live streams or recovery state.
                stats.record_quic_info(now, control.get_info())
            if getattr(conn, "socktype_wrapped", "") in TCP_SOCKTYPES:
                try:
                    from xpra.platform.netdev_query import get_socket_tcp_info
                except ImportError:
                    pass
                else:
                    if get_raw_socket := getattr(conn, "get_raw_socket", None):
                        try:
                            # noinspection calling-non-callable
                            if sock := get_raw_socket():
                                stats.record_tcp_info(now, get_socket_tcp_info(sock))
                        except (OSError, ValueError):
                            log("failed to query TCP_INFO for %s", conn, exc_info=True)
            stats.update_averages()
        may_update_bandwidth_limits(self)
        wids = tuple(self.calculate_window_ids)  # make a copy so we don't clobber new wids
        focus = self.get_focus()
        sources = self.window_sources.items()
        maximized_wids = tuple(wid for wid, source in sources if source is not None and source.maximized)
        fullscreen_wids = tuple(wid for wid, source in sources if source is not None and source.fullscreen)
        get_coverage = getattr(self, "get_window_coverage", lambda _wid: None)
        log("recalculate_delays() wids=%s, focus=%s, maximized=%s, fullscreen=%s",
            wids, focus, maximized_wids, fullscreen_wids)
        for wid in wids:
            # this is safe because we only add to this set from other threads:
            self.calculate_window_ids.remove(wid)
            self.calculate_window_pixels.pop(wid, None)
            ws = self.window_sources.get(wid)
            if ws is None:
                continue
            with log.trap_error("Error calculating delays for window %s", wid):
                ws.statistics.update_averages()
                ws.calculate_batch_delay(wid == focus,
                                         len(fullscreen_wids) > 0 and wid not in fullscreen_wids,
                                         len(maximized_wids) > 0 and wid not in maximized_wids,
                                         get_coverage(wid))
                ws.reconfigure()
            if self.is_closed():
                return
            # allow other threads to run
            # (ideally this would be a low priority thread)
            sleep(0)
        # calculate weighted average as new global default delay:
        wdimsum, wdelay, tsize, tcount = 0, 0, 0, 0
        for ws in tuple(self.window_sources.values()):
            if ws.batch_config.last_updated <= 0:
                continue
            w, h = ws.window_dimensions
            tsize += w * h
            tcount += 1
            time_w = 2.0 + (now - ws.batch_config.last_updated)  # add 2 seconds to even things out
            weight = int(w * h * time_w)
            wdelay += ws.batch_config.delay * weight
            wdimsum += weight
        if wdimsum > 0 and tcount > 0:
            # weighted delay:
            delay = wdelay // wdimsum
            self.global_batch_config.last_delays.append((now, delay))
            self.global_batch_config.delay = delay
            # store the delay as a normalized value per megapixel,
            # so we can adapt it to different window sizes:
            avg_size = tsize // tcount
            ratio = sqrt(1000000.0 / avg_size)
            normalized_delay = int(delay * ratio)
            self.global_batch_config.delay_per_megapixel = normalized_delay
            log("delay_per_megapixel=%i, delay=%i, for wdelay=%i, avg_size=%i, ratio=%.2f",
                normalized_delay, delay, wdelay, avg_size, ratio)

    def may_recalculate(self, wid: int, pixel_count: int, *, force=False) -> None:
        if wid in self.calculate_window_ids:
            return  # already scheduled
        v = self.calculate_window_pixels.get(wid, 0) + pixel_count
        self.calculate_window_pixels[wid] = v
        if not force and v < MIN_PIXEL_RECALCULATE:
            return  # not enough pixel updates
        statslog("may_recalculate(%#x, %i) total %i pixels, scheduling recalculate work item", wid, pixel_count, v)
        self.calculate_window_ids.add(wid)
        if self.calculate_timer:
            # already due
            return
        delta = monotonic() - self.calculate_last_time
        RECALCULATE_DELAY = 1.0  # 1s
        if delta > RECALCULATE_DELAY:
            add_work_item(self.recalculate_delays)
        else:
            delay = int(1000 * (RECALCULATE_DELAY - delta))
            self.calculate_timer = GLib.timeout_add(delay, add_work_item, self.recalculate_delays)

    def cancel_recalculate_timer(self) -> None:
        if ct := self.calculate_timer:
            self.calculate_timer = 0
            GLib.source_remove(ct)

    def parse_client_caps(self, c: typedict) -> None:
        # batch options:
        # since v6.3, we can have a "batch" dict in the "encoding" caps
        # rather than having it at the top level:
        batch_caps = c.get("batch", {})
        enc_caps = c.dictget("encoding")
        batch_caps = enc_caps.get("batch", batch_caps)

        def batch_value(prop: str, default: int, minv=-1, maxv=-1) -> int:
            assert default is not None
            raw_value = os.environ.get(f"XPRA_BATCH_{prop.upper()}") or batch_caps.get(prop) or c.get(f"batch.{prop}")
            v = parse_batch_int(raw_value, prop, default)
            assert v is not None
            if minv >= 0:
                v = max(minv, v)
            if maxv >= 0:
                v = min(maxv, v)
            return v

        # general features:
        self.lz4 = c.boolget("lz4", False) and use("lz4")
        self.brotli = c.boolget("brotli", False) and use("brotli")
        log("compressors: lz4=%s, brotli=%s", self.lz4, self.brotli)

        delay = batch_config.START_DELAY
        dbc = self.default_batch_config
        dbc.always = bool(batch_value("always", int(dbc.always)))
        dbc.min_delay = batch_value("min_delay", dbc.min_delay, 0, 1000)
        dbc.max_delay = batch_value("max_delay", dbc.max_delay, 1, 15000)
        dbc.max_events = batch_value("max_events", dbc.max_events)
        dbc.max_pixels = batch_value("max_pixels", dbc.max_pixels)
        dbc.time_unit = batch_value("time_unit", dbc.time_unit, 1)
        dbc.delay = batch_value("delay", delay, dbc.min_delay)
        log("default batch config: %s", dbc)
        evalue = c.get("encoding")
        if isinstance(evalue, dict):
            eopts = typedict(evalue)
        else:
            eopts = typedict()
        self.parse_encoding_caps(c, eopts)

    def parse_encoding_caps(self, c: typedict, eopts: typedict) -> None:
        window_requested = wants_windows(c)
        self.encoding_options.update(eopts)
        self.encodings = eopts.strtupleget("options")
        self.core_encodings = eopts.strtupleget("core", self.encodings)
        if not self.core_encodings and window_requested:
            raise ClientException("client failed to specify any supported encodings")
        self.full_csc_modes = eopts.dictget("full_csc_modes")
        log("encodings=%s, core_encodings=%s", self.encodings, self.core_encodings)

        self.window_icon_encodings = eopts.strtupleget("window-icon")
        log("window_icon_encodings=%s", self.window_icon_encodings)
        self.rgb_formats = validate_rgb_formats(eopts.strtupleget("rgb_formats"), self.core_encodings)

        self.set_encoding(eopts.strget("setting") or eopts.strget(""), None)
        # in milliseconds, 0 disables the lossless auto-refresh,
        # left unchanged when missing (ie: from an older client's `encoding-config` packet):
        if "auto_refresh_delay" in eopts:
            self.auto_refresh_delay = eopts.intget("auto_refresh_delay", 0)
        elif BACKWARDS_COMPATIBLE and "auto_refresh_delay" in c:
            # clients older than v8 send it at the top level:
            self.auto_refresh_delay = c.intget("auto_refresh_delay", 0)
        log("auto_refresh_delay=%i", self.auto_refresh_delay)
        self.icons_encoding_options.update(self.encoding_options.pop("icons", None) or {})
        log("encoding options: %s", self.encoding_options)
        log("icons encoding options: %s", self.icons_encoding_options)

        sc = self.encoding_options.get("scaling.control", self.scaling_control)
        if sc is not None:
            self.default_encoding_options["scaling.control"] = sc
        q = self.encoding_options.intget("quality", self.default_quality)  # 0.7 onwards:
        if q > 0:
            self.default_encoding_options["quality"] = q
        mq = self.encoding_options.intget("min-quality", self.default_min_quality)
        if mq > 0 and (q <= 0 or q > mq):
            self.default_encoding_options["min-quality"] = mq
        s = self.encoding_options.intget("speed", self.default_speed)
        if s > 0:
            self.default_encoding_options["speed"] = s
        ms = self.encoding_options.intget("min-speed", self.default_min_speed)
        if ms > 0 and (s <= 0 or s > ms):
            self.default_encoding_options["min-speed"] = ms
        log("default encoding options: %s", self.default_encoding_options)
        self.set_min_speed(ms)
        self.set_min_quality(mq)
        # are we going to need a cuda context?
        if not self.cuda_device_context and self.wants_cuda_device():
            self.allocate_cuda_device_context()

    def wants_cuda_device(self) -> bool:
        if getattr(self, "mmap_write_area", None):
            return False
        from xpra.codecs.loader import has_codec
        common_encodings = set(x for x in self.encodings if x in self.server_encodings)
        return any((
            has_codec("nvenc") and {"h264", "h265", "av1"} & common_encodings,
            has_codec("enc_nvjpeg") and "jpeg" in common_encodings,
        ))

    def allocate_cuda_device_context(self):
        cudalog = Logger("cuda")
        cudalog(f"allocate_cuda_device_context() cuda_device_context={self.cuda_device_context}")
        if not self.cuda_device_context:
            try:
                # pylint: disable=import-outside-toplevel
                from xpra.codecs.nvidia.cuda.context import get_device_context
            except ImportError as e:
                cudalog(f"unable to import cuda context: {e}")
                return None
            # Server-owned hint consumed by CUDA device selection: prefer the adapter holding
            # the captured D3D11 textures, so NVENC can copy them without a system-memory round trip.
            # Refresh after parsing client options, including clearing any client-supplied or stale value.
            self.encoding_options.pop("cuda-adapter-luid", None)
            try:
                if adapter_luid := self.get_capture_adapter_luid():
                    self.encoding_options["cuda-adapter-luid"] = adapter_luid
            except Exception:
                cudalog("failed to query the capture adapter LUID", exc_info=True)
            try:
                self.cuda_device_context = get_device_context(self.encoding_options)
                cudalog("cuda_device_context=%s", self.cuda_device_context)
            except Exception as e:
                cudalog("failed to get a cuda device context using encoding options %s",
                        self.encoding_options, exc_info=True)
                cudalog.error("Error: failed to allocate a CUDA context:")
                cudalog.estr(e)
                cudalog.error(" NVJPEG and NVENC will not be available")
        return self.cuda_device_context

    def print_encoding_info(self) -> None:
        log("print_encoding_info() core-encodings=%s, server-core-encodings=%s",
            self.core_encodings, self.server_core_encodings)
        others = tuple(x for x in self.core_encodings
                       if x in self.server_core_encodings and x != self.encoding)
        if self.encoding == "auto":
            s = "automatic picture encoding enabled"
        elif self.encoding == "stream":
            s = "streaming mode enabled"
        else:
            s = f"using {self.encoding!r} as primary encoding"
        if others:
            log.info(f" {s}, also available:")
            log.info("  " + csv(others))
        else:
            log.warn(f" {s}")
            log.warn("  no other encodings are available!")

    ######################################################################
    # Functions used by the server to request something
    # (window events, stats, user requests, etc)
    #
    def set_auto_refresh_delay(self, delay: int, window_ids) -> None:
        if window_ids is not None:
            wss = (self.window_sources.get(wid) for wid in window_ids)
        else:
            wss = self.all_window_sources()
        for ws in wss:
            if ws is not None:
                ws.set_auto_refresh_delay(delay)

    def set_encoding(self, encoding: str, window_ids, strict=False) -> None:
        """ Changes the encoder for the given 'window_ids',
            or for all windows if 'window_ids' is None.
        """
        log("set_encoding(%s, %s, %s)", encoding, window_ids, strict)
        if encoding and encoding not in ("auto", "stream"):
            # old clients (v0.9.x and earlier) only supported 'rgb24' as 'rgb' mode:
            if encoding == "rgb24":
                encoding = "rgb"
            if encoding not in self.encodings:
                log.warn(f"Warning: client specified {encoding!r} encoding,")
                log.warn(" but it only supports: " + csv(self.encodings))
            if encoding not in self.server_encodings:
                log.error(f"Error: encoding {encoding!r} is not supported by this server")
                log.error(" server encodings: " + csv(self.server_encodings))
                encoding = ""
        if not encoding:
            encoding = "auto"
        if window_ids is not None:
            wss = [self.window_sources.get(wid) for wid in window_ids]
        else:
            wss = self.all_window_sources()
        # if we're updating all the windows, reset global stats too:
        if set(wss).issuperset(self.all_window_sources()):
            log("resetting global stats")
            # we can't assume that 'self' is a full ClientConnection object:
            if stats := getattr(self, "statistics", None):
                stats.reset()
            self.global_batch_config = self.default_batch_config.clone()
        for ws in wss:
            if ws is not None:
                ws.set_new_encoding(encoding, strict)
        if not window_ids:
            self.encoding = encoding

    def get_info(self) -> dict[str, Any]:
        einfo = {
            "default": self.default_encoding or "",
            "defaults": dict(self.default_encoding_options),
            "client-defaults": dict(self.encoding_options),
        }
        ieo = dict(self.icons_encoding_options)
        ieo.pop("default.icons", None)
        info: dict[str, Any] = {
            "auto_refresh": self.auto_refresh_delay,
            "lz4": self.lz4,
            "encodings": {
                "": self.encodings,
                "core": self.core_encodings,
                "window-icon": self.window_icon_encodings,
            },
            "icons": ieo,
            "encoding": einfo,
        }
        return info

    def set_min_quality(self, min_quality: int) -> None:
        for ws in tuple(self.all_window_sources()):
            ws.set_min_quality(min_quality)

    def set_max_quality(self, max_quality: int) -> None:
        for ws in tuple(self.all_window_sources()):
            ws.set_max_quality(max_quality)

    def set_quality(self, quality: int) -> None:
        for ws in tuple(self.all_window_sources()):
            ws.set_quality(quality)

    def set_min_speed(self, min_speed: int) -> None:
        for ws in tuple(self.all_window_sources()):
            ws.set_min_speed(min_speed)

    def set_max_speed(self, max_speed: int) -> None:
        for ws in tuple(self.all_window_sources()):
            ws.set_max_speed(max_speed)

    def set_speed(self, speed: int) -> None:
        for ws in tuple(self.all_window_sources()):
            ws.set_speed(speed)

    def make_batch_config(self, wid: int, window):
        config = self.default_batch_config.clone()
        config.wid = wid
        # scale initial delay based on window size
        # (the global value is normalized to 1MPixel)
        # but use sqrt to smooth things and prevent excesses
        # (ie: a 4MPixel window, will start at 2 times the global delay)
        # (ie: a 0.5MPixel window will start at 0.7 times the global delay)
        dpm = self.global_batch_config.delay_per_megapixel
        w, h = window.get_dimensions()
        if dpm >= 0:
            ratio = sqrt(1000000.0 / (w * h))
            config.delay = max(config.min_delay, min(config.max_delay, int(dpm * sqrt(ratio))))
        log("make_batch_config(%i, %s) global delay per megapixel=%i, new window delay for %ix%i=%s",
            wid, window, dpm, w, h, config.delay)
        return config

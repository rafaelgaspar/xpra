# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.
# pylint: disable-msg=E1101

from io import BytesIO
from time import monotonic
from typing import Any, BinaryIO
from collections.abc import Callable

try:
    from PIL import Image
except ImportError:
    Image = None

from xpra.os_util import gi_import, POSIX, OSX
from xpra.util.io import load_binary_file
from xpra.net import compression
from xpra.net.packet_type import WINDOW_ICON
from xpra.codecs.image import to_png
from xpra.util.thread import check_main_thread
from xpra.util.str_fn import csv
from xpra.util.system import get_generic_os_name
from xpra.util.env import envint, envbool
from xpra.common import noop
from xpra.log import Logger

GLib = gi_import("GLib")

log = Logger("icon")

ARGB_ICONS = envbool("XPRA_ARGB_ICONS", True)
PNG_ICONS = envbool("XPRA_PNG_ICONS", True)
DEFAULT_ICONS = envbool("XPRA_DEFAULT_ICONS", True)

LOG_THEME_DEFAULT_ICONS = envbool("XPRA_LOG_THEME_DEFAULT_ICONS", False)
SAVE_WINDOW_ICONS = envbool("XPRA_SAVE_WINDOW_ICONS", False)
MAX_ARGB_PIXELS = envint("XPRA_MAX_ARGB_PIXELS", 1024)
DEFAULT_ICON_CACHE_SIZE = envint("XPRA_DEFAULT_ICON_CACHE_SIZE", 256)


def load_icon_file(filename: str | BinaryIO, size: int) -> tuple[int, int, str, bytes] | None:
    """
    Loads the icon using pillow, scaled to `size` and encoded as png.
    This does not use any Gtk or Gdk calls.
    """
    if not Image:
        return None
    try:
        with Image.open(filename) as img:
            img.load()
            w = int(img.width)
            h = int(img.height)
            log("load_icon_file(%r, %i) size=%ix%i", filename, size, w, h)
            if w != size or h != size:
                try:
                    NEAREST = Image.Resampling.NEAREST
                except AttributeError:
                    NEAREST = Image.NEAREST
                img = img.resize((size, size), NEAREST)
            return size, size, "png", to_png(img)
    except (OSError, ValueError, TypeError) as e:
        log("load_icon_file(%r, %i) %s", filename, size, e)
    return None


def load_cached_svg_icon(filename: str, size: int) -> tuple[int, int, str, bytes] | None:
    """
    Loads the png rendering of this SVG file from the menu icon cache, if it has one.
    This does not use any Gtk or Gdk calls.
    """
    if not POSIX or OSX:
        return None
    try:
        from xpra.platform.posix.menu_helper import load_cached_svg
        if not (svg_data := load_binary_file(filename)):
            return None
        cached = load_cached_svg(svg_data)
        log("load_cached_svg(%r)=%s", filename, bool(cached))
        if cached:
            return load_icon_file(BytesIO(cached[0]), size)
    except (OSError, ValueError, TypeError, ImportError) as e:
        log("load_cached_svg_icon(%r, %i) %s", filename, size, e)
    return None


def do_get_default_window_icon(size: int, name: str) -> tuple[int, int, str, bytes] | None:
    log("do_get_default_window_icon(%i, %s)", size, name)
    if POSIX and not OSX and Image:
        try:
            from xpra.platform.posix.menu_helper import find_icon
            # the extension order only applies within an icon directory, so this may still find an SVG:
            filename = find_icon(name, extensions=("png", "xpm", "svg"))
            log("find_icon(%r)=%r", name, filename)
            if filename.endswith(".svg"):
                if icon := load_cached_svg_icon(filename, size):
                    return icon
                # no PNG rendering of this SVG, try again without SVG:
                filename = find_icon(name, extensions=("png", "xpm"))
                log("find_icon(%r) without svg=%r", name, filename)
            if filename:
                return load_icon_file(filename, size)
        except (OSError, ValueError, TypeError, ImportError) as e:
            log("do_get_default_window_icon(%i, %r) %s", size, name, e)
    return None


def no_theme_icon(_size: int, _wmclass_name: str) -> tuple[str, Any]:
    return "", None


# GTK servers replace these with lookups in the GTK icon theme,
# both must be called from the main thread:
# `find_theme_icon(size, wmclass_name)` returns the icon's filename and an opaque object
# which `load_theme_icon(obj)` can use to load the icon if the file cannot be loaded with pillow (ie: SVG)
find_theme_icon: Callable[[int, str], tuple[str, Any]] = no_theme_icon
load_theme_icon: Callable[[Any], tuple[int, int, str, bytes] | None] = noop


def get_default_window_icon(size: int, wmclass_name: str) -> tuple[int, int, str, bytes] | None:
    # main thread, the icon theme cache:
    filename, theme_icon = find_theme_icon(size, wmclass_name)
    svg = filename.endswith(".svg")
    # any thread, file I/O:
    if filename and not svg:
        if icon := load_icon_file(filename, size):
            return icon
    # the menu icon cache may have a rendering of this SVG,
    # that's cheaper than searching for another icon:
    if svg:
        if icon := load_cached_svg_icon(filename, size):
            return icon
    # rendering SVGs is expensive, so try everything else first:
    if icon := do_get_default_window_icon(size, wmclass_name):
        return icon
    # main thread, may use Gtk and rsvg:
    if theme_icon:
        return load_theme_icon(theme_icon)
    return None


# results of `get_default_window_icon` by (size, wmclass name), misses included,
# least recently used first:
default_icon_cache: dict[tuple[int, str], tuple[int, int, str, bytes] | None] = {}


def get_cached_default_window_icon(size: int, wmclass_name: str) -> tuple[int, int, str, bytes] | None:
    key = (size, wmclass_name)
    try:
        # move it to the end:
        icon = default_icon_cache.pop(key)
    except KeyError:
        icon = get_default_window_icon(size, wmclass_name)
        # the wmclass is chosen by the application, so we must limit the number of entries:
        while default_icon_cache and len(default_icon_cache) >= DEFAULT_ICON_CACHE_SIZE:
            default_icon_cache.pop(next(iter(default_icon_cache)))
    default_icon_cache[key] = icon
    return icon


def clear_default_icon_cache() -> None:
    log("clear_default_icon_cache() %i entries", len(default_icon_cache))
    default_icon_cache.clear()


# the icon of the operating system, used by desktop windows:
OS_ICON = get_generic_os_name().lower() + ".png"

# icons shipped with xpra, by name, loaded once:
xpra_icons: dict[str, tuple[int, int, str, bytes] | None] = {}


def get_xpra_icon(name: str) -> tuple[int, int, str, bytes] | None:
    """
    Returns one of the icons shipped with xpra, encoded as png.
    The ones we use are preloaded by `warmup_default_window_icons`.
    This does not use any Gtk or Gdk calls.
    """
    try:
        return xpra_icons[name]
    except KeyError:
        pass
    icon = None
    from xpra.platform.paths import get_icon_filename
    filename = get_icon_filename(name)
    if Image and filename and (data := load_binary_file(filename)):
        try:
            with Image.open(BytesIO(data)) as img:
                if img.format != "PNG":
                    data = to_png(img)
                icon = img.width, img.height, "png", data
        except (OSError, ValueError) as e:
            log("get_xpra_icon(%r) %s", name, e)
    log("get_xpra_icon(%r) filename=%r, found=%s", name, filename, bool(icon))
    xpra_icons[name] = icon
    return icon


def warmup_default_window_icons() -> None:
    """
    Loads pillow's plugins, our own icons and the icon themes,
    so the first default window icon lookup doesn't have to.
    This does not use Gtk, it runs in the background worker thread.
    """
    start = monotonic()
    if Image:
        Image.init()
    for name in ("xpra.png", OS_ICON):
        get_xpra_icon(name)
    if POSIX and not OSX:
        try:
            from xpra.platform.posix.menu_helper import find_icon, load_theme_icon_names
            load_theme_icon_names()
            # a miss goes through all the themes:
            find_icon("xpra-warmup-no-such-icon")
        except (OSError, ValueError, TypeError, ImportError) as e:
            log("warmup_default_window_icons() %s", e)
    log("warmup_default_window_icons() took %ims", 1000 * (monotonic() - start))


def schedule_warmup() -> None:
    from xpra.util.background_worker import add_work_item
    add_work_item(warmup_default_window_icons)


def menus_reloaded() -> None:
    # the menu entries can provide icons,
    # and loading them clears the icon theme caches:
    clear_default_icon_cache()
    schedule_warmup()


class WindowIconSource:
    """
    Mixin for handling the sending of window icon pixels.
    """

    def __init__(self, window_icon_encodings, icons_encoding_options):
        self.window_icon_encodings = window_icon_encodings
        self.icons_encoding_options = icons_encoding_options  # icon caps

        self.has_png = PNG_ICONS and ("png" in self.window_icon_encodings)
        self.has_default = DEFAULT_ICONS and ("default" in self.window_icon_encodings)
        log("WindowIconSource(%s, %s) has_png=%s",
            window_icon_encodings, icons_encoding_options, self.has_png)

        self.window_icon_data: tuple[int, int, str, bytes] | None = None
        self.send_window_icon_timer = 0
        self.theme_default_icons = icons_encoding_options.strtupleget("default.icons")
        self.window_icon_greedy = icons_encoding_options.boolget("greedy", False)
        self.window_icon_size = icons_encoding_options.intpair("size", (64, 64))
        self.window_icon_max_size = icons_encoding_options.intpair("max_size", self.window_icon_size)
        self.window_icon_max_size = (
            max(self.window_icon_max_size[0], 16),
            max(self.window_icon_max_size[1], 16),
        )
        self.window_icon_size = (
            min(self.window_icon_size[0], self.window_icon_max_size[0]),
            min(self.window_icon_size[1], self.window_icon_max_size[1]),
        )
        self.window_icon_size = (
            max(self.window_icon_size[0], 16),
            max(self.window_icon_size[1], 16),
        )
        log("client icon settings: size=%s, max_size=%s", self.window_icon_size, self.window_icon_max_size)
        if LOG_THEME_DEFAULT_ICONS:
            log("theme_default_icons=%s", self.theme_default_icons)

    def cleanup(self) -> None:
        self.cancel_window_icon_timer()
        # if an icon is already queued for compression, it will be skipped:
        self.window_icon_data = None

    def cancel_window_icon_timer(self) -> None:
        if swit := self.send_window_icon_timer:
            self.send_window_icon_timer = 0
            GLib.source_remove(swit)

    def get_info(self) -> dict[str, Any]:
        idata = self.window_icon_data
        info = {
            "png": self.has_png,
            "default": self.has_default,
            "theme_default": self.theme_default_icons,
            "greedy": self.window_icon_greedy,
            "icon-size": self.window_icon_size,
            "icon-max-size": self.window_icon_max_size,
        }
        if idata:
            w, h, fmt, data = idata
            info["current"] = {
                "width": w,
                "height": h,
                "format": fmt,
                "bytes": len(data),
            }
        return {"icon": info}

    @staticmethod
    def get_fallback_window_icon() -> tuple[int, int, str, bytes] | None:
        return get_xpra_icon("xpra.png")

    def get_default_window_icon(self, size=48) -> tuple[int, int, str, bytes] | None:
        # return the icon which would be used from the wmclass
        wmclass_name = self.get_window_wm_class_name()
        if not wmclass_name:
            return None
        return get_cached_default_window_icon(size, wmclass_name)

    def get_window_wm_class_name(self) -> str:
        try:
            c_i = self.window.get_property("class-instance")
        except Exception:
            return ""
        if not c_i or len(c_i) != 2:
            return ""
        return c_i[0]

    def client_has_theme_icon(self):
        wm_class = self.get_window_wm_class_name()
        return wm_class and wm_class in self.theme_default_icons

    def send_window_icon(self) -> None:
        check_main_thread()
        if self.suspended or not self.has_png:
            return
        icons = self.window.get_property("icons")
        log("send_window_icon window %s found %i icons, window_icon_greedy=%s, has_default=%s",
            self.window, len(icons or ()), self.window_icon_greedy, self.has_default)
        if icons:
            self.icon_lookup_done(icons)
            return
        if self.client_has_theme_icon():
            log("%s in client theme icons already (not sending default icon)", self.theme_default_icons)
            return
        self.icon_lookup_done(self.get_default_icons())

    def get_default_icons(self) -> list[tuple[int, int, str, bytes]]:
        # try to load the icon for this class-instance from the theme:
        icons = []
        sizes = []
        for size in (self.window_icon_size, self.window_icon_max_size, (48, 64)):
            if size:
                for dim in size:  # ie: 48
                    if dim not in sizes:
                        sizes.append(dim)
        for size in sizes:
            if icon := self.window.get_default_window_icon(size):
                icons.append(icon)
        if not icons:
            # try to find one using the wmclass:
            if icon := self.get_default_window_icon():
                log("send_window_icon window %s using default window icon", self.window)
                icons.append(icon)
        return icons

    def icon_lookup_done(self, icons) -> None:
        max_w, max_h = self.window_icon_max_size
        icon = self.choose_icon(icons, max_w, max_h)
        if not icon:
            # try again, without size restrictions:
            # (we'll downscale it)
            icon = self.choose_icon(icons)
        if not icon:
            if not self.window_icon_greedy:
                return
            # "greedy": client does not set a default icon, so we must provide one every time
            # to make sure that the window icon does get set to something
            # (our icon is at least better than the window manager's default)
            if self.has_default:
                # client will set the default itself,
                # send a mostly empty packet:
                packet = (WINDOW_ICON, self.wid, 0, 0, "default", b"")
                log("queuing window icon update: %s", packet)
                # this is cheap, so don't use the encode thread,
                # and make sure we don't send another one via the timer:
                self.cancel_window_icon_timer()
                self.queue_packet(packet, wait_for_more=True)
                return
            icon = WindowIconSource.get_fallback_window_icon()
            log("using fallback window icon")
        if not icon:
            log("no suitable icon")
            return
        self.window_icon_data = icon
        if not self.send_window_icon_timer:
            # call compress via the work queue
            # and delay sending it by a bit to allow basic icon batching:
            w, h = self.window_icon_data[:2]
            delay = min(1000, max(50, w * h * self.batch_config.delay_per_megapixel // 1000000))
            log("send_window_icon() window=%s, wid=%#x, compression scheduled in %sms for batch delay=%i",
                self.window, self.wid, delay, self.batch_config.delay_per_megapixel)
            self.send_window_icon_timer = GLib.timeout_add(delay, self.queue_window_icon)

    def queue_window_icon(self) -> None:
        # the timer has fired, so the source is gone:
        # clear the timer here rather than from the encode thread,
        # otherwise `cancel_window_icon_timer` would try to remove a source
        # which no longer exists - and would fail to cancel anything:
        self.send_window_icon_timer = 0
        self.call_in_encode_thread(self.compress_and_send_window_icon)

    def compress_and_send_window_icon(self) -> None:
        # this runs in the work queue
        idata = self.window_icon_data
        if not idata or not self.has_png:
            return
        w, h, pixel_format, pixel_data = idata
        log("compress_and_send_window_icon() %ix%i in %s format, %i bytes for wid=%#x",
            w, h, pixel_format, len(pixel_data), self.wid)
        if pixel_format not in ("BGRA", "RGBA", "png"):
            raise RuntimeError(f"invalid window icon format {pixel_format}")
        # pixel data uses straight alpha, just like PNG
        # (`BGRA` is what we get from NetWMIcons)

        max_w, max_h = self.window_icon_max_size
        # encode as png if it is not already, or if we must downscale it (bigger than what the client is willing to deal with),
        # or if we want to save window icons
        must_scale = w > max_w or h > max_h
        log("compress_and_send_window_icon: %sx%s (max-size=%s, standard-size=%s), pixel_format=%s",
            w, h, self.window_icon_max_size, self.window_icon_size, pixel_format)
        must_convert = pixel_format != "png"
        log(" must convert=%s, must scale=%s", must_convert, must_scale)

        image = None
        if must_scale or must_convert or SAVE_WINDOW_ICONS:
            if Image is None:
                log("cannot scale or convert window icon without python-pillow")
                return
            # we're going to need a PIL Image:
            if pixel_format == "png":
                image = Image.open(BytesIO(pixel_data))
            else:
                from xpra.codecs.image import to_pil
                image = to_pil(w, h, pixel_data, pixel_format)
            if must_scale:
                # scale the icon down to the size the client wants
                # (we should scale + paste to preserve the aspect ratio, meh)
                icon_w, icon_h = self.window_icon_size
                if float(w) / icon_w >= float(h) / icon_h:
                    rh = min(max_h, h * icon_w // w)
                    rw = icon_w
                else:
                    rw = min(max_w, w * icon_h // h)
                    rh = icon_h
                log("scaling window icon down to %sx%s", rw, rh)
                try:
                    LANCZOS = Image.Resampling.LANCZOS
                except AttributeError:
                    LANCZOS = Image.LANCZOS
                image = image.resize((rw, rh), LANCZOS)
            if SAVE_WINDOW_ICONS:
                filename = f"server-window-{self.wid:#x}-icon-{int(monotonic())}.png"
                image.save(filename, 'PNG')
                log("server window icon saved to %s", filename)

        if image:
            # image got converted or scaled, get the new pixel data:
            pixel_data = to_png(image)
            w, h = image.size
        wrapper = compression.Compressed("png", pixel_data)
        packet = (WINDOW_ICON, self.wid, w, h, wrapper.datatype, wrapper)
        log("queuing window icon update: %s", packet)
        self.queue_packet(packet, wait_for_more=True)

    @staticmethod
    def choose_icon(icons, max_w=1024, max_h=1024):
        if not icons:
            return None
        log("choose_icon from: %s", csv("%ix%i %s" % icon[:3] for icon in icons))
        size_image = {icon[0] * icon[1]: icon for icon in icons if icon[0] < max_w and icon[1] < max_h}
        if not size_image:
            return None
        # we should choose one whose size is close to what the client wants,
        # take the biggest one for now:
        largest_size = sorted(size_image)[-1]
        icon = size_image[largest_size]
        log("choose_icon(..)=%ix%i %s", *icon[:3])
        return icon

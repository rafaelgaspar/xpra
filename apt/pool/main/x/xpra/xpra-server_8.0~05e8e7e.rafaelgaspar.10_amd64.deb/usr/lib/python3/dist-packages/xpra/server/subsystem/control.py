# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any

from xpra.util.objects import typedict
from xpra.util.parsing import str_to_bool
from xpra.util.str_fn import csv
from xpra.net.common import Packet, PacketElement, packet_handler
from xpra.net.control.common import ControlCode, parse_boolean_value
from xpra.server.common import get_sources_by_type
from xpra.server.subsystem.stub import StubSubsystem
from xpra.net.packet_type import CONTROL_REQUEST, HELLO
from xpra.log import Logger

log = Logger("command")

READONLY_CONTROL_COMMANDS = frozenset(("hello", "help"))


class ControlHandler(StubSubsystem):
    __slots__ = ("commands", "enabled")
    PREFIX = "control"

    def __init__(self, server=None):
        StubSubsystem.__init__(self, server)
        self.commands: dict[str, Any] = {}
        self.enabled = False
        self.server.hello_request_handlers["command"] = self._handle_hello_request_command

    def init(self, opts) -> None:
        self.enabled = str_to_bool(opts.control, True)

    def setup(self) -> None:
        self.add_default_control_commands()
        # Proxy worker processes use only add_default_control_commands():
        # these commands operate on a full server and its client sources.
        self.args_control("readonly", "set global readonly state", min_args=1, max_args=1,
                          validation=[parse_boolean_value])
        self.args_control("client-readonly", "set readonly state for client(s)", min_args=2, max_args=2,
                          validation=[str, parse_boolean_value])

    def add_default_control_commands(self) -> None:
        # for things that can take longer:
        try:
            from xpra.net.control.common import HelloCommand, HelpCommand, DisabledCommand
        except ImportError:
            return
        self.commands.setdefault("hello", HelloCommand())
        if self.enabled:
            self.do_add_control_command("help", HelpCommand(self.commands))
            self.args_control("client", "forwards a control command to the client(s)", min_args=1)
            self.args_control("toggle-feature", "toggle a server feature on or off",
                              min_args=1, max_args=2, validation=[str, parse_boolean_value])
        else:
            self.do_add_control_command("*", DisabledCommand())

    def add_control_command(self, name: str, control) -> None:
        if self.enabled:
            self.do_add_control_command(name, control)

    def do_add_control_command(self, name: str, control) -> None:
        self.commands[name] = control

    def process_control_command(self, proto, *args) -> tuple[ControlCode | int, str]:
        if args:
            name = str(args[0])
            ss = self.get_server_source(proto)
            if ss and getattr(ss, "effective_readonly", lambda: False)() and name not in READONLY_CONTROL_COMMANDS:
                return ControlCode.FAILED, f"control command {name!r} denied by readonly mode"
        from xpra.net.control.common import process_control_command
        return process_control_command(proto, self.commands, *args)

    def handle_command_request(self, proto, *args) -> None:
        """ client sent a command request as part of the hello packet """
        if not args:
            raise ValueError("no arguments supplied")
        from xpra.net.control.common import process_control_command
        code, response = process_control_command(proto, self.commands, *args)
        hello = {"command_response": (int(code), response)}
        proto.send_now(Packet(HELLO, hello))

    def _handle_hello_request_command(self, proto, caps: typedict) -> bool:
        command_req = tuple(str(x) for x in caps.tupleget("command_request"))
        if not command_req:
            return False
        self.handle_command_request(proto, *command_req)
        return True

    # control commands may spawn subprocesses or do file I/O, so run them on the
    # main thread rather than inline on the network parse thread:
    @packet_handler(CONTROL_REQUEST, main_thread=True)
    def _process_request(self, protocol, packet: Packet) -> None:
        """ client sent a command request through its normal channel """
        assert len(packet) >= 2, "invalid command request packet (too small!)"
        # this may end up calling do_handle_command_request via the adapter
        code, msg = self.process_control_command(protocol, *packet[1:])
        log("command request returned: %s (%s)", code, msg)

    #########################################
    # Control Commands
    #########################################

    def control_command_readonly(self, onoff) -> str:
        log("control_command_readonly(%s)", onoff)
        self.server.readonly = onoff
        self.setting_changed("readonly", onoff)
        msg = f"server readonly: {onoff}"
        log.info(msg)
        return msg

    def control_command_client_readonly(self, client_uuids: str, onoff) -> str:
        log("control_command_client_readonly(%s, %s)", client_uuids, onoff)
        sources = self.get_sources_by_type()
        if client_uuids != "*":
            uuids = tuple(x.strip() for x in client_uuids.split(",") if x.strip())
            sources = tuple(ss for ss in sources if getattr(ss, "uuid", "") in uuids)
        count = 0
        for ss in sources:
            if not hasattr(ss, "set_control_readonly"):
                continue
            ss.set_control_readonly(onoff)
            ss.send_setting_change("readonly", ss.server_enforced_readonly())
            self.server.emit("setting-changed", "readonly", ss.effective_readonly(), ss)
            count += 1
        msg = f"set client readonly={onoff} for {count} client(s)"
        log.info(msg)
        return msg

    def control_command_client(self, command: str, *args: PacketElement) -> str:
        try:
            from xpra.server.source.control import ControlConnection
        except ImportError:
            return "no control support available"
        control_connections = get_sources_by_type(self.server, ControlConnection)
        if command == "help":
            all_control_commands = []
            for source in control_connections:
                all_control_commands += list(source.client_control_commands)
            return "clients may support the following control commands: %s" % csv(all_control_commands)

        count = 0
        for source in control_connections:
            # forwards to *the* client, if there is *one*
            if command not in source.client_control_commands:
                log.info(f"client command {command!r} not forwarded to client {source} (not supported)")
            else:
                source.send_client_command(command, *args)
                count += 1

        return f"client control command {command!r} forwarded to {count} clients"

    def control_command_toggle_feature(self, feature: str, state: str="") -> str:
        log("control_command_toggle_feature(%s, %s)", feature, state)
        targets = [self.server] + list(self.server.subsystems.values())
        feature_targets: dict[str, object] = {}
        for target in targets:
            for cls in type(target).__mro__:
                for f in cls.__dict__.get("toggle_features", ()):
                    feature_targets.setdefault(f, target)
        features = set(feature_targets)
        if feature == "help":
            return "found the following features: %s" % csv(features)
        if feature not in features:
            msg = f"invalid feature {feature!r}"
            log.warn(msg)
            return msg
        fn = feature.replace("-", "_")
        target = feature_targets[feature]
        if not hasattr(target, fn):
            msg = f"attribute {feature!r} not found - bug?"
            log.warn(msg)
            return msg
        cur = getattr(target, fn, None)
        setattr(target, fn, state)
        setting_changed = getattr(target, "setting_changed", self.server.setting_changed)
        assert callable(setting_changed)
        # noinspection calling-non-callable
        setting_changed(feature, state)
        return f"{feature} set to {state} (was {cur!r})"

# This file is part of Xpra.
# Copyright (C) 2025 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import socket
from typing import Sequence, Any

from paramiko import PasswordRequiredException, SSHException

from xpra.net.bytestreams import SocketConnection
from xpra.net.ssh.util import LOG_EOF
from xpra.scripts.pinentry import input_pass
from xpra.util.env import envint
from xpra.util.io import load_binary_file
from xpra.util.str_fn import csv
from xpra.log import Logger
from xpra.util.thread import start_thread

log = Logger("network", "ssh")

if log.is_debug_enabled():
    import logging
    logging.getLogger("paramiko").setLevel(logging.DEBUG)

# how many times we prompt the user for a key passphrase:
PASSPHRASE_RETRY = max(1, min(5, envint("XPRA_SSH_PASSPHRASE_RETRY", 3)))


def keymd5(k) -> str:
    import binascii
    f = binascii.hexlify(k.get_fingerprint()).decode("latin1")
    s = "MD5"
    while f:
        s += ":" + f[:2]
        f = f[2:]
    return s


def get_sha256_fingerprint(blob: bytes) -> str:
    """
    the `SHA256:..` fingerprint for a public key blob,
    in the same format as the one shown by `ssh-keygen -l` and `ssh-add -l`
    """
    import base64
    import hashlib
    digest = hashlib.sha256(blob).digest()
    # the fingerprint skips the padding at the end of the base64 encoded value:
    encoded = base64.b64encode(digest).rstrip(b'=')
    return "SHA256:" + encoded.decode("ascii")


def get_sha256_fingerprint_for_key(key) -> str:
    """
    the `SHA256:..` fingerprint for a `paramiko` key object
    """
    try:
        return get_sha256_fingerprint(key.asbytes())
    except (AttributeError, SSHException) as e:
        log(f"failed to get the fingerprint for {key}: {e}")
        return ""


def get_sha256_fingerprint_for_keyfile(keyfile: str) -> str:
    import binascii
    if os.path.exists(f"{keyfile}.pub"):
        keyfile = f"{keyfile}.pub"
    with open(keyfile) as f:
        data = f.read()
    parts = data.split()
    if not parts or parts[0].startswith("-----"):
        # this is not a public key file:
        # we would have to load (and perhaps decrypt) the private key to get its fingerprint
        return ""
    # public key files look like this: `<keytype> <base64 blob> [comment]`
    # (the keytype prefix varies: `ssh-rsa`, `ecdsa-sha2-nistp256`, `sk-ssh-ed25519@openssh.com`, etc)
    blob = parts[1] if len(parts) > 1 else parts[0]
    return get_sha256_fingerprint(binascii.a2b_base64(blob))


def get_key_fingerprints(keyfiles: Sequence[str]) -> list[str]:
    allowed_key_fingerprints: list[str] = []
    failed: dict[str, str] = {}
    for keyfile in keyfiles:
        try:
            fingerprint = get_sha256_fingerprint_for_keyfile(keyfile)
            if fingerprint:
                allowed_key_fingerprints.append(fingerprint)
        except (ValueError, OSError) as e:
            if os.path.exists(keyfile):
                log(f"failed to load agent key fingerprint from {keyfile!r}: {e}")
                failed[keyfile] = str(e)
    if failed:
        log.info("unable to load key fingerprints for %s", csv(repr(keyfile) for keyfile in failed.keys()))
    return allowed_key_fingerprints


def load_encrypted_private_key(pkey_class, keyfile_path: str):
    """
    prompt the user for the passphrase, up to `PASSPHRASE_RETRY` times,
    unless the user cancels the prompt
    """
    for attempt in range(1, PASSPHRASE_RETRY + 1):
        prompt = f"please enter the passphrase for:\n{keyfile_path}"
        if PASSPHRASE_RETRY > 1:
            prompt += f"\n(attempt {attempt} of {PASSPHRASE_RETRY})"
        passphrase = input_pass(prompt)
        if not passphrase:
            # the user cancelled the prompt: don't try again
            log("no passphrase given, not retrying")
            return None
        try:
            return pkey_class.from_private_key_file(keyfile_path, passphrase)
        except SSHException as ke:
            log("from_private_key_file", exc_info=True)
            log.info(f"cannot load key from file {keyfile_path}:")
            for emsg in str(ke).split(". "):
                if emsg.startswith("('"):
                    emsg = emsg[2:]
                if emsg.endswith(")."):
                    emsg = emsg[:-2]
                if emsg:
                    log.info(" %s.", emsg)
    return None


def load_private_key(keyfile_path: str):
    if not os.path.exists(keyfile_path):
        log(f"no keyfile at {keyfile_path!r}")
        return None
    log(f"trying {keyfile_path!r}")
    import paramiko
    try_key_formats: Sequence[str] = ()
    for kf in ("RSA", "DSS", "ECDSA", "Ed25519"):
        if keyfile_path.lower().endswith(kf.lower()):
            try_key_formats = (kf,)
            break
    if not try_key_formats:
        try_key_formats = ("RSA", "DSS", "ECDSA", "Ed25519")
    for pkey_classname in try_key_formats:
        pkey_class = getattr(paramiko, f"{pkey_classname}Key", None)
        if pkey_class is None:
            log(f"no {pkey_classname} key type")
            continue
        log(f"trying to load as {pkey_classname}")
        try:
            key = pkey_class.from_private_key_file(keyfile_path)
            log(f"{keyfile_path!r} as {pkey_classname}: {keymd5(key)}")
            log.info(f"loaded {pkey_classname} private key from {keyfile_path!r}")
            return key
        except PasswordRequiredException as e:
            log(f"{keyfile_path!r} keyfile requires a passphrase: {e}")
            key = load_encrypted_private_key(pkey_class, keyfile_path)
            if key:
                log(f"{keyfile_path!r} as {pkey_classname}: {keymd5(key)}")
                log.info(f"loaded {pkey_classname} private key from {keyfile_path!r}")
                return key
        except Exception:
            log(f"auth_publickey() loading as {pkey_classname}", exc_info=True)
            key_data = load_binary_file(keyfile_path)
            if key_data and key_data.find(b"BEGIN OPENSSH PRIVATE KEY") >= 0:
                log(" (OpenSSH private key file)")
    return None


class SSHSocketConnection(SocketConnection):

    def __init__(self, ssh_channel, sock, sockname: str | tuple | list,
                 peername, target, info=None, socket_options=None):
        self._raw_socket = sock
        super().__init__(ssh_channel, sockname, peername, target, "ssh", info, socket_options)

    def get_raw_socket(self):
        return self._raw_socket

    def start_stderr_reader(self) -> None:
        start_thread(self._stderr_reader, "ssh-stderr-reader", daemon=True)

    def _stderr_reader(self) -> None:
        chan = self._socket
        stderr = chan.makefile_stderr("rb", 1)
        while self.active:
            v = stderr.readline()
            if not v:
                if LOG_EOF and self.active:
                    log.info("SSH EOF on stderr of %s", chan.get_name())
                break
            s = v.rstrip(b"\n\r").decode()
            if s:
                log.info(" SSH: %r", s)

    def peek(self, n) -> bytes:
        if not self._raw_socket:
            return b""
        return self._raw_socket.recv(n, socket.MSG_PEEK)

    def recv_into(self, buf) -> int:
        return self._recv_into(self._channel_recv_into, buf)

    def _channel_recv_into(self, buf) -> int:
        data = self._socket.recv(len(buf))
        n = len(data)
        if n:
            buf[:n] = data
        return n

    def get_socket_info(self) -> dict[str, Any]:
        if not self._raw_socket:
            return {}
        return self.do_get_socket_info(self._raw_socket)

    def get_info(self) -> dict[str, Any]:
        i = super().get_info()
        if s := self._socket:
            i["ssh-channel"] = {
                "id": s.get_id(),
                "name": s.get_name(),
            }
        return i

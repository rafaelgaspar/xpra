# This file is part of Xpra.
# Copyright (C) 2017 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import shlex
from subprocess import Popen
from collections.abc import Sequence

from xpra.auth.common import get_auth_exec_env
from xpra.util.objects import typedict
from xpra.util.str_fn import std, alnum, bytestostr
from xpra.util.env import envint, shellsub, first_time
from xpra.os_util import gi_import, WIN32
from xpra.util.parsing import TRUE_OPTIONS
from xpra.util.child_reaper import get_child_reaper
from xpra.auth.sys_auth_base import SysAuthenticator, log
from xpra.util.system import stop_proc

GLib = gi_import("GLib")

TIMEOUT = envint("XPRA_EXEC_AUTH_TIMEOUT", 600)


def get_default_auth_dialog() -> str:
    from xpra.util.io import find_libexec_command
    cmd = "auth_dialog.exe" if WIN32 else "auth_dialog"
    auth_dialog = find_libexec_command(cmd)
    if not auth_dialog:
        from xpra.platform.paths import get_app_dir  # pylint: disable=import-outside-toplevel
        auth_dialog = os.path.join(get_app_dir(), "auth_dialog")
    log(f"auth_dialog={auth_dialog!r}")
    if not os.path.exists(auth_dialog) and first_time("auth-dialog-not-found"):
        log.warn(f"Warning: authentication dialog command {cmd!r} was not found")
    return auth_dialog


class Authenticator(SysAuthenticator):

    __slots__ = (
        "command", "connection_str", "display", "http_headers", "proc", "require_challenge", "timeout",
        "timeout_event", "timer",
    )

    def __init__(self, **kwargs):
        log(f"exec.Authenticator({kwargs})")
        self.command = shlex.split(kwargs.pop("command", "${auth_dialog} ${info} ${timeout}"))
        self.require_challenge = kwargs.pop("require-challenge", "no").lower() in TRUE_OPTIONS
        self.timeout = kwargs.pop("timeout", TIMEOUT)
        self.display = kwargs.pop("display", "auto")
        self.timer = 0
        self.proc = None
        self.timeout_event = False
        if not self.command:
            self.command = [get_default_auth_dialog(), ]
        connection = kwargs.get("connection")
        if not connection:
            raise ValueError("connection object is missing")
        log(f"exec connection info: {connection}")
        self.connection_str = str(connection)
        self.http_headers = getattr(connection, "options", {}).get("http-headers", {})
        super().__init__(**kwargs)

    def requires_challenge(self) -> bool:
        return self.require_challenge

    def get_challenge(self, digests: Sequence[str]) -> tuple[bytes, str]:
        assert self.require_challenge
        if "xor" not in digests:
            log.error("Error: exec authentication requires the 'xor' digest")
            return b"", ""
        return super().get_challenge(("xor", ))

    def validate_caps(self, caps: typedict) -> bool:
        if not self.require_challenge:
            return True
        return super().validate_caps(caps)

    def default_authenticate_check(self, caps: typedict) -> bool:
        info = f"Connection request from {self.connection_str}"
        subs = {
            "auth_dialog": get_default_auth_dialog(),
            "info": info,
            "timeout": self.timeout,
            "username": alnum(self.username),
            "prompt": std(self.prompt),
            "display": self.display,
        }
        if self.http_headers:
            import json
            import base64
            subs["http_headers"] = base64.b64encode(json.dumps(self.http_headers).encode("utf8")).decode("latin1")
        if self.require_challenge:
            subs["password"] = bytestostr(self.unxor_response(caps))
        cmd = tuple(shellsub(v, subs) for v in self.command)
        log("authenticate(..) shellsub(%s)=%r", self.command, cmd)
        env = get_auth_exec_env(self.display)
        log("authenticate(..) env=%s", env)
        # [self.command, info, str(self.timeout)]
        try:
            with Popen(cmd, env=env) as proc:
                self.proc = proc
                log(f"authenticate(..) Popen({cmd})={proc}")
                # if required, make sure we kill the command when it times out:
                if self.timeout > 0:
                    self.timer = GLib.timeout_add(self.timeout * 1000, self.command_timedout)
                    get_child_reaper().add_process(proc, "exec auth", cmd, True, True, self.command_ended)
        except OSError as e:
            log(f"error running {cmd!r}", exc_info=True)
            log.error("Error: cannot run exec authentication module command")
            log.error(f" {cmd!r}")
            log.estr(e)
            return False
        except ValueError as e:
            # an argument that cannot be passed to a command,
            # ie: a `${password}` decoded from the client's response which contains a NUL byte,
            # don't log the command line here since it may contain that password:
            log(f"error running {cmd!r}", exc_info=True)
            log.error("Error: invalid exec authentication module command arguments")
            log.estr(e)
            return False
        v = proc.returncode
        log(f"authenticate(..) returncode({cmd})={v}")
        if self.timeout_event:
            return False
        return v == 0

    def command_ended(self, *args) -> None:
        t = self.timer
        log(f"exec auth.command_ended{args} timer={t}")
        if t:
            self.timer = 0
            GLib.source_remove(t)

    def command_timedout(self) -> None:
        proc = self.proc
        log(f"exec auth.command_timedout() proc={proc}")
        self.timeout_event = True
        self.timer = 0
        stop_proc(proc, "exec authentication command")

    def __repr__(self):
        return "exec"

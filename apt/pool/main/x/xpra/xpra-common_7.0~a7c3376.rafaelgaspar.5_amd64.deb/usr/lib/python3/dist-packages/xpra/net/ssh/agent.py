# This file is part of Xpra.
# Copyright (C) 2018 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import shlex
import stat
from collections.abc import Iterable

from xpra.os_util import valid_uuid
from xpra.util.io import is_socket
from xpra.log import Logger

log = Logger("server", "ssh")


def ssh_dir_path(session_dir: str = "") -> str:
    # evaluate the environment at call time, not at import time
    # (the session directory may be renamed after this module is imported):
    return os.path.join(session_dir or os.environ.get("XPRA_SESSION_DIR", ""), "ssh")


def setup_ssh_auth_sock(session_dir: str) -> str:
    # the 'ssh' dir contains agent socket symlinks to the real agent socket,
    # so we can just update the "agent" symlink
    # which is the one that applications are told to use
    ssh_dir = ssh_dir_path(session_dir)
    if not os.path.exists(ssh_dir):
        os.mkdir(ssh_dir, 0o700)
    # ie: "/run/user/1000/xpra/10/ssh/agent"
    agent_sockpath = get_ssh_agent_path("agent")
    # the current value from the environment:
    # ie: "SSH_AUTH_SOCK=/tmp/ssh-XXXX4KyFhe/agent.726992"
    # or "SSH_AUTH_SOCK=/run/user/1000/keyring/ssh"
    cur_sockpath = os.environ.pop("SSH_AUTH_SOCK", "")
    # ie: "/run/user/1000/xpra/10/ssh/agent.default"
    agent_default_sockpath = get_ssh_agent_path("agent.default")
    if os.path.islink(agent_default_sockpath):
        if not os.path.exists(agent_default_sockpath):
            # remove dead symlink
            os.unlink(agent_default_sockpath)
    elif os.path.exists(agent_default_sockpath):
        raise RuntimeError(f"{agent_default_sockpath!r} already exists but it is not a symbolic link")
    if cur_sockpath and cur_sockpath != agent_sockpath and not os.path.exists(agent_default_sockpath):
        # the current agent socket will be the default:
        # ie: "agent.default" -> "/run/user/1000/keyring/ssh"
        os.symlink(cur_sockpath, agent_default_sockpath)
    set_ssh_agent()
    return agent_sockpath


def get_ssh_agent_path(filename: str, session_dir: str = "") -> str:
    ssh_dir = ssh_dir_path(session_dir)
    if any((c and c in filename) for c in (os.path.sep, os.path.altsep, ":", "..", "~")) or filename.startswith("."):
        raise ValueError(f"illegal characters found in ssh agent filename {filename!r}")
    return os.path.join(ssh_dir, filename or "agent.default")


def set_ssh_agent(filename: str = "") -> None:
    ssh_dir = ssh_dir_path()
    if filename and os.path.isabs(filename):
        sockpath = filename
    else:
        filename = filename or "agent.default"
        sockpath = get_ssh_agent_path(filename)
    if not os.path.exists(sockpath):
        log(f"set_ssh_agent: invalid sockpath {sockpath!r}")
        return
    agent_sockpath = os.path.join(ssh_dir, "agent")
    try:
        if os.path.islink(agent_sockpath):
            os.unlink(agent_sockpath)
        log("setting ssh agent link:")
        log(f" {filename!r} -> {agent_sockpath!r}")
        os.symlink(filename, agent_sockpath)
    except OSError as e:
        log(f"set_ssh_agent({filename})", exc_info=True)
        log.error(f"Error: failed to set ssh agent socket path to {filename!r}")
        log.estr(e)


def clean_agent_socket(uuid: str = "") -> None:
    sockpath = get_ssh_agent_path(uuid)
    try:
        if os.path.exists(sockpath):
            log(f"removing ssh agent socket {sockpath!r}")
            os.unlink(sockpath)
    except OSError as e:
        log.error(f"Error: failed to remove ssh agent socket path {sockpath!r}")
        log.error(f" for uuid {uuid!r}")
        log.estr(e)


def setup_proxy_ssh_socket(
        cmdline: Iterable[str],
        auth_sock: str = "",
        session_dir: str = "",
) -> str:
    # evaluate the environment at call time, not at import time:
    auth_sock = auth_sock or os.environ.get("SSH_AUTH_SOCK", "")
    session_dir = session_dir or os.environ.get("XPRA_SESSION_DIR", "")
    log(f"setup_proxy_ssh_socket({shlex.join(cmdline)!r}, {auth_sock!r}")
    # this is the socket path that the ssh client wants us to use:
    # ie: "SSH_AUTH_SOCK=/tmp/ssh-XXXX4KyFhe/agent.726992"
    if not auth_sock or not os.path.exists(auth_sock) or not is_socket(auth_sock):
        log(f"setup_proxy_ssh_socket invalid SSH_AUTH_SOCK={auth_sock!r}")
        return ""
    if not session_dir or not os.path.exists(session_dir) or not os.path.isdir(session_dir):
        log(f"setup_proxy_ssh_socket invalid session_dir={session_dir!r}")
        return ""
    # locate the ssh agent uuid,
    # which is used to derive the agent path symlink
    # that the server will want to use for this connection,
    # newer clients pass it to the remote proxy command process using an env var:
    agent_uuid = ""
    for x in cmdline:
        if x.startswith("--env=SSH_AGENT_UUID="):
            agent_uuid = x.removeprefix("--env=SSH_AGENT_UUID=")
            break
    # prevent illegal paths:
    if not valid_uuid(agent_uuid):
        log(f"setup_proxy_ssh_socket invalid SSH_AGENT_UUID={agent_uuid!r}")
        return ""
    # ie: "/run/user/$UID/xpra/$DISPLAY/ssh/$UUID
    agent_uuid_sockpath = get_ssh_agent_path(agent_uuid, session_dir)
    if os.path.exists(agent_uuid_sockpath) or os.path.islink(agent_uuid_sockpath):
        if is_socket(agent_uuid_sockpath):
            log(f"setup_proxy_ssh_socket keeping existing valid socket {agent_uuid_sockpath!r}")
            # keep the existing socket unchanged - somehow it still works?
            return agent_uuid_sockpath
        log(f"setup_proxy_ssh_socket removing invalid symlink / socket {agent_uuid_sockpath!r}")
        try:
            os.unlink(agent_uuid_sockpath)
        except OSError as e:
            log(f"os.unlink({agent_uuid_sockpath!r})", exc_info=True)
            log.error("Error: removing the broken ssh agent symlink")
            log.estr(e)
    log(f"setup_proxy_ssh_socket {agent_uuid_sockpath!r} -> {auth_sock!r}")
    try:
        os.symlink(auth_sock, agent_uuid_sockpath)
    except OSError as e:
        log(f"os.symlink({auth_sock}, {agent_uuid_sockpath})", exc_info=True)
        log.error("Error creating ssh agent socket symlink")
        log.estr(e)
        return ""
    return agent_uuid_sockpath


def setup_client_ssh_agent_socket(uuid: str, ssh_auth_sock: str, ssh_auth_sock_stat: tuple[int, ...] = ()) -> str:
    if not uuid:
        log("cannot setup ssh agent without client uuid")
        return ""
    # perhaps the agent sock path for this uuid already exists:
    # ie: /run/user/1000/xpra/10/$UUID
    sockpath = get_ssh_agent_path(uuid)
    log(f"get_ssh_agent_path({uuid})={sockpath}")
    if not os.path.exists(sockpath) or not is_socket(sockpath):
        if os.path.islink(sockpath):
            # dead symlink
            try:
                os.unlink(sockpath)
            except OSError as e:
                log(f"os.unlink({sockpath!r})", exc_info=True)
                log.error("Error: removing the broken ssh agent symlink")
                log.estr(e)
        # Only reuse a client path when its socket identity matches. Identical
        # paths on different machines need not refer to the same agent.
        log(f"client supplied ssh-auth-sock={ssh_auth_sock}")
        if not ssh_auth_sock or not os.path.isabs(ssh_auth_sock) or len(ssh_auth_sock_stat) != 2:
            return ""
        try:
            sockstat = os.stat(ssh_auth_sock)
        except (OSError, ValueError):
            log(f"cannot stat client ssh-auth-sock={ssh_auth_sock!r}", exc_info=True)
            return ""
        identity = (getattr(sockstat, "st_dev", None), getattr(sockstat, "st_ino", None))
        if not stat.S_ISSOCK(sockstat.st_mode) or identity != ssh_auth_sock_stat or not identity[1]:
            log(f"client ssh-auth-sock identity mismatch: {identity} != {ssh_auth_sock_stat}")
            return ""
        if not hasattr(os, "geteuid") or sockstat.st_uid != os.geteuid():
            log(f"client ssh-auth-sock is not owned by the server user: {ssh_auth_sock!r}")
            return ""
        try:
            # ie: /run/user/1000/xpra/10/$UUID -> /tmp/ssh-XXXXvjt4hN/agent.766599
            os.symlink(ssh_auth_sock, sockpath)
        except OSError as e:
            log(f"os.symlink({ssh_auth_sock}, {sockpath})", exc_info=True)
            log.error("Error setting up ssh agent socket symlink")
            log.estr(e)
            sockpath = ""
    return sockpath

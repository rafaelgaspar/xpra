# This file is part of Xpra.
# Copyright (C) 2014 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from io import BytesIO
import PIL
from PIL import Image
from typing import Any
from collections.abc import Sequence

from xpra.common import SizedBuffer
from xpra.util.objects import typedict
from xpra.util.str_fn import csv, hexstr, Ellipsizer
from xpra.codecs.image_type import get_image_type
from xpra.codecs.debug import may_save_image
from xpra.log import Logger

log = Logger("encoder", "pillow")

Image.init()

DECODE_FORMATS = os.environ.get("XPRA_PILLOW_DECODE_FORMATS", "png,png/L,png/P,jpeg,webp").split(",")


def open_only(data: SizedBuffer, types=("png", "jpeg", "webp", "xpm")) -> Image:
    itype = get_image_type(data) or "unknown"
    if itype not in types:
        raise ValueError(f"invalid data: {itype}, not recognized as {csv(types)}, header: " + hexstr(data[:64]))
    buf = BytesIO(data)
    return Image.open(buf)


def get_version() -> str:
    return PIL.__version__


def get_type() -> str:
    return "pillow"


def do_get_encodings() -> list[str]:
    log("PIL.Image.OPEN=%s", Image.OPEN)
    encodings = []
    for encoding in DECODE_FORMATS:
        # strip suffix (so "png/L" -> "png")
        stripped = encoding.split("/")[0].upper()
        if stripped in Image.OPEN:
            encodings.append(encoding)
    log("do_get_encodings()=%s", encodings)
    return encodings


ENCODINGS: Sequence[str] = tuple(do_get_encodings())


def get_encodings() -> Sequence[str]:
    return ENCODINGS


def get_info() -> dict[str, Any]:
    return {
        "version": get_version(),
        "encodings": get_encodings(),
    }


def decompress(coding: str, img_data: SizedBuffer, options: typedict) -> tuple[str, bytes, int, int, int]:
    # can be called from any thread
    actual = get_image_type(img_data)
    if not actual or not coding.startswith(actual):
        raise ValueError(f"expected {coding!r} image data but received %r" % (actual or "unknown"))
    buf = BytesIO(img_data)
    try:
        img = Image.open(buf)
    except Image.DecompressionBombError:
        log("received a DecompressionBombError")
        log(" for %s", Ellipsizer(img_data))
        from xpra.codecs.constants import TransientCodecException
        raise TransientCodecException("received a DecompressionBombError on a %s" % actual) from None
    assert img.mode in ("L", "LA", "P", "RGB", "RGBA", "RGBX"), f"invalid image mode: {img.mode}"
    transparency = options.intget("transparency", -1)
    if img.mode == "P":
        if transparency >= 0:
            # this deals with alpha without any extra work
            img = img.convert("RGBA")
        else:
            img = img.convert("RGB")
    elif img.mode == "L":
        if transparency >= 0:
            # why do we have to deal with alpha ourselves??
            def mask_value(a: int) -> int:
                if a != transparency:
                    return 255
                return 0

            mask = Image.eval(img, mask_value)
            mask = mask.convert("L")

            def nomask_value(a: int) -> int:
                if a != transparency:
                    return a
                return 0

            img = Image.eval(img, nomask_value)
            img = img.convert("RGBA")
            img.putalpha(mask)
        else:
            img = img.convert("RGB")
    elif img.mode == "LA":
        img = img.convert("RGBA")

    if img.mode not in ("RGB", "RGBA", "RGBX"):
        raise ValueError(f"invalid image mode: {img.mode}")
    width, height = img.size
    requested_format = options.strget("rgb_format")
    rgb_format = requested_format or img.mode
    pack_image = img
    if requested_format:
        pack_mode = "RGBA" if "A" in rgb_format else "RGB"
        if img.mode != pack_mode:
            pack_image = img.convert(pack_mode)
    try:
        raw_data = pack_image.tobytes("raw", rgb_format)
    except ValueError:
        if not requested_format:
            raise
        log.warn("Warning: Pillow cannot convert decoded %s pixels to requested RGB format %r, using %s instead", img.mode, requested_format, img.mode)
        rgb_format = img.mode
        raw_data = img.tobytes("raw", rgb_format)
    rowstride = width * len(rgb_format)
    log("pillow decoded %7i bytes of %5s data to %8i bytes of %s", len(img_data), coding, len(raw_data), rgb_format)
    may_save_image(coding, img_data)
    return rgb_format, raw_data, width, height, rowstride


def selftest(_full=False) -> None:
    global ENCODINGS
    from xpra.codecs.checks import TEST_PICTURES  # pylint: disable=import-outside-toplevel
    # test data generated using the encoder:
    for encoding, test_data in TEST_PICTURES.items():
        if encoding not in ENCODINGS:
            # removed already
            continue
        for size, samples in test_data.items():
            log(f"testing {encoding} at size {size} with {len(samples)} samples")
            for i, (cdata, options) in enumerate(samples):
                try:
                    log(f"testing sample {i}: {len(cdata):5} bytes")
                    buf = BytesIO(cdata)
                    img = PIL.Image.open(buf)
                    assert img, "failed to open image data"
                    raw_data = img.tobytes("raw", img.mode)
                    assert raw_data
                    # now try with junk:
                    cdata = b"ABCD" + cdata
                    buf = BytesIO(cdata)
                    try:
                        img = PIL.Image.open(buf)
                        log.warn(f"Pillow failed to generate an error parsing invalid input: {img}, {options=}")
                    except Exception as e:
                        log("correctly raised exception for invalid input: %s", e)
                except Exception as e:
                    log("selftest:", exc_info=True)
                    log.error("Pillow error decoding %s with data:", encoding)
                    log.error(" %r", cdata)
                    log.error(" %s", e, exc_info=True)
                    ENCODINGS = tuple(x for x in ENCODINGS if x != encoding)


if __name__ == "__main__":
    selftest(True)
    print(csv(get_encodings()))

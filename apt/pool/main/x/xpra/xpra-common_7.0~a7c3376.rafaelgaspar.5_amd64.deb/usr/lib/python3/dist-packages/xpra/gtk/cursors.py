# This file is part of Xpra.
# Copyright (C) 2012 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from collections.abc import Sequence

from xpra.os_util import gi_import, WIN32
from xpra.util.env import envbool, first_time
from xpra.log import Logger

Gdk = gi_import("Gdk")

log = Logger("gtk", "cursor")

SAVE_CURSORS = envbool("XPRA_SAVE_CURSORS", False)

cursor_names = {}
cursor_types = {}
missing_cursor_names = set()


def _init_map() -> None:
    for x in dir(Gdk.CursorType):
        if not x.isupper():
            # probably a method
            continue
        try:
            v = int(getattr(Gdk.CursorType, x))
            cursor_names[v] = x
            cursor_types[x] = v
        except (TypeError, ValueError):
            pass


_init_map()


def get_default_cursor() -> Gdk.Cursor:
    display = Gdk.Display.get_default()
    return Gdk.Cursor.new_from_name(display, "default")


# the servers send x11 cursor names,
# which the other platforms don't necessarily know:
# macos only has the css names, win32 only the legacy cursor types,
# and some names have no equivalent at all - just something close enough:
CURSOR_ALIASES: dict[str, tuple[str, ...]] = {
    "size_ver": ("ns-resize", "sb_v_double_arrow"),
    "size_hor": ("ew-resize", "sb_h_double_arrow"),
    "size_fdiag": ("nwse-resize", "bottom_right_corner"),
    "size_bdiag": ("nesw-resize", "bottom_left_corner"),
    "size_all": ("move", "fleur"),
    "sb_v_double_arrow": ("ns-resize", ),
    "sb_h_double_arrow": ("ew-resize", ),
    "top_side": ("n-resize", "ns-resize"),
    "bottom_side": ("s-resize", "ns-resize"),
    "left_side": ("w-resize", "ew-resize"),
    "right_side": ("e-resize", "ew-resize"),
    "top_left_corner": ("nw-resize", "nwse-resize"),
    "top_right_corner": ("ne-resize", "nesw-resize"),
    "bottom_left_corner": ("sw-resize", "nesw-resize"),
    "bottom_right_corner": ("se-resize", "nwse-resize"),
}


def new_cursor(display, cursor_name: str):
    try:
        cursor = Gdk.Cursor.new_from_name(display, cursor_name)
    except TypeError:
        log("Gdk.Cursor.new_from_name%s", (display, cursor_name), exc_info=True)
        cursor = None
    if cursor:
        log("Gdk.Cursor.new_from_name(%s, %s)=%s", display, cursor_name, cursor)
        return cursor
    gdk_cursor = cursor_types.get(cursor_name.upper())
    log("gdk_cursor(%s)=%s", cursor_name, gdk_cursor)
    if gdk_cursor is None:
        return None
    try:
        cursor = Gdk.Cursor.new_for_display(display, gdk_cursor)
        log("Cursor.new_for_display(%s, %s)=%s", display, gdk_cursor, cursor)
        return cursor
    except TypeError as e:
        log("new_Cursor_for_display(%s, %s)", display, gdk_cursor, exc_info=True)
        if first_time("cursor:%s" % cursor_name.upper()):
            log.error("Error creating cursor %s: %s", cursor_name.upper(), e)
    return None


def get_local_cursor(cursor_name: str):
    display = Gdk.Display.get_default()
    if not cursor_name or not display:
        return None
    # some cursors exist but have no image we can use (win32 does that),
    # so keep trying the aliases until we find one we can paint:
    for name in (cursor_name, ) + CURSOR_ALIASES.get(cursor_name.lower(), ()):
        cursor = new_cursor(display, name)
        if cursor:
            pixbuf = cursor.get_image()
            log("%s.get_image()=%s", name, pixbuf)
            # #2498: gtk3 on MS Windows hands out empty pixel buffers,
            # which would paint an invisible cursor:
            if pixbuf and any(pixbuf.get_pixels()):
                return pixbuf
    if cursor_name not in missing_cursor_names:
        log("cursor name '%s' not found", cursor_name)
        missing_cursor_names.add(cursor_name)
    return None


def make_cursor(cursor_data: Sequence, xscale=1.0, yscale=1.0) -> Gdk.Cursor | None:
    from xpra.util.str_fn import Ellipsizer, repr_ellipsized, bytestostr, hexstr
    from xpra.gtk.pixbuf import get_pixbuf_from_data
    from xpra.platform.gui import get_default_cursor_size, get_max_cursor_size
    # if present, try cursor by name:
    display = Gdk.Display.get_default()
    if not display:
        return None
    GdkPixbuf = gi_import("GdkPixbuf")
    from xpra.util.system import is_Wayland
    # wayland does not give us cursor images, it only knows the names:
    USE_LOCAL_CURSORS = envbool("XPRA_USE_LOCAL_CURSORS", not is_Wayland())
    log("make_cursor(%s) has-name=%s, has-cursor-types=%s, xscale=%s, yscale=%s, USE_LOCAL_CURSORS=%s",
        Ellipsizer(cursor_data),
        len(cursor_data) >= 10, bool(cursor_types), xscale, yscale, USE_LOCAL_CURSORS)
    pixbuf = None
    if len(cursor_data) >= 10 and cursor_types and USE_LOCAL_CURSORS:
        cursor_name = bytestostr(cursor_data[9])
        pixbuf = get_local_cursor(cursor_name)
    # create cursor from the pixel data:
    encoding, _, _, w, h, xhot, yhot, serial, pixels = cursor_data[0:9]
    if encoding != "raw":
        log.warn("Warning: invalid cursor encoding: %s", encoding)
        return None
    if not pixbuf:
        if not pixels:
            log.warn("Warning: no cursor pixel data")
            log.warn(f" in cursor data {cursor_data}")
            return None
        if len(pixels) < w * h * 4:
            log.warn("Warning: not enough pixels provided in cursor data")
            log.warn(" %s needed and only %s bytes found:", w * h * 4, len(pixels))
            log.warn(" '%s')", repr_ellipsized(hexstr(pixels)))
            return None
        pixbuf = get_pixbuf_from_data(pixels, True, w, h, w * 4)
    else:
        w = pixbuf.get_width()
        h = pixbuf.get_height()
        pixels = pixbuf.get_pixels()
        # this is a local cursor: the server hotspot belongs to the image we did not use,
        # the theme records its own with the pixbuf:
        hotspot = tuple(pixbuf.get_option(f"{axis}_hot") or "" for axis in ("x", "y"))
        if all(value.isdigit() for value in hotspot):
            log("using local cursor hotspot %s instead of %s", hotspot, (xhot, yhot))
            xhot, yhot = int(hotspot[0]), int(hotspot[1])
    x = max(0, min(xhot, w - 1))
    y = max(0, min(yhot, h - 1))
    csize = display.get_default_cursor_size()
    # the platform knows better than GDK, which reports `SM_CXCURSOR` as the limit on win32:
    cmaxw, cmaxh = get_max_cursor_size()
    if min(cmaxw, cmaxh) <= 0:
        cmaxw, cmaxh = display.get_maximal_cursor_size()
    log("new %s cursor at %s,%s with serial=%#x, dimensions: %sx%s, len(pixels)=%s",
        encoding, xhot, yhot, serial, w, h, len(pixels))
    log("default cursor size is %s, maximum=%s", csize, (cmaxw, cmaxh))

    # always apply desktop-scale first:
    if xscale != 1 or yscale != 1:
        sw = round(w * xscale)
        sh = round(h * yscale)
        sx = round(x * xscale)
        sy = round(y * yscale)
        sw = max(1, sw)
        sh = max(1, sh)
        # ensure we honour the max size if there is one,
        # shrinking both axes by the same ratio so the cursor keeps its shape and hotspot:
        if 0 < cmaxw < sw or 0 < cmaxh < sh:
            ratio = 1.0
            if cmaxw > 0:
                ratio = max(ratio, sw / cmaxw)
            if cmaxh > 0:
                ratio = max(ratio, sh / cmaxh)
            log("clamping cursor size to %ix%i using ratio=%s", cmaxw, cmaxh, ratio)
            sx, sy = round(sx / ratio), round(sy / ratio)
            sw, sh = max(1, round(sw / ratio)), max(1, round(sh / ratio))

        log("scaling cursor to %ix%i for desktop-scale %s/%s", sw, sh, xscale, yscale)
        pixbuf = pixbuf.scale_simple(sw, sh, GdkPixbuf.InterpType.BILINEAR)
        w, h, x, y = sw, sh, sx, sy

    # on win32, paste the cursor in the top-left corner of a transparent square:
    # * pixels of the previous cursor can remain visible outside of a smaller one (seen with VirtualBox),
    #   so make it at least as big as the system cursors
    # * GDK centers non-square cursors in a square bitmap without moving the hotspot
    size = max(w, h, *get_default_cursor_size()) if WIN32 else 0
    if size and (w, h) != (size, size):
        log("padding %ix%i cursor to %ix%i", w, h, size, size)
        square = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, True, 8, size, size)
        square.fill(0)
        pixbuf.copy_area(0, 0, w, h, square, 0, 0)
        pixbuf = square
    if SAVE_CURSORS:
        pixbuf.savev("cursor-%#x.png" % serial, "png", [], [])
    # clamp to pixbuf size:
    w = pixbuf.get_width()
    h = pixbuf.get_height()
    x = max(0, min(x, w - 1))
    y = max(0, min(y, h - 1))
    try:
        c = Gdk.Cursor.new_from_pixbuf(display, pixbuf, x, y)
    except RuntimeError as e:
        log.error("Error: failed to create cursor:")
        log.estr(e)
        log.error(" Gdk.Cursor.new_from_pixbuf%s", (display, pixbuf, x, y))
        log.error(" using size %ix%i with hotspot at %ix%i", w, h, x, y)
        c = None
    return c


def main() -> None:
    # pylint: disable=import-outside-toplevel
    from xpra.util.str_fn import csv
    from xpra.platform import program_context
    with program_context("Cursors", "Cursors"):
        print(csv(cursor_types))


if __name__ == "__main__":
    main()

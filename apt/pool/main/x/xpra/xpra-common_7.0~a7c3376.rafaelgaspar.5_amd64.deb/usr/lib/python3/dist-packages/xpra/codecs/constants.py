# This file is part of Xpra.
# Copyright (C) 2012 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from enum import IntEnum
from typing import Any
from weakref import WeakSet, WeakKeyDictionary
from dataclasses import dataclass, fields
from collections.abc import Callable, Iterable, Sequence

from xpra.util.objects import typedict
from xpra.util.env import envint, first_time
from xpra.util.str_fn import csv

# noinspection PyPep8
COMPRESS_FMT_PREFIX : str = "compress: %5.1fms for %4ix%-4i pixels at %4i,%-4i for wid=%-5i using %9s"
COMPRESS_RATIO      : str = " with ratio %5.1f%%  (%5iKB to %5iKB)"
COMPRESS_FMT_SUFFIX : str = ", sequence %5i, client_options=%-50s, options=%s"
COMPRESS_FMT        : str = COMPRESS_FMT_PREFIX + COMPRESS_RATIO + COMPRESS_FMT_SUFFIX
COMPRESS_FMT_DIRECT : str = (
    "compress:            %4ix%-4i pixels at %4i,%-4i for wid=%-5i using %9s" + COMPRESS_RATIO + COMPRESS_FMT_SUFFIX
)


FAST_DECODE_MIN_SPEED: int = envint("XPRA_FAST_DECODE_MIN_SPEED", 70)


# note: this is just for defining the order of encodings,
# so we have both core encodings (rgb24/rgb32) and regular encodings (rgb) in here:
PREFERRED_ENCODING_ORDER: Sequence[str] = (
    "h265", "av1", "h264", "vp9", "vp8", "mpeg4",
    "mpeg4+mp4", "h264+mp4", "vp8+webm", "vp9+webm",
    "webp", "png", "png/P", "png/L", "avif", "jph",
    "rgb", "rgb24", "rgb32", "jpeg", "jpega",
    "scroll",
    "grayscale",
    "stream",
)

PSEUDO_LOSSLESS_ENCODINGS: Sequence[str] = ("rgb", "png", "png/P", "png/L", "webp", "avif", "jph", "jpeg", "jpega")

TRUE_LOSSLESS_ENCODINGS: Sequence[str] = ("rgb", "png", "png/P", "png/L", "webp", "avif", "jph")

PREFERRED_REFRESH_ENCODING_ORDER: Sequence[str] = (
    "webp", "avif", "jph", "png", "png/P", "png/L", "rgb", "rgb24", "rgb32", "jpeg", "jpega",
)
STREAM_ENCODINGS: Sequence[str] = (
    "h265", "av1", "h264", "vp9", "vp8", "mpeg4",
    "mpeg4+mp4", "h264+mp4", "vp8+webm", "vp9+webm",
)

# encoding order for edges (usually one pixel high or wide):
EDGE_ENCODING_ORDER: Sequence[str] = (
    "rgb24", "rgb32",
    "png", "webp", "jph",
    "png/P", "png/L", "rgb", "jpeg", "jpega",
)

HELP_ORDER: Sequence[str] = (
    "auto",
    "stream",
    "grayscale",
    "h265", "av1", "h264", "vp8", "vp9", "mpeg4",
    "png", "png/P", "png/L", "webp", "avif", "jph",
    "rgb", "jpeg", "jpega",
    "scroll",
)


# value: how much smaller the output is
LOSSY_PIXEL_FORMATS: dict[str, float | int] = {
    "NV12": 2,
    "YUV420P": 2,
    "YUVA420P": 2,
    "YUV422P": 1.5,
    "YUVA422P": 1.5,
}


def get_plane_name(pixel_format: str = "YUV420P", index: int = 0) -> str:
    return ({
        "NV12": ("Y", "UV"),
        "AYUV": ("AYUV", ),
        "XYUV": ("XYUV", ),
        "Y410": ("Y410", ),
    }.get(pixel_format, list(pixel_format))[index])


# noinspection PyPep8
PIXEL_SUBSAMPLING : dict[str, Sequence[tuple[int, int]]] = {
    # NV12 is actually subsampled horizontally too - just like YUV420P
    # (but combines U and V planes so the resulting rowstride for the UV plane is the same as the Y plane):
    "NV12"      : ((1, 1), (1, 2)),
    "YUV420P"   : ((1, 1), (2, 2), (2, 2)),
    "YUVA420P"  : ((1, 1), (2, 2), (2, 2), (1, 1)),
    "YUV422P"   : ((1, 1), (2, 1), (2, 1)),
    "YUVA422P"  : ((1, 1), (2, 1), (2, 1), (1, 1)),
    "YUV444P"   : ((1, 1), (1, 1), (1, 1)),
    "YUVA444P"  : ((1, 1), (1, 1), (1, 1), (1, 1)),
    "YUV400P"   : ((1, 1), ),
    "GBRP"      : ((1, 1), (1, 1), (1, 1)),
    "GBRP9LE"   : ((1, 1), (1, 1), (1, 1)),
    "AYUV"      : ((1, 1), ),
    "XYUV"      : ((1, 1), ),
    "Y410"      : ((1, 1), ),
}


class ColorRange(IntEnum):
    UNKNOWN = -1
    STUDIO = 0
    FULL = 1


# Upper bound for any image dimension or rowstride we accept from a decoder.
# Decoders parse these values out of the compressed stream, so they are attacker
# controlled and must be validated before being used to size or index a buffer.
# None of the formats we support can legitimately reach this limit:
#  * webp dimensions are 14-bit fields, so capped at 16383x16383
#  * av1 tops out at 16384x8704 (level 6.3)
#  * vp9, h264 and hevc levels are all well below that
#  * jpeg SOF dimensions are 16-bit, but no real encoder emits anything this big
MAX_IMAGE_DIMENSION: int = envint("XPRA_MAX_IMAGE_DIMENSION", 16384)


def check_image_size(width: int, height: int, what: str = "image") -> None:
    """ validate dimensions decoded from an untrusted stream, raises ValueError """
    if width <= 0 or height <= 0:
        raise ValueError(f"invalid {what} size {width}x{height}")
    if width > MAX_IMAGE_DIMENSION or height > MAX_IMAGE_DIMENSION:
        raise ValueError(f"{what} size {width}x{height} exceeds the {MAX_IMAGE_DIMENSION} pixel limit")


def get_subsampling(pixel_format: str) -> str:
    # "YUV420P16" and "YUV420P10" are the same as "YUV420P" when it comes to subsampling:
    return pixel_format.replace("P16", "P").replace("P10", "P")


def get_subsampling_divs(pixel_format: str) -> Sequence[tuple[int, int]]:
    # Return size dividers for the given pixel format
    #  (Y_w, Y_h), (U_w, U_h), (V_w, V_h)
    subsampling = get_subsampling(pixel_format)
    if subsampling not in PIXEL_SUBSAMPLING:
        raise ValueError(f"invalid pixel format: {pixel_format!r}")
    return PIXEL_SUBSAMPLING[subsampling]


def preforder(encodings: Iterable[str]) -> Sequence[str]:
    encs: set[str] = set(encodings)
    return tuple(x for x in PREFERRED_ENCODING_ORDER if x in encs)


def get_profile(options: typedict, encoding: str = "h264", csc_mode: str = "YUV420P",
                default_profile: str = "main") -> str:
    for x in (
        options.strget(f"{encoding}.{csc_mode}.profile"),
        options.strget(f"{encoding}.profile"),
        os.environ.get(f"XPRA_{encoding.upper()}_{csc_mode}_PROFILE"),
        os.environ.get(f"XPRA_{encoding.upper()}_PROFILE"),
        default_profile,
    ):
        if x:
            return x
    return ""


# the levels each video encoding defines, as 10 x the level so that they can be
# compared exactly (a level is written "4.1" but 4.1 is not a round float).
# these are the levels the specifications list, not the ones any given encoder can reach:
# a codec which cannot manage all of them says so itself - see `unsupported_level`.
# clients express the level the same way for every codec (ie: "4.1"),
# the value that actually ends up in the bitstream is codec specific - see `get_level_value`.
# encodings which have no notion of a level (ie: vp8) are simply absent from this table:
VIDEO_LEVELS: dict[str, tuple[int, ...]] = {
    # h264 also defines "1b", which cannot be written as a number:
    "h264": (10, 11, 12, 13, 20, 21, 22, 30, 31, 32, 40, 41, 42, 50, 51, 52, 60, 61, 62),
    "h265": (10, 20, 21, 30, 31, 40, 41, 50, 51, 52, 60, 61, 62),
    "hevc": (10, 20, 21, 30, 31, 40, 41, 50, 51, 52, 60, 61, 62),
    # av1 has 4 minor levels for every major one, all the way up:
    "av1": tuple(major * 10 + minor for major in range(2, 8) for minor in range(4)),
    "vp9": (10, 11, 20, 21, 30, 31, 40, 41, 50, 51, 52, 60, 61, 62),
}


def parse_level(value: str, encoding: str = "h264") -> float:
    """
    parse a level (ie: "4.1") and validate it against the levels this encoding defines.
    anything we don't like returns 0, which every encoder treats as
    "no level requested, pick one yourself".
    since the value comes from the client, we only ever complain about it once.
    """
    levels = VIDEO_LEVELS.get(encoding, ())
    try:
        level = float(value)
    except (TypeError, ValueError):
        level = 0
    if round(level * 10) in levels:
        return level
    if first_time(f"invalid-{encoding}-level-{value}"):
        # pylint: disable=import-outside-toplevel
        from xpra.log import Logger
        log = Logger("encoding")
        log.warn(f"Warning: ignoring invalid {encoding} level {value!r}")
        if levels:
            log.warn(" valid levels are: %s", csv(f"{v // 10}.{v % 10}" for v in levels))
        else:
            log.warn(f" the {encoding!r} encoding has no configurable level")
    return 0


def get_level(options: typedict, encoding: str = "h264", csc_mode: str = "YUV420P") -> float:
    """
    the level requested by the client for this encoding (ie: 4.1),
    0 means that the encoder is free to choose one.

    there is deliberately no default level here, and encoders must not invent one:
    a level is an upper bound on the resolution, framerate and bitrate that a decoder
    is promised it will not have to exceed, so the only correct value is the lowest one
    the stream actually needs - which only the encoder can know, since it is the one
    choosing the resolution and bitrate. every encoder we drive can work it out for
    itself, and picking a level here instead would just make small streams claim to
    need more than they do, locking out decoders that could have kept up.
    """
    for x in (
        options.strget(f"{encoding}.{csc_mode}.level"),
        options.strget(f"{encoding}.level"),
        os.environ.get(f"XPRA_{encoding.upper()}_{csc_mode}_LEVEL", ""),
        os.environ.get(f"XPRA_{encoding.upper()}_LEVEL", ""),
    ):
        if x:
            return parse_level(x, encoding)
    return 0


def get_level_value(level: float, encoding: str = "h264") -> int:
    """
    the codec specific integer a level (ie: 4.1) is encoded as:
    * h264 `level_idc` (and vp9's target level) use 10 x the level: 41
    * hevc `general_level_idc` uses 30 x the level: 123
    * av1 uses a `seq_level_idx` counting 4 minor levels per major level, starting at 2.0: 9
    """
    major, minor = divmod(round(level * 10), 10)
    if encoding == "av1":
        return (major - 2) * 4 + minor
    if encoding in ("h265", "hevc"):
        return major * 30 + minor * 3
    return major * 10 + minor


def get_level_tuple(level: float) -> tuple[int, ...]:
    """
    a level (ie: 4.1) as a `(major, minor)` pair, for info dictionaries.
    empty if no level was requested.
    """
    if not level:
        return ()
    return divmod(round(level * 10), 10)


def unsupported_level(level: float, encoding: str = "h264", codec: str = "") -> None:
    """
    the level is a valid one for this encoding, but this particular codec cannot use it.
    as with `parse_level`, this comes from the client so we only say so once.
    """
    if first_time(f"{codec}-{encoding}-level-{level}"):
        # pylint: disable=import-outside-toplevel
        from xpra.log import Logger
        log = Logger("encoding")
        log.warn(f"Warning: {codec!r} cannot encode {encoding} at level {level}")
        log.warn(" using the encoder's default level instead")


def get_x264_quality(pct: int, profile: str = "") -> int:
    if pct >= 100 and profile == "high444":
        return 0
    return 50 - (min(100, max(0, pct)) * 49 // 100)


def get_x264_preset(speed: int = 50, fast_decode: bool = False) -> int:
    if fast_decode:
        speed = max(FAST_DECODE_MIN_SPEED, speed)
    if speed > 99:
        # only allow "ultrafast" if pct > 99
        return 0
    return 5 - max(0, min(4, speed // 20))


# the content-types made of sharp synthetic edges
# (coloured text, window borders, icons, syntax highlighting..)
# rather than natural continuous-tone imagery:
SCREEN_CONTENT_TYPES: Sequence[str] = ("text", "browser", "desktop", "lossless")


def is_screen_content(content_types: Iterable[str]) -> bool:
    if "video" in content_types:
        # real video content has no synthetic edges to preserve,
        # and needs the bandwidth more than the fidelity:
        return False
    return any(x in content_types for x in SCREEN_CONTENT_TYPES)


# the content-types that are continuous tone rather than synthetic:
VIDEO_CONTENT_TYPES: Sequence[str] = ("video", "picture")


def is_video_content(content_types: Iterable[str]) -> bool:
    # this is not simply `not is_screen_content(..)`:
    # both are false for a window we have not identified,
    # which some encoders have to treat differently from either:
    if is_screen_content(content_types):
        return False
    return any(x in content_types for x in VIDEO_CONTENT_TYPES)


RGB_FORMATS: Sequence[str] = (
    "XRGB",
    "BGRX",
    "ARGB",
    "BGRA",
    "RGB",
    "BGR",
    "r210",
)


class TransientCodecException(RuntimeError):
    pass


class CodecStateException(RuntimeError):
    pass


class EncodingNotSupported(RuntimeError):
    pass


# Live codec instances are tracked per `codec_class`, not per `CodecSpec` object:
# specs are cheap throw-away objects, re-created by every `get_specs()` call since #4483,
# so anything stored on the spec itself is lost as soon as the list is regenerated.
# The resource we actually want to account for - typically a hardware engine -
# is tied to the codec class, and one class covers all the encodings
# and colorspaces a codec module exposes.
_instances: WeakKeyDictionary[Callable, WeakSet[Any]] = WeakKeyDictionary()


def get_instances(codec_class: Callable) -> WeakSet[Any]:
    # `setdefault` is atomic, so concurrent encode threads all end up
    # sharing whichever set was inserted first:
    return _instances.setdefault(codec_class, WeakSet())


# noinspection PyPep8
@dataclass(kw_only=True)
class CodecSpec:

    codec_class     : Callable
    # arguments passed to `codec_class` by `make_instance()`,
    # for codecs that cannot bake all their parameters into module state
    # (ie: the `remote` encoder, which binds a server connection here):
    codec_args      : tuple = ()
    codec_type      : str
    input_colorspace: str = "invalid"
    output_colorspaces : Sequence[str] = ()      # ie: ("YUV420P" : "YUV420P", ...)
    quality         : int = 50
    speed           : int = 50
    size_efficiency : int = 50
    setup_cost      : int = 50
    cpu_cost        : int = 100
    gpu_cost        : int = 0
    min_w           : int = 1
    min_h           : int = 1
    max_w           : int = 4 * 1024
    max_h           : int = 4 * 1024
    can_scale       : bool = False
    score_boost     : int = 0
    width_mask      : int = 0xFFFF
    height_mask     : int = 0xFFFF
    max_instances   : int = 0
    skipped_fields : Sequence[str] = ("skipped_fields", "codec_args", )

    def make_instance(self) -> Any:
        # pylint: disable=import-outside-toplevel
        # I can't imagine why someone would have more than this many
        # encoders or csc modules active at the same time!
        WARN_LIMIT = envint("XPRA_CODEC_INSTANCE_COUNT_WARN", 25)
        from xpra.log import Logger
        log = Logger("encoding")
        live = get_instances(self.codec_class)
        cur = len(live)
        if 0 < self.max_instances < cur or cur >= WARN_LIMIT:
            instances = tuple(live)
            log.warn(f"Warning: already {cur} active instances of {self.codec_class}:")
            try:
                import gc
                for i in instances:
                    refs = gc.get_referrers(i)
                    log.warn(f" referers({i})={refs}")
            except Exception:
                pass
        else:
            log("make_instance() %s - instance count=%s", self.codec_type, cur)
        v = self.codec_class(*self.codec_args)
        live.add(v)
        return v

    def get_instance_count(self) -> int:
        return len(get_instances(self.codec_class))

    def to_dict(self, *skip: str) -> dict[str, Any]:
        # note: no `asdict()` here - it deep-copies every value before we get
        # a chance to drop the fields we don't want to export,
        # which chokes on the objects found in `codec_args`
        skipped = tuple(self.skipped_fields) + skip
        return dict((f.name, getattr(self, f.name)) for f in fields(self) if f.name not in skipped)

    def get_runtime_factor(self) -> float:
        # a cost multiplier that some encoder may want to override
        # 1.0 means no change:
        mi = self.max_instances
        ic = self.get_instance_count()
        if ic == 0 or mi == 0:
            return 1.0                      # no problem
        if ic >= mi:
            return 0                        # not possible
        if mi > 0 and ic > 0:
            # squared slope: 50% utilisation -> value=0.75
            return max(0.0, 1.0 - (1.0*ic/mi)**2)
        return 1.0


@dataclass(kw_only=True)
class VideoSpec(CodecSpec):

    encoding: str = "invalid"
    has_lossless_mode: bool = False
    full_range: bool = True

    def get_effective_quality(self, quality: int, width: int, height: int) -> int:
        """Return the quality this encoder can provide at the given dimensions."""
        return quality

    def __repr__(self):
        return f"{self.codec_type}({self.input_colorspace} - {self.encoding})"


@dataclass(kw_only=True)
class CSCSpec(CodecSpec):

    def __repr__(self):
        return f"{self.codec_type}({self.input_colorspace} to {self.output_colorspaces})"


def main() -> None:
    # pylint: disable=import-outside-toplevel
    from xpra.platform import program_context
    with program_context("Codec-Constants", "Codec Constants Info"):
        import sys
        from xpra.log import Logger, consume_verbose_argv
        consume_verbose_argv(sys.argv, "encoding")
        log = Logger("encoding")
        log.info("LOSSY_PIXEL_FORMATS=%s", LOSSY_PIXEL_FORMATS)
        log.info("PIXEL_SUBSAMPLING=%s", PIXEL_SUBSAMPLING)
        log.info("RGB_FORMATS=%s", RGB_FORMATS)


if __name__ == "__main__":
    main()

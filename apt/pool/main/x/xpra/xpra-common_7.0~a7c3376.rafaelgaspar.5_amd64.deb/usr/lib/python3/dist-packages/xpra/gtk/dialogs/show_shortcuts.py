# This file is part of Xpra.
# Copyright (C) 2020 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import sys
from collections.abc import Sequence

from xpra.os_util import gi_import
from xpra.util.str_fn import sorted_nicely
from xpra.util.thread import check_main_thread
from xpra.client.gui.keyboard_shortcuts_parser import (
    get_modifier_names, get_modifier_labels, shortcut_keys_str, shortcut_action_str,
)
from xpra.gtk.window import add_close_accel
from xpra.gtk.widget import label
from xpra.gtk.pixbuf import get_icon_pixbuf
from xpra.gtk.dialogs.common_style import add_style_class, style_body, style_window
from xpra.gtk.util import quit_on_signals, gtk_main
from xpra.gtk.css_overrides import inject_css_overrides
from xpra.log import Logger

Gtk = gi_import("Gtk")
GLib = gi_import("GLib")

log = Logger("client", "util")

inject_css_overrides()


def lal(text: str, font="", *style_classes: str) -> Gtk.Alignment:
    align = Gtk.Alignment(xalign=0, yalign=0.5, xscale=0.0, yscale=0.0)
    lbl = label(text, font=font)
    add_style_class(lbl, *style_classes)
    align.add(lbl)
    return align


class ShortcutInfo(Gtk.Window):

    def __init__(self, shortcut_modifiers: Sequence[str], shortcuts: dict[str, Sequence],
                 modifier_names: dict[str, str] | None = None):
        check_main_thread()
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        style_window(self, "shortcuts-dialog")

        def window_deleted(*_args):
            self.is_closed = True
            self.hide()

        add_close_accel(self, window_deleted)
        self.connect("delete_event", window_deleted)
        self.set_title("Xpra Keyboard Shortcuts")
        self.set_size_request(320, 320)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.is_closed = False
        vbox = Gtk.VBox()
        vbox.set_spacing(4)
        style_body(vbox)
        icon = get_icon_pixbuf("keyboard.png")
        if icon:
            self.set_icon(icon)

        if modifier_names is None:
            modifier_names = get_modifier_names({})
        mod_labels = get_modifier_labels(modifier_names)

        def mod_label(name: str) -> str:
            # `name` is either a key name (ie: "meta") or an internal modifier name (ie: "mod1"):
            mod_name = modifier_names.get(name.lower(), name)
            return mod_labels.get(mod_name, name)

        def vlabel(text, font="", padding=0, *style_classes):
            vbox.pack_start(lal(text, font, *style_classes), False, False, padding)

        vlabel("Keyboard shortcuts", "", 4, "xpra-dialog-title")
        vlabel("Prefix: %s" % ("+".join(mod_label(x) for x in shortcut_modifiers)), "", 0, "xpra-subtitle")
        # each key may have multiple shortcuts, count them all:
        total = 0
        for keyname in shortcuts:
            total += len(shortcuts[keyname])
        vlabel("%i Shortcuts:" % (total,), "", 4, "xpra-heading")

        grid = Gtk.Grid()
        grid.set_column_spacing(10)
        add_style_class(grid, "xpra-card", "xpra-table")

        row = 0

        def attach(s: str, x=0, font="") -> None:
            align = Gtk.Alignment(xalign=0, yalign=0.5, xscale=0.0, yscale=0.0)
            lbl = label(s, font=font)
            if row == 0:
                add_style_class(lbl, "xpra-cell", "xpra-heading")
            lbl.set_margin_start(5)
            lbl.set_margin_top(1)
            lbl.set_margin_end(5)
            lbl.set_margin_bottom(1)
            align.add(lbl)
            grid.attach(align, x, row, 1, 1)

        attach("Keys", 0, "sans bold 12")
        attach("Action", 1, "sans bold 12")
        row += 1
        for keyname in sorted_nicely(shortcuts.keys()):
            key_shortcuts = shortcuts[keyname]
            for shortcut in key_shortcuts:
                modifiers, action, args = shortcut
                attach(shortcut_keys_str(keyname, modifiers, mod_labels), 0)
                attach(shortcut_action_str(action, args), 1)
                row += 1
        vbox.pack_start(grid, False, True, 0)
        self.add(vbox)


def main(_args):
    from xpra.platform import program_context
    from xpra.platform.gui import force_focus
    from xpra.platform.keyboard import Keyboard
    from xpra.util.system import is_X11
    from xpra.client.gui.keyboard_shortcuts_parser import parse_shortcut_modifiers, parse_shortcuts
    from xpra.scripts.config import read_xpra_defaults
    from xpra.util.parsing import TRUE_OPTIONS
    with program_context("Keyboard-Shortcuts", "Keyboard Shortcuts"):
        if is_X11():
            try:
                from xpra.x11.bindings.display_source import init_display_source
                init_display_source()
            except Exception as e:
                log("init_display_source failure", exc_info=True)
                log.warn("Warning: failed to connect to the X11 server")
                log.warn(f" {e}")
                # hope for the best..

        if not Keyboard:
            log.warn("missing keyboard support")
            return
        keyboard = Keyboard()  # pylint: disable=not-callable
        mod_meanings = keyboard.get_keymap_modifiers()[0]
        modifier_names = get_modifier_names(mod_meanings)

        conf = read_xpra_defaults()
        key_shortcuts = conf["key-shortcut"]
        shortcut_modifiers = conf["shortcut-modifiers"]
        swap_keys = getattr(keyboard, "swap_keys", False)
        if "swap-keys" in conf:
            swap_keys = str(conf["swap-keys"]).lower() in TRUE_OPTIONS
        modifiers = parse_shortcut_modifiers(shortcut_modifiers, modifier_names, swap_keys)
        shortcuts = parse_shortcuts(key_shortcuts, modifiers, modifier_names=modifier_names)

        w = ShortcutInfo(modifiers, shortcuts, modifier_names)
        w.connect('delete_event', Gtk.main_quit)

        quit_on_signals("Keyboard-Shortcuts")
        add_close_accel(w, Gtk.main_quit)
        force_focus()
        w.show_all()
        gtk_main()


if __name__ == "__main__":  # pragma: no cover
    main(sys.argv)

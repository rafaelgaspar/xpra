#!/usr/bin/env python3
# This file is part of Xpra.
# Copyright (C) 2026 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from __future__ import annotations

import os

from xpra.log import Logger
from xpra.seccomp import is_available
from xpra.seccomp.draw import DECODE_SYSCALLS
from xpra.util.env import envbool

log = Logger("seccomp")

ACTION_ENV = "XPRA_SECCOMP_PARSE_ACTION"

# gate the network parse filter independently of the decode filter,
# so that `XPRA_SECCOMP_DECODE=1` does not silently enable it:
ENABLED = envbool("XPRA_SECCOMP_PARSE", envbool("XPRA_SECCOMP", False))

# syscalls the socket-reading threads need on top of the decode baseline:
# * `recvfrom` - what `socket.recv_into` maps to on x86_64
# * `sendto` - what `socket.send` maps to on x86_64, for replies written from this thread
#   (`sendmsg` is already in the baseline, and creating or connecting sockets is not allowed)
# * `setsockopt` - the `hello` handler sets `TCP_NODELAY` on the connection
# * `getsockname` / `getsockopt` / `getpeername` - read-only socket introspection used when
#   gathering connection info (peer credentials, unix socket path, ...)
# * `sysinfo` - read-only system statistics, used by `os.getloadavg()` in the
#   ping handlers (which stay on the parse thread), see `blocks_getloadavg`:
SOCKET_SYSCALLS: tuple[str, ...] = (
    "recvfrom",
    "sendto",
    "getsockname",
    "getsockopt",
    "setsockopt",
    "getpeername",
    "sysinfo",
)

# the parse thread reads from the socket, decrypts, decompresses and decodes packets,
# and dispatches the packet handlers inline. Every handler that spawned a subprocess or
# did file I/O has been moved off this thread (file transfers, printing, `open-url`,
# `start-command`, control - see `docs/Usage/Seccomp.md`), so the parse filter now drops
# file access too, just like the decode filter: the decode baseline plus the socket syscalls.
# Caveat: a handler that lazily imports a module for the first time on this thread would
# still hit `openat`. `--seccomp=default` uses `errno` (non-fatal) for exactly this reason -
# validate a deployment with `XPRA_SECCOMP_PARSE_ACTION=log` before switching to `strict`.
PARSE_SYSCALLS: tuple[str, ...] = DECODE_SYSCALLS + SOCKET_SYSCALLS


def is_enabled() -> bool:
    return ENABLED and is_available()


def install_thread() -> bool:
    if not is_enabled():
        return False
    from xpra.seccomp import install_filter
    action = get_action()
    log("installing parse thread seccomp policy with action=%s", action)
    install_filter(PARSE_SYSCALLS, action)
    return True


# glibc 2.35 and later implement `getloadavg()` with the `sysinfo` syscall,
# older versions read `/proc/loadavg` instead - and the parse filter does not allow `openat`:
GETLOADAVG_SYSINFO_GLIBC: tuple[int, int] = (2, 35)


def blocks_getloadavg() -> bool:
    """
    Whether calling `getloadavg()` from the parse thread would trip the filter.
    Call this before the filter is installed, ie: from the main thread at startup.
    """
    if not is_enabled():
        return False
    from xpra.seccomp.glibc import get_version
    version = get_version()
    blocked = bool(version) and version < GETLOADAVG_SYSINFO_GLIBC
    log("blocks_getloadavg() glibc version=%s, blocked=%s", version, blocked)
    return blocked


def get_action() -> str:
    action = str(os.environ.get(ACTION_ENV, "kill_process")).strip().lower()
    if action in ("kill", "kill-thread", "kill_thread"):
        return "kill_thread"
    if action in ("kill_process", "kill-process"):
        return "kill_process"
    if action in ("errno", "log", "allow"):
        return action
    log.warn("Warning: invalid %s value %r", ACTION_ENV, action)
    return "kill_process"

# This file is part of Xpra.
# Copyright (C) 2018 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from collections.abc import Callable
from importlib import import_module
from importlib.util import find_spec

from xpra.gtk.configure.common import ConfigureGUIWindow, run_gui
from xpra.os_util import LINUX, POSIX, OSX, gi_import
from xpra.gtk.dialogs.base_gui_window import BaseGUIWindow
from xpra.gtk.dialogs.common_style import add_style_class
from xpra.gtk.widget import label as gtk_label
from xpra.util.i18n import _

Gtk = gi_import("Gtk")


def label(text, *args, **kwargs):
    return gtk_label(_(text), *args, **kwargs)


class HomeGUI(ConfigureGUIWindow):

    def __init__(self):
        super().__init__(
            _("Configure Xpra"),
            "toolbox.png",
            wm_class=("xpra-configure-gui", "Xpra Configure GUI"),
            default_size=(520, 600),
            header_bar=(True, False),
        )
        self.dialogs: dict[str, BaseGUIWindow] = {}

    def populate(self) -> None:
        subtitle = label("Tune your xpra configuration:")
        subtitle.set_halign(Gtk.Align.START)
        add_style_class(subtitle, "xpra-subtitle", "configure-intro")
        self.vbox.add(subtitle)
        if LINUX:
            self.sub("Packages", "package.png", "Install or remove xpra packages", "packages")
        self.sub("Features", "features.png", "Enable or disable feature groups", "features")
        self.sub("Settings", "gears.png", "Configure specific settings", "settings")
        self.sub("Picture compression", "encoding.png", "Encodings, speed and quality", "encodings", "xpra.codecs")
        self.sub("Shadow Server", "shadow.png", "Configure the Shadow Server", "shadow", "xpra.server")
        if POSIX and not OSX:
            self.sub("Virtual Framebuffer", "monitor.png", "Configure the vfb command", "vfb", "xpra.x11")
        # self.sub("OpenGL acceleration", "opengl.png", "Test and validate OpenGL renderer", "opengl")

    def add_headerbar_buttons(self, add_hb_button: Callable) -> None:
        add_hb_button(_("Configure debug logging"), "bugs", lambda _btn: self.show_dialog("debug"))

    def show_dialog(self, configure: str) -> None:
        dialog = self.dialogs.get(configure)
        if dialog is None:
            mod = import_module(f"xpra.gtk.configure.{configure}")
            dialog = mod.ConfigureGUI(self)
            self.dialogs[configure] = dialog
        dialog.show()

    def sub(self, title="", icon_name="browse.png", tooltip="", configure: str = "", req_module="xpra") -> None:

        def callback(_btn) -> None:
            self.show_dialog(configure)

        sensitive = not req_module or bool(find_spec(req_module))
        if not sensitive:
            tooltip = _("not available in this build:\n'%s'") % _(tooltip)
        self.ib(_(title), icon_name, _(tooltip), callback=callback, sensitive=sensitive)


def main(_args) -> int:
    return run_gui(HomeGUI)


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv[1:]))

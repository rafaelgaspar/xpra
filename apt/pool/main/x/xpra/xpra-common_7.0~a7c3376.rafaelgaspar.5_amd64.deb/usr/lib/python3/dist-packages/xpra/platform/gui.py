#!/usr/bin/env python3
# This file is part of Xpra.
# Copyright (C) 2010 Nathaniel Smith <njs@pobox.com>
# Copyright (C) 2012 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import sys
import binascii
from typing import Any
from collections.abc import Callable, Sequence

from xpra.common import noop
from xpra.platform import platform_import
from xpra.util.str_fn import bytestostr
from xpra.log import Logger

_init_done = False


def init() -> None:
    # warning: we currently call init() from multiple places to try
    # to ensure we run it as early as possible..
    global _init_done
    if not _init_done:
        _init_done = True
        do_init()


def do_init() -> None:
    """ some platforms override this """


_ready_done = False


def ready() -> None:
    global _ready_done
    if not _ready_done:
        _ready_done = True
        do_ready()


def do_ready() -> None:
    """ some platforms override this """


_default_icon = "xpra.png"


def set_default_icon(icon_filename: str) -> None:
    global _default_icon
    _default_icon = icon_filename


def get_default_icon() -> str:
    return _default_icon


def force_focus() -> None:
    """ only implemented on macos """


def use_stdin() -> bool:
    stdin = sys.stdin
    return bool(stdin) and stdin.isatty()


def system_bell(*_args) -> bool:
    # let the toolkit classes use their own
    return False


def get_session_type() -> str:
    return ""


def get_xdpi() -> int:
    return -1


def get_ydpi() -> int:
    return -1


def get_monitors_info(xscale=1, yscale=1) -> dict[int, Any]:
    from xpra.gtk.info import get_monitors_info
    return get_monitors_info(xscale, yscale)


def get_icon_size() -> int:
    xdpi = get_xdpi()
    ydpi = get_ydpi()
    if xdpi > 0 and ydpi > 0:
        dpi = round((xdpi + ydpi) / 2)
    else:
        dpi = 96
    if dpi > 144:
        return 48
    if dpi > 120:
        return 32
    if dpi > 96:
        return 24
    return 16


def get_antialias_info() -> dict[str, Any]:
    return {}


def get_display_icc_info() -> dict[str, Any]:
    # per display info
    return {}


def get_icc_info() -> dict[str, Any]:
    return default_get_icc_info()


def default_get_icc_info() -> dict[str, Any]:
    ENV_ICC_DATA = os.environ.get("XPRA_ICC_DATA", "")
    if ENV_ICC_DATA:
        return {
            "source": "environment-override",
            "data": binascii.unhexlify(ENV_ICC_DATA),
        }
    return get_pillow_icc_info()


def get_pillow_icc_info() -> dict[str, Any]:
    screenlog = Logger("screen")
    info: dict[str, Any] = {}
    try:
        from PIL import ImageCms
        from PIL.ImageCms import get_display_profile
    except ImportError as e:
        screenlog.warn(f"Warning: unable to query color profile via Pillow: {e}")
        return info
    try:
        INTENT_STR: dict[Any, str] = {}
        for x in ("PERCEPTUAL", "RELATIVE_COLORIMETRIC", "SATURATION", "ABSOLUTE_COLORIMETRIC"):
            intent = getattr(ImageCms, "Intent", None)
            if intent:
                v = getattr(intent, x, None)
            else:
                v = getattr(ImageCms, "INTENT_%s" % x, None)
            if v:
                INTENT_STR[v] = x.lower().replace("_", "-")
        screenlog("get_icc_info() intents=%s", INTENT_STR)
        p = get_display_profile()  # NOSONAR @SuppressWarnings("python:S5727")
        screenlog("get_icc_info() display_profile=%s", p)
        if p:

            def getDefaultIntentStr(v) -> str:
                return INTENT_STR.get(v, "unknown")

            def getData(v) -> bytes:
                return v.tobytes()

            for (k, fn, conv) in (
                    ("name", "getProfileName", None),
                    ("info", "getProfileInfo", None),
                    ("copyright", "getProfileCopyright", None),
                    ("manufacturer", "getProfileManufacturer", None),
                    ("model", "getProfileModel", None),
                    ("description", "getProfileDescription", None),
                    ("default-intent", "getDefaultIntent", getDefaultIntentStr),
                    ("data", "getData", getData),
            ):
                if m := getattr(ImageCms, fn, None):
                    try:
                        # noinspection calling-non-callable
                        v = m(p)
                        if conv:
                            v = conv(v)
                        info[k] = bytestostr(v).rstrip("\n\r")
                    except Exception as e:
                        screenlog("get_icc_info()", exc_info=True)
                        screenlog("ICC profile error on %s using %s: %s", k, fn, e)
    except Exception as e:
        screenlog("get_icc_info()", exc_info=True)
        screenlog.warn("Warning: cannot query ICC profiles:")
        screenlog.warn(" %s", e)
    return info


# global workarea for all screens
def get_workarea() -> tuple[int, int, int, int] | None:
    return None


# per monitor workareas (assuming a single screen)
def get_workareas() -> Sequence[tuple[int, int, int, int]]:
    return ()


def get_number_of_desktops() -> int:
    return 1


def get_desktop_names() -> Sequence[str]:
    return ()


def get_vrefresh() -> int:
    return -1


def get_mouse_config() -> dict:
    return {}


def get_double_click_time() -> int:
    return -1


def get_double_click_distance() -> tuple[int, int]:
    return -1, -1


def get_default_cursor_size() -> tuple[int, int]:
    return -1, -1


def get_max_cursor_size() -> tuple[int, int]:
    return -1, -1


def get_window_min_size() -> tuple[int, int]:
    return 0, 0


def get_window_max_size() -> tuple[int, int]:
    return 2 ** 15 - 1, 2 ** 15 - 1


def get_window_frame_size(_x, _y, _w, _h) -> dict[str, Any]:
    return {}


def get_window_frame_sizes() -> dict[str, Any]:
    return {}


def add_window_hooks(_window) -> None:
    """
    To add platform specific code to each window,
    called when the window is created.
    """


def remove_window_hooks(_window) -> None:
    """
    Remove the hooks,
    called when the window is destroyed
    """


def show_desktop(_show) -> None:
    """ If possible, show the desktop """


def set_fullscreen_monitors(_window, _fsm, _source_indication: int = 0) -> None:
    """ Only overridden by posix """


def set_shaded(_window, _shaded: bool) -> None:
    """
    GTK never exposed the 'shaded' window attribute,
    posix clients will hook it up here.
    """


def pointer_grab(handle: int) -> bool:
    """
    Pointer grabs require platform specific code.
    `handle` is the native window handle (HWND / xid / ...).
    """
    return False


def pointer_ungrab(handle: int) -> bool:
    """
    Pointer grabs require platform specific code.
    `handle` is the native window handle (HWND / xid / ...).
    """
    return False


def gl_check() -> str:
    return ""  # no problem


def setup_gl_drawing_area(_handle: int) -> None:
    """Install platform hooks on the GL drawing area (by native window handle) after it is realized."""


def cleanup_gl_drawing_area(_handle: int) -> None:
    """Remove platform hooks installed by setup_gl_drawing_area."""


def get_wm_name() -> str:
    return ""


def get_display_name() -> str:
    return ""


def get_display_size() -> tuple[int, int]:
    return 0, 0


def can_access_display() -> bool:
    return True


def is_session_locked() -> bool:
    """
    is the desktop session currently locked?
    (platforms that cannot tell us always answer `False`)
    """
    return False


def set_window_progress(_window, _pct: int) -> None:
    """ some platforms can indicate progress for a specific window """


take_screenshot: Callable = noop


def get_info_base() -> dict[str, Any]:
    def fname(v) -> str:
        try:
            return v.__name__
        except AttributeError:
            return str(v)

    return {
        "system_bell": fname(system_bell),
        "wm_name": get_wm_name() or "",
        "workarea": get_workarea() or "",
        "workareas": get_workareas(),
        "monitors": get_monitors_info(),
        "desktops": get_number_of_desktops(),
        "desktop_names": get_desktop_names(),
        "session-type": get_session_type(),
        "vertical-refresh": get_vrefresh(),
        "cursor-size": {
            "default": get_default_cursor_size(),
            "max": get_max_cursor_size(),
        },
        "icon_size": get_icon_size(),
        "mouse": get_mouse_config(),
        "double_click": {
            "time": get_double_click_time(),
            "distance": get_double_click_distance(),
        },
        "dpi": {
            "x": get_xdpi(),
            "y": get_ydpi(),
        },
        "antialias": get_antialias_info(),
        "icc": get_icc_info(),
        "display-icc": get_display_icc_info(),
        "window_frame": get_window_frame_sizes(),
        "can_access_display": can_access_display(),
    }


get_info = get_info_base

platform_import(globals(), "gui", False,
                "do_ready",
                "do_init",
                "force_focus",
                "gl_check",
                "use_stdin",
                "get_wm_name",
                "show_desktop", "set_fullscreen_monitors", "set_shaded",
                "pointer_grab", "pointer_ungrab",
                "take_screenshot",
                "get_session_type",
                "get_vrefresh", "get_workarea", "get_workareas",
                "get_number_of_desktops", "get_desktop_names",
                "get_antialias_info", "get_icc_info", "get_display_icc_info", "get_xdpi", "get_ydpi",
                "get_monitors_info",
                "get_icon_size",
                "get_window_min_size", "get_window_max_size",
                "get_mouse_config",
                "get_double_click_time", "get_double_click_distance",
                "get_default_cursor_size", "get_max_cursor_size",
                "get_window_frame_sizes",
                "add_window_hooks", "remove_window_hooks",
                "system_bell",
                "get_display_name",
                "get_display_size",
                "can_access_display",
                "is_session_locked",
                "set_window_progress",
                "get_info",
                "setup_gl_drawing_area",
                "cleanup_gl_drawing_area",
                )


def main(argv: list[str]) -> int:
    from xpra.platform import program_context
    from xpra.util.str_fn import print_nested_dict
    from xpra.util.system import is_X11
    from xpra.log import enable_color, consume_verbose_argv
    with program_context("GUI-Properties"):
        enable_color()
        consume_verbose_argv(argv, "all")
        init()

        # naughty, but how else can I hook this up?
        if is_X11():
            from xpra.x11.bindings.display_source import init_display_source
            init_display_source()
        i = get_info()
        print_nested_dict(i, hex_keys=("data", "icc-data", "icc-profile"))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

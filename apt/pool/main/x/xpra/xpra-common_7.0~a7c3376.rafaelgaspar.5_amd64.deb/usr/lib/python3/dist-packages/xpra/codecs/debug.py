# This file is part of Xpra.
# Copyright (C) 2022 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from time import monotonic

from xpra.codecs.image import ImageWrapper
from xpra.util.str_fn import memoryview_to_bytes
from xpra.log import Logger

log = Logger("codec")

_save_to_file_warned = False


def get_save_to_file() -> str:
    # single place where `XPRA_SAVE_TO_FILE` is evaluated: it must be honoured
    # everywhere through this function so that the seccomp check below is always applied.
    save = os.environ.get("XPRA_SAVE_TO_FILE", "")
    if save:
        # decoders save frames from the decode thread, which runs under a seccomp filter
        # that blocks file access - writing there would kill the process (see seccomp.md):
        try:
            from xpra.seccomp import is_enabled
        except ImportError:
            is_enabled = None
        if is_enabled and is_enabled():
            global _save_to_file_warned
            if not _save_to_file_warned:
                _save_to_file_warned = True
                log.warn("Warning: 'XPRA_SAVE_TO_FILE' is ignored because seccomp is enabled")
            return ""
    return save


SAVE_TO_FILE = get_save_to_file()


def may_save_image(coding: str, data: memoryview | bytes | bytearray, now: float = 0):
    if SAVE_TO_FILE:  # pragma: no cover
        now = now or monotonic()
        ext = coding.lower().replace("/", "-")
        filename = f"./{SAVE_TO_FILE}-{now}.{ext}"
        bdata = memoryview_to_bytes(data)
        with open(filename, "wb") as f:
            f.write(bdata)
        log.info("saved %7i bytes to %s", len(data), filename)


def save_imagewrapper(image: ImageWrapper, filename: str) -> None:
    import os.path
    from xpra.util.objects import typedict
    from xpra.codecs.pillow.encoder import encode
    ext = os.path.splitext(filename)[1].lstrip(".")
    cdata = encode(ext, image, typedict())[1]
    w = image.get_width()
    h = image.get_height()
    stride = image.get_rowstride()
    log("save_image: saving %4ix%-4i pixels, %7i bytes to %s", w, h, (stride * h), filename)
    with open(filename, "wb") as f:
        f.write(cdata.data)

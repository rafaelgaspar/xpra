# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from __future__ import annotations

import os
import subprocess
import hashlib
import fnmatch
import uuid
from queue import SimpleQueue
from threading import Thread
from typing import Any, Final
from time import monotonic
from dataclasses import dataclass
from collections.abc import Callable

from xpra.net.packet_type import (
    FILE_SEND, FILE_ACK_CHUNK, FILE_SEND_CHUNK, FILE_DATA_REQUEST, FILE_DATA_RESPONSE, FILE_REQUEST, FILE_OPEN_URL,
)
from xpra.util.child_reaper import get_child_reaper
from xpra.os_util import POSIX, WIN32, gi_import
from xpra.util.io import umask_context, osclose
from xpra.util.objects import typedict
from xpra.util.str_fn import csv, single_line, truncate
from xpra.util.env import envint, envbool
from xpra.util.parsing import str_to_bool, parse_with_unit
from xpra.common import SizedBuffer
from xpra.net.common import Packet, PacketElement, BACKWARDS_COMPATIBLE
from xpra.util.stats import std_unit
from xpra.util.thread import start_thread
from xpra.log import Logger

GLib = gi_import("GLib")

printlog = Logger("printing")
filelog = Logger("file")

DELETE_PRINTER_FILE = envbool("XPRA_DELETE_PRINTER_FILE", True)
FILE_CHUNKS_SIZE = max(0, envint("XPRA_FILE_CHUNKS_SIZE", 65536))
MAX_CONCURRENT_FILES = max(1, envint("XPRA_MAX_CONCURRENT_FILES", 10))
PRINT_JOB_TIMEOUT = max(60, envint("XPRA_PRINT_JOB_TIMEOUT", 3600))
SEND_REQUEST_TIMEOUT = max(300, envint("XPRA_SEND_REQUEST_TIMEOUT", 3600))
CHUNK_TIMEOUT = 10 * 1000
MAX_PRINT_TITLE = 256
MAX_FILENAME = 128
# file transfers do their disk I/O (writing received files, reading files to send)
# and CPU-heavy work (compression, hashing) on a dedicated daemon thread, so that
# it is all kept off the network parse thread:
FILE_IO_THREAD = envbool("XPRA_FILE_IO_THREAD", True)
FILE_IO_JOIN_TIMEOUT = envint("XPRA_FILE_IO_JOIN_TIMEOUT", 5)
# noinspection HttpUrlsUsage
URL_PREFIXES = tuple(prefix for prefix in os.environ.get("XPRA_URL_PREFIXES", "http://,https://").split(",") if prefix)

MIMETYPE_EXTS: dict[str, str] = {
    "application/postscript": "ps",
    "application/pdf": "pdf",
    "raw": "raw",
}

DENY: Final[int] = 0
ACCEPT: Final[int] = 1  # the file / URL will be sent
OPEN: Final[int] = 2  # don't send, open on sender


def basename(filename: str) -> str:
    # we can't use os.path.basename,
    # because the remote end may have sent us a filename
    # which is using a different pathsep
    tmp = filename
    for sep in ("\\", "/", os.sep):
        i = tmp.rfind(sep) + 1
        tmp = tmp[i:]
    # bidi controls can be used to disguise the file extension, ie: "invoice\u202efdp.exe" shows as "invoiceexe.pdf":
    filename = single_line(tmp).strip()
    if len(filename) > MAX_FILENAME:
        root, ext = os.path.splitext(filename)
        if len(ext) > 16:
            ext = ""
        filename = truncate(root, MAX_FILENAME - len(ext)) + ext
    tmp = filename
    if WIN32:  # pragma: no cover
        # many characters aren't allowed at all on win32:
        tmp = ""
        for char in filename:
            if ord(char) < 32 or char in ("<", ">", ":", "\"", "|", "?", "*"):
                char = "_"
            tmp += char
    return tmp


def valid_url(url: str) -> bool:
    # the url is shown to the user before we open it:
    return single_line(url) == url


def safe_open_download_file(basefilename: str, mimetype: str) -> tuple[str, int]:
    from xpra.platform.paths import get_download_dir  # pylint: disable=import-outside-toplevel
    dd = os.path.abspath(os.path.expanduser(get_download_dir()))
    # resolve symlinks in the download directory so we can compare against fully resolved paths:
    real_dd = os.path.realpath(dd)
    safe_basename = basename(basefilename).lstrip(".") or "download"
    filename = os.path.abspath(os.path.join(dd, safe_basename))
    if os.path.commonpath((dd, filename)) != dd:
        raise ValueError(f"download path {filename!r} escapes download directory {dd!r}")
    ext = MIMETYPE_EXTS.get(mimetype)
    if ext and not filename.endswith("." + ext):
        # on some platforms (win32),
        # we want to force an extension
        # so that the file manager can display them properly when you double-click on them
        filename += "." + ext
    # Atomically select a filename that does not exist already.
    root, ext = os.path.splitext(filename)
    flags = os.O_CREAT | os.O_RDWR | os.O_EXCL
    try:
        flags |= os.O_BINARY  # @UndefinedVariable (win32 only)
    except AttributeError:
        pass
    base = 0
    while True:
        # verify the resolved path (following any symlinks) stays within the download directory:
        # if a symlink points outside, skip this name rather than write outside the directory
        # (O_CREAT|O_EXCL already refuses to follow a symlink when creating the file):
        real_path = os.path.realpath(filename)
        if real_path != real_dd and os.path.commonpath((real_dd, real_path)) != real_dd:
            filelog(f"cannot save file as {filename!r}: path escapes the download directory")
            base += 1
            filename = f"{root}-{base}{ext}"
            continue
        try:
            with umask_context(0o133):
                fd = os.open(filename, flags)
        except FileExistsError:
            filelog(f"cannot save file as {filename!r}: file already exists")
            base += 1
            filename = f"{root}-{base}{ext}"
        else:
            filelog("safe_open_download_file(%s, %s) will use %r", basefilename, mimetype, filename)
            filelog(f"using {filename=!r}, {fd=}")
            return filename, fd


@dataclass
class ChunkState:
    start: float
    send_id: str
    filesize: int


@dataclass
class ReceiveChunkState(ChunkState):
    fd: int
    filename: str
    mimetype: str
    printit: bool
    openit: bool
    options: typedict
    digest: hashlib._Hash | None
    written: int
    cancelled: bool
    timer: int
    chunk: int


@dataclass
class SendChunkState(ChunkState):
    data: bytes
    chunk_size: int
    timer: int
    chunk: int


@dataclass
class SendPendingData:
    datatype: str
    url: str
    mimetype: str
    data: bytes
    filesize: int
    printit: bool
    openit: bool
    options: dict


@dataclass(frozen=True)
class RequestedFile:
    filename: str
    openit: bool
    basename_pattern: str = ""


@dataclass(frozen=True)
class AcceptedData:
    printit: bool
    openit: bool


APPROVAL_OPTION_KEYS: Final[tuple[str, ...]] = ("request-file", "printer", "title", "copies", "options")


def comparable_transfer_options(options: dict | typedict | None) -> dict[str, Any]:
    if not options:
        return {}
    return {str(k): v for k, v in dict(options).items() if str(k) in APPROVAL_OPTION_KEYS}


@dataclass(frozen=True)
class AcceptedDataRequest:
    dtype: str
    url: str
    mimetype: str
    filesize: int
    printit: bool
    openit: bool
    options: dict[str, Any]

    def matches(self, dtype: str, url: str, mimetype: str, filesize: int,
                options: dict | typedict | None = None) -> bool:
        expected = (self.dtype, self.url, self.mimetype, self.filesize, self.options)
        actual = (dtype, url, mimetype, filesize, comparable_transfer_options(options))
        return expected == actual


class FileTransferAttributes:

    def __init__(self):
        self.init_attributes()

    def init_opts(self, opts, can_ask=True) -> None:
        # get the settings from a config object
        self.init_attributes(opts.file_transfer, opts.file_size_limit,
                             opts.printing, opts.open_files, opts.open_url, opts.open_command, can_ask)

    def init_attributes(self, file_transfer: str = "no", file_size_limit: str = "1G", printing: str = "no",
                        open_files: str = "no", open_url: str = "no", open_command: str | None = None,
                        can_ask: bool = True) -> None:
        filelog("file transfer: init_attributes%s",
                (file_transfer, file_size_limit, printing, open_files, open_url, open_command, can_ask))

        def pask(v) -> bool:
            return v.lower() in ("ask", "auto")

        fta = pask(file_transfer)
        self.file_transfer_ask = fta and can_ask
        self.file_transfer = fta or str_to_bool(file_transfer)
        self.file_size_limit = parse_with_unit("file-size-limit", file_size_limit, "B", min_value=0) or 0
        self.file_chunks = FILE_CHUNKS_SIZE
        pa = pask(printing)
        self.printing_ask = pa and can_ask
        self.printing = pa or str_to_bool(printing)
        ofa = pask(open_files)
        self.open_files_ask = ofa and can_ask
        self.open_files = ofa or str_to_bool(open_files)
        # FIXME: command line options needed here:
        oua = pask(open_url)
        self.open_url_ask = oua and can_ask
        self.open_url = oua or str_to_bool(open_url)
        self.file_ask_timeout = SEND_REQUEST_TIMEOUT
        self.open_command = open_command
        self.files_requested: dict[str, RequestedFile] = {}
        self.files_accepted: dict[str, AcceptedData] = {}
        self.data_send_requests: dict[str, AcceptedDataRequest] = {}
        self.file_request_callback: dict[str, Callable[[str, int], None]] = {}
        filelog("file transfer attributes=%s", self.get_file_transfer_features())

    def get_file_transfer_features(self) -> dict[str, Any]:
        return self.get_file_transfer_info()

    def get_file_transfer_info(self) -> dict[str, Any]:
        # slightly different from above... for legacy reasons
        # this one is used for get_info() in a proper "file." namespace from base.py
        info = {
            "enabled": self.file_transfer,
            "ask": self.file_transfer_ask,
            "size-limit": self.file_size_limit,
            "chunks": self.file_chunks,
            "open": self.open_files,
            "open-ask": self.open_files_ask,
            "open-url": self.open_url,
            "open-url-ask": self.open_url_ask,
            "ask-timeout": self.file_ask_timeout,
        }
        if BACKWARDS_COMPATIBLE:
            info.update({
                "printing": self.printing,
                "printing-ask": self.printing_ask,
            })
        return info

    def get_printer_features(self) -> dict[str, Any]:
        return {
            "printing": self.printing,
            "printing-ask": self.printing_ask,
        }

    def get_info(self) -> dict[str, Any]:
        return {
            "file": self.get_file_transfer_info(),
            "printer": self.get_printer_features(),
        }

    @staticmethod
    def request_file_match(request: RequestedFile, filename: str, options: typedict) -> bool:
        request_file = options.tupleget("request-file")
        if len(request_file) != 2:
            return False
        if request_file[0] != request.filename or bool(request_file[1]) != request.openit:
            return False
        sent_basename = basename(filename)
        if request.basename_pattern:
            return fnmatch.fnmatch(sent_basename, request.basename_pattern)
        return sent_basename == basename(request.filename)


def digest_mismatch(filename: str, digest, expected_digest) -> None:
    filelog.error(f"Error: data does not match, invalid {digest.name} file digest")
    filelog.error(f" for {filename!r}")
    filelog.error(f" received {digest.hexdigest()}")
    filelog.error(f" expected {expected_digest}")


def get_open_env() -> dict[str, str]:
    env = os.environ.copy()
    # prevent loops:
    env["XPRA_XDG_OPEN"] = "1"
    return env


def write_file_data(fd: int, data: SizedBuffer) -> None:
    view = memoryview(data)
    while view:
        written = os.write(fd, view)
        if written <= 0:
            raise OSError("failed to write file data")
        view = view[written:]


class FileTransferHandler(FileTransferAttributes):
    """
        Utility class for receiving files and optionally printing them,
        used by both clients and server to share the common code and attributes
    """

    def init_attributes(self, *args) -> None:
        super().init_attributes(*args)
        self.remote_file_transfer = False
        self.remote_file_transfer_ask = False
        self.remote_printing = False
        self.remote_printing_ask = False
        self.remote_open_files = False
        self.remote_open_files_ask = False
        self.remote_open_url = False
        self.remote_open_url_ask = False
        self.remote_file_ask_timeout = SEND_REQUEST_TIMEOUT
        self.remote_file_size_limit = 0
        self.remote_file_chunks = 0
        self.pending_send_data: dict[str, SendPendingData] = {}
        self.pending_send_data_timers: dict[str, int] = {}
        self.send_chunks_in_progress: dict[str, SendChunkState] = {}
        self.receive_chunks_in_progress: dict[str, ReceiveChunkState] = {}
        self.file_descriptors: set[int] = set()
        self._file_io_queue: SimpleQueue = SimpleQueue()
        self._file_io_thread: Thread | None = None

    def cleanup(self) -> None:
        # drain and stop the file I/O thread first, so any in-flight write completes
        # (and closes its file descriptor) before we clean up below:
        self.stop_file_io_thread()
        for t in self.pending_send_data_timers.values():
            GLib.source_remove(t)
        self.pending_send_data_timers = {}
        for v in self.send_chunks_in_progress.values():
            if v.timer:
                GLib.source_remove(v.timer)
        self.send_chunks_in_progress = {}
        for v in self.receive_chunks_in_progress.values():
            if v.timer:
                GLib.source_remove(v.timer)
            if v.fd in self.file_descriptors:
                osclose(v.fd)
                self.file_descriptors.discard(v.fd)
            if os.path.exists(v.filename):
                try:
                    os.unlink(v.filename)
                except OSError as e:
                    filelog.error("Error: failed to delete incomplete download %r: %s", v.filename, e)
        self.receive_chunks_in_progress = {}
        for x in tuple(self.file_descriptors):
            try:
                os.close(x)
            except OSError as e:
                filelog(f"os.close({x}) {e}")
        self.file_descriptors = set()
        self.init_attributes()

    ######################################################################
    # file worker thread:
    # file transfers run their disk I/O (writing received files, reading files to
    # send) and CPU-heavy work (compression, hashing) on this dedicated daemon
    # thread, keeping it off the network parse thread - which the seccomp filter can
    # then forbid from touching the filesystem. See `docs/Usage/Seccomp.md`.
    def schedule_file_io(self, fn: Callable, *args) -> None:
        if not FILE_IO_THREAD:
            fn(*args)
            return
        self._file_io_queue.put((fn, args))
        if self._file_io_thread is None:
            # start the thread from the main thread (rather than the parse thread we
            # are running on now) so that it does not inherit a seccomp filter:
            GLib.idle_add(self._ensure_file_io_thread)

    def _ensure_file_io_thread(self) -> None:
        # runs on the main thread (see `schedule_file_io`):
        if self._file_io_thread is None:
            self._file_io_thread = start_thread(self._file_io_loop, "file-io", daemon=True)

    def _file_io_loop(self) -> None:
        filelog("file I/O thread started")
        while True:
            item = self._file_io_queue.get()
            if item is None:
                break
            fn, args = item
            with filelog.trap_error("Error processing file I/O"):
                fn(*args)
        filelog("file I/O thread ended")

    def stop_file_io_thread(self) -> None:
        thread = self._file_io_thread
        self._file_io_thread = None
        if thread is None:
            return
        # `None` is the exit marker - anything queued before it still gets written:
        self._file_io_queue.put(None)
        if thread.is_alive():
            thread.join(FILE_IO_JOIN_TIMEOUT)

    def parse_file_transfer_caps(self, c: typedict) -> None:
        fc = typedict(c.dictget("file"))
        if not fc and BACKWARDS_COMPATIBLE:
            fc = typedict({
                "enabled": c.boolget("file-transfer"),
                "ask": c.boolget("file-transfer-ask"),
                "size-limit": c.intget("file-size-limit"),
                "chunks": c.intget("file-chunks"),
                "open": c.boolget("open-files"),
                "open-ask": c.boolget("open-files-ask"),
                "open-url": c.boolget("open-url"),
                "open-url-ask": c.boolget("open-url-ask"),
                "ask-timeout": c.intget("file-ask-timeout", SEND_REQUEST_TIMEOUT),
            })
        filelog("parse_file_transfer_caps: %s", fc)
        # v5 with "file" namespace:
        self.remote_file_transfer = fc.boolget("enabled")
        self.remote_file_transfer_ask = fc.boolget("ask")
        self.remote_open_files = fc.boolget("open")
        self.remote_open_files_ask = fc.boolget("open-ask")
        self.remote_open_url = fc.boolget("open-url")
        self.remote_open_url_ask = fc.boolget("open-url-ask")
        self.remote_file_ask_timeout = fc.intget("ask-timeout")
        self.remote_file_size_limit = fc.intget("max-file-size") or fc.intget("size-limit")
        self.remote_file_chunks = max(0, fc.intget("chunks"))
        self.dump_remote_file_caps()

    def parse_printer_caps(self, c: typedict) -> None:
        fc = typedict(c.dictget("printer"))
        if not fc and BACKWARDS_COMPATIBLE:
            # older versions used the `file` namespace:
            fc = typedict(c.dictget("file"))
        self.remote_printing = fc.boolget("printing")
        self.remote_printing_ask = fc.boolget("printing-ask")

    def dump_remote_file_caps(self) -> None:
        filelog("file transfer remote caps:")
        filelog(" file-transfer=%-5s   (ask=%s)", self.remote_file_transfer, self.remote_file_transfer_ask)
        filelog(" open-files=%-5s      (ask=%s)", self.remote_open_files, self.remote_open_files_ask)
        filelog(" open-url=%-5s        (ask=%s)", self.remote_open_url, self.remote_open_url_ask)
        filelog(" file-size-limit=%s", self.remote_file_size_limit)

    def get_info(self) -> dict[str, Any]:
        info = super().get_info()
        info["remote"] = {
            "file-transfer": self.remote_file_transfer,
            "file-transfer-ask": self.remote_file_transfer_ask,
            "file-size-limit": self.remote_file_size_limit,
            "file-chunks": self.remote_file_chunks,
            "open-files": self.remote_open_files,
            "open-files-ask": self.remote_open_files_ask,
            "open-url": self.remote_open_url,
            "open-url-ask": self.remote_open_url_ask,
            "printing": self.remote_printing,
            "printing-ask": self.remote_printing_ask,
            "file-ask-timeout": self.remote_file_ask_timeout,
        }
        return info

    def _check_chunk_receiving(self, chunk_id: str, chunk_no: int) -> None:
        chunk_state = self.receive_chunks_in_progress.get(chunk_id)
        filelog("_check_chunk_receiving(%s, %s) chunk_state=%s", chunk_id, chunk_no, chunk_state)
        if not chunk_state:
            # transfer not found
            return
        if chunk_state.cancelled:
            # transfer has been cancelled
            return
        if chunk_state.chunk != chunk_no:
            # this timeout belongs to an older chunk
            return
        chunk_state.timer = 0  # this timer has been used
        filelog.error(f"Error: chunked file transfer f{chunk_id} timed out")
        self.cancel_file(chunk_id, "chunked file transfer timed out", chunk_no)

    def cancel_download(self, send_id: str, message="Cancelled") -> None:
        filelog("cancel_download(%s, %s)", send_id, message)
        for chunk_id, chunk_state in dict(self.receive_chunks_in_progress).items():
            if chunk_state.send_id == send_id:
                self.cancel_file(chunk_id, message)
                return
        filelog.error(f"Error: cannot cancel download {send_id!r}, entry not found!")

    def cancel_file(self, chunk_id: str, message: str, chunk: int = 0) -> None:
        filelog("cancel_file%s", (chunk_id, message, chunk))
        if chunk_state := self.receive_chunks_in_progress.get(chunk_id):
            if chunk_state.cancelled:
                self.send(FILE_ACK_CHUNK, chunk_id, False, message, chunk)
                return
            # mark it as cancelled:
            chunk_state.cancelled = True
            self.transfer_progress_error(False, chunk_state, message)
            timer = chunk_state.timer
            if timer:
                chunk_state.timer = 0
                GLib.source_remove(timer)
            osclose(chunk_state.fd)
            self.file_descriptors.discard(chunk_state.fd)

            # remove this transfer after a little while,
            # so in-flight packets won't cause errors

            def clean_receive_state() -> bool:
                self.receive_chunks_in_progress.pop(chunk_id, None)
                return False

            GLib.timeout_add(20000, clean_receive_state)
            filename = chunk_state.filename
            try:
                os.unlink(filename)
            except OSError as e:
                filelog(f"os.unlink({filename})", exc_info=True)
                filelog.error("Error: failed to delete temporary download file")
                filelog.error(f" {filename!r} : {e}")
        self.send(FILE_ACK_CHUNK, chunk_id, False, message, chunk)

    def _process_send_chunk(self, packet: Packet) -> None:
        # write the chunk to disk from the file I/O thread, off the parse thread:
        self.schedule_file_io(self.do_process_file_send_chunk, packet)

    def do_process_file_send_chunk(self, packet: Packet) -> None:
        chunk_id = packet.get_str(1)
        chunk = packet.get_u32(2)
        file_data: SizedBuffer = packet.get_buffer(3)
        has_more = packet.get_bool(4)
        # if len(file_data)<1024:
        #    from xpra.util.str_fn import hexstr
        #    filelog.warn("file_data=%s", hexstr(file_data))
        # filelog(f"file_data={len(file_data)} {type(file_data)}")
        filelog(f"file_data={len(file_data)} {type(file_data)}")
        filelog("_process_send_chunk%s", (chunk_id, chunk, f"{len(file_data)} bytes", has_more))
        chunk_state = self.receive_chunks_in_progress.get(chunk_id)

        def progress(position: int, error: str = "") -> None:
            s_elapsed = monotonic() - chunk_state.start
            self.transfer_progress_update(False, chunk_state.send_id, s_elapsed, position, chunk_state.filesize, error)

        def error(message: str) -> None:
            filelog.error(f"Error: {message}")
            self.cancel_file(chunk_id, message, chunk)

        if not chunk_state:
            error(f"file transfer id {chunk_id!r} not found")
            return

        if chunk_state.cancelled:
            filelog("got chunk for a cancelled file transfer, ignoring it")
            return

        fd = chunk_state.fd
        if chunk_state.chunk + 1 != chunk:
            error("chunk number mismatch")
            return
        if not file_data:
            error("empty file chunk")
            return

        # update chunk number:
        chunk_state.chunk = chunk
        try:
            write_file_data(fd, file_data)
            if chunk_state.digest:
                chunk_state.digest.update(file_data)
            chunk_state.written += len(file_data)
        except OSError as e:
            error(f"cannot write file chunk: {e}")
            return

        if chunk_state.written > chunk_state.filesize:
            error("more data received than specified in the file size!")
            return
        if has_more and chunk_state.written == chunk_state.filesize:
            error("more chunks requested after the declared file size was reached")
            return

        self.send(FILE_ACK_CHUNK, chunk_id, True, "", chunk)
        if chunk_state.cancelled:
            # check again if the transfer has been cancelled
            filelog("got chunk for a cancelled file transfer, ignoring it")
            return

        if has_more:
            progress(chunk_state.written)
            if chunk_state.timer:
                GLib.source_remove(chunk_state.timer)
            # remote end will send more after receiving the ack
            chunk_state.timer = GLib.timeout_add(CHUNK_TIMEOUT, self._check_chunk_receiving, chunk_id, chunk)
            pct = round(100 * chunk_state.written / chunk_state.filesize)
            filelog(f"waiting for the next chunk, got {chunk_state.written:8} of {chunk_state.filesize:8}: {pct:3}%")
            return

        # we have received all the packets
        filename = chunk_state.filename
        options = chunk_state.options
        filelog(f"file {filename!r} complete")
        if chunk_state.digest:
            expected_digest = options.strget(chunk_state.digest.name)  # ie: "sha256"
            if expected_digest and chunk_state.digest.hexdigest() != expected_digest:
                digest_mismatch(filename, chunk_state.digest, expected_digest)
                error("checksum mismatch")
                return
            filelog("%s digest matches: %s", chunk_state.digest.name, expected_digest)

        # check file size and digest then process it:
        if chunk_state.written != chunk_state.filesize:
            error(f"expected a file of {chunk_state.filesize} bytes, got {chunk_state.written}")
            return

        self.receive_chunks_in_progress.pop(chunk_id, None)
        osclose(fd)
        self.file_descriptors.discard(fd)
        progress(chunk_state.written)
        elapsed = monotonic() - chunk_state.start
        filelog("%i bytes received in %i chunks, took %ims", chunk_state.filesize, chunk, elapsed * 1000)
        self.process_downloaded_file(filename, chunk_state.mimetype,
                                     chunk_state.printit, chunk_state.openit, chunk_state.filesize, options,
                                     chunk_state.send_id)

    def record_data_request_acceptance(self, send_id: str, dtype: str, url: str, mimetype: str, filesize: int,
                                       printit: bool, openit: bool, options: dict | typedict | None = None) -> None:
        self.data_send_requests[send_id] = AcceptedDataRequest(
            dtype, url, mimetype, filesize, printit, openit, comparable_transfer_options(options),
        )

    def accept_data(self, send_id: str, dtype: str, basefilename: str,
                    printit: bool, openit: bool, mimetype: str = "", filesize: int = 0,
                    options: dict | typedict | None = None) -> tuple[bool, bool, bool]:
        # subclasses should check the flags,
        # and if ask is True, verify they have accepted this specific send_id
        filelog("accept_data%s", (send_id, dtype, basefilename, printit, openit, mimetype, filesize, options))
        filelog("accept_data: printing=%s, printing-ask=%s",
                self.printing, self.printing_ask)
        filelog("accept_data: file-transfer=%s, file-transfer-ask=%s",
                self.file_transfer, self.file_transfer_ask)
        filelog("accept_data: open-files=%s, open-files-ask=%s",
                self.open_files, self.open_files_ask)
        if accepted := self.data_send_requests.pop(send_id, None):
            if accepted.matches(dtype, basefilename, mimetype, filesize, options):
                return True, accepted.printit, accepted.openit
            filelog.warn("Warning: the file attributes are different")
            filelog.warn(" from the ones that were used to accept the transfer")
            actual_options = comparable_transfer_options(options)
            expected = (accepted.dtype, accepted.url, accepted.mimetype, accepted.filesize, accepted.options)
            actual = (dtype, basefilename, mimetype, filesize, actual_options)
            filelog.warn(" expected %s but got %s", expected, actual)
            return False, False, False
        if dtype == "url":
            if not self.open_url or self.open_url_ask:
                return False, False, False
            return True, False, True
        if dtype != "file":
            return False, False, False
        req = self.files_accepted.pop(send_id, None)
        filelog("accept_data: files_accepted[%s]=%s", send_id, req)
        if req is not None:
            return True, req.printit, req.openit
        if printit:
            if not self.printing or self.printing_ask:
                return False, False, False
            return True, True, False
        if not self.file_transfer or self.file_transfer_ask:
            return False, False, False
        if openit and (not self.open_files or self.open_files_ask):
            # we can't ask in this implementation,
            # so deny the request to open it:
            openit = False
        return True, printit, openit

    def _process_send(self, packet: Packet) -> None:
        # save the file from the file I/O thread, off the parse thread:
        self.schedule_file_io(self.do_process_file_send, packet)

    def do_process_file_send(self, packet: Packet) -> None:
        # the remote end is sending us a file
        start = monotonic()
        basefilename = basename(packet.get_str(1))
        mimetype = packet.get_str(2)
        printit = packet.get_bool(3)
        openit = packet.get_bool(4)
        filesize = packet.get_u64(5)
        file_data: SizedBuffer = packet.get_buffer(6)
        options: typedict = typedict(packet.get_dict(7))
        send_id = ""
        if len(packet) >= 9:
            send_id = packet.get_str(8)
        chunk_id = options.strget("file-chunk-id")
        chunk = 0
        log = filelog

        def cancel(message: str) -> None:
            log.error(f"Error: {message}")
            if chunk_id:
                self.cancel_file(chunk_id, message, chunk)

        if filesize <= 0:
            cancel(f"invalid file size {filesize} for {basefilename!r}")
            return
        if filesize > self.file_size_limit:
            fstr = std_unit(filesize)
            limstr = std_unit(self.file_size_limit)
            cancel(f"file {basefilename!r} is too large: {fstr}B, the file size limit is {limstr}B")
            return
        if chunk_id and chunk_id in self.receive_chunks_in_progress:
            message = f"file transfer id {chunk_id!r} is already in use"
            log.error(f"Error: {message}")
            self.send(FILE_ACK_CHUNK, chunk_id, False, message, 0)
            return

        args = (send_id, "file", basefilename, printit, openit, mimetype, filesize, options)
        acceptit, printit, openit = self.accept_data(*args)
        filelog("%s%s=%s", self.accept_data, args, (acceptit, printit, openit))
        if not acceptit:
            ftype = "printing" if args[3] else "transfer"
            cancel(f"{ftype} rejected for file {basefilename!r}")
            return

        # accept_data() method can override the flags:
        if printit:
            log = printlog
            assert self.printing
        else:
            log = filelog
            assert self.file_transfer
        log("receiving file: %s",
            (basefilename, mimetype, printit, openit, filesize, f"{len(file_data)} bytes", options))

        try:
            filename, fd = safe_open_download_file(basefilename, mimetype)
        except (OSError, ValueError) as e:
            log("cannot save file %s / %s", basefilename, mimetype, exc_info=True)
            cancel(f"failed to save downloaded file: {e}")
            return
        self.file_descriptors.add(fd)

        # from now on, call error() so we also close / cleanup the temporary file:
        def error(message: str) -> None:
            cancel(message)
            if fd:
                try:
                    os.close(fd)
                except OSError:
                    log.error(f"Error: failed to close {fd=} used for file transfer")
                else:
                    self.file_descriptors.discard(fd)
            try:
                os.unlink(filename)
            except OSError as e:
                log.error("Error: failed to delete incomplete download %r: %s", filename, e)
            self.transfer_progress_update(False, send_id, monotonic() - start, -1, filesize, message)

        digest: hashlib._Hash | None = None
        for hash_fn in ("sha512", "sha384", "sha256", "sha224", "sha1"):
            if options.strget(hash_fn):
                digest = getattr(hashlib, hash_fn)()
                break
        if chunk_id:
            nfiles = len(self.receive_chunks_in_progress)
            if nfiles >= MAX_CONCURRENT_FILES:
                error(f"too many file transfers in progress: {nfiles}")
                return
            timer = GLib.timeout_add(CHUNK_TIMEOUT, self._check_chunk_receiving, chunk_id, chunk)
            self.receive_chunks_in_progress[chunk_id] = ReceiveChunkState(
                start=monotonic(), send_id=send_id, filesize=filesize,
                fd=fd, filename=filename, mimetype=mimetype,
                printit=printit, openit=openit, options=options,
                digest=digest, written=0, cancelled=False, timer=timer, chunk=chunk,
            )
            self.send(FILE_ACK_CHUNK, chunk_id, True, b"", chunk)
            return
        # not chunked, full file:
        if not file_data:
            error("no file data")
            return
        if len(file_data) != filesize:
            error(f"file {basefilename!r} size: received {len(file_data)} bytes, expected {filesize} bytes")
            return
        # check digest if present:
        if digest:
            digest.update(file_data)
            expected_digest = options.strget(digest.name)  # ie: "sha256"
            if expected_digest and digest.hexdigest() != expected_digest:
                digest_mismatch(basefilename, digest, expected_digest)
                error("checksum mismatch")
                return
            log("%s digest matches: %s", digest.name, expected_digest)
        try:
            write_file_data(fd, file_data)
        except OSError as e:
            error(f"failed to write file data: {e}")
            return
        osclose(fd)
        self.file_descriptors.discard(fd)
        self.transfer_progress_update(False, send_id, monotonic() - start, filesize, filesize, None)
        self.process_downloaded_file(filename, mimetype, printit, openit, filesize, options, send_id)

    def process_downloaded_file(self, filename: str, mimetype: str,
                                printit: bool, openit: bool, filesize: int, options, send_id: str = "") -> None:
        sizestr = std_unit(filesize)
        ftype = mimetype or "temporary"
        extra = " for printing" if printit else ""
        filelog.info(f"downloaded {sizestr} bytes to {ftype} file{extra}:")
        filelog.info(f" {filename!r}")
        # some file requests may have a custom callback
        # (ie: bug report tool will just include the file)
        # the callback is keyed on the send-id we generated for the request,
        # so it always consumes the transfer we requested and the file is never
        # opened or printed behind our back:
        cb = None
        if send_id and (request := self.files_requested.get(send_id)):
            if self.request_file_match(request, filename, options):
                self.files_requested.pop(send_id, None)
                cb = self.file_request_callback.pop(send_id, None)
            else:
                filelog.warn("Warning: received mismatched requested file response for send-id %r", send_id)
        if cb:
            try:
                cb(filename, filesize)
            except Exception as e:
                filelog("file request callback for %r", send_id, exc_info=True)
                filelog.error("Error: file request callback for %r failed: %s", send_id, e)
            return
        if printit or openit:
            t = start_thread(self.do_process_downloaded_file, "process-download", daemon=False,
                             args=(filename, mimetype, printit, openit, filesize, options))
            filelog("started process-download thread: %s", t)

    def do_process_downloaded_file(self, filename: str, mimetype: str, printit: bool, openit: bool, filesize: int,
                                   options: typedict) -> None:
        filelog("do_process_downloaded_file%s", (filename, mimetype, printit, openit, filesize, options))
        if printit:
            self._print_file(filename, mimetype, options)
            return
        if openit:
            if not self.open_files:
                filelog.warn("Warning: opening files automatically is disabled,")
                filelog.warn(" ignoring uploaded file:")
                filelog.warn(" '%s'", filename)
                return
            self._open_file(filename)

    def _print_file(self, filename: str, mimetype: str, options: typedict) -> None:
        printlog("print_file%s", (filename, mimetype, options))
        printer = options.strget("printer")
        # the job title comes from the peer, it is logged and shown in the print queue:
        title = truncate(single_line(options.strget("title")), MAX_PRINT_TITLE)
        copies = options.intget("copies", 1)
        if title:
            printlog.info(f" sending {title!r} to printer {printer!r}")
        else:
            printlog.info(f" sending to printer {printer!r}")
        from xpra.platform.printing import print_files, printing_finished, get_printers
        printers = get_printers()

        def delfile() -> None:
            if DELETE_PRINTER_FILE:
                try:
                    os.unlink(filename)
                except OSError as e:
                    printlog.error("Error: failed to delete print job file %r: %s", filename, e)

        if not printer:
            printlog.error("Error: the printer name is missing")
            printlog.error(" printers available: %s", csv(printers.keys()) or "none")
            delfile()
            return
        if printer not in printers:
            printlog.error(f"Error: printer {printer!r} does not exist!")
            printlog.error(" printers available: %s", csv(printers.keys()) or "none")
            delfile()
            return
        try:
            job_options = options.dictget("options")
            job_options["copies"] = copies
            job = print_files(printer, [filename], title, job_options)
        except Exception as e:
            printlog("print_files%s", (printer, [filename], title, options), exc_info=True)
            printlog.error("Error: cannot print file '%s'", os.path.basename(filename))
            printlog.estr(e)
            delfile()
            return
        printlog(f"printing {filename!r}, job={job}")
        if job <= 0:
            printlog(f"printing failed and returned {job}")
            delfile()
            return
        start = monotonic()

        def check_printing_finished() -> bool:
            try:
                done = printing_finished(job)
            except Exception as e:
                printlog("printing_finished(%s)", job, exc_info=True)
                printlog.error("Error: failed to query print job %s: %s", job, e)
                delfile()
                return False
            printlog("printing_finished(%s)=%s", job, done)
            if done:
                delfile()
                return False
            if monotonic() - start >= PRINT_JOB_TIMEOUT:
                printlog.warn("Warning: print job %s timed out", job)
                delfile()
                return False
            return True  # try again..

        if check_printing_finished():
            # check every 10 seconds:
            GLib.timeout_add(10000, check_printing_finished)

    def _open_file(self, url: str) -> None:
        filelog("_open_file(%s)", url)
        self.exec_open_command(url)

    def _open_url(self, url: str) -> None:
        filelog("_open_url(%s)", url)
        if POSIX:
            # we can't use webbrowser,
            # because this will use "xdg-open" from the $PATH
            # which may point back to us!
            self.exec_open_command(url)
        else:
            import webbrowser  # pylint: disable=import-outside-toplevel
            webbrowser.open_new_tab(url)

    def exec_open_command(self, url: str) -> None:
        filelog("exec_open_command(%s)", url)
        if not self.open_command:
            filelog.error("Error: cannot open %r: no open command is configured", url)
            return
        try:
            import shlex  # pylint: disable=import-outside-toplevel
        except ImportError as e:
            filelog("exec_open_command(%s) no shlex: %s", url, e)
            command = self.open_command.split(" ")
        else:
            try:
                command = shlex.split(self.open_command)
            except (TypeError, ValueError) as e:
                filelog.error("Error: cannot parse open command %r: %s", self.open_command, e)
                return
        if not command:
            filelog.error("Error: cannot open %r: the open command is empty", url)
            return
        command.append(url)
        filelog("exec_open_command(%s) command=%s", url, command)
        try:
            # pylint: disable=consider-using-with
            proc = subprocess.Popen(command, env=get_open_env(), shell=WIN32)
        except Exception as e:
            filelog("exec_open_command(%s)", url, exc_info=True)
            filelog.error("Error: cannot open '%s': %s", url, e)
            return
        filelog("exec_open_command(%s) Popen(%s)=%s", url, command, proc)

        def open_done(*_args) -> None:
            returncode = proc.poll()
            filelog("open_file: command %s has ended, returncode=%s", command, returncode)
            if returncode != 0:
                filelog.warn("Warning: failed to open the downloaded content")
                filelog.warn(" '%s' returned %s", " ".join(command), returncode)

        cr = get_child_reaper()
        cr.add_process(proc, f"Open file {url}", command, True, True, open_done)

    def file_size_warning(self, action: str, location: str, basefilename: str, filesize: int, limit: int) -> None:
        filelog.warn("Warning: cannot %s the file '%s'", action, basefilename)
        filelog.warn(" this file is too large: %sB", std_unit(filesize))
        filelog.warn(" the %s file size limit is %sB", location, std_unit(limit))

    def check_file_size(self, action: str, filename: str, filesize: int) -> bool:
        basefilename = os.path.basename(filename)
        if filesize > self.file_size_limit:
            self.file_size_warning(action, "local", basefilename, filesize, self.file_size_limit)
            return False
        if filesize > self.remote_file_size_limit:
            self.file_size_warning(action, "remote", basefilename, filesize, self.remote_file_size_limit)
            return False
        return True

    def send_request_file(self, filename: str, openit: bool = True, basename_pattern: str = "",
                          callback: Callable[[str, int], None] | None = None) -> str:
        send_id = uuid.uuid4().hex
        self.files_requested[send_id] = RequestedFile(filename, openit, basename_pattern)
        if callback:
            self.file_request_callback[send_id] = callback
        self.send(FILE_REQUEST, filename, openit, send_id)
        return send_id

    def _process_open_url(self, packet: Packet) -> None:
        url = packet.get_str(1)
        send_id = packet.get_str(2)
        if not self.open_url:
            filelog.warn("Warning: received a request to open URL %r", url)
            filelog.warn(" but opening of URLs is disabled")
            return
        if not any(url.lower().startswith(url_prefix.lower()) for url_prefix in URL_PREFIXES):
            filelog.warn("Warning: received a request to open URL %r", url)
            filelog.warn(" but this does not match any of the allowed prefixes")
            filelog.warn(" %s", csv(URL_PREFIXES))
            return
        if not valid_url(url):
            filelog.warn("Warning: received a request to open URL %r", url)
            filelog.warn(" but it contains invalid characters")
            return
        if self.open_url_ask:
            acceptit, _printit, _openit = self.accept_data(send_id, "url", url, False, True)
            if not acceptit:
                filelog("url '%s' not accepted", url)
                return
        self._open_url(url)

    def send_open_url(self, url: str) -> bool:
        if not self.remote_open_url:
            filelog.warn("Warning: remote end does not accept URLs")
            return False
        if self.remote_open_url_ask:
            # ask the client if it is OK to send
            return bool(self.send_data_request("open", "url", url))
        self.do_send_open_url(url)
        return True

    def do_send_open_url(self, url: str, send_id: str = "") -> None:
        self.send(FILE_OPEN_URL, url, send_id)

    def send_file(self, filename: str, mimetype: str, data: SizedBuffer, filesize=0,
                  printit=False, openit=False, options=None, send_id="") -> bool:
        if printit:
            if not self.printing:
                printlog.warn("Warning: printing is not enabled for %s", self)
                return False
            if not self.remote_printing:
                printlog.warn("Warning: remote end does not support printing")
                return False
            logger = printlog
            ask = self.remote_printing_ask
            action = "print"
        else:
            if not self.file_transfer:
                filelog.warn("Warning: file transfers are not enabled for %s", self)
                return False
            if not self.remote_file_transfer:
                filelog.warn("Warning: remote end does not support file transfers")
                return False
            logger = filelog
            ask = self.remote_file_transfer_ask
            action = "upload"
            if openit:
                if not self.remote_open_files:
                    logger.info("opening the file after transfer is disabled on the remote end")
                    logger.info(" sending only, the file will need to be opened manually")
                    openit = False
                    action = "upload"
                else:
                    ask |= self.remote_open_files_ask
                    action = "open"
        assert len(data) >= filesize, "data is smaller then the given file size!"
        data = data[:filesize]  # gio may null terminate it
        logger("send_file%s action=%s, ask=%s",
               (filename, mimetype, type(data), f"{filesize} bytes", printit, openit, options), action, ask)
        self.dump_remote_file_caps()
        if not self.check_file_size(action, filename, filesize):
            return False
        if ask:
            return bool(self.send_data_request(action, "file", filename, mimetype, data, filesize,
                                               printit, openit, options, send_id))
        send_id = send_id or uuid.uuid4().hex
        self.do_send_file(filename, mimetype, data, filesize, printit, openit, options, send_id)
        return True

    def send_data_request(self, action: str, dtype: str, url: str, mimetype: str = "", data: SizedBuffer = b"",
                          filesize: int = 0, printit: bool = False, openit: bool = True,
                          options: dict | None = None, send_id: str = "") -> str:
        send_id = send_id or uuid.uuid4().hex
        if len(self.pending_send_data) >= MAX_CONCURRENT_FILES:
            filelog.warn("Warning: %s dropped", action)
            filelog.warn(" %i transfers already waiting for a response", len(self.pending_send_data))
            return ""
        spd = SendPendingData(dtype, url, mimetype, data, filesize, printit, openit, options or {})
        self.pending_send_data[send_id] = spd
        delay = self.remote_file_ask_timeout * 1000
        self.pending_send_data_timers[send_id] = GLib.timeout_add(delay, self.send_data_ask_timeout, send_id)
        filelog(f"sending data request for {dtype} {url!r} with send-id {send_id!r}")
        self.send(FILE_DATA_REQUEST, dtype, send_id, url, mimetype, filesize, printit, openit, options or {})
        return send_id

    def _process_data_request(self, packet: Packet) -> None:
        dtype = packet.get_str(1)
        send_id = packet.get_str(2)
        url = packet.get_str(3)
        mimetype = packet.get_str(4)
        filesize = packet.get_u64(5)
        printit = packet.get_bool(6)
        openit = packet.get_bool(7)
        options = {}
        if len(packet) >= 9:
            options = packet.get_dict(8)
        # filenames and url are always sent encoded as utf8:
        self.do_process_file_data_request(dtype, send_id, url, filesize, printit, openit, typedict(options), mimetype)

    def do_process_file_data_request(self, dtype: str, send_id: str, url: str, filesize: int,
                                     printit: bool, openit: bool, options: typedict, mimetype: str = "") -> None:
        filelog("do_process_file_data_request: %s", (send_id, url, mimetype, filesize, printit, openit, options))

        def cb_answer(accept: bool) -> None:
            filelog("accept%s=%s", (url, printit, openit), accept)
            self.send(FILE_DATA_RESPONSE, send_id, accept)

        # could be a request we made:
        # (in which case we can just accept it without prompt)
        # we match on the send-id we generated for the request,
        # which the server echoes back - so a server cannot have a file
        # auto-accepted unless we actually requested it with this exact id:
        if send_id and (request := self.files_requested.get(send_id)):
            if self.request_file_match(request, url, options):
                self.files_requested.pop(send_id, None)
                accepted_url = basename(url) if dtype == "file" else url
                self.record_data_request_acceptance(send_id, dtype, accepted_url, mimetype, filesize,
                                                    printit, request.openit, options)
                cb_answer(True)
                return
            filelog.warn("Warning: received mismatched requested file approval for send-id %r", send_id)
        if dtype == "file":
            url = basename(url)
            if printit:
                if not self.printing:
                    cb_answer(False)
                    return
                ask = self.printing_ask
            else:
                if not self.file_transfer:
                    cb_answer(False)
                    return
                if openit:
                    if not self.open_files:
                        cb_answer(False)
                        return
                    ask = self.file_transfer_ask or self.open_files_ask
                else:
                    ask = self.file_transfer_ask
        elif dtype == "url":
            if not self.open_url or not valid_url(url):
                cb_answer(False)
                return
            ask = self.open_url_ask
        else:
            filelog.warn("Warning: unknown data request type '%s'", dtype)
            cb_answer(False)
            return
        if not ask:
            filelog.warn("Warning: received a send-data request for a %s,", dtype)
            filelog.warn(" but authorization is not required by the client")
            # fail it because if we responded with True,
            # it would fail later when we don't find this send_id in our accepted list
            cb_answer(False)
            return
        self.ask_data_request(cb_answer, send_id, dtype, url, filesize, printit, openit, mimetype, options)

    def ask_data_request(self, cb_answer: Callable[[bool], None],
                         send_id: str, dtype: str, url: str, filesize: int,
                         printit: bool, openit: bool, mimetype: str = "",
                         options: typedict | None = None) -> None:
        # subclasses may prompt the user here instead
        filelog("ask_data_request%s", (send_id, dtype, url, filesize, printit, openit, mimetype, options))
        cb_answer(False)

    def _process_data_response(self, packet: Packet) -> None:
        send_id = packet.get_str(1)
        accept = packet.get_i8(2)
        filelog("process send-data-response: send_id=%s, accept=%s", send_id, accept)
        # A denied response may also complete a file request that we sent.
        # This lets the peer report an unavailable requested file without a
        # notification or a new packet type.
        if accept == DENY and send_id in self.files_requested:
            self.files_requested.pop(send_id, None)
            self.file_request_callback.pop(send_id, None)
            return
        if timer := self.pending_send_data_timers.pop(send_id, None):
            GLib.source_remove(timer)
        try:
            spd: SendPendingData = self.pending_send_data[send_id]
        except KeyError:
            filelog.warn(f"Warning: cannot find send-file entry for {send_id!r}")
            return
        self.pending_send_data.pop(send_id, None)
        if accept == DENY:
            filelog.info("the request to send %s '%s' has been denied", spd.datatype, spd.url)
            return
        if accept not in (ACCEPT, OPEN):
            raise ValueError(f"unknown value for send-data response: {accept!r}")
        if spd.datatype == "file":
            if accept == ACCEPT:
                # the hashing / compression is done on the file worker thread, off the parse thread:
                self.schedule_file_io(self.do_send_file, spd.url, spd.mimetype, spd.data, spd.filesize,
                                      spd.printit, spd.openit, spd.options, send_id)
            else:
                assert spd.openit and accept == OPEN
                # try to open at this end, on the main thread (it spawns a subprocess):
                GLib.idle_add(self._open_file, spd.url)
        elif spd.datatype == "url":
            if accept == ACCEPT:
                self.do_send_open_url(spd.url, send_id)
            else:
                assert accept == OPEN
                # open it at this end, on the main thread (it spawns a subprocess):
                GLib.idle_add(self._open_url, spd.url)
        else:
            filelog.error("Error: unknown datatype '%s'", spd.datatype)

    def send_data_ask_timeout(self, send_id: str) -> bool:
        self.pending_send_data_timers.pop(send_id, None)
        spd = self.pending_send_data.pop(send_id, None)
        if not spd:
            filelog.warn(f"Warning: send timeout, id {send_id!r} not found!")
            return False
        filelog.warn("Warning: failed to %s file '%s',", ["send", "print"][spd.printit], spd.url)
        filelog.warn(" the send approval request timed out")
        self.transfer_progress_update(True, send_id, 0.0, -1, spd.filesize, "approval request timed out")
        return False

    def do_send_file(self, filename: str, mimetype: str, data, filesize: int = 0,
                     printit: bool = False, openit: bool = False, options=None, send_id: str = "") -> bool:
        if printit:
            action = "print"
            logger = printlog
        else:
            action = "upload"
            logger = filelog
        start = monotonic()
        logger("do_send_file%s", (filename, mimetype, type(data), f"{filesize} bytes", printit, openit, options))
        if not self.check_file_size(action, filename, filesize):
            return False
        h = hashlib.sha256()
        h.update(data)
        absfile = os.path.abspath(filename)
        filelog(f"sha256 digest({absfile})=%s", h.hexdigest())
        options = options or {}
        options["sha256"] = h.hexdigest()
        chunk_size = min(self.file_chunks, self.remote_file_chunks)
        chunked = 0 < chunk_size < filesize
        if chunked:
            in_progress = len(self.send_chunks_in_progress)
            if in_progress >= MAX_CONCURRENT_FILES:
                raise RuntimeError(f"too many file transfers in progress: {in_progress}")
            # chunking is supported and the file is big enough
            chunk_id = uuid.uuid4().hex
            options["file-chunk-id"] = chunk_id
            # timer to check that the other end is requesting more chunks:
            chunk_no = 0
            timer = GLib.timeout_add(CHUNK_TIMEOUT, self._check_chunk_sending, chunk_id, chunk_no)
            self.send_chunks_in_progress[chunk_id] = SendChunkState(
                start=start, send_id=send_id, filesize=filesize,
                data=data, chunk_size=chunk_size, timer=timer, chunk=chunk_no,
            )
            cdata = b""
            filelog("using chunks, sending initial file-chunk-id=%s, for chunk size=%s",
                    chunk_id, chunk_size)
        else:
            # send everything now:
            cdata = self.compressed_wrapper("file-data", data)
            assert len(cdata) <= filesize  # compressed wrapper ensures this is true
            filelog("sending full file: %i bytes (chunk size=%i)", filesize, chunk_size)
            # transfer is complete as soon as we send it:
            self.transfer_progress_update(True, send_id, monotonic() - start, filesize, filesize, None)
        basefilename = os.path.basename(filename)
        self.send(FILE_SEND, basefilename, mimetype, printit, openit, filesize, cdata, options, send_id)
        return True

    def _check_chunk_sending(self, chunk_id: str, chunk_no: int) -> None:
        chunk_state = self.send_chunks_in_progress.get(chunk_id)
        filelog("_check_chunk_sending(%s, %s) chunk_state found: %s", chunk_id, chunk_no, bool(chunk_state))
        if not chunk_state:
            # transfer already removed
            return
        if chunk_state.chunk != chunk_no:
            # this timeout belongs to an older chunk
            return
        chunk_state.timer = 0  # timer has fired
        filelog.error(f"Error: chunked file transfer {chunk_id} timed out")
        filelog.error(f" on chunk {chunk_no}")
        position = chunk_state.filesize - len(chunk_state.data)
        self.transfer_progress_error(True, chunk_state, f"chunk {chunk_no} timed out after {position} bytes")
        self.cancel_sending(chunk_id)

    def cancel_sending(self, chunk_id: str) -> None:
        chunk_state = self.send_chunks_in_progress.pop(chunk_id, None)
        filelog("cancel_sending(%s) chunk state found: %s", chunk_id, bool(chunk_state))
        if not chunk_state:
            return
        timer = chunk_state.timer
        if timer:
            chunk_state.timer = 0
            GLib.source_remove(timer)

    def _process_ack_chunk(self, packet: Packet) -> None:
        # compress and send the next chunk from the file worker thread, off the parse thread:
        self.schedule_file_io(self.do_process_file_ack_chunk, packet)

    def do_process_file_ack_chunk(self, packet: Packet) -> None:
        # the other end received our send-file or send-file-chunk,
        # send some more file data
        filelog("ack-file-chunk: %s", packet[1:])
        chunk_id = packet.get_str(1)
        state = packet.get_bool(2)
        error_message = packet.get_str(3)
        chunk = packet.get_u32(4)
        if not state:
            filelog.info("the remote end is cancelling the file transfer:")
            filelog.info(" %s", error_message)
            if chunk_state := self.send_chunks_in_progress.get(chunk_id):
                self.transfer_progress_error(True, chunk_state, error_message)
            self.cancel_sending(chunk_id)
            return
        chunk_state = self.send_chunks_in_progress.get(chunk_id)
        if not chunk_state:
            filelog.error(f"Error: cannot find the file transfer id {chunk_id!r}")
            return
        if chunk_state.chunk != chunk:
            filelog.error("Error: chunk number mismatch (%i vs %i)", chunk_state.chunk, chunk)
            self.transfer_progress_error(True, chunk_state, f"chunk number mismatch ({chunk_state.chunk} vs {chunk})")
            self.cancel_sending(chunk_id)
            return
        chunk_size = chunk_state.chunk_size
        elapsed = monotonic() - chunk_state.start
        position = chunk_state.filesize - len(chunk_state.data)
        self.transfer_progress_update(True, chunk_state.send_id, elapsed, position, chunk_state.filesize, None)
        if not chunk_state.data:
            # all sent!
            elapsed = monotonic() - chunk_state.start
            if elapsed > 0:
                bs = chunk * chunk_size / elapsed
            else:
                bs = 9999 * 1000 * 1000
            filelog("%i chunks of %i bytes sent in %ims (%sB/s)",
                    chunk, chunk_size, elapsed * 1000, std_unit(bs))
            self.cancel_sending(chunk_id)
            return
        assert chunk_size > 0
        # carve out another chunk:
        cdata = self.compressed_wrapper("file-data", chunk_state.data[:chunk_size])
        chunk_state.data = chunk_state.data[chunk_size:]
        chunk += 1
        chunk_state.chunk = chunk
        if chunk_state.timer:
            GLib.source_remove(chunk_state.timer)
        chunk_state.timer = GLib.timeout_add(CHUNK_TIMEOUT, self._check_chunk_sending, chunk_id, chunk)
        self.send(FILE_SEND_CHUNK, chunk_id, chunk, cdata, bool(chunk_state.data))

    def send(self, packet_type: str, *parts: PacketElement) -> None:
        raise NotImplementedError()

    def compressed_wrapper(self, datatype, data, level=5):
        raise NotImplementedError()

    def transfer_progress_error(self, send: bool, chunk_state: ChunkState, message: str) -> None:
        elapsed = monotonic() - chunk_state.start
        self.transfer_progress_update(send, chunk_state.send_id, elapsed, -1, chunk_state.filesize, message)

    def transfer_progress_update(self, send=True, transfer_id: str = "", elapsed=0.0, position=0, total=0,
                                 error=None) -> None:
        # this method is overridden in the gtk client:
        filelog("transfer_progress_update%s", (send, transfer_id, elapsed, position, total, error))

# This file is part of Xpra.
# Copyright (C) 2011 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import tempfile
from time import monotonic
from abc import ABC, abstractmethod
from collections.abc import Sequence
from typing import TypeAlias

from xpra.notification.common import IconData, is_icon_name
from xpra.util.env import envint, first_time
from xpra.log import Logger
from xpra.common import noop
from xpra.constants import NotificationID

log = Logger("notify")

AUTO_DELETE_DELAY = envint("XPRA_AUTO_DELETE_DELAY", 60)
# how long before we ask the notification service who it is again,
# if we failed to find out (ie: no notification service running yet):
PROXY_CHECK_DELAY = envint("XPRA_NOTIFICATION_PROXY_CHECK_DELAY", 10)

NID: TypeAlias = int | NotificationID


class NotifierBase(ABC):

    def __init__(self, closed_cb=noop, action_cb=noop):
        # posix only - but degrades ok on non-posix:
        self.dbus_id = os.environ.get("DBUS_SESSION_BUS_ADDRESS", "")
        # `None` until we have asked the notification service who it is - see `is_proxy_service`:
        self.proxy_service: bool | None = None
        self.proxy_service_time: float = 0
        self.temp_files = {}
        self.closed_cb = closed_cb
        self.action_cb = action_cb
        self.handles_actions = False

    def cleanup(self) -> None:
        if tf := self.temp_files.keys():
            self.temp_files = {}
            for nid in tf:
                self.clean_notification(nid)

    @abstractmethod
    def show_notify(self, dbus_id: str, tray, nid: NID,
                    app_name: str, replaces_nid: NID, app_icon: str,
                    summary: str, body: str, actions: Sequence[str], hints: dict, expire_timeout: int,
                    icon: IconData | None) -> None:
        pass

    def get_icon_string(self, nid: NID, app_icon: str, icon: IconData | None, hints: dict) -> str:
        app_icon_data: IconData | None = hints.pop("app-icon-data", None)
        if app_icon_data:
            return self.temp_icon_file(int(nid), app_icon_data)
        if app_icon and is_icon_name(app_icon):
            # an icon theme name, safe to use
            return app_icon
        if icon:
            return self.temp_icon_file(int(nid), icon)
        return ""

    def temp_icon_file(self, nid: int, icon: IconData) -> str:
        ext = icon[0]
        if ext not in ("png", "webp", "jpeg"):
            log.warn("Warning: unsuppported icon data type %r", ext)
            return ""
        icon_data = icon[3]
        from xpra.platform.paths import get_xpra_tmp_dir
        tmp = get_xpra_tmp_dir()
        d = tmp
        missing = []
        while d and not os.path.exists(d):
            missing.append(d)
            d = os.path.dirname(d)
        for d in reversed(missing):
            os.mkdir(d, 0o700)
        temp = tempfile.NamedTemporaryFile(mode='w+b', suffix='.%s' % ext,
                                           prefix='xpra-notification-icon-', dir=tmp, delete=False)
        temp.write(icon_data)
        temp.close()
        self.temp_files[nid] = temp.name
        if AUTO_DELETE_DELAY > 0:
            from xpra.os_util import gi_import
            GLib = gi_import("GLib")
            GLib.timeout_add(AUTO_DELETE_DELAY, self.clean_notification, nid)
        return temp.name

    def notify_failed(self, nid: NID, reason: str = "failed to show the notification") -> None:
        # the notification is not on screen: tell the server it is closed
        self.clean_notification(nid)
        self.closed_cb(int(nid), 4, reason)

    def clean_notification(self, nid: NID) -> None:
        temp_file = self.temp_files.pop(int(nid), "")
        log("clean_notification(%s) temp_file=%s", nid, temp_file)
        if temp_file:
            try:
                os.unlink(temp_file)
            except Exception as e:
                log("failed to remove temporary icon file '%s':", temp_file)
                log(" %s", e)

    def is_proxy_service(self) -> bool:
        """
        is the notification service we are about to use one of our own forwarders?
        (ie: we share the session bus with an xpra server which claimed the interface)
        anything we show it would be sent straight back to us, and we would loop forever.
        the answer is cached: the service is not expected to change during our lifetime
        """
        if self.proxy_service is None and monotonic() - self.proxy_service_time > PROXY_CHECK_DELAY:
            from xpra.notification.common import get_notification_service_name, PROXY_NAME
            self.proxy_service_time = monotonic()
            name = get_notification_service_name()
            if name:
                self.proxy_service = name == PROXY_NAME
        return bool(self.proxy_service)

    def dbus_check(self, dbus_id: str) -> bool:
        # `dbus_id` identifies the bus the notification came from,
        # but it is not always available (ie: notifications generated by the server itself)
        # and the same bus can be identified using more than one address string,
        # so also ask the notification service who it is:
        if dbus_id and self.dbus_id == dbus_id:
            return self.loop_warning("the remote dbus instance is the same as our local one")
        if self.is_proxy_service():
            from xpra.notification.common import BUS_NAME
            return self.loop_warning(f"the {BUS_NAME!r} service is an xpra notification forwarder")
        return True

    def loop_warning(self, reason: str) -> bool:
        if first_time("notification-loop"):
            log.warn("Warning: %s,", reason)
            log.warn(" cannot forward notification to ourself as this would create a loop")
            log.warn(" disable notification to avoid this warning")
        return False

# This file is part of Xpra.
# Copyright (C) 2019 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import re
from functools import cache
from typing import Protocol, Any, Final, TypeAlias
from collections.abc import Callable, Sized, Iterable, Sequence, MutableSequence

from xpra.constants import NotificationID, Gravity


# Window-content hints understood by Xpra's encoders and client backings.
# Keep this list in sync with ``fs/etc/xpra/content-type``.
CONTENT_TYPE_TEXT: Final[str] = "text"
CONTENT_TYPE_AUDIO: Final[str] = "audio"
CONTENT_TYPE_VIDEO: Final[str] = "video"
CONTENT_TYPE_BROWSER: Final[str] = "browser"
CONTENT_TYPE_PICTURE: Final[str] = "picture"
CONTENT_TYPE_LOSSLESS: Final[str] = "lossless"
CONTENT_TYPE_DESKTOP: Final[str] = "desktop"
CONTENT_TYPES: Final[tuple[str, ...]] = (
    CONTENT_TYPE_TEXT, CONTENT_TYPE_AUDIO, CONTENT_TYPE_VIDEO, CONTENT_TYPE_BROWSER,
    CONTENT_TYPE_PICTURE, CONTENT_TYPE_LOSSLESS, CONTENT_TYPE_DESKTOP,
)


def get_invalid_content_types(content_types: Iterable[str]) -> tuple[str, ...]:
    """Return content-type hints which are not part of Xpra's vocabulary."""
    return tuple(x for x in content_types if x not in CONTENT_TYPES)


def valid_content_types(content_types: Iterable[str]) -> tuple[str, ...]:
    """Return only the recognized Xpra window-content hints."""
    return tuple(x for x in content_types if x in CONTENT_TYPES)


# X11 window properties which are never forwarded to the peer, as regular expressions:
# the window manager properties (ICCCM, EWMH, KDE, Motif, GTK, XEmbed and XDND) are handled separately,
# and would let the peer control how the window manager treats the window:
X11_PROPERTIES_DENYLIST: Final[tuple[str, ...]] = (
    "WM_.*", "SM_CLIENT_ID", "_NET_.*", "_KDE_.*", "_MOTIF_.*", "_GTK_.*", "_XEMBED.*", "Xdnd.*", "XPRA_.*",
)
MAX_X11_PROPERTY_NAME: Final[int] = 256


@cache
def get_x11_properties_denylist() -> re.Pattern:
    env_value = os.environ.get("XPRA_X11_PROPERTIES_DENYLIST")
    patterns = X11_PROPERTIES_DENYLIST if env_value is None else tuple(x for x in env_value.split(",") if x)
    try:
        return re.compile("|".join(f"(?:{pattern})" for pattern in patterns) or "(?!)")
    except re.error as e:
        from xpra.log import Logger
        Logger("x11", "metadata").warn("Warning: invalid 'XPRA_X11_PROPERTIES_DENYLIST': %s", e)
        return re.compile("|".join(f"(?:{pattern})" for pattern in X11_PROPERTIES_DENYLIST))


def is_x11_property_denied(name: str) -> bool:
    if not name or len(name) > MAX_X11_PROPERTY_NAME or not name.isascii() or not name.isprintable():
        return True
    return bool(get_x11_properties_denylist().fullmatch(name))


try:
    # Python 3.11 and later:
    from typing import Self
except ImportError:     # pragma: no cover
    Self = Any

try:
    # Python 3.12 and later:
    from collections.abc import Buffer

    class SizedBuffer(Buffer, Sized, Protocol):
        pass
except ImportError:
    class SizedBuffer(Sized, Protocol):
        def __buffer__(self):
            raise NotImplementedError()


def gravity_str(v) -> str:
    try:
        return Gravity(v).name
    except ValueError:
        return str(v)


DEFAULT_DPI: int = 96

PaintCallback: TypeAlias = Callable[[int | bool, str], None]
PaintCallbacks: TypeAlias = MutableSequence[PaintCallback]


def noop(*_args, **_kwargs) -> None:
    """ do nothing """


def noerr(fn: Callable, *args):
    # noinspection PyBroadException
    try:
        return fn(*args)
    except Exception:
        return None


def stop_asyncio_loop() -> None:
    """Stop the optional threaded asyncio loop if it has already been loaded."""
    import sys
    if module := sys.modules.get("xpra.net.aio.thread"):
        module.stop_threaded_loop()


def is_covered_by_opaque_region(opaque_region: Sequence[tuple], w: int, h: int) -> bool:
    """Check if any opaque-region rectangle fully covers a window of size w x h.

    Windows with 32-bit depth (ARGB) may declare themselves effectively opaque
    via _NET_WM_OPAQUE_REGION. Each entry is (ox, oy, ow, oh); if any single
    rectangle encloses the entire window area (0, 0, w, h), the window is opaque.
    """
    return any(
        ox <= 0 and oy <= 0 and ox + ow >= w and oy + oh >= h
        for ox, oy, ow, oh in opaque_region
    )


def roundup(n: int, m: int) -> int:
    return (n + m - 1) & ~(m - 1)


def uniq(seq: Iterable) -> list:
    seen = set()
    return [x for x in seq if not (x in seen or seen.add(x))]


def skipkeys(d: dict, *keys) -> dict:
    return {k: v for k, v in d.items() if k not in keys}


def subsystem_name(c: type) -> str:
    return c.__name__.replace("Server", "").rstrip("_").lower()


def _progress_target(obj):
    # `show_progress`/`progress_process` live on the `progress` subsystem when the
    # object exposes one (a composed client, where the subsystem holds the splash
    # process); otherwise fall back to the object itself:
    get_subsystem = getattr(obj, "get_subsystem", None)
    if callable(get_subsystem):
        # noinspection calling-non-callable
        return get_subsystem("progress") or obj
    return obj


def may_show_progress(obj, pct: int, text="", *args) -> None:
    from xpra.util.i18n import _
    msg = _(text)
    if args:
        msg += ": " + ", ".join(str(v) for v in args)
    target = _progress_target(obj)
    show_progress = getattr(target, "show_progress", noop)
    show_progress(pct, msg)


def set_progress_process(obj, progress_process) -> None:
    _progress_target(obj).progress_process = progress_process


def may_notify_client(obj, nid : NotificationID | int, summary, body, *args, **kwargs) -> None:
    # `notify_client` lives on the `notification` subsystem when the object
    # exposes one (a composed client, where the subsystem holds the notifier
    # state); server-side `source` objects and un-composed clients have it
    # directly, so fall back to the object itself:
    target = obj
    get_subsystem = getattr(obj, "get_subsystem", None)
    if callable(get_subsystem):
        # noinspection calling-non-callable
        target = get_subsystem("notification") or obj
    notify_client = getattr(target, "notify_client", notify_to_log)
    notify_client(nid, summary, body, *args, **kwargs)
    # hide splash progress:
    may_show_progress(obj, 100, "notification", summary)


def notify_to_log(nid : NotificationID | int, summary, body, *args, **kwargs) -> None:
    from xpra.log import Logger
    notifylog = Logger("notify")
    notifylog("may_notify_client(%s, %s, %s, %s, %s)", nid, summary, body, args, kwargs)
    notifylog.info("%s", summary)
    if body:
        for x in body.splitlines():
            notifylog.info(" %s", x)


def force_size_constraint(width: int, height: int) -> dict[str, dict[str, Any]]:
    size = width, height
    return {
        "size-constraints": {
            "maximum-size": size,
            "minimum-size": size,
            "base-size": size,
        },
    }

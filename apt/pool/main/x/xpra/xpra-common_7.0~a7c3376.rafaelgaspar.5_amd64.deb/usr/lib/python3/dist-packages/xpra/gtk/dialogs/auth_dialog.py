# This file is part of Xpra.
# Copyright (C) 2017 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import sys

from xpra.gtk.window import add_close_accel
from xpra.gtk.widget import label
from xpra.gtk.pixbuf import get_icon_pixbuf
from xpra.gtk.dialogs.common_style import (
    add_style_class, style_actions, style_body, style_button, style_window,
)
from xpra.gtk.util import gtk_main
from xpra.util.glib import register_os_signals
from xpra.os_util import gi_import
from xpra.util.thread import check_main_thread
from xpra.log import Logger

Gtk = gi_import("Gtk")
GLib = gi_import("GLib")

log = Logger("util")


class AuthDialog(Gtk.Window):

    def __init__(self, title="Session Access Request", info="unknown user from unknown location", timeout=600):
        check_main_thread()
        super().__init__()
        self.timeout = timeout
        self.exit_code = 1
        self.set_title(title)
        self.set_resizable(True)
        self.set_decorated(True)
        # pylint: disable=no-member
        style_window(self, "auth-dialog")
        icon = get_icon_pixbuf("authentication.png")
        if icon:
            self.set_icon(icon)
        add_close_accel(self, self.quit)
        self.connect("delete_event", self.quit)

        self.vbox = Gtk.VBox(homogeneous=False, spacing=20)
        style_body(self.vbox)
        self.add(self.vbox)

        title_label = label(title)
        add_style_class(title_label, "xpra-dialog-title")
        self.vbox.add(title_label)

        info_label = label(info)
        add_style_class(info_label, "xpra-card", "xpra-subtitle")
        self.vbox.add(info_label)

        if self.timeout > 0:
            self.timeout_label = label()
            add_style_class(self.timeout_label, "xpra-countdown")
            self.update_timeout()
            self.vbox.add(self.timeout_label)
            GLib.timeout_add(1000, self.update_timeout)

        al = Gtk.Alignment(xalign=1.0, yalign=0.5, xscale=0.0, yscale=0.0)
        al.set_margin_start(10)
        al.set_margin_end(10)
        hbox = Gtk.HBox(homogeneous=False, spacing=10)
        style_actions(hbox)
        al.add(hbox)
        cancel_btn = self.btn("Cancel", Gtk.STOCK_NO, self.cancel)
        accept_btn = self.btn("Accept", Gtk.STOCK_OK, self.accept)
        style_button(cancel_btn)
        style_button(accept_btn, primary=True)
        hbox.add(cancel_btn)
        hbox.add(accept_btn)
        self.vbox.add(al)

        register_os_signals(self.app_signal, "Authentication Dialog")
        self.show_all()

    @staticmethod
    def btn(label, stock_icon, callback):
        btn = Gtk.Button(label=label)
        settings = btn.get_settings()
        settings.set_property('gtk-button-images', True)
        btn.connect("clicked", callback)
        if stock_icon:
            # pylint: disable=no-member
            image = Gtk.Image.new_from_icon_name(stock_icon, Gtk.IconSize.BUTTON)
            if image:
                btn.set_image(image)
        return btn

    def update_timeout(self) -> bool:
        if self.timeout <= 0:
            self.exit_code = 2
            self.quit()
            return False
        self.timeout_label.set_text(f"This request will timeout in {self.timeout} seconds")
        self.timeout -= 1
        return True

    def cancel(self, _btn) -> None:
        self.exit_code = 3
        self.quit()

    def accept(self, _btn) -> None:
        self.exit_code = 0
        self.quit()

    def quit(self, *args) -> None:
        log("quit%s", args)
        self.do_quit()

    @staticmethod
    def do_quit() -> None:
        log("do_quit()")
        Gtk.main_quit()

    def app_signal(self, signum: int) -> None:
        self.exit_code = 128 + signum
        log("app_signal(%s) exit_code=%i", signum, self.exit_code)
        self.do_quit()


def main(argv: list[str]) -> int:
    # pylint: disable=import-outside-toplevel
    from xpra.util.io import stderr_print
    from xpra.platform import program_context
    with program_context("Session Access"):
        from xpra.platform.gui import init as gui_init
        gui_init()
        if len(argv) < 2:
            stderr_print(f"usage: {argv[0]} 'message' [timeout-in-seconds]")
            return 4
        info = argv[1]
        if len(argv) >= 3:
            try:
                timeout = int(argv[2])
            except ValueError:
                stderr_print("invalid timeout value")
                stderr_print(f"usage: {argv[0]} 'message' [timeout-in-seconds]")
                return 4
        else:
            timeout = 600
        w = AuthDialog(info=info, timeout=timeout)
        gtk_main()
        return w.exit_code


if __name__ == "__main__":
    r = main(sys.argv)
    sys.exit(r)

#!/usr/bin/env python3
# This file is part of Xpra.
# Copyright (C) 2026 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from __future__ import annotations

import os

from xpra.log import Logger
from xpra.seccomp import is_enabled

log = Logger("seccomp")

# this module is the `decode` filter (`--seccomp=decode`, `XPRA_SECCOMP_DECODE`):
# it keeps its original file name, from when the only sandboxed decoding thread was the draw loop.
ACTION_ENV = "XPRA_SECCOMP_DECODE_ACTION"

# permissive baseline shared with the network parse and rfb filters.
# `pause` is needed by any daemon thread that is still running when the interpreter exits:
# CPython (3.14+) parks it forever in `PyThread_hang_thread()`, which loops on `pause()`.
# those threads dispatch many packet handlers (hello, audio, encodings, ...)
# with a large lazy-import surface, so they keep the ability to open files -
# see `xpra/seccomp/parse.py` and `xpra/seccomp/rfb.py`:
BASE_SYSCALLS: tuple[str, ...] = (
    "access",
    "arch_prctl",
    "brk",
    "clock_gettime",
    "clone",
    "clone3",
    "close",
    "dup",
    "dup2",
    "dup3",
    "epoll_create1",
    "epoll_ctl",
    "epoll_pwait",
    "epoll_wait",
    "exit",
    "exit_group",
    "fadvise64",
    "fallocate",
    "fcntl",
    "fstat",
    "fsync",
    "ftruncate",
    "futex",
    "getcwd",
    "getdents64",
    "getegid",
    "geteuid",
    "getgid",
    "getpid",
    "getppid",
    "getrandom",
    "gettid",
    "getuid",
    "ioctl",
    "lseek",
    "madvise",
    "membarrier",
    "mincore",
    "mkdir",
    "mmap",
    "mprotect",
    "mremap",
    "munmap",
    "nanosleep",
    "newfstatat",
    "open",
    "openat",
    "pause",
    "poll",
    "ppoll",
    "pread64",
    "prctl",
    "prlimit64",
    "pselect6",
    "read",
    "readlink",
    "readlinkat",
    "recvmsg",
    "rename",
    "renameat",
    "renameat2",
    "rseq",
    "rt_sigaction",
    "rt_sigprocmask",
    "rt_sigreturn",
    "sched_getaffinity",
    "sched_yield",
    "select",
    "sendmsg",
    "set_robust_list",
    "set_tid_address",
    "sigaltstack",
    "stat",
    "statx",
    "tgkill",
    "unlink",
    "unlinkat",
    "write",
    "writev",
    "clock_nanosleep",
    "restart_syscall",
)

# this filter is installed on the client's shared `decode` thread
# (`xpra/client/subsystem/decode.py`), which decodes every kind of untrusted picture data
# the server sends: draw packets, window icons and cursors.
# That thread only decodes images that are already in memory: the decoders it uses
# are pre-loaded and pre-warmed by the codec selftest (XPRA_CODEC_SELFTEST, on by default)
# before the filter is installed, every consumer imports what it needs from its
# `preload_decode()` hook, and hardware decoders are disabled under seccomp
# (see `xpra/client/subsystem/encoding.py`). So it never needs to open, create or delete
# files - blocking those confines a decoder bug from touching the filesystem.
# (Debug image dumping via XPRA_SAVE_TO_FILE, XPRA_SAVE_WINDOW_ICONS and XPRA_SAVE_CURSORS
# is turned off under seccomp.)
FILE_SYSCALLS: tuple[str, ...] = (
    "open",
    "openat",
    "unlink",
    "unlinkat",
    "mkdir",
    "rename",
    "renameat",
    "renameat2",
    "ftruncate",
    "fallocate",
)

DECODE_SYSCALLS: tuple[str, ...] = tuple(s for s in BASE_SYSCALLS if s not in FILE_SYSCALLS)


def install_thread() -> bool:
    if not is_enabled():
        return False
    from xpra.seccomp import install_filter
    action = get_action()
    log("installing decode thread seccomp policy with action=%s", action)
    install_filter(DECODE_SYSCALLS, action)
    return True


def get_action() -> str:
    action = str(os.environ.get(ACTION_ENV, "kill_process")).strip().lower()
    if action in ("kill", "kill-thread", "kill_thread"):
        return "kill_thread"
    if action in ("kill_process", "kill-process"):
        return "kill_process"
    if action in ("errno", "log", "allow"):
        return action
    log.warn("Warning: invalid %s value %r", ACTION_ENV, action)
    return "kill_process"

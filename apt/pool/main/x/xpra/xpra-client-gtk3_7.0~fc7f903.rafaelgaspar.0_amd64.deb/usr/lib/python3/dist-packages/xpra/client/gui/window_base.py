# This file is part of Xpra.
# Copyright (C) 2011 Serviware (Arthur Huillet, <ahuillet@serviware.com>)
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from typing import Any, Final
from collections.abc import Callable, MutableSequence, Sequence

from xpra.os_util import OSX, WIN32
from xpra.client.gui.widget_base import ClientWidgetBase
from xpra.client.gui.window.backing import fire_paint_callbacks, get_backing_client_properties
from xpra.client.gui.window_border import WindowBorder
from xpra.net.common import PacketElement, BACKWARDS_COMPATIBLE
from xpra.common import gravity_str, force_size_constraint, is_covered_by_opaque_region, is_x11_property_denied
from xpra.util.colourspace import Colourspace, SRGB
from xpra.util.parsing import scaleup_value, scaledown_value
from xpra.util.system import is_Wayland
from xpra.util.objects import typedict
from xpra.client.gui.window_title import do_get_window_title, window_title_str
from xpra.util.env import envint, envbool, ignorewarnings
from xpra.log import Logger

log = Logger("window")
paintlog = Logger("paint")
workspacelog = Logger("workspace")
keylog = Logger("keyboard")
metalog = Logger("metadata")
geomlog = Logger("geometry")
iconlog = Logger("icon")
alphalog = Logger("alpha")
scalinglog = Logger("scaling")

PROPERTIES_DEBUG = [x.strip() for x in os.environ.get("XPRA_WINDOW_PROPERTIES_DEBUG", "").split(",")]
SET_SIZE_CONSTRAINTS = envbool("XPRA_SET_SIZE_CONSTRAINTS", True)
DEFAULT_GRAVITY = envint("XPRA_DEFAULT_GRAVITY", 0)
OVERRIDE_GRAVITY = envint("XPRA_OVERRIDE_GRAVITY", 0)
FORCE_FLUSH = envbool("XPRA_FORCE_FLUSH", False)

SHOW_SPINNER_WINDOW_TYPES = set(os.environ.get("XPRA_SHOW_SPINNER_WINDOW_TYPES", "DIALOG,NORMAL,SPLASH").split(","))

# sentinel for "requested-position" metadata: a position no window can ever occupy
# (0, 0) and negative coordinates are all valid positions, so we need an out-of-range value:
NOT_REQUESTED: Final[tuple[int, int]] = (-2 ** 32, -2 ** 32)


class ClientWindowBase(ClientWidgetBase):

    def __init__(self, client, group_leader, wid: int,
                 geom: tuple[int, int, int, int],
                 backing_size: tuple[int, int],
                 metadata: typedict, override_redirect: bool, client_properties: typedict,
                 border: WindowBorder, max_window_size, pixel_depth: int,
                 headerbar="no"):
        log("%s%s", type(self),
            (client, group_leader, wid,
             geom, backing_size,
             metadata, override_redirect, client_properties,
             border, max_window_size, pixel_depth,
             headerbar))
        self.idle_add: Callable = client.idle_add
        self.timeout_add: Callable = client.timeout_add
        self.source_remove: Callable = client.source_remove
        wx, wy, ww, wh = geom
        bw, bh = backing_size
        has_alpha = metadata.boolget("has-alpha")
        # gdk-quartz makes the `NSWindow` of an RGBA visual non-opaque with a clear background,
        # and on macOS 27 that makes the native title bar transparent:
        # don't use alpha for windows which declare themselves fully opaque via `_NET_WM_OPAQUE_REGION` (ie: chromium)
        # (the opaque region is in server coordinates, like the backing size)
        opaque = OSX and has_alpha and is_covered_by_opaque_region(metadata.tupleget("opaque-region"), bw, bh)
        if opaque:
            alphalog("window %#x is covered by its opaque region, not using alpha", wid)
            has_alpha = False
        super().__init__(client, wid, has_alpha)
        # `set_has_alpha` must not turn it back on when the initial metadata is applied:
        self._opaque_alpha_dropped = opaque
        self._override_redirect = override_redirect
        self.group_leader = group_leader
        self._pos = (wx, wy)
        self._size = (ww, wh)
        display = client.get_subsystem("display")
        self._xscale = display.xscale if display else 1
        self._yscale = display.yscale if display else 1
        self._client_properties = client_properties
        self._set_initial_position = metadata.boolget("set-initial-position", False)
        self._requested_position = metadata.intpair("requested-position", NOT_REQUESTED)
        self.size_constraints = typedict()
        self.geometry_hints = typedict()
        self.content_types: tuple[str, ...] = ()
        # the colourspace the server tagged this window with, if any:
        # `None` means it did not, and we fall back to the session colourspace
        self.colourspace: Colourspace | None = None
        self._fullscreen = None
        self._maximized = False
        self._above = False
        self._below = False
        self._shaded = False
        self._sticky = False
        self._skip_pager = False
        self._skip_taskbar = False
        self._iconified = False
        self._focused = False
        self._attention_requested = False
        self._opaque_region = ()
        self._actions = ()
        self.window_gravity = OVERRIDE_GRAVITY or DEFAULT_GRAVITY
        self.border = border
        self.max_window_size = max_window_size
        self.pixel_depth = pixel_depth  # 0 for default
        # window_offset is the delta between the location of the window requested by the server,
        # and where we actually end up mapping it on the client
        # (ie: when we reposition an OR window to ensure it is visible on screen)
        self.window_offset = None
        self.pending_refresh: list[tuple[int, int, int, int]] = []
        self.headerbar = headerbar

        self.init_window(client, metadata, client_properties)
        self.setup_window(bw, bh)
        self.update_metadata(metadata)
        self.finalize_window()

    def __repr__(self):
        return f"ClientWindow({self.wid:#x})"

    def init_window(self, client, metadata: typedict, client_props: typedict) -> None:
        self._backing = None
        self._metadata = typedict()
        # used for only sending focus events *after* the window is mapped:
        self._been_mapped = False

        if self.max_window_size and "size-constraints" not in metadata:
            # this ensures that we will set size-constraints and honour max_window_size:
            metadata["size-constraints"] = {}
        # initialize gravity early:
        sc = typedict(metadata.dictget("size-constraints"))
        self.window_gravity = OVERRIDE_GRAVITY or sc.intget("gravity", DEFAULT_GRAVITY)
        self.set_decorated(metadata.boolget("decorations", True))

    def finalize_window(self) -> None:
        """ subclasses override this method """

    def get_info(self) -> dict[str, Any]:
        attributes = []
        for attr in (
                "fullscreen", "maximized",
                "above", "below",
                "shaded", "sticky",
                "skip-pager", "skip-taskbar",
                "iconified", "focused",
        ):
            if getattr(self, "_%s" % attr.replace("-", "_"), False):
                attributes.append(attr)
        info = super().get_info()
        info |= {
            "override-redirect": self._override_redirect,
            # "group-leader"          : self.group_leader,
            "position": self._pos,
            "size": self._size,
            "client-properties": dict(self._client_properties),
            "set-initial-position": self._set_initial_position,
            "size-constraints": dict(self.size_constraints),
            "geometry-hints": dict(self.geometry_hints),
            "content-types": self.content_types,
            "colourspace": self.get_colourspace().to_dict(),
            "attributes": attributes,
            "gravity": gravity_str(self.window_gravity),
            # "border"                : self.border or "",
            "max-size": self.max_window_size,
            "offset": self.window_offset or (0, 0),
        }
        return info

    ######################################################################
    # screen scaling:
    def fsx(self, v) -> float:
        """ convert X coordinate from server to client """
        return v * self._xscale

    def fsy(self, v) -> float:
        """ convert Y coordinate from server to client """
        return v * self._yscale

    def sx(self, v) -> int:
        """ convert X coordinate from server to client """
        return round(self.fsx(v))

    def sy(self, v) -> int:
        """ convert Y coordinate from server to client """
        return round(self.fsy(v))

    def srect(self, x, y, w, h) -> tuple[int, int, int, int]:
        """ convert rectangle coordinates from server to client """
        return self.sx(x), self.sy(y), self.sx(w), self.sy(h)

    def sp(self, x, y) -> tuple[int, int]:
        """ convert X,Y coordinates from server to client """
        return self.sx(x), self.sy(y)

    def cx(self, v) -> int:
        """ convert X coordinate from client to server """
        return round(v / self._xscale)

    def cy(self, v) -> int:
        """ convert Y coordinate from client to server """
        return round(v / self._yscale)

    def crect(self, x, y, w, h) -> tuple[int, int, int, int]:
        """ convert rectangle coordinates from client to server """
        return self.cx(x), self.cy(y), self.cx(w), self.cy(h)

    def cp(self, x, y) -> tuple[int, int]:
        """ convert X,Y coordinates from client to server """
        return self.cx(x), self.cy(y)

    def new_backing(self, bw: int, bh: int):
        backing_class = self.get_backing_class()
        log("new_backing(%s, %s) backing_class=%s", bw, bh, backing_class)
        assert backing_class is not None
        w, h = self._size
        self._backing = self.make_new_backing(backing_class, w, h, bw, bh)
        self._backing.border = self.border
        self._backing.content_types = self.content_types
        # soft dependency on `PointerWindow`:
        self._backing.default_cursor_data = getattr(self, "default_cursor_data", ())
        self._backing.gravity = self.window_gravity
        # this is only used by cairo to request a repaint for the fps counter:
        self._backing.repaint = self.repaint
        return self._backing._backing

    def destroy(self) -> None:
        # ensure we clear reference to other windows:
        self.group_leader = None
        self._metadata = typedict()
        if self._backing:
            self._backing.close()
            self._backing = None

    def setup_window(self, bw: int, bh: int) -> None:
        self.new_backing(bw, bh)
        # tell the server about the encoding capabilities of this backing instance:
        enc = self.get_subsystem("encoding")
        encoding_defaults = enc.encoding_defaults if enc else {}
        self._client_properties.update(get_backing_client_properties(self._backing, encoding_defaults))

    def send(self, packet_type: str, *args: PacketElement) -> None:
        self._client.send(packet_type, *args)

    def reset_icon(self) -> None:
        current_icon = self._current_icon
        iconlog("reset_icon() current icon=%s", current_icon)
        if current_icon:
            self.update_icon(current_icon)

    def update_icon(self, img) -> None:
        raise NotImplementedError

    def apply_transient_for(self, wid: int) -> None:
        raise NotImplementedError

    def xget_u32_property(self, target, name: str, default_value=0) -> int:
        return default_value

    def is_OR(self) -> bool:
        return self._override_redirect

    def get_session_colourspace(self) -> Colourspace:
        """ the colourspace the session renders into, which is what we use for untagged windows """
        display = self._client.get_subsystem("display")
        if not display:
            return SRGB
        return getattr(display, "server_colourspace", SRGB)

    def get_colourspace(self) -> Colourspace:
        """
        The colourspace this window's pixels are in,
        which is what we have to convert from to render them accurately:
        the value the server tagged this window with if it provided one,
        otherwise the colourspace the whole session renders into, otherwise sRGB.
        """
        if self.colourspace is not None:
            return self.colourspace
        return self.get_session_colourspace()

    def update_metadata(self, metadata: typedict) -> None:
        metalog("update_metadata(%s)", metadata)
        if not BACKWARDS_COMPATIBLE and "content-type" in metadata:
            metadata = typedict(metadata)
            metadata.pop("content-type")
        if self.is_readonly():
            metadata.update(force_size_constraint(*self._size))
        self._metadata.update(metadata)
        try:
            self.set_metadata(metadata)
        except RuntimeError:
            metalog.warn("failed to set window metadata to '%s'", metadata, exc_info=True)
        # the initial value is resolved when the window is created,
        # only an update means that the server has moved the window relative to its parent:
        if "relative-position" in metadata:
            self.apply_relative_position(metadata.inttupleget("relative-position"))

    def apply_relative_position(self, rel_pos: Sequence[int]) -> None:
        """ the windows that can follow their parent override this """

    def _get_window_title(self, metadata: typedict) -> str:
        try:
            return do_get_window_title(self._client, self.wid, dict(self._metadata) | dict(metadata))
        except Exception as e:
            log.error("Error parsing window title:")
            log.estr(e)
            return self._client.title.replace("\0", "")

    def set_metadata(self, metadata: typedict):
        metalog("set_metadata(%s)", metadata)
        debug_props = tuple(x for x in PROPERTIES_DEBUG if x in metadata.keys())
        for x in debug_props:
            metalog.info("set_metadata: %s=%s", x, metadata.get(x))
        # WARNING: "class-instance" needs to go first because others may realize the window
        # (and GTK doesn't set the "class-instance" once the window is realized)
        if "class-instance" in metadata:
            self.set_class_instance(*metadata.strtupleget("class-instance", ("xpra", "Xpra"), 2, 2))
            self.reset_icon()

        if "title" in metadata:
            title = self._get_window_title(metadata)
            self.set_title(title)

        if "icon-title" in metadata:
            icon_title = window_title_str(metadata.strget("icon-title"))
            self.set_icon_name(icon_title)
            # the DE may have reset the icon now,
            # force it to use the one we really want:
            self.reset_icon()

        if "size-constraints" in metadata:
            sc = typedict(metadata.dictget("size-constraints"))
            self.size_constraints = sc
            self._set_initial_position = sc.boolget("set-initial-position", self._set_initial_position)
            self.set_size_constraints(sc, self.max_window_size)

        if "opacity" in metadata:
            opacity = metadata.intget("opacity", -1)
            # older servers may send sign-extended 32-bit values:
            opacity = 1 if opacity < 0 else min(1, (opacity & 0xffffffff) / 0xffffffff)
            ignorewarnings(self.set_opacity, opacity)

        if "content-types" in metadata:
            self.content_types = metadata.strtupleget("content-types")
            if b := self._backing:
                b.content_types = self.content_types
        elif BACKWARDS_COMPATIBLE and "content-type" in metadata:
            content_type = metadata.strget("content-type")
            self.content_types = tuple(x for x in content_type.replace("+", ",").split(",") if x)
            self._metadata["content-types"] = self.content_types
            self._metadata.pop("content-type", None)
            if b := self._backing:
                b.content_types = self.content_types

        if "colourspace" in metadata:
            # fall back to the session colourspace for anything the server left out:
            self.colourspace = Colourspace.from_dict(metadata.dictget("colourspace"),
                                                     self.get_session_colourspace())
            metalog("window %i colourspace=%s", self.wid, self.colourspace)

        if "transient-for" in metadata:
            self.apply_transient_for(metadata.intget("transient-for"))

        if "set-initial-position" in metadata:
            # this should be redundant - but we keep it here for consistency
            self._set_initial_position = metadata.boolget("set-initial-position")

        if "x11-property" in metadata:
            attr = metadata.tupleget("x11-property")
            if len(attr) >= 4:
                name, ptype, _, value = attr[:4]
                if not is_x11_property_denied(name):
                    self.set_x11_property(name, ptype, value)

        standard_properties: dict[str, type] = {
            "locale": str,
            "modal": bool,
            "role": str,
            "xid": str,
            "has-alpha": bool,
            "maximized": bool,
            "fullscreen": bool,
            "iconic": bool,
            "decorations": bool,
            "above": bool,
            "below": bool,
            "shaded": bool,
            "sticky": bool,
            "skip-taskbar": bool,
            "skip-pager": bool,
            "focused": bool,
            "attention-requested": bool,
            "workspace": int,
            "bypass-compositor": int,
            "strut": dict,
            "shape": dict,
            "command": str,
            "actions": tuple[str],
            "fullscreen-monitors": tuple[int],
            "opaque-region": tuple,
            "window-type": tuple[str],
        }
        getters: dict[type, Callable] = {
            str: typedict.strget,
            bool: typedict.boolget,
            int: typedict.intget,
            dict: typedict.dictget,
            tuple[str]: typedict.strtupleget,
            tuple[int]: typedict.inttupleget,
            tuple: typedict.tupleget,
        }
        for prop, ptype in standard_properties.items():
            if prop in metadata:
                getter = getters[ptype]
                value = getter(metadata, prop)
                setter = getattr(self, "set_" + prop.replace("-", "_"))
                setter(value)

    def set_actions(self, actions: tuple[str, ...]) -> None:
        self._actions = actions

    def set_x11_property(self, *x11_property) -> None:
        pass  # see gtk client window base

    def set_above(self, above: bool) -> None:
        if self._above != above:
            self._above = above
            self.set_keep_above(above)

    def set_below(self, below: bool) -> None:
        if self._below != below:
            self._below = below
            self.set_keep_below(below)

    def set_sticky(self, sticky: bool) -> None:
        if self._sticky != sticky:
            self._sticky = sticky
            if sticky:
                self.stick()
            else:
                self.unstick()

    def set_skip_taskbar(self, skip_taskbar: bool) -> None:
        if self._skip_taskbar != skip_taskbar:
            self._skip_taskbar = skip_taskbar
            self.set_skip_taskbar_hint(skip_taskbar)

    def set_skip_pager(self, skip_pager: bool) -> None:
        if self._skip_pager != skip_pager:
            self._skip_pager = skip_pager
            self.set_skip_pager_hint(skip_pager)

    def set_focused(self, focused: bool) -> None:
        # only implemented for X11
        pass

    def set_opaque_region(self, rectangles: tuple[tuple[int, int, int, int], ...]) -> None:
        pass  # see gtk client window base

    def set_attention_requested(self, attention: bool) -> None:
        """ ask the desktop to draw the user's attention to this window,
            see the toolkit specific window classes for the implementations
        """

    def set_decorations(self, decorated: bool) -> None:
        was_decorated = self.get_decorated()
        if WIN32 and decorated != was_decorated:
            log.info("decorations flag toggled, now %s, re-initializing window", decorated)
            self.idle_add(self.get_subsystem("window").reinit_window, self.wid, self)
        else:
            self.set_decorated(decorated)
            self.apply_geometry_hints(self.geometry_hints)

    def set_iconic(self, iconified: bool) -> None:
        if self._iconified != iconified:
            self._iconified = iconified
            if iconified:
                self.iconify()
            else:
                self.deiconify()

    def set_fullscreen(self, fullscreen: bool) -> None:
        """ see gtk3 window for implementation """

    def set_has_alpha(self, alpha: bool) -> None:
        if alpha and self._opaque_alpha_dropped:
            alphalog("window %#x: ignoring has-alpha, the window is covered by its opaque region", self.wid)
            return
        if alpha == self._has_alpha:
            return
        # losing the alpha channel is safe: the window keeps the visual and the backing
        # it was realized with, and opaque pixels painted into them just render opaque.
        # (a wayland window does this whenever its client commits an `XRGB` buffer)
        # gaining one is the undefined case: the visual is chosen once, at realize time.
        # win32 without opengl can't do transparency, so it warns about everything:
        if alpha and not WIN32:
            alphalog.warn("Warning: window %#x changed its transparency attribute", self.wid)
            alphalog.warn(" from %s to %s, behaviour is undefined", self._has_alpha, alpha)
        else:
            alphalog("window %#x changed its transparency attribute from %s to %s",
                     self.wid, self._has_alpha, alpha)
        self._has_alpha = alpha

    def set_maximized(self, maximized: bool) -> None:
        if maximized != self._maximized:
            self._maximized = maximized
            if maximized:
                self.maximize()
            else:
                self.unmaximize()

    def set_command(self, command) -> None:
        """ see gtk3 window for implementation """

    def set_class_instance(self, wmclass_name, wmclass_class) -> None:
        """ see gtk3 window for implementation """

    def set_shape(self, shape) -> None:
        """ see gtk3 window for implementation """

    def set_bypass_compositor(self, v) -> None:
        """ see gtk3 window for implementation """

    def set_strut(self, strut) -> None:
        """ see gtk3 window for implementation """

    def set_fullscreen_monitors(self, fsm) -> None:
        """ see gtk3 window for implementation """

    def set_shaded(self, shaded) -> None:
        """ see gtk3 window for implementation """

    def reset_size_constraints(self) -> None:
        self.set_size_constraints(self.size_constraints, self.max_window_size)

    def set_size_constraints(self, size_constraints: typedict, max_window_size: tuple[int, int]):
        if not SET_SIZE_CONSTRAINTS:
            return
        geomlog("set_size_constraints(%s, %s)", size_constraints, max_window_size)
        hints = typedict()
        for (a, h1, h2) in (
                ("maximum-size", "max_width", "max_height"),
                ("minimum-size", "min_width", "min_height"),
                ("base-size", "base_width", "base_height"),
                ("increment", "width_inc", "height_inc"),
        ):
            v = size_constraints.intpair(a)
            geomlog("intpair(%s)=%s", a, v)
            if v == (0, 0):
                continue
            v1, v2 = v
            if a == "maximum-size" and v1 >= 16384 and v2 >= 16384 and WIN32:
                # causes problems, see #2714, #3533
                continue
            # the window's own scaling (self._xscale) tracks the display scale:
            sv1 = self.sx(v1)
            sv2 = self.sy(v2)
            if a in ("base-size", "increment"):
                # rounding is not allowed for these values
                fsv1 = self.fsx(v1)
                fsv2 = self.fsy(v2)

                def closetoint(value):
                    # tolerate some rounding error:
                    # (ie: 2:3 scaling may not give an integer without a tiny bit of rounding)
                    return abs(round(value) - value) < 0.00001

                if not closetoint(fsv1) or not closetoint(fsv2):
                    # the scaled value is not close to an int,
                    # so we can't honour it:
                    geomlog("cannot honour '%s' due to scaling, scaled values are not both integers: %s, %s",
                            a, fsv1, fsv2)
                    continue
            hints[h1] = sv1
            hints[h2] = sv2
        if not OSX:
            for (a, h) in (
                    ("minimum-aspect-ratio", "min_aspect"),
                    ("maximum-aspect-ratio", "max_aspect"),
            ):
                v = size_constraints.intpair(a)
                if v != (0, 0):
                    v1, v2 = v
                    hints[h] = (v1 * self._xscale) / (v2 * self._yscale)
        # apply max-size override if needed:
        w, h = max_window_size
        if w > 0 and h > 0 and not self._fullscreen:
            # get the min size, if there is one:
            minw = max(1, hints.intget("min_width", 1))
            minh = max(1, hints.intget("min_height", 1))
            # the actual max size is:
            # * greater than the min-size
            # * the lowest of the max-size set by the application and the one we have
            # * ensure we honour the other hints, and round the max-size down if needed:
            # according to the GTK docs:
            # allowed window widths are base_width + width_inc * N where N is any integer
            # allowed window heights are base_height + width_inc * N where N is any integer
            maxw = hints.intget("max_width", 32768)
            maxh = hints.intget("max_height", 32768)
            maxw = max(minw, min(w, maxw))
            maxh = max(minh, min(h, maxh))
            rw = (maxw - hints.intget("base_width", 0)) % max(hints.intget("width_inc", 1), 1)
            rh = (maxh - hints.intget("base_height", 0)) % max(hints.intget("height_inc", 1), 1)
            maxw -= rw
            maxh -= rh
            # if the hints combination is invalid, it's possible that we'll end up
            # not honouring "base" + "inc", but honouring just "min" instead:
            maxw = max(minw, maxw)
            maxh = max(minh, maxh)
            scaling_info = self._xscale, self._yscale
            geomlog("modified hints for max window size %s and scaling %s: %s (rw=%s, rh=%s) -> max=%sx%s",
                    max_window_size, scaling_info, hints, rw, rh, maxw, maxh)
            # ensure we don't have duplicates with bytes / strings,
            # and that keys are always "bytes":
            # (in practice this code should never fire, just here as a reminder)
            for x in ("max_width", "max_height"):
                hints.pop(x, None)
            # bug 2214: GTK3 on win32 gets confused if we specify a large max-size,
            # and it will mess up maximizing the window
            if not WIN32 or (maxw < 32000 or maxh < 32000):
                hints["max_width"] = maxw
                hints["max_height"] = maxh
        try:
            geomlog("calling: %s(%s)", self.apply_geometry_hints, hints)
            # save them so the window hooks can use the last value used:
            self.geometry_hints = hints
            self.apply_geometry_hints(hints)
        except Exception as e:
            geomlog("set_size_constraints%s", (size_constraints, max_window_size), exc_info=True)
            geomlog.error("Error setting window hints:")
            geomlog.estr(e)
            for k, v in hints.items():
                geomlog.error(f"  {k}={v}")
            geomlog.error(" from size constraints:")
            for k, v in size_constraints.items():
                geomlog.error("  %s=%s", k, v)
        self.window_gravity = OVERRIDE_GRAVITY or size_constraints.intget("gravity", DEFAULT_GRAVITY)
        if b := self._backing:
            b.gravity = self.window_gravity

    def set_locale(self, locale: str) -> None:
        pass  # see gtk client window base

    def set_window_type(self, window_types) -> None:
        pass  # see gtk client window base

    def set_workspace(self, workspace) -> None:
        pass  # see gtk client window base

    def set_xid(self, xid) -> None:
        pass  # see gtk client window base

    def dismiss_popups(self) -> None:
        if window := self.get_subsystem("window"):
            window.dismiss_popups()

    def toggle_debug(self, *_args) -> None:
        b = self._backing
        log.info("toggling debug on backing %s for window %i", b, self.wid)
        if not b:
            return
        if b.paint_box_line_width > 0:
            b.paint_box_line_width = 0
        else:
            b.paint_box_line_width = b.default_paint_box_line_width

    def increase_quality(self, *_args) -> None:
        enc = self.get_subsystem("encoding")
        if not enc:
            return
        if enc.quality > 0:
            # change fixed quality:
            enc.quality = min(100, enc.quality + 10)
            enc.send_quality()
            log("new quality=%s", enc.quality)
        else:
            enc.min_quality = min(100, enc.min_quality + 10)
            enc.send_min_quality()
            log("new min-quality=%s", enc.min_quality)

    def decrease_quality(self, *_args) -> None:
        enc = self.get_subsystem("encoding")
        if not enc:
            return
        if enc.quality > 0:
            # change fixed quality:
            enc.quality = max(1, enc.quality - 10)
            enc.send_quality()
            log("new quality=%s", enc.quality)
        else:
            enc.min_quality = max(0, enc.min_quality - 10)
            enc.send_min_quality()
            log("new min-quality=%s", enc.min_quality)

    def increase_speed(self, *_args) -> None:
        enc = self.get_subsystem("encoding")
        if not enc:
            return
        if enc.speed > 0:
            # change fixed speed:
            enc.speed = min(100, enc.speed + 10)
            enc.send_speed()
            log("new speed=%s", enc.speed)
        else:
            enc.min_speed = min(100, enc.min_speed + 10)
            enc.send_min_speed()
            log("new min-speed=%s", enc.min_speed)

    def decrease_speed(self, *_args) -> None:
        enc = self.get_subsystem("encoding")
        if not enc:
            return
        if enc.speed > 0:
            # change fixed speed:
            enc.speed = max(1, enc.speed - 10)
            enc.send_speed()
            log("new speed=%s", enc.speed)
        else:
            enc.min_speed = max(0, enc.min_speed - 10)
            enc.send_min_speed()
            log("new min-speed=%s", enc.min_speed)

    def scaleup(self, *_args) -> None:
        if display := self._client.get_subsystem("display"):
            display.scaleup()

    def window_scaleup(self, *_args) -> None:
        scaling = max(self._xscale, self._yscale)
        options = scaleup_value(scaling)
        scalinglog("scaleup() options=%s", options)
        if options:
            self._scaleto(min(options))

    def scaledown(self, *_args) -> None:
        if display := self._client.get_subsystem("display"):
            display.scaledown()

    def window_scaledown(self, *_args) -> None:
        scaling = min(self._xscale, self._yscale)
        options = scaledown_value(scaling)
        scalinglog("scaledown() options=%s", options)
        if options:
            self._scaleto(max(options))

    def scalingoff(self) -> None:
        if display := self._client.get_subsystem("display"):
            display.scalingoff()

    def window_scalingoff(self) -> None:
        self._scaleto(1)

    def _scaleto(self, scaling) -> None:
        xscale = self._xscale
        yscale = self._yscale
        w, h = self._size
        self._xscale = self._yscale = scaling
        nw = round(w / xscale * self._xscale)
        nh = round(h / yscale * self._yscale)
        self.reset_size_constraints()
        self.resize(nw, nh)

    def scalereset(self, *_args) -> None:
        if display := self._client.get_subsystem("display"):
            display.scalereset()

    def magic_key(self, *args) -> None:
        if b := self.border:
            b.toggle()
            log("magic_key%s border=%s", args, b)
            self.redraw_border()

    def redraw_border(self) -> None:
        self.repaint(0, 0, *self._size)

    def repaint(self, x: int, y: int, w: int, h: int):
        # self.queue_draw_area(0, 0, *self._size)
        raise NotImplementedError("no repaint on %s" % type(self))

    def refresh_window(self, *args) -> None:
        log("refresh_window(%s) wid=%#x", args, self.wid)
        self.get_subsystem("window").send_refresh(self.wid)

    def refresh_all_windows(self, *_args) -> None:
        # this method is only here because we may want to fire it
        # from a --key-shortcut action and the event is delivered to
        # the "ClientWindow"
        self.get_subsystem("window").send_refresh_all()

    def draw_region(self, x: int, y: int, width: int, height: int,
                    coding: str, img_data, rowstride: int,
                    options: typedict, callbacks: MutableSequence[Callable]):
        """ Note: this runs from the decode thread (not UI thread) """
        backing = self._backing
        if not backing:
            log("draw_region: window %s has no backing, gone?", self.wid)
            fire_paint_callbacks(callbacks, -1, "no backing")
            return
        # only register this callback if we actually need it:
        if backing.draw_needs_refresh:
            if not backing.repaint_all:
                self.pending_refresh.append((x, y, width, height))
            if options.intget("flush", 0) == 0 or FORCE_FLUSH:
                callbacks.append(self.after_draw_refresh)
        if coding == "void":
            fire_paint_callbacks(callbacks)
            return
        backing.draw_region(x, y, width, height, coding, img_data, rowstride, options, callbacks)

    def after_draw_refresh(self, success, message="") -> None:
        backing = self._backing
        pr = self.pending_refresh
        self.pending_refresh = []
        paintlog(f"after_draw_refresh({success}, {message!r}) pending_refresh={pr}, {backing=}")
        if not backing:
            return
        if backing.repaint_all or self._xscale != 1 or self._yscale != 1 or is_Wayland():
            # easy: just repaint the whole window:
            rw, rh = self.get_size()
            self.idle_add(self.repaint, 0, 0, rw, rh)
            return
        display = self._client.get_subsystem("display")
        for x, y, w, h in pr:
            rx, ry, rw, rh = display.srect(x, y, w, h) if display else (x, y, w, h)
            if self.window_offset:
                rx += self.window_offset[0]
                ry += self.window_offset[1]
            self.idle_add(self.repaint, rx, ry, rw, rh)

    def eos(self) -> None:
        """ Note: this runs from the decode thread (not UI thread) """
        if backing := self._backing:
            backing.eos()

    def set_alert_state(self, alert_state: bool) -> None:
        can = self.can_have_alert()
        backing = self._backing
        log("set_alert_state(%s) can_have_alert=%s, backing=%s", alert_state, can, backing)
        if not can or not backing:
            return
        backing.alert_state = alert_state

    def can_have_alert(self) -> bool:
        if self._backing is None:
            return False
        window_types = self._metadata.strtupleget("window-type")
        return bool(set(window_types) & SHOW_SPINNER_WINDOW_TYPES)

    def redraw(self):
        # queue a repaint request
        w, h = self.get_size()
        self.repaint(0, 0, w, h)

    def _unfocus(self) -> bool:
        # overriden in FocusWindow
        return self.get_subsystem("window").update_focus(self.wid, False)

    @staticmethod
    def log(message="") -> None:
        log.info(message)

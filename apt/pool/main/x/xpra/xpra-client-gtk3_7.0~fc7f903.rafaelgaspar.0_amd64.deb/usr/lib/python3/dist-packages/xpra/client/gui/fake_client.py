# This file is part of Xpra.
# Copyright (C) 2023 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any
from collections.abc import Sequence

from xpra.common import noop
from xpra.util.glib_scheduler import GLibScheduler
from xpra.log import Logger

log = Logger("client")


class FakePointerSubsystem:
    def __init__(self):
        self.wheel_smooth = False
        self.server_pointer = True
        self.middle_click = True
        self.button_transform: dict[tuple[str, int], int] = {}

    def get_mouse_position(self) -> tuple[int, int]:
        return 0, 0

    def split_pointer_position(self, position) -> tuple[tuple[int, ...], dict]:
        return tuple(position[:2]), {}

    def send_button(self, *_args) -> None:
        log("send_button ignored")

    def wheel_event(self, *_args) -> None:
        log("wheel_event ignored")


class FakeWindowSubsystem:
    def __init__(self):
        self.modal_windows = False
        self.server_window_states: Sequence[str] = ()
        self.server_window_frame_extents = False
        self._id_to_window = {}
        self._focused = None
        self._window_with_grab = None
        self.pointer_grabbed = None

    def has_focus(self, *_args) -> bool:
        return False

    def update_focus(self, *_args) -> bool:
        return False

    def control_refresh(self, *_args) -> None:
        log("control_refresh ignored")

    def send_refresh(self, *_args) -> None:
        log("send_refresh ignored")

    def window_close_event(self, *_args) -> None:
        log("window_close_event ignored")


class FakeClient(GLibScheduler):
    def __init__(self):
        self.title = ""
        self.readonly = False
        self._remote_server_mode = "seamless"
        self.find_window = noop
        self.request_frame_extents = noop
        self.server_readonly = False
        self.window_ungrab = noop
        self.subsystems = {
            "window": FakeWindowSubsystem(),
            "pointer": FakePointerSubsystem(),
        }

    def get_subsystem(self, name: str):
        return self.subsystems.get(name)

    def legacy_server(self) -> bool:
        return False

    def get_window_frame_sizes(self, *_args) -> dict[str, Any]:
        return {}

    def signal_disconnect_and_quit(self, *_args):
        log.info("signal_disconnect_and_quit")

    def send(self, *args):
        log("send%s", args)

    def get_current_modifiers(self) -> Sequence[str]:
        return ()

    def get_raw_mouse_position(self) -> tuple[int, int]:
        return 0, 0

    def get_mouse_position(self) -> tuple[int, int]:
        return 0, 0

    def __repr__(self):
        return f"<FakeClient {self.subsystems!r}>"

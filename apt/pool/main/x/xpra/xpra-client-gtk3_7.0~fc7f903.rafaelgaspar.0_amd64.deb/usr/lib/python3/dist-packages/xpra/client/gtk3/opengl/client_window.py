# This file is part of Xpra.
# Copyright (C) 2012 Serviware (Arthur Huillet, <ahuillet@serviware.com>)
# Copyright (C) 2012 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from xpra.client.gtk3.window.window import ClientWindow
from xpra.gtk.window import set_visual
from xpra.util.objects import typedict
from xpra.util.env import envbool
from xpra.log import Logger

log = Logger("opengl", "window")

MONITOR_REINIT = envbool("XPRA_OPENGL_MONITOR_REINIT", False)


class GLClientWindowBase(ClientWindow):

    def __repr__(self):
        return f"GLClientWindow({self.wid:#x} : {self._backing})"

    def get_backing_class(self) -> type:
        raise NotImplementedError()

    def is_GL(self) -> bool:
        return True

    def queue_draw_area(self, x: int, y: int, w: int, h: int) -> None:
        b = self._backing
        if not b:
            return
        b.gl_expose_rect(x, y, w, h)

    def monitor_changed(self, monitor) -> None:
        super().monitor_changed(monitor)
        da = self.drawing_area
        if da and MONITOR_REINIT:
            # re-create the drawing area,
            # which will re-create the opengl context:
            try:
                self.remove(da)
            except Exception:
                log("monitor_changed: failed to remove %s", da)
            self.drawing_area = None
            w, h = self.get_size()
            self.new_backing(w, h)

    def remove_backing(self) -> None:
        b = self._backing
        log("remove_backing() backing=%s", b)
        if b:
            self._backing = None
            b.paint_screen = False
            b.close()
            glarea = b._backing
            log("remove_backing() glarea=%s", glarea)
            if glarea:
                try:
                    self.remove(glarea)
                except Exception:
                    log.warn("Warning: cannot remove %s", glarea, exc_info=True)

    def magic_key(self, *args) -> None:
        if self.border:
            self.border.toggle()
            self.redraw_border()
        log("gl magic_key%s border=%s, backing=%s", args, self.border, self._backing)

    def redraw_border(self) -> None:
        if b := self._backing:
            with b.gl_context() as ctx:
                b.gl_init(ctx)
                b.present_fbo(ctx, 0, 0, *b.size)
            self.repaint(0, 0, *self._size)

    def do_map_event(self, event) -> None:
        log("GL do_map_event(%s)", event)
        ClientWindow.do_map_event(self, event)
        # a configure event is not guaranteed to follow: without a window manager,
        # windows that are mapped at the size they asked for don't get one at all,
        # and the backing would then never paint anything to the screen
        self.enable_paint_screen()

    def do_configure_event(self, event) -> None:
        log("GL do_configure_event(%s)", event)
        ClientWindow.do_configure_event(self, event)
        self.enable_paint_screen()

    def enable_paint_screen(self) -> None:
        backing = self._backing
        if backing:
            backing.paint_screen = True

    def destroy(self) -> None:
        self.remove_backing()
        super().destroy()

    def init_drawing_area(self) -> None:
        self.drawing_area = None

    def new_backing(self, bw: int, bh: int) -> None:
        widget = super().new_backing(bw, bh)
        if self.drawing_area:
            self.remove(self.drawing_area)
        visual_id = getattr(getattr(self._backing, "context", None), "visual_id", 0)
        set_visual(widget, self._has_alpha, visual_id)
        widget.show()
        self.init_widget_events(widget)
        if self.size_constraints:
            # apply min size to the drawing_area:
            thints = typedict(self.size_constraints)
            minsize = thints.intpair("minimum-size", (0, 0))
            if minsize != (0, 0):
                widget.set_size_request(*minsize)
        self.add(widget)
        self.drawing_area = widget
        # maybe redundant?:
        self.apply_geometry_hints(self.geometry_hints)

    def draw_widget(self, widget, context) -> bool:
        mapped = self.get_mapped()
        backing = self._backing
        log(f"draw_widget({widget}, {context}) {mapped=}, {backing=}", )
        if not mapped:
            return False
        if not backing:
            return False
        return backing.draw_fbo(context)

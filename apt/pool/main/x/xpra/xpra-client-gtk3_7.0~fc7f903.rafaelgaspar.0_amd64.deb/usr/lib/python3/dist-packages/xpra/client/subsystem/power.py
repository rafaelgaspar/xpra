# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.
# pylint: disable-msg=E1101

from time import time
from datetime import timedelta

from xpra.client.base.stub import StubClientSubsystem
from xpra.os_util import WIN32, OSX
from xpra.util.env import envint
from xpra.log import Logger

log = Logger("event")

FAKE_SUSPEND_RESUME: int = envint("XPRA_FAKE_SUSPEND_RESUME", 0)


class PowerEventClient(StubClientSubsystem):
    """
    Adds power events callbacks
    """
    __slots__ = ("_platform_watcher", "paused", "platform_paused", "suspended", "ui_watcher")
    PREFIX = "power"
    __signals__: list[str] = ["suspend", "resume", "pause", "unpause"]

    def __init__(self, client=None):
        StubClientSubsystem.__init__(self, client)
        self.ui_watcher = None
        self.suspended = 0.0
        self.paused = False
        # the platform told us the UI thread is about to be starved (ie: macos native menus):
        self.platform_paused = False
        # extra, platform-specific suspend/resume signal sources feeding the
        # same `suspend()`/`resume()` below:
        self._platform_watcher = None

    def run(self) -> None:
        try:
            self.client.connect("first-ui-received", self.start_ui_watcher)
        except (TypeError, AttributeError):
            log("no 'first-ui-received' signal")
        from xpra.platform.events import add_handler
        add_handler("suspend", self.suspend)
        add_handler("resume", self.resume)
        # some platforms can tell us that the UI thread is about to be starved
        # (ie: macos native menus), which is much more reliable and immediate
        # than having the UI thread watcher detect it after the fact:
        add_handler("pause", self.platform_pause)
        add_handler("unpause", self.platform_unpause)
        if FAKE_SUSPEND_RESUME:
            def fake_suspend() -> bool:
                self.suspend()
                self.timeout_add(FAKE_SUSPEND_RESUME * 500, self.resume)
                return True
            self.timeout_add(FAKE_SUSPEND_RESUME * 1000, fake_suspend)
        if WIN32:
            from xpra.platform.win32.power import Win32ScreensaverWatcher
            self._platform_watcher = Win32ScreensaverWatcher(self)
        elif OSX:
            from xpra.platform.darwin.power import DarwinDisplaySleepWatcher
            self._platform_watcher = DarwinDisplaySleepWatcher(self)
        if self._platform_watcher:
            self._platform_watcher.setup()

    def start_ui_watcher(self, _client) -> None:
        if self.ui_watcher:
            return
        from xpra.util.ui_thread_watcher import get_ui_watcher
        ui_watcher = get_ui_watcher()
        assert ui_watcher
        # register before exposing the watcher, so that `cleanup`
        # can only ever find a watcher we have registered with:
        ui_watcher.add_resume_callback(self.ui_unpause)
        ui_watcher.add_fail_callback(self.ui_pause)
        ui_watcher.show_message = self.ui_message
        self.ui_watcher = ui_watcher
        ui_watcher.start()

    def cleanup(self) -> None:
        from xpra.platform.events import remove_handler
        remove_handler("suspend", self.suspend)
        remove_handler("resume", self.resume)
        remove_handler("pause", self.platform_pause)
        remove_handler("unpause", self.platform_unpause)
        if uw := self.ui_watcher:
            self.ui_watcher = None
            # the watcher is a process-wide singleton which outlives this client,
            # so we must remove our own callbacks or they would accumulate
            # (one dead client's worth per re-connection):
            from xpra.util.ui_thread_watcher import log_message
            uw.remove_resume_callback(self.ui_unpause)
            uw.remove_fail_callback(self.ui_pause)
            uw.show_message = log_message
            uw.stop()
        if pw := self._platform_watcher:
            self._platform_watcher = None
            pw.cleanup()

    def ui_thread_tick(self):
        # only ever call this from the OS suspend / resume events:
        # ticking from the watcher's own callbacks would reset
        # the clock it uses to detect that the UI thread is blocked
        if uiw := self.ui_watcher:
            uiw.tick()

    def platform_pause(self, *args):
        self.platform_paused = True
        self.ui_pause(*args)

    def platform_unpause(self, *args):
        self.platform_paused = False
        self.ui_unpause(*args)

    def ui_pause(self, *args):
        # this can be triggered both by the platform events
        # and by the UI thread watcher noticing the same stall later on,
        # so only ever emit the state changes:
        log("ui_pause(%s) paused=%s", args, self.paused)
        if self.paused:
            return
        self.paused = True
        self.emit("pause")

    def ui_unpause(self, *args):
        log("ui_unpause(%s) paused=%s", args, self.paused)
        if not self.paused:
            return
        self.paused = False
        self.emit("unpause")

    def ui_message(self, message: str) -> None:
        # the UI thread watcher is expected to notice the stalls we have already been told about,
        # but when it is the one pausing, its messages are the only trace of the stall:
        if self.suspended or self.platform_paused:
            log(message)
        else:
            log.info(message)

    def suspend(self, *args) -> None:
        log("suspend(%s)", args)
        log.info(f"{self.client} suspending")
        self.suspended = time()
        self.ui_thread_tick()
        self.emit("suspend")
        if self.legacy_server():
            # ("ui" and "window-ids" arguments are optional since v6.3)
            win = self.get_subsystem("window")
            wids = tuple(win._id_to_window.keys()) if win else ()
            self.send("suspend", True, wids)
        else:
            # the boolean argument tells the server we are suspending:
            self.send("suspend", True)

    def resume(self, *args) -> None:
        log("resume(%s)", args)
        if not self.suspended:
            # happens on macos with every workspace change, including the ones caused by
            # a window going fullscreen: the "resume" handlers would re-initialize the opengl
            # windows, which would go fullscreen again, causing another workspace change..
            log("not suspended, ignoring resume")
            return
        self.ui_thread_tick()
        self.emit("resume")
        elapsed = max(0.0, time() - self.suspended)
        self.suspended = 0.0
        if self.legacy_server():
            win = self.get_subsystem("window")
            wids = tuple(win._id_to_window.keys()) if win else ()
            self.send("resume", True, wids)
        else:
            # a `suspend` packet with a `False` argument means "resume":
            self.send("suspend", False)
        if elapsed < 1:
            # not really suspended
            # happens on macos when switching workspace!
            return
        delta = timedelta(seconds=int(elapsed))
        log.info(f"{self.client} resuming, was suspended for %s", str(delta).lstrip("0:"))

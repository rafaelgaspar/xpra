# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any
from collections.abc import Sequence

from xpra.client.base import features
from xpra.client.base.stub import StubClientSubsystem
from xpra.client.gui.keyboard_helper import KeyboardHelper, KEYCODE_DEF
from xpra.keyboard.common import KeyEvent, DELAY_KEYBOARD_DATA
from xpra.keyboard.mask import DEFAULT_MODIFIER_MEANINGS
from xpra.util.objects import typedict
from xpra.util.str_fn import csv
from xpra.common import noop
from xpra.os_util import WIN32
from xpra.log import Logger

log = Logger("keyboard")


def noauto(val: str | Sequence) -> str | Sequence:
    if not val or str(val).lower() == "auto":
        # a keyboard option is either a string or a list of strings;
        # return an empty default of the same shape (str is a Sequence too)
        return "" if isinstance(val, str) else []
    return val


class KeyboardClient(StubClientSubsystem):
    """
    Utility mixin for clients that handle keyboard input
    """
    __slots__ = (
        "_win32_keyboard_hook", "enabled", "grabbed", "helper", "helper_class", "key_repeat_delay",
        "key_repeat_interval", "server_enabled", "sync", "warning",
    )
    PREFIX = "keyboard"

    def __init__(self, client=None):
        StubClientSubsystem.__init__(self, client)
        self.enabled = True
        self.helper_class: type = KeyboardHelper
        self.helper = None
        self.grabbed: bool = False
        self.sync: bool = False
        self.key_repeat_delay = -1
        self.key_repeat_interval = -1
        self.server_enabled: bool = True
        self.warning: bool = False
        # win32 global low-level keyboard hook:
        self._win32_keyboard_hook = None

    def init_ui(self, opts) -> None:
        send_keyboard = noop
        if not self.client.readonly:
            def do_send_keyboard(*parts):
                log("do_send_keyboard%s", parts)
                self.client.after_handshake(self.send, *parts)

            send_keyboard = do_send_keyboard
        try:
            kwargs = dict(
                (x, noauto(getattr(opts, "keyboard_%s" % x))) for x in (
                    "backend", "model", "layout", "layouts", "variant", "variants", "options",
                )
            )
            self.sync = opts.keyboard_sync
            self.helper = self.helper_class(send_keyboard, self.sync,
                                            opts.shortcut_modifiers,
                                            opts.key_shortcut,
                                            opts.keyboard_raw, **kwargs)
            self.helper.legacy_server = self.legacy_server
            if DELAY_KEYBOARD_DATA and not self.client.readonly:
                self.client.after_handshake(self.helper.send_config)
        except ImportError as e:
            log("error instantiating %s", self.helper_class, exc_info=True)
            log.warn(f"Warning: no keyboard support, {e}")
        # only meaningful on macOS, but harmless to set unconditionally:
        if self.helper and self.helper.keyboard:
            log("%s.swap_keys=%s", self.helper.keyboard, opts.swap_keys)
            self.helper.keyboard.swap_keys = opts.swap_keys
            # the default shortcut modifiers depend on swap-keys:
            self.helper.parse_shortcuts()

    def run(self) -> None:
        if WIN32:
            from xpra.platform.win32.gui import FORWARD_WINDOWS_KEY
            if FORWARD_WINDOWS_KEY and features.window:
                from xpra.platform.win32.keyboard_hook import Win32KeyboardHookWatcher
                self._win32_keyboard_hook = Win32KeyboardHookWatcher(self)
                self._win32_keyboard_hook.setup()

    def cleanup(self) -> None:
        if kh := self.helper:
            self.helper = None
            kh.cleanup()
        if wkh := self._win32_keyboard_hook:
            self._win32_keyboard_hook = None
            wkh.cleanup()

    def get_info(self) -> dict[str, dict[str, Any]]:
        return {KeyboardClient.PREFIX: self.get_keyboard_caps()}

    def get_caps(self) -> dict[str, Any]:
        # return {KeyboardClient.PREFIX: caps}
        return self.get_keyboard_caps()

    def parse_server_capabilities(self, c: typedict) -> bool:
        self.server_enabled = c.boolget("keyboard", True)
        if not self.server_enabled and self.helper:
            # swallow packets:
            self.helper.send = noop
        try:
            from xpra import keyboard
            if not keyboard:
                # cythonized code can bind None for missing imports
                raise ImportError("xpra.keyboard")
        except ImportError:
            log.warn("Warning: keyboard module is missing")
            self.enabled = False
            return True
        if self.helper:
            modifier_keycodes = c.dictget("modifier_keycodes")
            if modifier_keycodes:
                self.helper.set_modifier_mappings(modifier_keycodes)
        self.key_repeat_delay, self.key_repeat_interval = c.intpair("key_repeat", (-1, -1))
        return True

    def get_keyboard_caps(self) -> dict[str, Any]:
        caps = {}
        kh = self.helper
        if self.client.readonly or not kh:
            # don't bother sending keyboard info, as it won't be used
            caps["keyboard"] = False
        else:
            caps["keyboard"] = True
            caps["ibus"] = True
            caps["modifiers"] = self.get_current_modifiers()
            delay_ms, interval_ms = kh.key_repeat_delay, kh.key_repeat_interval
            if delay_ms <= 0 or interval_ms <= 0:
                # cannot do keyboard sync without a key repeat value
                self.sync = False
            kh.sync = self.sync
            skip = ("keycodes", "x11_keycodes") if DELAY_KEYBOARD_DATA else ()
            keymap = kh.get_keymap_properties(skip)
            if DELAY_KEYBOARD_DATA:
                # tell the server not to configure the keymap using this incomplete data,
                # but to wait for the keyboard config packet we will send after the handshake:
                keymap["delay"] = True
            caps["keymap"] = keymap
            # show the user a summary of what we have detected:
            self.helper.log_keyboard_info()
            if delay_ms > 0 and interval_ms > 0:
                caps["key_repeat"] = (delay_ms, interval_ms)
            caps["keyboard_sync"] = self.sync
        log("keyboard capabilities: %s", caps)
        return caps

    def next_keyboard_layout(self, update_platform_layout) -> None:
        if self.helper:
            self.helper.next_layout(update_platform_layout)

    def window_keyboard_layout_changed(self, window=None) -> None:
        # win32 can change the keyboard mapping per window...
        log("window_keyboard_layout_changed(%s)", window)
        if self.helper:
            self.helper.keymap_changed()

    def handle_key_action(self, window, key_event: KeyEvent) -> bool:
        kh = self.helper
        if not kh:
            return False
        # the window registry is owned by the `window` subsystem:
        window_sub = self.get_subsystem("window")
        wid = window_sub._window_to_id[window]
        log(f"handle_key_action({window}, {key_event}) wid={wid:#x}")
        if kh.key_handled_as_shortcut(window, key_event.keyname, key_event.modifiers, key_event.pressed):
            return False
        if self.client.readonly or self.client.server_readonly:
            return False
        kh.process_key_event(wid, key_event)
        return False

    def find_keycode_entry(self, keyname: str) -> KEYCODE_DEF | None:
        # find the keymap entry matching this key name,
        # preferring the entries which don't require any modifier (level 0):
        best = None
        for entry in self.helper.keycodes if self.helper else ():
            if entry[1] != keyname:
                continue
            if entry[4] == 0:
                return entry
            if best is None:
                best = entry
        return best

    def send_key_sequence(self, keynames: Sequence[str]) -> None:
        """
        Synthesize the key press events for all the key names given (in order),
        followed by the matching key release events (in reverse order).
        """
        kh = self.helper
        if not kh:
            log.warn("Warning: cannot send key sequence %s", csv(keynames))
            log.warn(" keyboard support is not available")
            return
        if self.client.readonly or self.client.server_readonly:
            log.info("key sequence %s not sent: connection is read-only", csv(keynames))
            return
        # send the events to the window which currently has the focus, if any:
        window_sub = self.get_subsystem("window")
        wid = getattr(window_sub, "_focused", 0) or 0
        mod_meanings = kh.mod_meanings or DEFAULT_MODIFIER_MEANINGS
        # the modifiers held down as we walk through the sequence:
        modifiers: list[str] = []

        def send(keyname: str, pressed: bool) -> None:
            key_event = KeyEvent()
            key_event.keyname = keyname
            key_event.pressed = pressed
            key_event.modifiers = list(modifiers)
            if entry := self.find_keycode_entry(keyname):
                key_event.keyval, _, key_event.keycode, key_event.group = entry[:4]
            log("send_key_sequence: %s", key_event)
            kh.send_key_action(wid, key_event)

        log("send_key_sequence(%s) wid=%i", keynames, wid)
        for keyname in keynames:
            send(keyname, True)
            mod = mod_meanings.get(keyname, "")
            if mod and mod not in modifiers:
                modifiers.append(mod)
        for keyname in reversed(tuple(keynames)):
            # the modifier is still held down when its key is released:
            send(keyname, False)
            mod = mod_meanings.get(keyname, "")
            if mod in modifiers:
                modifiers.remove(mod)

    def mask_to_names(self, mask) -> list[str]:
        if self.helper is None:
            return []
        return self.helper.mask_to_names(int(mask))

    def get_current_modifiers(self) -> Sequence[str]:
        # delegate to the client for now, since querying the current modifiers
        # requires toolkit-specific access to the pointer / root window:
        return self.client.get_current_modifiers()

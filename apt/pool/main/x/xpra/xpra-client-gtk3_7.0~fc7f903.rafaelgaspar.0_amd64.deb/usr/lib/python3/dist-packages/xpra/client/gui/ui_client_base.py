# This file is part of Xpra.
# Copyright (C) 2011 Serviware (Arthur Huillet, <ahuillet@serviware.com>)
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import sys
from typing import Any
from collections.abc import Callable, Sequence

from xpra.client.gui.factory import get_client_subsystems
from xpra.client.base.client import XpraClientBase
from xpra.platform import set_name
from xpra.platform.gui import ready as gui_ready, get_wm_name, get_session_type
from xpra.common import noerr, may_notify_client
from xpra.net.constants import ConnectionMessage
from xpra.constants import NotificationID
from xpra.net.common import (
    Packet, PacketElement, print_proxy_caps, FULL_INFO, BACKWARDS_COMPATIBLE,
    DEFAULT_PROTOCOL_VERSION, MODERN_PROTOCOL_VERSION,
)
from xpra.net.packet_type import (
    CURSOR_SET, KEYBOARD_SYNC, NOTIFICATION_STATUS, SHARING_TOGGLE, SHARING_LOCK,
    DISPLAY_MONITOR_CONFIGURE, DISPLAY_UNGRAB,
)
from xpra.util.child_reaper import reaper_cleanup
from xpra.util.objects import typedict
from xpra.util.version import parse_version
from xpra.util.parsing import parse_sharing
from xpra.util.system import get_run_info
from xpra.util.str_fn import Ellipsizer, repr_ellipsized, single_line, truncate
from xpra.util.env import envint, envbool
from xpra.exit_codes import ExitCode, ExitValue
from xpra.client.base import features
from xpra.log import Logger

# Composed subsystems live as separate instances in `client.subsystems` (reached via
# `get_subsystem(...)`), so they are kept OUT of the client's MRO - `UIXpraClient` just
# inherits from `XpraClientBase` directly.

log = Logger("client")
sharinglog = Logger("sharing")

NOTIFICATION_EXIT_DELAY = envint("XPRA_NOTIFICATION_EXIT_DELAY", 2)
FORCE_ALERT = envbool("XPRA_FORCE_ALERT", False)
MAX_SESSION_NAME = 128


def session_name_str(name) -> str:
    # the server's session name is shown in the tray, menus and dialogs:
    return truncate(single_line(str(name)), MAX_SESSION_NAME)


# servers that don't accept the `setting-change` packet from clients
# expect a dedicated packet type for each setting:
LEGACY_SETTING_PACKETS: dict[str, str] = {
    "readonly": "readonly-toggled",
    "xsettings": "server-settings",
}


class UIXpraClient(XpraClientBase):
    """
    Utility superclass for client classes which have a UI.
    See gtk_client_base and its subclasses.
    """
    # NOTE: these signals aren't registered here because this class
    # does not extend GObject,
    # the gtk client subclasses will take care of it.
    # these are all "no-arg" signals.
    # composed subsystems own and declare their own signals now (see their
    # `__signals__`) and are not aggregated here - `SignalEmitter` warns if a
    # signal used with `emit`/`connect` isn't in the emitter's own list.
    __signals__ = ["first-ui-received"] + XpraClientBase.__signals__

    @staticmethod
    def get_subsystem_classes() -> dict[str, type]:
        classes = dict(XpraClientBase.get_subsystem_classes())
        classes.update({cls.PREFIX: cls for cls in get_client_subsystems()})
        return classes

    def __init__(self):
        # composes every subsystem (base and UI) in one pass via the polymorphic
        # `get_subsystem_classes()` - see `XpraClientBase.__init__`:
        XpraClientBase.__init__(self)
        # try to ensure we start on a new line (see #4023):
        noerr(sys.stdout.write, "\n")
        run_info = get_run_info(f"{self.client_toolkit()} client")
        wm = get_wm_name()  # pylint: disable=assignment-from-none
        if wm:
            run_info.append(f" window manager is {wm!r}")
        for info in run_info:
            log.info(info)
        # the menu helper is a client-owned UI service (used by the `tray`
        # subsystem and by window shortcut menus); toolkit clients override
        # `get_menu_helper`/`get_menu_helper_class` to add their variants:
        self.menu_helper = None
        # react to the `ping` subsystem's "timeout" signal by drawing an alert
        # state over the windows (a UI concern, so it lives here, not in `ping`):
        if ping := self.get_subsystem("ping"):
            ping.connect("timeout", self.server_connection_state_change)
        self._ui_events: int = 0
        self.title: str = ""
        self.session_name: str = ""
        self.server_session_name: str = ""
        self.server_border: str = ""

        # features:
        self.readonly: bool = False
        self.headerbar = None
        # `suspended` is owned by the `power` subsystem,
        # `server_pointer` by the `pointer` subsystem,
        # `server_is_desktop` by the `display` subsystem
        self.server_sharing: bool = False
        self.server_sharing_toggle: bool = False
        self.server_lock: bool = False
        self.server_lock_toggle: bool = False
        self.server_readonly = False
        self.server_setting_updates: dict[str, Any] = {}

        self.client_supports_sharing: bool = False
        self.client_lock: bool = False

        # state:
        self._on_server_setting_changed: dict[str, Sequence[Callable[[str, Any], None]]] = {}
        self.redraw_timer = 0

    def init(self, opts) -> None:
        """ initialize variables from configuration """
        XpraClientBase.init(self, opts)

        self.title = opts.title
        self.session_name = opts.session_name
        self.readonly = opts.readonly
        self.client_supports_sharing = parse_sharing(opts.sharing) is True
        sharinglog("sharing=%r: client_supports_sharing=%s", opts.sharing, self.client_supports_sharing)
        self.client_lock = opts.lock is True
        self.headerbar = opts.headerbar

    def client_toolkit(self) -> str:
        raise NotImplementedError()

    def run(self) -> ExitValue:
        if FORCE_ALERT:
            self.schedule_timer_redraw()
        XpraClientBase.run(self)
        return self.exit_code or 0

    def quit(self, exit_code: ExitValue = 0) -> None:
        raise NotImplementedError()

    def cleanup(self) -> None:
        log("UIXpraClient.cleanup()")
        self.cancel_redraw_timer()
        # subsystems cleaned up and the protocol closed by `XpraClientBase.cleanup`:
        # (cleaner and needed when we run embedded in the client launcher)
        XpraClientBase.cleanup(self)
        log("UIXpraClient.cleanup() done")

    def signal_cleanup(self) -> None:
        log("UIXpraClient.signal_cleanup()")
        XpraClientBase.signal_cleanup(self)
        reaper_cleanup()
        log("UIXpraClient.signal_cleanup() done")

    def get_info(self) -> dict[str, Any]:
        info = XpraClientBase.get_info(self)
        if FULL_INFO > 0:
            info["session-name"] = self.session_name
        return info

    def is_readonly(self) -> bool:
        """The user's read-only choice, or the read-only policy enforced by the server."""
        return bool(self.readonly or self.server_readonly)

    ######################################################################
    # dialogs: every one of these is served by the optional `dialogs`
    # subsystem, which is toolkit specific (see `xpra.client.gtk3.dialogs`).
    # They live here rather than on a toolkit client so that any backend
    # composing a `dialogs` subsystem gets them - the win32 backend reuses
    # the Gtk one when started with `--tray=gtk`.
    def _call_dialogs(self, method: str, *args, **kwargs):
        dialogs = self.get_subsystem("dialogs")
        if not dialogs:
            log.warn(f"Warning: {method}() is not implemented in {self!r}")
            return None
        return getattr(dialogs, method)(*args, **kwargs)

    def show_about(self, *args) -> None:
        self._call_dialogs("show_about", *args)

    def show_docs(self, *args) -> None:
        self._call_dialogs("show_docs", *args)

    def show_shortcuts(self, *args) -> None:
        self._call_dialogs("show_shortcuts", *args)

    def show_session_info(self, *args) -> None:
        self._call_dialogs("show_session_info", *args)

    def show_bug_report(self, *args) -> None:
        self._call_dialogs("show_bug_report", *args)

    def show_debug_config(self, *args) -> None:
        self._call_dialogs("show_debug_config", *args)

    def show_server_commands(self, *args) -> None:
        self._call_dialogs("show_server_commands", *args)

    def show_start_new_command(self, *args) -> None:
        self._call_dialogs("show_start_new_command", *args)

    def show_file_upload(self, *args) -> None:
        self._call_dialogs("show_file_upload", *args)

    def show_ask_data_dialog(self, *args) -> None:
        self._call_dialogs("show_ask_data_dialog", *args)

    def ask_data_request(self, *args, **kwargs) -> None:
        self._call_dialogs("ask_data_request", *args, **kwargs)

    def transfer_progress_update(self, *args, **kwargs) -> None:
        self._call_dialogs("transfer_progress_update", *args, **kwargs)

    def file_size_warning(self, *args) -> None:
        self._call_dialogs("file_size_warning", *args)

    def download_server_log(self, *args, **kwargs) -> None:
        self._call_dialogs("download_server_log", *args, **kwargs)

    def send_download_request(self, *args) -> None:
        self._call_dialogs("send_download_request", *args)

    def configure_server_debug(self, *args) -> None:
        self._call_dialogs("configure_server_debug", *args)

    ######################################################################
    # monitors
    def send_remove_monitor(self, index) -> None:
        assert self.get_subsystem("display").server_monitors
        self.send(DISPLAY_MONITOR_CONFIGURE, "remove", "index", index)

    def send_add_monitor(self, resolution="1024x768") -> None:
        assert self.get_subsystem("display").server_monitors
        self.send(DISPLAY_MONITOR_CONFIGURE, "add", resolution)

    def _ui_event(self) -> None:
        if self._ui_events == 0:
            self.emit("first-ui-received")
        self._ui_events += 1

    def get_notifier_classes(self) -> Sequence[Callable]:
        # the canonical notifier list lives on the client: concrete clients
        # (e.g. gtk3) override this to add their toolkit-specific notifiers on
        # top of the notification subsystem's native ones. This base default
        # exposes just the native classes (for clients with no toolkit variants).
        notification = self.get_subsystem("notification")
        return list(notification.get_native_notifier_classes()) if notification else []

    def get_gl_client_window_module(self, _enable_opengl: str) -> tuple[dict, Any]:
        # the (toolkit-specific) OpenGL window backend, asked for by the `display`
        # subsystem's `init_opengl`. No backend by default; toolkits that support
        # OpenGL rendering (e.g. gtk3) override this.
        return {}, None

    def get_menu_helper(self):
        """
        menu helper used by our tray (make_tray / setup_xpra_tray)
        and for showing the menu on windows via a shortcut;
        concrete clients (e.g. gtk3) override this to add toolkit variants.
        """
        if not self.menu_helper:
            from xpra.util.objects import make_instance
            mhc = (self.get_menu_helper_class(), )
            log("get_menu_helper() menu helper classes: %s", mhc)
            self.menu_helper = make_instance(mhc, self)
        return self.menu_helper

    @staticmethod
    def get_menu_helper_class():
        from xpra.platform.systray import get_menu_helper_class
        return get_menu_helper_class()

    def get_popup_menu_helper(self):
        """
        the xpra menu, as a menu we can pop up (ie: from a window's header bar):
        the same one as the tray's, unless the platform shows that one itself
        """
        mh = self.get_menu_helper()
        return mh if mh and mh.can_popup else None

    def show_menu(self, *_args) -> None:
        # (the menu may not exist yet: only the tray creates it up front)
        if mh := self.get_popup_menu_helper():
            mh.build()
            mh.activate()

    def get_tray_classes(self) -> list[type]:
        # the canonical tray class list lives on the client: concrete clients
        # (e.g. gtk3) override this to add their toolkit-specific trays on top
        # of the tray subsystem's native ones.
        tray = self.get_subsystem("tray")
        return list(tray.get_native_tray_classes()) if tray else []

    def server_ok(self) -> bool:
        # get the real value from the PingClient feature, if present:
        ping = self.get_subsystem("ping")
        return ping._server_ok if ping else True

    def get_windows(self) -> tuple:
        """ all the windows currently registered with the `window` subsystem """
        window = self.get_subsystem("window")
        return tuple(window._id_to_window.values()) if window else ()

    def get_mouse_position(self) -> tuple:
        raise NotImplementedError()

    def get_current_modifiers(self) -> Sequence[str]:
        raise NotImplementedError()

    ######################################################################
    # trigger notifications on disconnection,
    # and wait before actually exiting so the notification has a chance of being seen
    # Defer cleanup to the disconnect timer so the notifier and tray stay alive.
    def _schedule_disconnect(self, disconnect: Callable, reason: str, *info) -> None:
        def cleanup_and_disconnect() -> None:
            try:
                self.cleanup()
            finally:
                disconnect(self, reason, *info)

        delay = NOTIFICATION_EXIT_DELAY * int(features.notification)
        self.timeout_add(delay * 1000, cleanup_and_disconnect)

    def server_disconnect_warning(self, reason, *info):
        if self.exit_code is None:
            body = "\n".join(info)
            if not self.connection_established:
                if ConnectionMessage.AUTHENTICATION_FAILED.value in info:
                    title = "Authentication failed"
                    self.exit_code = ExitCode.AUTHENTICATION_FAILED
                else:
                    title = "Connection failed: %s" % reason
                    self.exit_code = ExitCode.CONNECTION_FAILED
            else:
                if self.completed_startup:
                    title = "Xpra Session Disconnected: %s" % reason
                    self.exit_code = ExitCode.CONNECTION_LOST
                else:
                    title = "Connection failed during startup: %s" % reason
                    self.exit_code = ExitCode.CONNECTION_FAILED
            may_notify_client(self, NotificationID.DISCONNECT, title, body, icon_name="disconnected")
            # show text notification then quit:
            self._schedule_disconnect(XpraClientBase.server_disconnect_warning, title, *info)

    def server_disconnect(self, reason: str, *info) -> None:
        body = "\n".join(info)
        may_notify_client(self, NotificationID.DISCONNECT,
                          f"Xpra Session Disconnected: {reason}", body, icon_name="disconnected")
        if self.exit_code is None:
            self.exit_code = self.server_disconnect_exit_code(reason, *info)
        self._schedule_disconnect(XpraClientBase.server_disconnect, reason, *info)

    ######################################################################
    # hello:
    def make_hello(self) -> dict[str, Any]:
        # `XpraClientBase.make_hello` already gathers `get_caps` from every
        # composed subsystem generically (base and UI alike - see
        # `get_subsystem_classes`), so only the UI-only extras are added here:
        caps = XpraClientBase.make_hello(self)
        if BACKWARDS_COMPATIBLE:
            caps.setdefault("wants", []).append("events")
        caps |= {
            "setting-change": True,
            "server-features": True,
            "versions": True,
            # generic server flags:
            "readonly": self.readonly,
            "share": self.client_supports_sharing,
            "lock": self.client_lock,
        }
        if FULL_INFO > 0:
            caps["session-type"] = get_session_type()
        return caps

    ######################################################################
    # connection setup:
    def parse_server_capabilities(self, c: typedict) -> bool:
        # A server older than v7 running in backwards compatible mode accepts peers older than
        # our `MIN_PROTOCOL_VERSION`, and sends every client the legacy packet
        # names and capabilities layout they need (for example, a `display`
        # name string rather than the `display` capabilities namespace).
        # (v7 servers switch to the modern ones for clients like us)
        min_version = c.inttupleget("protocol-version") or DEFAULT_PROTOCOL_VERSION
        if not BACKWARDS_COMPATIBLE and self._protocol.TYPE != "rfb" and (
                min_version < MODERN_PROTOCOL_VERSION and parse_version(c.strget("version"))[:1] < (7, )):
            self.warn_and_quit(ExitCode.INCOMPATIBLE_VERSION,
                               "the server is running in backwards compatible mode,"
                               " which is not supported by clients using `XPRA_BACKWARDS_COMPATIBLE=0`")
            return False
        if not XpraClientBase.parse_server_capabilities(self, c):
            return False
        self.server_session_name = session_name_str(c.strget("session_name"))
        set_name("Xpra", self.session_name or self.server_session_name or "Xpra")
        self.server_sharing = c.boolget("sharing")
        self.server_sharing_toggle = c.boolget("sharing-toggle")
        self.server_lock = c.boolget("lock")
        self.server_lock_toggle = c.boolget("lock-toggle")
        sharinglog("server sharing=%s (toggle=%s), lock=%s (toggle=%s)",
                   self.server_sharing, self.server_sharing_toggle, self.server_lock, self.server_lock_toggle)
        # `readonly` remains the user's own choice, so the server can turn its own off again:
        self.server_readonly = c.boolget("readonly")
        if self.server_readonly and not self.readonly:
            log.info("server is read only")
        print_proxy_caps(c)
        return True

    def connection_accepted(self, caps: typedict) -> None:
        """ overriden here so we can call `handshake_complete` from the main thread """
        log("connection accepted caps=%s", Ellipsizer(caps))
        self.connection_established = True
        self.idle_add(self.handshake_complete)

    def _process_startup_complete(self, packet: Packet) -> None:
        log("all the existing windows and system trays have been received")
        super()._process_startup_complete(packet)
        gui_ready()

    def send_hello(self, challenge_response=b"", client_salt=b"") -> None:
        self.idle_add(super().send_hello, challenge_response, client_salt)

    ######################################################################
    # server messages:
    # noinspection PyMethodMayBeStatic

    def on_server_setting_changed(self, setting: str, cb: Callable[[str, Any], None]) -> None:
        self._on_server_setting_changed.setdefault(setting, []).append(cb)
        # has the value already been updated:
        value = self.server_setting_updates.get(setting)
        log("on_server_setting_changed%s value=%s", (setting, cb), value)
        if value is not None:
            cb(setting, value)

    def _process_setting_change(self, packet: Packet) -> None:
        setting = packet.get_str(1)
        value = packet[2]
        # convert "hello" / "setting" variable names to client variables:
        if BACKWARDS_COMPATIBLE:
            setting = {"xdg-menu": "menu"}.get(setting, setting)
        if setting in (
            "clipboard-limits",
        ):
            # FIXME: this should update the limits?
            pass
        elif setting in (
                "bell", "randr", "cursors", "notifications", "clipboard",
                "clipboard-direction", "session_name",
                "sharing", "sharing-toggle", "lock", "lock-toggle",
                "readonly",
                "start-new-commands", "client-shutdown", "webcam",
                "bandwidth-limit", "clipboard-limits",
                "menu", "monitors",
                "ibus-layouts", "border",
        ):
            setattr(self, "server_%s" % setting.replace("-", "_"), value)
        else:
            log.info("unknown server setting changed: %s=%s", setting, repr_ellipsized(value))
            return
        log("_process_setting_change: %s=%s", setting, Ellipsizer(value))
        # these are too big to log
        if setting not in ("menu", "monitors", "ibus-layouts"):
            log.info("server setting changed: %s=%s", setting, repr_ellipsized(value))
        self.server_setting_changed(setting, value)

    def server_setting_changed(self, setting: str, value) -> None:
        self.server_setting_updates[setting] = value
        cbs: Sequence[Callable[[str, Any], None]] = self._on_server_setting_changed.get(setting, ())
        log("setting_changed(%s, %s) callbacks=%s", setting, Ellipsizer(value, limit=200), cbs)
        for cb in cbs:
            log("setting_changed(%s, %s) calling %s", setting, Ellipsizer(value, limit=200), cb)
            cb(setting, value)

    def add_control_commands(self) -> None:
        # called by the `control` subsystem (it owns the base commands; this
        # adds the UI-specific ones on top, via the `add_control_command` delegate
        # since this class and the `control` subsystem are no longer related by
        # inheritance - see `Control.parse_server_capabilities`):
        try:
            from xpra.net.control.common import ControlCommand, ArgsControlCommand
        except ImportError as e:
            log(f"control commands are not available: {e}")
            return
        self.add_control_command(
            "show_session_info", ControlCommand("show-session-info", "Shows the session info dialog", self.show_session_info))
        self.add_control_command(
            "show_bug_report", ControlCommand("show-bug-report", "Shows the bug report dialog", self.show_bug_report))
        self.add_control_command(
            "name", ArgsControlCommand("name", "Sets the server session name", self.set_server_session_name,
                                       min_args=1, max_args=1))

    def set_server_session_name(self, name: str):
        self.server_session_name = session_name_str(name)
        log.info("session name updated from server: %s", self.server_session_name)

    ######################################################################
    # features:
    def send_setting_change(self, setting: str, value: PacketElement) -> None:
        """ ask the server to change a setting (mirror of `ClientConnection.send_setting_change`) """
        if not self.legacy_server() or "setting-change" in self.get_server_packet_types():
            self.send("setting-change", setting, value)
            return
        legacy = LEGACY_SETTING_PACKETS.get(setting, "")
        if not legacy:
            log.warn("Warning: this server does not support changing %r", setting)
            return
        self.send(legacy, value)

    def send_sharing_enabled(self) -> None:
        assert self.server_sharing and self.server_sharing_toggle
        sharinglog("send_sharing_enabled() sharing=%s", self.client_supports_sharing)
        self.send(SHARING_TOGGLE, self.client_supports_sharing)

    def send_lock_enabled(self) -> None:
        assert self.server_lock_toggle
        sharinglog("send_lock_enabled() lock=%s", self.client_lock)
        self.send(SHARING_LOCK, self.client_lock)

    def send_notify_enabled(self) -> None:
        notification = self.get_subsystem("notification")
        assert notification.client_supports, "cannot toggle notifications: the feature is disabled by the client"
        self.send(NOTIFICATION_STATUS, notification.enabled)

    def send_cursors_enabled(self) -> None:
        cursor = self.get_subsystem("cursor")
        assert cursor and cursor.client_supports, "cannot toggle cursors: the feature is disabled by the client"
        assert cursor.server_enabled, "cannot toggle cursors: the feature is disabled by the server"
        self.send(CURSOR_SET, cursor.enabled)

    def send_force_ungrab(self, wid: int) -> None:
        self.send(DISPLAY_UNGRAB, wid)

    def send_keyboard_sync_enabled_status(self, *_args) -> None:
        if kb := self.get_subsystem("keyboard"):
            self.send(KEYBOARD_SYNC, kb.sync)

    ######################################################################
    # windows overrides
    def cook_metadata(self, _new_window, metadata: dict) -> typedict:
        # convert to a typedict and apply client-side overrides:
        tdmeta = typedict(metadata)
        display = self.get_subsystem("display")
        if display and display.server_is_desktop and display.desktop_fullscreen:
            # force it fullscreen:
            metadata.pop("size-constraints", None)
            metadata["fullscreen"] = True
            # FIXME: try to figure out the monitors we go fullscreen on for X11:
            # if POSIX:
            #    metadata["fullscreen-monitors"] = [0, 1, 0, 1]
        return tdmeta

    ######################################################################
    # network and status:
    def server_connection_state_change(self, *_args) -> None:
        # handler for the `ping` subsystem's "timeout" signal (see `__init__`):
        windows = self.get_windows()
        if not windows:
            return
        if self.server_ok() or FORCE_ALERT:
            log.info("server is OK again")
            return
        log.info("server is not responding, drawing alert state over the windows")
        self.schedule_timer_redraw()

    def schedule_timer_redraw(self) -> None:
        log("schedule_timer_redraw()")
        if self.redraw_timer:
            return

        def timer_redraw() -> bool:
            ok = self.server_ok() and not FORCE_ALERT
            log("timer_redraw() ok=%s", ok)
            # ensure every window has the latest state:
            for window in self.get_windows():
                if not window.is_tray():
                    window.set_alert_state(not ok)
            self.redraw_windows()
            if ok:
                self.redraw_timer = 0
            return not ok  # repaint again until ok

        self.idle_add(self.redraw_windows)
        self.redraw_timer = self.timeout_add(100, timer_redraw)

    def cancel_redraw_timer(self) -> None:
        rt = self.redraw_timer
        if rt:
            self.redraw_timer = 0
            self.source_remove(rt)

    def redraw_windows(self) -> None:
        # redraws all the windows without requesting a refresh from the server:
        for window in self.get_windows():
            window.redraw()

    ######################################################################
    # packets:
    def init_authenticated_packet_handlers(self) -> None:
        log("init_authenticated_packet_handlers()")
        XpraClientBase.init_authenticated_packet_handlers(self)
        # run from the UI thread:
        self.add_packets("startup-complete", "setting-change", main_thread=True)

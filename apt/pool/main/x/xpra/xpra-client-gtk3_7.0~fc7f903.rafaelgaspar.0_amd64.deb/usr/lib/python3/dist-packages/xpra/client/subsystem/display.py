# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from time import monotonic
from typing import Any
from collections.abc import Sequence

from xpra.net.packet_type import DISPLAY_CONFIGURE, DISPLAY_RESIZED
from xpra.exit_codes import ExitCode
from xpra.platform.gui import (
    get_vrefresh,
    get_antialias_info, get_icc_info, get_display_icc_info, show_desktop,
    get_xdpi, get_ydpi, get_number_of_desktops, get_desktop_names, get_wm_name,
)
from xpra.scripts.main import check_display
from xpra.net.common import Packet, FULL_INFO, BACKWARDS_COMPATIBLE
from xpra.net.constants import MAX_PACKET_SIZE
from xpra.common import (
    noop, skipkeys, may_notify_client,
)
from xpra.constants import NotificationID
from xpra.os_util import WIN32, OSX, POSIX
from xpra.util.parsing import (
    parse_scaling, scaleup_value, scaledown_value, fequ, r4cmp, str_to_bool,
    MIN_SCALING, MAX_SCALING, SCALING_EMBARGO_TIME, FALSE_OPTIONS, get_refresh_rate_for_value,
    adjust_monitor_refresh_rate, MIN_VREFRESH, MAX_VREFRESH,
)
from xpra.util.colourspace import Colourspace, SRGB
from xpra.util.objects import typedict
from xpra.util.screen import log_screen_sizes, MonitorLayout
from xpra.util.env import envbool, envint
from xpra.util.system import is_Wayland
from xpra.client.base.stub import StubClientSubsystem
from xpra.log import Logger

log = Logger("screen")
workspacelog = Logger("client", "workspace")
scalinglog = Logger("scaling")

MONITOR_CHANGE_REINIT = envbool("XPRA_MONITOR_CHANGE_REINIT", WIN32 or OSX)
# legacy: send our ICC profile to the server so that it applies it to the vfb.
# the server now declares the colourspace it renders into instead, see `server_colourspace`.
SYNC_ICC: bool = envbool("XPRA_SYNC_ICC", False)


class DisplayClient(StubClientSubsystem):
    """
    Utility mixin for clients that handle a desktop / display
    Adds client-side scaling handling
    """
    __slots__ = (
        "_cg_display", "_current_screen_sizes", "_last_screen_settings", "_monitor_layout", "_x11_props", "can_scale",
        "desktop_fullscreen", "desktop_scaling", "dpi", "initial_scaling", "log_screen_info", "refresh_rate",
        "scale_change_embargo", "screen_size_change_counter", "screen_size_change_suspended",
        "screen_size_change_timer", "server_actual_desktop_size", "server_add_monitor_label",
        "server_colourspace", "server_desktop_size", "server_display", "server_is_desktop", "server_is_monitor",
        "server_max_desktop_size", "server_monitors", "server_multi_monitors",
        "server_new_monitor_resolutions", "server_opengl", "server_randr", "xscale", "yscale",
    )
    __signals__ = ["scaling-changed"]
    PREFIX = "display"

    def __init__(self, client=None):
        StubClientSubsystem.__init__(self, client)
        check_display()
        self.dpi = 0
        self.can_scale = False
        self.initial_scaling = 1, 1
        self.xscale, self.yscale = self.initial_scaling
        self.scale_change_embargo = float("inf")
        self.refresh_rate = ""
        self.desktop_fullscreen = False
        self.desktop_scaling = "no"
        self.screen_size_change_timer = 0
        self.screen_size_change_counter = 0
        self.screen_size_change_suspended = False
        self._last_screen_settings = ()
        self._current_screen_sizes = []
        self._monitor_layout = MonitorLayout()

        self.server_desktop_size = (0, 0)
        self.server_actual_desktop_size = (0, 0)
        self.server_max_desktop_size = (0, 0)
        self.server_display = None
        self.server_randr = False
        self.server_opengl = None
        self.server_multi_monitors = False
        self.server_monitors = {}
        self.server_new_monitor_resolutions = ()
        self.server_add_monitor_label = ""
        self.server_is_desktop = False
        self.server_is_monitor = False
        # the colourspace the server renders into,
        # which we are expected to convert to whatever our display uses:
        self.server_colourspace: Colourspace = SRGB
        self.log_screen_info = True
        # X11 XSettings / root-window property watching (DPI, workarea, desktop names,
        # window stacking) feeds the display and window subsystems:
        self._x11_props = None
        # darwin GPU/display reconfiguration watching:
        self._cg_display = None

    def init(self, opts) -> None:
        self.desktop_fullscreen = opts.desktop_fullscreen
        self.desktop_scaling = opts.desktop_scaling
        self.refresh_rate = opts.refresh_rate
        self.dpi = int(opts.dpi)
        self.can_scale = opts.desktop_scaling not in FALSE_OPTIONS
        scalinglog("can_scale(%s)=%s", opts.desktop_scaling, self.can_scale)
        if self.can_scale:
            self.parse_scaling(opts.desktop_scaling)
        self.init_display_watcher(opts)

    def init_display_watcher(self, opts) -> None:
        # subclasses without a window system to watch (ie: the terminal client) override this as a no-op
        if POSIX and not OSX and not is_Wayland():
            from xpra.platform.posix.display import X11DisplayPropsWatcher
            self._x11_props = X11DisplayPropsWatcher(self, str_to_bool(opts.xsettings))
            self._x11_props.setup()
        elif OSX:
            from xpra.platform.darwin.display import DarwinDisplayReconfigWatcher
            self._cg_display = DarwinDisplayReconfigWatcher(self)
            self._cg_display.setup()

    def load(self):
        self.client.after_handshake(self.adjust_display)
        if power := self.get_subsystem("power"):
            power.connect("suspend", self.suspend_screen_size_change)
            power.connect("resume", self.resume_screen_size_change)

    def suspend_screen_size_change(self, _screen) -> bool:
        self.screen_size_change_suspended = True
        return True

    def resume_screen_size_change(self, _screen) -> bool:
        self.screen_size_change_suspended = False
        if self.screen_size_change_counter > 0:
            # we had some screen size change events whilst suspended,
            # so fire it now that we have resumed:
            self.screen_size_change_counter = 0
            self.cancel_screen_size_change_timer()
            self.schedule_screen_size_change_timer()
        return True

    def parse_scaling(self, desktop_scaling: str) -> None:
        root_w, root_h = self.get_root_size()
        self.initial_scaling = parse_scaling(desktop_scaling, root_w, root_h, MIN_SCALING, MAX_SCALING)
        self.xscale, self.yscale = self.initial_scaling
        scalinglog("scaling(%s)=%s", self.initial_scaling, (self.xscale, self.yscale))

    def cleanup(self) -> None:
        self.cancel_screen_size_change_timer()
        if xp := self._x11_props:
            self._x11_props = None
            xp.cleanup()
        if cgd := self._cg_display:
            self._cg_display = None
            cgd.cleanup()

    def get_screen_sizes(self, xscale=1, yscale=1) -> list[tuple[int, int]]:
        raise NotImplementedError()

    def get_root_size(self) -> tuple[int, int]:
        raise NotImplementedError()

    def get_info(self) -> dict[str, Any]:
        screen = self.get_screen_caps()
        screen["scaling"] = self.get_scaling_caps()
        screen["dpi"] = self.get_dpi_caps()
        return {
            "screen": screen,
            "server-colourspace": self.server_colourspace.to_dict(),
        }

    ######################################################################
    # hello:
    def get_caps(self) -> dict[str, Any]:
        dc = self.get_display_caps()
        if not BACKWARDS_COMPATIBLE:
            return {DisplayClient.PREFIX: dc}
        dc["display"] = dict(dc)
        return dc

    def get_display_caps(self) -> dict[str, Any]:
        caps: dict[str, Any] = {
            "show-desktop": True,
            "resize-events": True,
            "refresh-rate": self.get_vrefresh(),
            "refresh-rate.raw": self.get_raw_vrefresh(),
        }
        if BACKWARDS_COMPATIBLE:
            caps["vrefresh"] = self.get_vrefresh()
        if FULL_INFO > 0:
            wm_name = get_wm_name()
            if wm_name:
                caps["wm_name"] = wm_name

            # opengl caps are still reported here (in the display capabilities),
            # but the state is owned by the `opengl` subsystem:
            gl = self.get_subsystem("opengl")
            op = gl.properties if gl else {}
            if FULL_INFO < 2:
                op = skipkeys(op, "extensions", "GLU.extensions")
            caps["opengl"] = op

        self._last_screen_settings = self.get_screen_settings()
        root_w, root_h, sss, ndesktops, desktop_names, u_root_w, u_root_h = self._last_screen_settings[:7]
        if u_root_w and u_root_h:
            caps["desktop_size"] = self.cp(u_root_w, u_root_h)
        if ndesktops:
            caps["desktops"] = ndesktops
            caps["desktop.names"] = tuple(desktop_names)

        ss = self.get_screen_sizes()
        self._current_screen_sizes = ss

        if self.log_screen_info:
            log.info(" desktop size is %sx%s:", u_root_w, u_root_h)
            log_screen_sizes(u_root_w, u_root_h, ss)
        if self.xscale != 1 or self.yscale != 1:
            if BACKWARDS_COMPATIBLE:
                caps["screen_sizes.unscaled"] = ss
            caps["desktop_size.unscaled"] = u_root_w, u_root_h
            if self.log_screen_info:
                root_w, root_h = self.cp(u_root_w, u_root_h)
                if fequ(self.xscale, self.yscale):
                    sinfo = "%i%%" % round(self.xscale * 100)
                else:
                    sinfo = "%i%% x %i%%" % (round(self.xscale * 100), round(self.yscale * 100))
                scaled_up = u_root_w > root_w or u_root_h > root_h
                log.info(" %sscaled to %s, virtual screen size: %ix%i",
                         "up" if scaled_up else "down", sinfo, root_w, root_h)
                log_screen_sizes(root_w, root_h, sss)
        else:
            sss = ss
        if BACKWARDS_COMPATIBLE:
            # legacy per-screen tuples; modern servers use the `monitors` dict instead:
            caps["screen_sizes"] = sss
        monitors = adjust_monitor_refresh_rate(self.refresh_rate, self.get_monitors_info())
        self._monitor_layout = MonitorLayout(monitors)
        caps["monitors"] = monitors
        # we attach a `monitor` descriptor to our window and pointer packets,
        # so the server can map our positions onto its own area for `sharing=combine`:
        caps["monitor-relative"] = True
        caps.update(self.get_screen_caps())
        caps["dpi"] = self.get_dpi_caps()
        caps["screen-scaling"] = self.get_scaling_caps()
        if self.desktop_fullscreen:
            caps["desktop-fullscreen"] = True
        self.log_screen_info = False        # don't log it again
        return caps

    def get_dpi_caps(self) -> dict[str, Any]:
        # command line (or config file) override supplied:
        caps = {}
        dpi = 0
        if self.dpi > 0:
            # scale it:
            dpi = round((self.cx(self.dpi) + self.cy(self.dpi)) / 2.0)
        else:
            # not supplied, use platform detection code:
            # platforms may also provide per-axis dpi (later win32 versions do)
            xdpi = self.client.get_xdpi()
            ydpi = self.client.get_ydpi()
            log("xdpi=%i, ydpi=%i", xdpi, ydpi)
            if xdpi > 0 and ydpi > 0:
                xdpi = self.cx(xdpi)
                ydpi = self.cy(ydpi)
                dpi = round((xdpi + ydpi) / 2.0)
                caps = {
                    "x": xdpi,
                    "y": ydpi,
                }
        if dpi:
            caps[""] = dpi
        log("get_dpi_caps()=%s", caps)
        return caps

    def get_scaling_caps(self) -> dict[str, Any]:
        return {
            "": True,
            "enabled": self.xscale != 1 or self.yscale != 1,
            "values": (int(1000 * self.xscale), int(1000 * self.yscale)),
        }

    def get_vrefresh(self) -> int:
        raw = self.get_raw_vrefresh()
        rate = get_refresh_rate_for_value(self.refresh_rate, raw)
        log("get_vrefresh()=%s (from %s and %s)", rate, self.refresh_rate, raw)
        return rate

    def get_raw_vrefresh(self) -> int:
        # env override takes precedence, otherwise use the platform value;
        # (this env+clamp logic used to live on the gtk3 client's override):
        rate = envint("XPRA_VREFRESH", 0)
        if not rate:
            rate = get_vrefresh()
        if rate < 0:
            return -1
        return max(MIN_VREFRESH, min(MAX_VREFRESH, rate))

    def get_screen_caps(self) -> dict[str, Any]:
        caps: dict[str, int | dict] = {
            "vrefresh": self.get_vrefresh(),
        }
        aa = get_antialias_info()
        if aa:
            caps["antialias"] = aa
        return caps

    def parse_server_capabilities(self, caps: typedict) -> bool:
        if self._x11_props:
            self._x11_props.server_xsettings = caps.boolget("xsettings")
        d = caps.get("display")
        if isinstance(d, dict):
            c = typedict(d)
            self.server_display = c.strget("name")
        elif BACKWARDS_COMPATIBLE:
            c = caps
            self.server_display = c.strget("display")
        else:
            raise ValueError("missing display capabilities, got %r" % d)
        self.server_desktop_size = c.intpair("desktop_size")
        log("server desktop size=%s", self.server_desktop_size)
        self.server_max_desktop_size = c.intpair("max_desktop_size", (2 ** 15, 2 ** 15))
        self.server_actual_desktop_size = c.intpair("actual_desktop_size")
        log("server actual desktop size=%s", self.server_actual_desktop_size)
        self.server_opengl = c.dictget("opengl")
        Logger("screen", "opengl")("server opengl=%s", self.server_opengl)
        # the server mode, randr and monitor features are not part of the `display` namespace:
        self.server_randr = caps.boolget("resize_screen")
        log("server has randr: %s", self.server_randr)
        self.server_multi_monitors = caps.boolget("multi-monitors", False)
        self.server_monitors = caps.dictget("monitors")
        # resolutions the server allows for new monitors (ie: parsec-vdd EDID modes);
        # falls back to the client's own list when the server does not provide one:
        self.server_new_monitor_resolutions = caps.strtupleget("monitors.add-resolutions")
        # optional label for the "add monitor" menu entry (ie: "Add a virtual monitor"):
        self.server_add_monitor_label = caps.strget("monitors.add-label")
        log("server multi-monitors=%s, monitors=%s, new-monitor-resolutions=%s",
            self.server_multi_monitors, self.server_monitors, self.server_new_monitor_resolutions)
        self.server_is_desktop = caps.boolget("shadow") or caps.boolget("desktop") or caps.boolget("monitor")
        self.server_is_monitor = caps.boolget("monitor")
        # the colourspace capability is not part of the `display` namespace,
        # servers without it are assumed to be rendering into sRGB:
        self.server_colourspace = Colourspace.from_dict(caps.dictget("colourspace"))
        log("server colourspace=%s", self.server_colourspace)
        if self.server_colourspace != SRGB:
            log.warn("Warning: the server renders into %s", self.server_colourspace)
            log.warn(" this client cannot convert it to the colourspace used by your display")
            log.warn(" the colours shown will be inaccurate")
        self.print_desktop_size(c)
        return True

    def print_desktop_size(self, c: typedict) -> None:
        if self.server_is_desktop and not self.server_is_monitor:
            v = c.intpair("actual_desktop_size")
            if v != (0, 0):
                w, h = v
                ss = c.tupleget("screen_sizes")
                log.info(f" remote desktop size is {w}x{h}")
                if ss:
                    log_screen_sizes(w, h, ss)

    def adjust_display(self) -> None:
        if not self.server_is_monitor:
            self.verify_display_size()
        # now that we have the server's screen info, allow scale changes:
        self.scale_change_embargo = 0
        self.set_max_packet_size()
        self.send_icc_data()

    def verify_display_size(self):
        log("verify_display_size()")
        skip_vfb_size_check = False  # if we decide not to use scaling, skip warnings
        if not fequ(self.xscale, 1.0) or not fequ(self.yscale, 1.0):
            # scaling is used, make sure that we need it and that the server can support it
            # (without rounding support, size-hints can cause resize loops)
            if self.server_is_desktop and not self.desktop_fullscreen:
                # don't honour auto mode in this case
                if self.desktop_scaling == "auto":
                    log.info(" not scaling a desktop server")
                    skip_vfb_size_check = self.xscale > 1 or self.yscale > 1
                    self.scale_change_embargo = 0
                    self.scalingoff()
        if self.can_scale:
            self.may_adjust_scaling()
        if not self.server_is_desktop and not skip_vfb_size_check and self.server_max_desktop_size != (0, 0):
            avail_w, avail_h = self.server_max_desktop_size
            root_w, root_h = self.get_root_size()
            log("validating server_max_desktop_size=%s vs root size=%s",
                self.server_max_desktop_size, (root_w, root_h))
            if self.cx(root_w) != root_w or self.cy(root_h) != root_h:
                log(" root size scaled to %s", (self.cx(root_w), self.cy(root_h)))
            if self.cx(root_w) > (avail_w + 1) or self.cy(root_h) > (avail_h + 1):
                log.warn("Server's virtual screen is too small")
                log.warn(" server: %sx%s vs client: %sx%s", avail_w, avail_h, self.cx(root_w), self.cy(root_h))
                log.warn(" you may see strange behavior,")
                log.warn(" please see https://github.com/Xpra-org/xpra/blob/master/docs/Usage/Xdummy.md")

    def send_icc_data(self) -> None:
        if SYNC_ICC and (not self.legacy_server() or "configure-display" in self.get_server_packet_types()):
            # it is now safe to send the colorspace data if we have any:
            icc = self.get_icc_info()
            dicc = self.get_display_icc_info()
            if icc or dicc:
                self.send(DISPLAY_CONFIGURE, {
                    "icc": {
                        "global": icc,
                        "display": dicc,
                    },
                })

    # noinspection PyUnreachableCode
    def set_max_packet_size(self) -> None:
        p = self.client._protocol
        if not p or p.TYPE != "xpra":
            return
        root_w, root_h = self.cp(*self.get_root_size())
        maxw, maxh = root_w, root_h
        try:
            server_w, server_h = self.server_actual_desktop_size
            maxw = max(root_w, server_w)
            maxh = max(root_h, server_h)
        except (TypeError, ValueError):
            pass
        if maxw <= 0 or maxh <= 0 or maxw >= 32768 or maxh >= 32768:
            message = "invalid maximum desktop size: %ix%i" % (maxw, maxh)
            log(message)
            self.client.quit(ExitCode.INTERNAL_ERROR)
            return
        # max packet size to accommodate
        # a full screen RGBX (32 bits) uncompressed image
        # also with enough headroom for some metadata (4k)
        # we can't assume to have a real ClientConnection object:
        p.max_packet_size = max(MAX_PACKET_SIZE, maxw * maxh * 4 + 4 * 1024)
        p.abs_max_packet_size = maxw * maxh * 4 * 4 + 4 * 1024
        log("maximum packet size set to %i", p.max_packet_size)

    def has_transparency(self) -> bool:
        return False

    def get_icc_info(self) -> dict[str, Any]:
        return get_icc_info()

    def get_display_icc_info(self) -> dict[str, Any]:
        return get_display_icc_info()

    def get_monitors_info(self) -> dict:
        from xpra.platform.gui import get_monitors_info
        return get_monitors_info(self.xscale, self.yscale)

    def get_monitor_relative_position(self, position: Sequence[int]) -> tuple[int, int, int] | None:
        if len(position) < 2:
            return None
        return self._monitor_layout.relative_position(int(position[0]), int(position[1]))

    def _process_show_desktop(self, packet: Packet) -> None:
        show = packet.get_bool(1)
        log("calling %s(%s)", show_desktop, show)
        show_desktop(show)

    def _process_resized(self, packet: Packet) -> None:
        root_w = packet.get_u16(1)
        root_h = packet.get_u16(2)
        max_w = packet.get_u16(3)
        max_h = packet.get_u16(4)
        log("server has resized the desktop to: %sx%s (max %sx%s)", root_w, root_h, max_w, max_h)
        self.server_max_desktop_size = max_w, max_h
        self.server_actual_desktop_size = root_w, root_h
        if self.can_scale:
            self.may_adjust_scaling()

    def _process_desktop_size(self, packet: Packet) -> None:
        self._process_resized(packet)

    def may_adjust_scaling(self) -> None:
        scalinglog("may_adjust_scaling() server_is_desktop=%s, desktop_fullscreen=%s",
                   self.server_is_desktop, self.desktop_fullscreen)
        if self.server_is_desktop and not self.desktop_fullscreen:
            # don't try to make it fit
            return
        assert self.can_scale
        max_w, max_h = self.server_max_desktop_size  # ie: server limited to 8192x4096?
        w, h = self.get_root_size()  # ie: 5760, 2160
        sw, sh = self.cp(w, h)  # ie: upscaled to: 11520x4320
        scalinglog("may_adjust_scaling() server max desktop size=%s, server actual desktop size=%s",
                   self.server_max_desktop_size, self.server_actual_desktop_size)
        scalinglog("may_adjust_scaling() client root size=%s", self.get_root_size())
        scalinglog(" scaled client root size using %sx%s: %s", self.xscale, self.yscale, (sw, sh))

        # server size is too small for the client screen size with the current scaling value,
        # calculate the minimum scaling to fit it:

        def clamp(v) -> int | float:
            return max(MIN_SCALING, min(MAX_SCALING, v))

        if self.desktop_fullscreen:
            sw, sh = self.server_actual_desktop_size
            x = clamp(w / sw)
            y = clamp(h / sh)
        else:
            if sw < (max_w + 1) and sh < (max_h + 1):
                # no change needed
                return
            x = clamp(w / max_w)
            y = clamp(h / max_h)
            # avoid wonky scaling:
            if not 0.75 < x / y < 1.25:
                x = y = min(x, y)

        def mint(v) -> int | float:
            # prefer `int` to `float`,
            # and even tolerate a 0.1% difference to get it:
            if round(v) * 1000 == round(v * 1000):
                return int(v)
            return v

        self.xscale = mint(x)
        self.yscale = mint(y)
        scalinglog(" xscale=%s, yscale=%s", self.xscale, self.yscale)
        # to use the same scale for both axes:
        # self.xscale = mint(max(x, y))
        # self.yscale = self.xscale
        summary = "Desktop scaling adjusted to accommodate the server"
        xstr = ("%.3f" % self.xscale).rstrip("0")
        ystr = ("%.3f" % self.yscale).rstrip("0")
        messages = [
            "server desktop size is %ix%i" % (max_w, max_h),
            "using scaling factor %s x %s" % (xstr, ystr),
        ]
        may_notify_client(self.client, NotificationID.SCALING, summary, "\n".join(messages), icon_name="scaling")
        scalinglog.warn("Warning: %s", summary)
        for m in messages:
            scalinglog.warn(" %s", m)
        self.emit("scaling-changed")

    ######################################################################
    # screen scaling:
    def fsx(self, v) -> float:
        """ convert X coordinate from server to client """
        return v * self.xscale

    def fsy(self, v) -> float:
        """ convert Y coordinate from server to client """
        return v * self.yscale

    def sx(self, v) -> int:
        """ convert X coordinate from server to client """
        return round(self.fsx(v))

    def sy(self, v) -> int:
        """ convert Y coordinate from server to client """
        return round(self.fsy(v))

    def srect(self, x, y, w, h) -> tuple[int, int, int, int]:
        """ convert rectangle coordinates from server to client """
        return self.sx(x), self.sy(y), self.sx(w), self.sy(h)

    def sp(self, x, y) -> tuple[int, int]:
        """ convert X,Y coordinates from server to client """
        return self.sx(x), self.sy(y)

    def cx(self, v) -> int:
        """ convert X coordinate from client to server """
        return round(v / self.xscale)

    def cy(self, v) -> int:
        """ convert Y coordinate from client to server """
        return round(v / self.yscale)

    def crect(self, x, y, w, h) -> tuple[int, int, int, int]:
        """ convert rectangle coordinates from client to server """
        return self.cx(x), self.cy(y), self.cx(w), self.cy(h)

    def cp(self, x, y) -> tuple[int, int]:
        """ convert X,Y coordinates from client to server """
        return self.cx(x), self.cy(y)

    @staticmethod
    def get_server_position(position: Sequence[int]) -> tuple[int, int]:
        """Return an absolute position in the coordinate space sent to the server."""
        return int(position[0]), int(position[1])

    ######################################################################
    # desktop, screen and scaling:
    def desktops_changed(self, *args) -> None:
        workspacelog("desktops_changed%s", args)
        self.screen_size_changed(*args)

    def workspace_changed(self, *args) -> None:
        workspacelog("workspace_changed%s", args)
        for win in self.get_windows():
            ws_changed = getattr(win, "workspace_changed", noop)
            ws_changed()

    def screen_size_changed(self, *args) -> None:
        log("screen_size_changed(%s) timer=%s, suspended=%s, counter=%i",
            args, self.screen_size_change_timer, self.screen_size_change_suspended, self.screen_size_change_counter)
        if self.screen_size_change_suspended:
            self.screen_size_change_counter += 1
            return
        self.cancel_screen_size_change_timer()
        self.schedule_screen_size_change_timer()

    def schedule_screen_size_change_timer(self):
        # update via timer so the data is more likely to be final (up to date) when we query it,
        # some properties (like _NET_WORKAREA for X11 clients, via `X11DisplayPropsWatcher`) may
        # trigger multiple calls to screen_size_changed, delayed by some amount
        # (sometimes up to 1s..)
        delay = 1000
        self.screen_size_change_timer = self.timeout_add(delay, self.do_process_screen_size_change)

    def cancel_screen_size_change_timer(self):
        if ssct := self.screen_size_change_timer:
            self.screen_size_change_timer = 0
            self.source_remove(ssct)

    def do_process_screen_size_change(self) -> None:
        self.screen_size_change_timer = 0
        changed = self.update_screen_size()
        log("do_process_screen_size_change() changed=%s, MONITOR_CHANGE_REINIT=%s", changed, MONITOR_CHANGE_REINIT)
        if changed and MONITOR_CHANGE_REINIT:
            log.info("screen size change: will reinit the windows")
            if window := self.get_subsystem("window"):
                window.reinit_windows()
                window.reinit_window_icons()

    def get_screen_settings(self) -> tuple:
        u_root_w, u_root_h = self.get_root_size()
        root_w, root_h = self.cp(u_root_w, u_root_h)
        self._current_screen_sizes = self.get_screen_sizes()
        sss = self.get_screen_sizes(self.xscale, self.yscale)
        ndesktops = get_number_of_desktops()
        desktop_names = get_desktop_names()
        log("get_screen_settings() sizes=%s, %s desktops: %s", sss, ndesktops, desktop_names)
        if self.dpi > 0:
            # use command line value supplied, but scale it:
            xdpi = ydpi = self.dpi
            log("get_screen_settings() dpi=%s", self.dpi)
        else:
            # not supplied, use platform detection code:
            xdpi = self.client.get_xdpi()
            ydpi = self.client.get_ydpi()
            log("get_screen_settings() xdpi=%s, ydpi=%s", get_xdpi(), get_ydpi())
        xdpi = self.cx(xdpi)
        ydpi = self.cy(ydpi)
        log("get_screen_settings() scaled: xdpi=%s, ydpi=%s", xdpi, ydpi)
        vrefresh = self.get_vrefresh()
        log("get_screen_settings() vrefresh=%s", vrefresh)
        # expose both the real and the cooked per-monitor refresh rate, as in the hello caps:
        monitors = adjust_monitor_refresh_rate(self.refresh_rate, self.get_monitors_info())
        self._monitor_layout = MonitorLayout(monitors)
        return root_w, root_h, sss, ndesktops, desktop_names, u_root_w, u_root_h, xdpi, ydpi, vrefresh, monitors

    def update_screen_size(self) -> bool:
        self.screen_size_change_timer = 0
        screen_settings = self.get_screen_settings()
        log("update_screen_size()     new settings=%s", screen_settings)
        log("update_screen_size() current settings=%s", self._last_screen_settings)
        if self._last_screen_settings == screen_settings:
            log("screen size unchanged")
            return False
        root_w, root_h, sss = screen_settings[:3]
        log.info("sending updated screen size to server: %sx%s", root_w, root_h)
        log_screen_sizes(root_w, root_h, sss)
        if not self.legacy_server() or "configure-display" in self.get_server_packet_types():
            root_w, root_h = screen_settings[:2]
            ndesktops, desktop_names = screen_settings[3:5]
            u_root_w, u_root_h = screen_settings[5:7]
            xdpi, ydpi = screen_settings[7:9]
            rrate, monitors = screen_settings[9:11]
            attrs = {
                "desktop-size": (root_w, root_h),
                "desktop-size-unscaled": (u_root_w, u_root_h),
                "monitors": monitors,
                "dpi": {"x": xdpi, "y": ydpi},
            }
            icc = self.get_icc_info()
            dicc = self.get_display_icc_info()
            if icc or dicc:
                attrs["icc"] = {
                    "global": icc,
                    "display": dicc,
                }
            if ndesktops:
                attrs["desktops"] = ndesktops
                attrs["desktop-names"] = desktop_names or ()
            if rrate:
                attrs["vrefresh"] = rrate
            log(f"configure-display: {attrs}")
            self.send(DISPLAY_CONFIGURE, attrs)
        self._last_screen_settings = screen_settings
        # update the max packet size (may have gone up):
        self.set_max_packet_size()
        return True

    def get_xdpi(self) -> int:
        return get_xdpi()

    def get_ydpi(self) -> int:
        return get_ydpi()

    def scaleup(self) -> None:
        scaling = max(self.xscale, self.yscale)
        options = scaleup_value(scaling)
        scalinglog("scaleup() options=%s", options)
        if options:
            self._scaleto(min(options))

    def scaledown(self) -> None:
        scaling = min(self.xscale, self.yscale)
        options = scaledown_value(scaling)
        scalinglog("scaledown() options=%s", options)
        if options:
            self._scaleto(max(options))

    def _scaleto(self, new_scaling) -> None:
        scaling = max(self.xscale, self.yscale)
        scalinglog("_scaleto(%s) current value=%s", r4cmp(new_scaling, 1000) / 1000.0, r4cmp(scaling, 1000) / 1000.0)
        if new_scaling > 0:
            self.scale_change(new_scaling / scaling, new_scaling / scaling)

    def scalingoff(self) -> None:
        self.scaleset(1, 1)

    def scalereset(self) -> None:
        self.scaleset(*self.initial_scaling)

    def scaleset(self, xscale=1.0, yscale=1.0) -> None:
        scalinglog("scaleset(%s, %s) current scaling: %s, %s", xscale, yscale, self.xscale, self.yscale)
        self.scale_change(xscale / self.xscale, yscale / self.yscale)

    def scale_change(self, xchange=1.0, ychange=1.0) -> None:
        scalinglog("scale_change(%s, %s)", xchange, ychange)
        if self.server_is_desktop and self.desktop_fullscreen:
            scalinglog("scale_change(%s, %s) ignored, fullscreen shadow mode is active", xchange, ychange)
            return
        if not self.can_scale:
            scalinglog("scale_change(%s, %s) ignored, scaling is disabled", xchange, ychange)
            return
        if self.screen_size_change_timer:
            scalinglog("scale_change(%s, %s) screen size change is already pending", xchange, ychange)
            return
        if monotonic() < self.scale_change_embargo:
            scalinglog("scale_change(%s, %s) screen size change not permitted during embargo time - try again",
                       xchange, ychange)
            return

        def clamp(v) -> int | float:
            return max(MIN_SCALING, min(MAX_SCALING, v))

        xscale = clamp(self.xscale * xchange)
        yscale = clamp(self.yscale * ychange)
        scalinglog("scale_change xscale: clamp(%s*%s)=%s", self.xscale, xchange, xscale)
        scalinglog("scale_change yscale: clamp(%s*%s)=%s", self.yscale, ychange, yscale)
        if fequ(xscale, self.xscale) and fequ(yscale, self.yscale):
            scalinglog("scaling unchanged: %sx%s", self.xscale, self.yscale)
            return
        # re-calculate change values against clamped scale:
        xchange = xscale / self.xscale
        ychange = yscale / self.yscale
        # check against maximum server supported size:
        maxw, maxh = self.server_max_desktop_size
        root_w, root_h = self.get_root_size()
        sw = int(root_w / xscale)
        sh = int(root_h / yscale)
        scalinglog("scale_change root size=%s x %s, scaled to %s x %s", root_w, root_h, sw, sh)
        scalinglog("scale_change max server desktop size=%s x %s", maxw, maxh)
        if not self.server_is_desktop and (sw > (maxw + 1) or sh > (maxh + 1)):
            # would overflow..
            summary = "Invalid Scale Factor"
            messages = [
                "cannot scale by %i%% x %i%% or lower" % (round(100 * xscale), round(100 * yscale)),
                "the scaled client screen %i x %i -> %i x %i" % (root_w, root_h, sw, sh),
                " would overflow the server's screen: %i x %i" % (maxw, maxh),
            ]
            may_notify_client(self.client, NotificationID.SCALING, summary, "\n".join(messages), icon_name="scaling")
            scalinglog.warn("Warning: %s", summary)
            for m in messages:
                scalinglog.warn(" %s", m)
            return
        self.xscale = xscale
        self.yscale = yscale
        scalinglog("scale_change new scaling: %sx%s, change: %sx%s", self.xscale, self.yscale, xchange, ychange)
        self.scale_reinit(xchange, ychange)

    def scale_reinit(self, xchange=1.0, ychange=1.0) -> None:
        # wait at least one second before changing again:
        self.scale_change_embargo = monotonic() + SCALING_EMBARGO_TIME
        if fequ(self.xscale, self.yscale):
            scalinglog.info("setting scaling to %i%%:", round(100 * self.xscale))
        else:
            scalinglog.info("setting scaling to %i%% x %i%%:", round(100 * self.xscale), round(100 * self.yscale))
        self.update_screen_size()
        window = self.get_subsystem("window")
        if window:
            # re-initialize all the windows with their new size
            for win in self.get_windows():
                if hasattr(win, "_xscale"):
                    win._xscale *= xchange
                if hasattr(win, "_yscale"):
                    win._yscale *= ychange

            max_window_size = window.max_window_size

            def new_size_fn(w, h) -> tuple[int, int]:
                minx, miny = 16384, 16384
                if max_window_size != (0, 0):
                    minx, miny = max_window_size
                return max(1, min(minx, round(w * xchange))), max(1, min(miny, round(h * ychange)))

            window.resize_windows(new_size_fn)
            window.reinit_window_icons()
        self.emit("scaling-changed")

    def init_authenticated_packet_handlers(self) -> None:
        self.add_legacy_alias("show-desktop", "display-show-desktop")
        self.add_packets("display-show-desktop", DISPLAY_RESIZED, main_thread=True)

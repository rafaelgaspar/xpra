# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from typing import Any

from xpra.os_util import WIN32, gi_import
from xpra.net.common import BACKWARDS_COMPATIBLE
from xpra.util.objects import typedict
from xpra.util.env import envbool, envint
from xpra.util.thread import is_main_thread
from xpra.exit_codes import ExitCode
from xpra.util.str_fn import csv
from xpra.util.parsing import TRUE_OPTIONS, FALSE_OPTIONS
from xpra.client.base.stub import StubClientSubsystem
from xpra.net.mmap.common import split_paths
from xpra.net.mmap.io import init_client_mmap, clean_mmap, int_from_buffer, validate_chunks
from xpra.net.mmap.objects import BaseMmapArea
from xpra.log import Logger

GLib = gi_import("GLib")

log = Logger("mmap")

KEEP_MMAP_FILE = envbool("XPRA_KEEP_MMAP_FILE", False)
MIN_SIZE = envint("XPRA_MMAP_MIN_SIZE", 2048 * 1024 * 1024)
# cannot exceed 4GB, see xpra.net.mmap.common for details
MAX_SIZE = envint("XPRA_MMAP_MAX_SIZE", 4096 * 1024 * 1024)


class MmapArea(BaseMmapArea):
    __slots__ = (
        "delete", "enabled", "filename", "group", "mmap", "name", "size", "tempfile", "token", "token_bytes",
        "token_index",
    )

    def __init__(self, name: str, group="", filename="", size=0):
        super().__init__(name, filename, size)
        self.group = group
        self.tempfile = None
        self.delete: bool = False

    def get_info(self) -> dict[str, Any]:
        info = super().get_info()
        info["group"] = self.group
        return info

    def cleanup(self) -> None:
        super().close()
        self.clean_mmap()

    def clean_mmap(self) -> bool:
        log("%s.clean_mmap() filename=%s", self, self.filename)
        if not is_main_thread():
            # the areas are enabled from `parse_server_capabilities`, which runs on the
            # network parse thread - and its seccomp filter forbids `unlink`
            # (see `docs/Usage/Seccomp.md`), so delete the file from the main thread:
            GLib.idle_add(self.clean_mmap)
            return False
        if self.tempfile:
            try:
                self.tempfile.close()
            except OSError as e:
                log("%s.clean_mmap() error closing file %s: %s", self, self.tempfile, e)
            self.tempfile = None
        if self.delete:
            # this should be redundant: closing the tempfile should get it deleted
            if self.filename and os.path.exists(self.filename):
                clean_mmap(self.filename)
                self.filename = ""
        return False

    def enable_from_caps(self, mmap_caps: typedict) -> bool:
        try:
            self.parse_caps(mmap_caps)
            if self.enabled:
                # a valid token is the only proof that the peer is really using this area,
                # `verify_token` does not always clear the `enabled` flag itself:
                self.enabled = self.verify_token()
            if not self.enabled:
                self.clean_mmap()
            return self.enabled
        finally:
            # the server will have a handle on the mmap file by now, safe to delete:
            if not KEEP_MMAP_FILE:
                self.clean_mmap()

    def init_mmap(self, socket_filename: str) -> None:
        log("%s.init_mmap(%r)", self, socket_filename)
        self.enabled, self.delete, self.mmap, self.size, self.tempfile, self.filename = \
            init_client_mmap(self.group, socket_filename, self.size, self.filename)
        if self.enabled:
            # the length actually mapped may differ from the size we asked for:
            self.size = len(self.mmap)
            self.gen_token()
            self.write_token()


class MmapClient(StubClientSubsystem):
    """
    Mixin for adding mmap support to a client
    """
    __slots__ = ("mmap_group", "mmap_option", "mmap_read_area", "mmap_supported", "mmap_write_area")
    PREFIX = "mmap"

    def __init__(self, client=None):
        StubClientSubsystem.__init__(self, client)
        self.mmap_option = "no"
        self.mmap_group = "auto"
        self.mmap_read_area: MmapArea | None = None
        self.mmap_write_area: MmapArea | None = None
        self.mmap_supported = True

    def init(self, opts) -> None:
        self.mmap_option = opts.mmap
        self.mmap_group = opts.mmap_group

    def load(self):
        mopt = self.mmap_option.lower()
        log("mmap.init(..) mmap=%r", mopt)
        if mopt in FALSE_OPTIONS:
            self.mmap_supported = False
            return
        if mopt == "auto" and WIN32:
            # mmap can only be used with a server running on the same host,
            # which is the exception rather than the rule for MS Windows clients,
            # and the areas are not free: each one costs its full size
            # in commit charge as soon as it is created - long before we find out
            # whether the server can use it.
            # (`mmap=yes` still enables it explicitly)
            log("mmap is not enabled automatically on MS Windows")
            self.mmap_supported = False
            return
        self.mmap_supported = True
        read = write = False
        if mopt in ("auto", "read"):
            # by default, only enable mmap reads, not writes:
            read = True
            filenames = ("", )
        elif mopt == "write":
            write = True
            filenames = ("", "")
        elif mopt in TRUE_OPTIONS or mopt == "both":
            read = write = True
            filenames = ("", "")
        else:
            # assume path(s) have been specified: a file or a directory for each area
            filenames = split_paths(self.mmap_option)
            if len(filenames) >= 3:
                raise RuntimeError("too many mmap paths specified: %r" % csv(filenames))
            read = True
            write = len(filenames) == 2
        group = self.mmap_group
        # weak dependency on the `display` subsystem:
        display = self.get_subsystem("display")
        root_w, root_h = display.get_root_size() if display else (0, 0)
        size = min(MAX_SIZE, max(MIN_SIZE, root_w * root_h * 4 * 8))
        if read:
            self.mmap_read_area = MmapArea("read", group, filenames[0], size)
        if write:
            self.mmap_write_area = MmapArea("write", group, filenames[1], size)
        log("init(..) group=%s, mmap=%s, read-area=%s, write-area=%s",
            group, self.mmap_option, self.mmap_read_area, self.mmap_write_area)

    def cleanup(self) -> None:
        self.clean_areas()

    def clean_areas(self) -> None:
        def clean(area: MmapArea | None) -> None:
            try:
                if not area:
                    return
            except ValueError as e:
                log("clean(%r) %s ignored", area, e)
                return
            area.cleanup()

        mra = self.mmap_read_area
        self.mmap_read_area = None
        clean(mra)
        mwa = self.mmap_write_area
        self.mmap_write_area = None
        clean(mwa)

    def setup_connection(self, conn) -> None:
        log("setup_connection(%s) mmap supported=%s", conn, self.mmap_supported)
        if not self.mmap_supported:
            return
        for name, area in {
            "read": self.mmap_read_area,
            "write": self.mmap_write_area,
        }.items():
            log(f"{name!r}={area}")
            if area is not None:
                area.init_mmap(conn.filename or "")

    @staticmethod
    def get_root_size() -> tuple[int, int]:
        # subclasses should provide real values
        return 1024, 1024

    # noinspection PyUnreachableCode
    def parse_server_capabilities(self, c: typedict) -> bool:
        mmap_caps = typedict(c.dictget("mmap"))
        log(f"mmap.parse_server_capabilities(..) {mmap_caps=}")
        if not self.mmap_supported or not mmap_caps:
            self.clean_areas()
            return True
        READ_PREFIXES = ("read", )
        # older versions didn't use a prefix:
        WRITE_PREFIXES = ("write", "") if BACKWARDS_COMPATIBLE else ("write", )
        # parse each area
        for prefixes, area in (
            (WRITE_PREFIXES, self.mmap_read_area),
            (READ_PREFIXES, self.mmap_write_area),
        ):
            log(f"{prefixes} : {area}")
            if not area:
                continue
            area_caps = {}
            prefix = ""
            for prefix in prefixes:
                if prefix:
                    area_caps = mmap_caps.dictget(prefix)
                else:
                    # older versions only have one mmap area:
                    area_caps = mmap_caps
                if area_caps:
                    break
            log(f"caps({prefix!r})={area_caps!r}")
            if area_caps:
                try:
                    if area.enable_from_caps(typedict(area_caps)):
                        # enabled!
                        continue
                except ValueError:
                    log("mmap.parse_server_capabilities(..)", exc_info=True)
                    self.quit(ExitCode.MMAP_TOKEN_FAILURE)
                    return False
            # not found, or not enabled:
            area.cleanup()
        return True

    def free_packet_chunks(self, img_data, options: typedict) -> None:
        """
            Acknowledge the chunks used by a packet we have finished with,
            so that the server can re-use this space:
            the `data_start` pointer tells it how far we have read.
        """
        area = self.mmap_read_area
        if not area:
            return
        # newer versions use the 'chunks' option - see `paint_mmap`:
        chunks = options.tupleget("chunks")
        if not chunks and BACKWARDS_COMPATIBLE:
            # older versions overload the pixel data:
            chunks = tuple(img_data)
        if not chunks:
            log.error("Error: no mmap chunks found in packet")
            return
        try:
            # the chunks come from the server, so they must be validated
            # before we can move the shared pointer:
            validate_chunks(area.mmap, chunks)
        except ValueError as e:
            log.error("Error: invalid mmap chunks found in packet")
            log.error(" %s", e)
            return
        offset, length = chunks[-1]
        int_from_buffer(area.mmap, 0).value = offset + length

    def get_info(self) -> dict[str, Any]:
        info = {}
        for prefix, area in {
            "read": self.mmap_read_area,
            "write": self.mmap_write_area,
        }.items():
            if area:
                info[prefix] = area.get_info()
        return {MmapClient.PREFIX: info}

    def get_caps(self) -> dict[str, Any]:
        if not self.mmap_supported:
            return {}
        caps = {}
        for prefix, area in {
            "read": self.mmap_read_area,
            "write": self.mmap_write_area,
        }.items():
            if area:
                caps[prefix] = area.get_caps()
        if BACKWARDS_COMPATIBLE and self.mmap_read_area:
            # duplicate it for legacy unprefixed caps:
            caps.update(self.mmap_read_area.get_caps())
        return {MmapClient.PREFIX: caps}

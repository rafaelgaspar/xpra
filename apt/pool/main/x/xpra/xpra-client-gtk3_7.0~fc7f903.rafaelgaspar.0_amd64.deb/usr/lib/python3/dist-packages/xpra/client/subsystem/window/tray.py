# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any

from xpra.net.common import Packet, BACKWARDS_COMPATIBLE
from xpra.os_util import OSX
from xpra.util.system import is_Ubuntu
from xpra.util.objects import typedict, make_instance
from xpra.util.str_fn import single_line, truncate
from xpra.util.env import envint, envbool
from xpra.client.base.stub import StubClientSubsystem
from xpra.log import Logger

log = Logger("window", "tray")

DYNAMIC_TRAY_ICON: bool = envbool("XPRA_DYNAMIC_TRAY_ICON", not OSX and not is_Ubuntu())
ICON_OVERLAY: int = envint("XPRA_ICON_OVERLAY", 50)
ICON_SHRINKAGE: int = envint("XPRA_ICON_SHRINKAGE", 75)


class WindowTray(StubClientSubsystem):
    __slots__ = ()
    # these mixins are all composed into a single `WindowClient` instance,
    # which is the subsystem registered as `window`: declaring the prefix here
    # too keeps each mixin usable (and testable) on its own
    PREFIX = "window"
    SLOT_NAMES = ("systemtray_enabled",)

    def __init__(self):
        self.systemtray_enabled: bool = False

    def init(self, opts) -> None:
        if opts.system_tray:
            try:
                from xpra.client.gui import client_tray
                assert client_tray
            except ImportError:
                log.warn("Warning: the tray forwarding module is missing")
            else:
                self.systemtray_enabled = True

    ######################################################################
    # hello:
    def get_caps(self) -> dict[str, Any]:
        return {
            "system_tray": self.systemtray_enabled,
        }

    def parse_server_capabilities(self, c: typedict) -> bool:
        return True

    ######################################################################
    # system tray
    def make_new_tray(self, wid: int, w: int, h: int, metadata: typedict):
        assert self.systemtray_enabled
        # scaling helpers are owned by the `display` subsystem:
        display = self.get_subsystem("display")
        w = max(1, display.sx(w))
        h = max(1, display.sy(h))
        log("make_new_tray(%#x, %i, %i, %s)", wid, w, h, metadata)
        if wid in self._id_to_window:
            raise ValueError("we already have a window %#x: %s" % (wid, self.get_window(wid)))
        app_id = wid
        tray = self.setup_system_tray(self, app_id, wid, w, h, metadata)
        log("make_new_tray(..) tray=%s", tray)
        self._id_to_window[wid] = tray
        self._window_to_id[tray] = wid
        return tray

    def _process_new_tray(self, packet: Packet) -> None:
        # legacy packet: newer servers overload `window-create` with `tray=True` metadata instead
        assert BACKWARDS_COMPATIBLE
        self.client._ui_event()
        wid = packet.get_wid()
        w = packet.get_u16(2)
        h = packet.get_u16(3)
        metadata = typedict()
        if len(packet) >= 5:
            metadata = typedict(packet.get_dict(4))
        self.make_new_tray(wid, w, h, metadata)

    def make_system_tray(self, *args):
        """ tray used for application systray forwarding """
        tc = self.client.get_system_tray_classes()
        log("make_system_tray%s system tray classes=%s", args, tc)
        return make_instance(tc, self.client, *args)

    # noinspection PyMethodMayBeStatic
    def get_system_tray_classes(self) -> list[type]:
        # subclasses may add their toolkit specific variants, if any
        # by overriding this method
        # use the native ones first:
        from xpra.platform.systray import get_forwarding_backends
        return get_forwarding_backends()

    def setup_system_tray(self, client, app_id, wid: int, w: int, h: int, metadata: typedict):
        tray_widget = None

        # this is a tray forwarded for a remote application

        def tray_click(button, pressed, event_time=0):
            tray = self.get_window(wid)
            log("tray_click(%s, %s, %s) tray=%s", button, pressed, event_time, tray)
            if tray:
                if pointer := self.get_subsystem("pointer"):
                    keyboard = self.get_subsystem("keyboard")
                    modifiers = keyboard.get_current_modifiers() if keyboard else ()
                    buttons = (button, ) if pressed else ()
                    pointer.send_button(-1, wid, button, pressed, pointer.get_mouse_position(), modifiers, buttons, {})
                tray.reconfigure()

        def tray_mouseover(x, y):
            tray = self.get_window(wid)
            log("tray_mouseover(%s, %s) tray=%s", x, y, tray)
            if tray:
                keyboard = self.get_subsystem("keyboard")
                modifiers = keyboard.get_current_modifiers() if keyboard else ()
                device_id = -1
                cp = self.get_subsystem("display").cp(x, y)
                self.get_subsystem("pointer").send_mouse_position(device_id, wid, cp, modifiers)

        def do_tray_geometry(*args):
            # tell the "ClientTray" where it now lives
            # which should also update the location on the server if it has changed
            tray = self.get_window(wid)
            if tray_widget:
                geom = tray_widget.get_geometry()
            else:
                geom = ()
            log("tray_geometry(%s) widget=%s, geometry=%s tray=%s", args, tray_widget, geom, tray)
            if tray and geom:
                tray.move_resize(*geom)

        def tray_geometry(*args):
            # the tray widget may still be None if we haven't returned from make_system_tray yet,
            # in which case we will check the geometry a little bit later:
            if tray_widget:
                do_tray_geometry(*args)
            else:
                self.idle_add(do_tray_geometry, *args)

        def tray_exit(*args):
            log("tray_exit(%s)", args)

        # used as tooltip:
        title = truncate(single_line(metadata.strget("title")), 256)
        tray_widget = self.make_system_tray(app_id, None, title, "",
                                            tray_geometry, tray_click, tray_mouseover, tray_exit)
        log("setup_system_tray%s tray_widget=%s", (client, app_id, wid, w, h, title), tray_widget)
        assert tray_widget, "could not instantiate a system tray for tray id %s" % wid
        tray_widget.show()
        from xpra.client.gui.client_tray import ClientTray
        # the mmap read area is owned by the `mmap` subsystem:
        mmap_sub = self.get_subsystem("mmap")
        mmap = mmap_sub.mmap_read_area if mmap_sub else None
        return ClientTray(client, wid, w, h, metadata, tray_widget, mmap)

    def get_tray_window(self, app_name: str, hints: dict):
        # try to identify the application tray that generated this notification,
        # so we can show it as coming from the correct systray icon
        # on platforms that support it (ie: win32)
        trays = tuple(w for w in self._id_to_window.values() if w.is_tray())
        if trays:
            try:
                pid = int(hints.get("pid") or 0)
            except (TypeError, ValueError):
                pass
            else:
                if pid:
                    for tray in trays:
                        metadata: typedict = typedict(tray._metadata)
                        if metadata.intget("pid") == pid:
                            log("tray window: matched pid=%i", pid)
                            return tray.tray_widget
            if app_name and app_name.lower() != "xpra":
                # exact match:
                for tray in trays:
                    # log("window %s: is_tray=%s, title=%s", window,
                    #    window.is_tray(), getattr(window, "title", None))
                    if tray.title == app_name:
                        return tray.tray_widget
                for tray in trays:
                    if tray.title.find(app_name) >= 0:
                        return tray.tray_widget
        # the xpra system tray is owned by the `tray` subsystem (which may be disabled):
        tray_subsystem = self.get_subsystem("tray")
        return tray_subsystem.tray if tray_subsystem else None

    def set_tray_icon(self) -> None:
        # find all the window icons,
        # and if they are all using the same one, then use it as tray icon
        # otherwise use the default icon
        # the xpra system tray is owned by the `tray` subsystem (which may be disabled):
        tray_subsystem = self.get_subsystem("tray")
        tray = tray_subsystem.tray if tray_subsystem else None
        log("set_tray_icon() DYNAMIC_TRAY_ICON=%s, tray=%s", DYNAMIC_TRAY_ICON, tray)
        if not tray:
            return
        if not DYNAMIC_TRAY_ICON:
            # the icon ends up looking garbled on win32,
            # and we somehow also lose the settings that can keep us in the visible systray list
            # so don't bother
            return
        windows = tuple(w for w in self._window_to_id if not w.is_tray())
        # get all the icons:
        icons = tuple(getattr(w, "_current_icon", None) for w in windows)
        missing = sum(1 for icon in icons if icon is None)
        log("set_tray_icon() %i windows, %i icons, %i missing", len(windows), len(icons), missing)
        if icons and not missing:
            icon = icons[0]
            for i in icons[1:]:
                if i != icon:
                    # found a different icon
                    icon = None
                    break
            if icon:
                has_alpha = icon.mode == "RGBA"
                width, height = icon.size
                log("set_tray_icon() using unique %s icon: %ix%i (has-alpha=%s)",
                    icon.mode, width, height, has_alpha)
                rowstride = width * (3 + int(has_alpha))
                rgb_data = icon.tobytes("raw", icon.mode)
                tray.set_icon_from_data(rgb_data, has_alpha, width, height, rowstride)
                return
        # this sets the default icon (badly named function!)
        log("set_tray_icon() using default icon")
        tray.set_icon()

    def init_authenticated_packet_handlers(self) -> None:
        if BACKWARDS_COMPATIBLE:
            # newer servers send trays as `window-create` packets with `tray=True` metadata,
            # which are handled by the window manager subsystem:
            self.add_packets("new-tray", main_thread=True)

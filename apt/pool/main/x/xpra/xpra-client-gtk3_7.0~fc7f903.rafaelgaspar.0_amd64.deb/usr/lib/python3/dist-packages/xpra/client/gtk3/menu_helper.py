# This file is part of Xpra.
# Copyright (C) 2011 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
import re
from collections.abc import Callable, Sequence

from xpra.common import noop
from xpra.util.str_fn import repr_ellipsized, csv, Ellipsizer
from xpra.util.env import envbool, IgnoreWarningsContext
from xpra.os_util import OSX, gi_import
from xpra.client.gui.menu_helper import MenuHelper, ImageMenuItem, MenuItem
from xpra.codecs.icon_util import INKSCAPE_RE
from xpra.codecs.image_type import get_image_type
from xpra.gtk.widget import scaled_image, menuitem
from xpra.gtk.pixbuf import get_pixbuf_from_data, load_pixbuf
from xpra.gtk.dialogs.about import close_about
from xpra.platform.paths import get_icon_dir
from xpra.util.i18n import _
from xpra.log import Logger

log = Logger("menu")

Gtk = gi_import("Gtk")
GdkPixbuf = gi_import("GdkPixbuf")

MENU_ICONS = envbool("XPRA_MENU_ICONS", True)
MENU_SVG_ICONS = envbool("XPRA_MENU_SVG_ICONS", True)
HIDE_DISABLED_MENU_ENTRIES = envbool("XPRA_HIDE_DISABLED_MENU_ENTRIES", False)

LOSSLESS = "Lossless"
QUALITY_OPTIONS_COMMON: dict[int, str] = {
    50: "Average",
    30: "Low",
}
MIN_QUALITY_OPTIONS = QUALITY_OPTIONS_COMMON.copy()
MIN_QUALITY_OPTIONS |= {
    0: "None",
    75: "High",
}
MIN_QUALITY_OPTIONS = dict(sorted(MIN_QUALITY_OPTIONS.items()))
QUALITY_OPTIONS = QUALITY_OPTIONS_COMMON.copy()
QUALITY_OPTIONS |= {
    0: "Auto",
    1: "Lowest",
    90: "Best",
    100: LOSSLESS,
}
QUALITY_OPTIONS = dict(sorted(QUALITY_OPTIONS.items()))

SPEED_OPTIONS_COMMON: dict[int, str] = {
    70: "Low Latency",
    50: "Average",
    30: "Low Bandwidth",
}
MIN_SPEED_OPTIONS = SPEED_OPTIONS_COMMON.copy()
MIN_SPEED_OPTIONS[0] = "None"
MIN_SPEED_OPTIONS = dict(sorted(MIN_SPEED_OPTIONS.items()))
SPEED_OPTIONS = SPEED_OPTIONS_COMMON.copy()
SPEED_OPTIONS |= {
    0: "Auto",
    1: "Lowest Bandwidth",
    100: "Lowest Latency",
}
SPEED_OPTIONS = dict(sorted(SPEED_OPTIONS.items()))


def get_bandwidth_menu_options() -> Sequence[int]:
    options = []
    for x in os.environ.get("XPRA_BANDWIDTH_MENU_OPTIONS", "1,2,5,10,20,50,100").split(","):
        try:
            options.append(int(float(x) * 1000 * 1000))
        except ValueError:
            log.warn("Warning: invalid bandwidth menu option '%s'", x)
    return options


BANDWIDTH_MENU_OPTIONS = get_bandwidth_menu_options()


def ll(m) -> str:
    try:
        return "%s:%s" % (type(m), m.get_label())
    except AttributeError:
        return str(m)


def set_sensitive(widget, sensitive: bool) -> None:
    if OSX:
        if sensitive:
            widget.show()
        else:
            widget.hide()
    widget.set_sensitive(sensitive)


def get_appimage(app_name: str, icondata=b"", menu_icon_size=24, encodings=()) -> Gtk.Image | None:
    pixbuf = None
    if app_name and not icondata:
        # try to load from our icons:
        # (local files are trusted and loaded no matter what `encodings` allows)
        nstr = app_name.lower()
        icon_filename = os.path.join(get_icon_dir(), "%s.png" % nstr)
        if os.path.exists(icon_filename):
            pixbuf = GdkPixbuf.Pixbuf.new_from_file(filename=icon_filename)

    if icondata:
        # only parse remote icon data we actually have a decoder for
        # (svg is added by the caller so it can still go through the GdkPixbuf loader):
        itype = get_image_type(icondata)
        if itype not in encodings:
            log.warn(f"Warning: cannot show menu icon for {app_name!r}")
            log.warn(f" unsupported image encoding {itype or 'unknown'!r}")
            log.warn(" icon data=%s", Ellipsizer(icondata))
            log.warn(f" allowed encodings: {csv(encodings)}")
            icondata = b""

    def err(e) -> None:
        log("failed to load icon", exc_info=True)
        log.error(f"Error: failed to load icon data for {app_name!r}:")
        log.estr(e)
        log.error(" data=%s", repr_ellipsized(icondata))

    if not pixbuf and icondata:
        # gtk pixbuf loader:
        try:
            pixbuf = load_pixbuf(icondata)
        except Exception as e:
            log("pixbuf loader failed", exc_info=True)
            if re.findall(INKSCAPE_RE, icondata):
                try:
                    pixbuf = load_pixbuf(re.sub(INKSCAPE_RE, b"", icondata))
                except Exception:
                    # there is almost no chance pillow will be able to load it
                    # (it doesn't even have svg support at time of writing)
                    # so don't bother showing another error for the same data:
                    err(e)
                    icondata = None
    if not pixbuf and icondata:
        # let's try pillow:
        try:
            from xpra.codecs.pillow.decoder import open_only  # pylint: disable=import-outside-toplevel
            from xpra.codecs.image_type import is_svg  # pylint: disable=import-outside-toplevel
            if not is_svg(icondata):
                img = open_only(icondata)
                if img.mode not in ("RGB", "RGBA"):
                    try:
                        img = img.convert("RGB")
                    except ValueError as e:
                        log("ignoring %s image: %s", img.mode, e)
                        return None
                has_alpha = img.mode == "RGBA"
                width, height = img.size
                rowstride = width * (3 + int(has_alpha))
                imgdata = img.tobytes()
                pixbuf = get_pixbuf_from_data(imgdata, has_alpha, width, height, rowstride)
                return scaled_image(pixbuf, icon_size=menu_icon_size)
        except Exception as e:
            err(e)
    if pixbuf:
        return scaled_image(pixbuf, icon_size=menu_icon_size)
    return None


# utility method to ensure there is always only one CheckMenuItem
# selected in a submenu:
def ensure_item_selected(submenu, item, recurse=True):
    if not isinstance(item, Gtk.CheckMenuItem):
        return None
    if item.get_active():
        # deactivate all except this one
        def deactivate(items, skip=None) -> None:
            for x in items:
                if x == skip:
                    continue
                if isinstance(x, Gtk.MenuItem):
                    submenu = x.get_submenu()
                    if submenu and recurse:
                        deactivate(submenu.get_children(), skip)
                if isinstance(x, Gtk.CheckMenuItem):
                    if x != item and x.get_active():
                        x.set_active(False)

        deactivate(submenu.get_children(), item)
        return item

    # ensure there is at least one other active item

    def get_active_item(items) -> int:
        for x in items:
            if isinstance(x, Gtk.MenuItem):
                submenu = x.get_submenu()
                if submenu:
                    a = get_active_item(submenu.get_children())
                    if a:
                        return a
            if isinstance(x, Gtk.CheckMenuItem) and x.get_active():
                return x
        return 0

    active = get_active_item(submenu.get_children())
    if active:
        return active
    # if not then keep this one active:
    item.set_active(True)
    return item


class MinAutoMenu(Gtk.Menu):
    def __init__(self, title: str, min_options: dict[int, str], options: dict[int, str],
                 get_current_min_value: Callable[[], int],
                 get_current_value: Callable[[], int],
                 set_min_value_cb: Callable[[int], None],
                 set_value_cb: Callable[[int], None]):
        super().__init__()
        self.title = title
        self.min_options = min_options
        self.options = options
        self.get_current_min_value = get_current_min_value
        self.get_current_value = get_current_value
        self.set_min_value_cb = set_min_value_cb
        self.set_value_cb = set_value_cb
        self.updating = False
        self.found_match = False

        self.menu_items = self.gen_menuitems(options, get_current_value(), self.value_selected)
        mv = -1
        if get_current_value() <= 0:
            mv = self.get_current_min_value()
        self.min_menu_items = self.gen_menuitems(min_options, mv, self.minvalue_selected)

        fstitle = Gtk.MenuItem()
        fstitle.set_label(f"Fixed {title}")
        set_sensitive(fstitle, False)
        self.append(fstitle)
        self.append(Gtk.SeparatorMenuItem())
        for qi in self.menu_items.values():
            self.append(qi)
        mstitle = Gtk.MenuItem()
        mstitle.set_label(f"Minimum {title}:")
        set_sensitive(mstitle, False)
        self.append(mstitle)
        for qi in self.min_menu_items.values():
            self.append(qi)

        self.show_all()

    def gen_menuitems(self, options: dict[int, str],
                      value: int | None,
                      menu_selected_cb: Callable[[Gtk.Menu], None]
                      ) -> dict[int, Gtk.CheckMenuItem]:
        items: dict[int, Gtk.CheckMenuItem] = {}
        if value and value > 0 and value not in options:
            options[value] = f"{value}%"
        for s in sorted(options.keys()):
            t = options.get(s)
            qi = Gtk.CheckMenuItem(label=t)
            qi.connect("activate", menu_selected_cb)
            qi.set_draw_as_radio(True)
            candidate_match = s >= max(0, value)
            qi.set_active(not self.found_match and candidate_match)
            self.found_match |= candidate_match
            if s > 0:
                qi.set_tooltip_text(f"{s}%")
            items[s] = qi
        return items

    def value_selected(self, item: Gtk.CheckMenuItem) -> None:
        if not item.get_active() or self.updating:
            return
        try:
            self.updating = True
            # user selected a new value from the menu:
            s = -1
            for ts, tl in self.options.items():
                if tl == item.get_label():
                    s = ts
                    break
            if s >= 0 and s != self.get_current_value():
                log(f"setting {self.title} to {s}")
                self.set_value_cb(s)
                # deselect other items:
                for x in self.menu_items.values():
                    if x != item:
                        x.set_active(False)
                # min is only relevant in auto-mode:
                if s != 0:
                    for v, x in self.min_menu_items.items():
                        x.set_active(v == 0)
        finally:
            self.updating = False

    def minvalue_selected(self, item: Gtk.CheckMenuItem) -> None:
        if not item.get_active() or self.updating:
            return
        try:
            self.updating = True
            # user selected a new min-value from the menu:
            s = -1
            for ts, tl in self.min_options.items():
                if tl == item.get_label():
                    s = ts
                    break
            if s >= 0 and s != self.get_current_min_value():
                log(f"setting min-{self.title} to {s}")
                self.set_min_value_cb(s)
                # deselect other min items:
                for x in self.min_menu_items.values():
                    if x != item:
                        x.set_active(False)
                # min requires auto-mode:
                for x in self.menu_items.values():
                    if x.get_label() == "Auto":
                        if not x.get_active():
                            x.activate()
                    else:
                        x.set_active(False)
        finally:
            self.updating = False


def make_encodingsmenu(get_current_encoding: Callable, set_encoding: Callable,
                       encodings, server_encodings) -> Gtk.Menu:
    encodings_submenu = Gtk.Menu()
    populate_encodingsmenu(encodings_submenu, get_current_encoding, set_encoding, encodings, server_encodings)
    return encodings_submenu


def populate_encodingsmenu(encodings_submenu, get_current_encoding: Callable, set_encoding: Callable,
                           encodings, server_encodings) -> None:
    from xpra.codecs.loader import get_encoding_help, get_encoding_name
    encodings_submenu.get_current_encoding = get_current_encoding
    encodings_submenu.set_encoding = set_encoding
    encodings_submenu.encodings = encodings
    encodings_submenu.server_encodings = server_encodings
    encodings_submenu.index_to_encoding = {}
    encodings_submenu.encoding_to_index = {}
    NAME_TO_ENCODING = {}
    for i, encoding in enumerate(encodings):
        if encoding == "-":
            encodings_submenu.append(Gtk.SeparatorMenuItem())
            continue
        if encoding.startswith("label:"):
            if not HIDE_DISABLED_MENU_ENTRIES:
                label = Gtk.MenuItem()
                label.set_label(encoding.removeprefix("label:"))
                set_sensitive(label, False)
                encodings_submenu.append(label)
            continue
        name = get_encoding_name(encoding)
        descr = get_encoding_help(encoding)
        NAME_TO_ENCODING[name] = encoding
        encoding_item = Gtk.CheckMenuItem(label=name)
        if descr:
            if encoding not in server_encodings:
                descr += "\n(not available on this server)"
            encoding_item.set_tooltip_text(descr)

        def encoding_changed(item):
            ensure_item_selected(encodings_submenu, item)
            enc = NAME_TO_ENCODING.get(item.get_label())
            log("encoding_changed(%s) enc=%s, current=%s", item, enc, encodings_submenu.get_current_encoding())
            if enc is not None and encodings_submenu.get_current_encoding() != enc:
                encodings_submenu.set_encoding(enc)

        log("populate_encodingsmenu(..) encoding=%s, current=%s, active=%s",
            encoding, get_current_encoding(), encoding == get_current_encoding())
        encoding_item.set_active(encoding == get_current_encoding())
        sensitive = encoding in server_encodings
        if not sensitive and HIDE_DISABLED_MENU_ENTRIES:
            continue
        set_sensitive(encoding_item, encoding in server_encodings)
        encoding_item.set_draw_as_radio(True)
        encoding_item.connect("toggled", encoding_changed)
        encodings_submenu.append(encoding_item)
        encodings_submenu.index_to_encoding[i] = encoding
        encodings_submenu.encoding_to_index[encoding] = i
    encodings_submenu.show_all()


# pylint: disable=import-outside-toplevel


def gen_non_none_menu_items(*gen: Callable[[], Gtk.ImageMenuItem | Gtk.MenuItem | None]) -> Sequence[Gtk.ImageMenuItem | Gtk.MenuItem]:
    log("get_menu_items(%s)", gen)
    items: list[Gtk.ImageMenuItem | Gtk.MenuItem] = []
    for gen in gen:
        item = gen()
        if item:
            items.append(item)
    log("get_menu_items()=%s", items)
    return items


class GTKMenuHelper(MenuHelper):

    def setup_menu(self):
        log("setup_menu()")
        return self.do_setup_menu(self.get_menu_items())

    def do_setup_menu(self, items: Sequence[ImageMenuItem | MenuItem]):
        menu = Gtk.Menu()
        for menu_item in items:
            menu.append(menu_item)
        menu.connect("deactivate", self.menu_deactivated)
        menu.show_all()
        return menu

    def get_menu_items(self) -> list[ImageMenuItem | MenuItem]:
        raise NotImplementedError()

    def set_sensitive(self, menuitem, sensitive: bool):
        set_sensitive(menuitem, sensitive)

    def cleanup(self) -> None:
        super().cleanup()
        close_about()

    def do_show_menu(self, button: int, time) -> None:
        with IgnoreWarningsContext():
            self.menu.popup(None, None, None, None, button, time)

    def get_image(self, icon_name, size=None):
        # loading an icon is pure toolkit work, so do it here if the client
        # does not provide its own (the Gtk-free backends never do):
        get_image: Callable | None = getattr(self.client, "get_image", None)
        if get_image:
            # noinspection calling-non-callable
            return get_image(icon_name, size)
        with log.trap_error(f"Error getting image for icon name {icon_name} and size {size}"):
            from xpra.gtk.pixbuf import get_icon_pixbuf
            pixbuf = get_icon_pixbuf(icon_name)
            if not pixbuf:
                return None
            return scaled_image(pixbuf, size)
        return None

    def menuitem(self, title, icon_name="", tooltip="", cb: Callable = noop, **kwargs) -> ImageMenuItem:
        """ Utility method for easily creating an ImageMenuItem """
        image = None
        if MENU_ICONS:
            image = kwargs.get("image")
            if icon_name and not image:
                icon_size = self.menu_icon_size or 24
                image = self.get_image(icon_name, icon_size)

        # Gtk adds ImageMenuItem as arguments to the callback, but we don't want any:
        def menu_cb(*_args) -> None:
            if cb:
                cb()

        return menuitem(title, image, tooltip, menu_cb)

    def make_updatecheckmenuitem(self) -> ImageMenuItem:
        def show_update_window() -> None:
            from xpra.gtk.dialogs.update_status import get_update_status_window
            w = get_update_status_window()
            w.show()
            w.check()

        return self.menuitem(_("Check for updates"), "update.png", cb=show_update_window)

    def make_qrmenuitem(self) -> ImageMenuItem:
        try:
            from xpra.net.qrcode.qrencode import encode_image
        except ImportError as e:
            log(f"no qrcode support {e}")
            return None
        from xpra.gtk.dialogs.qrcode import show_qr

        def show() -> None:
            uri = self.client.display_desc.get("display_name")
            show_qr(uri)

        qr_menuitem = self.menuitem(_("Show QR connection string"), "qr.png", cb=show)
        log("make_qrmenuitem() qrencode.encode_image=%s", encode_image)
        if encode_image:
            def with_connection(*_args) -> None:
                uri = self.client.display_desc.get("display_name")
                if not uri or not any(uri.startswith(proto) for proto in ("tcp:", "ws:", "wss:")):
                    set_sensitive(qr_menuitem, False)
                    qr_menuitem.set_tooltip_text(_("server uri is not shareable"))

            self.after_handshake(with_connection)
        else:
            set_sensitive(qr_menuitem, False)
            qr_menuitem.set_tooltip_text(_("qrencode library is missing"))
        return qr_menuitem

    def make_sessioninfomenuitem(self) -> ImageMenuItem:
        def show_session_info_cb(*_args) -> None:
            # we define a generic callback to remove the arguments
            # (which contain the menu widget and are of no interest to the 'show_session_info' function)
            self.show_session_info()

        sessioninfomenuitem = self.handshake_menuitem(_("Session"), "statistics.png", cb=show_session_info_cb)
        return sessioninfomenuitem

    def make_bugreportmenuitem(self) -> ImageMenuItem:
        return self.menuitem(_("Bug Report"), "forward.png", cb=self.show_bug_report)

    def make_debugmenuitem(self) -> ImageMenuItem:
        return self.menuitem(_("Debug Logging"), "bugs.png", cb=self.show_debug_config)

    def make_closemenuitem(self) -> ImageMenuItem:
        return self.menuitem(_("Close Menu"), "close.png", cb=self.close_menu)

# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from xpra.os_util import gi_import
from xpra.util.objects import typedict
from xpra.util.str_fn import csv
from xpra.util.env import first_time, envbool
from xpra.util.thread import check_main_thread
from xpra.client.gtk3.window.stub_window import GtkStubWindow
from xpra.keyboard.common import KeyEvent, KEY_TRANSLATIONS
from xpra.log import Logger

Gdk = gi_import("Gdk")

log = Logger("window", "keyboard")

UNICODE_KEYNAMES = envbool("XPRA_UNICODE_KEYNAMES", False)


class KeyboardWindow(GtkStubWindow):

    def init_window(self, client, metadata: typedict, client_props: typedict) -> None:
        self.connect("key-press-event", self.handle_key_press_event)
        self.connect("key-release-event", self.handle_key_release_event)

    def get_window_event_mask(self) -> Gdk.EventMask:
        return Gdk.EventMask.KEY_PRESS_MASK | Gdk.EventMask.KEY_RELEASE_MASK

    def next_keyboard_layout(self, update_platform_layout) -> None:
        if kb := self.get_subsystem("keyboard"):
            kb.next_keyboard_layout(update_platform_layout)

    def keyboard_layout_changed(self, *args) -> None:
        # used by win32 hooks to tell us about keyboard layout changes for this window
        log("keyboard_layout_changed%s", args)
        if kb := self.get_subsystem("keyboard"):
            kb.window_keyboard_layout_changed(self)

    def parse_key_event(self, event, pressed: bool) -> KeyEvent:
        keyval = event.keyval
        keycode = event.hardware_keycode
        keyname = Gdk.keyval_name(keyval) or ""
        keyname = KEY_TRANSLATIONS.get((keyname, keyval, keycode), keyname)
        if keyname.startswith("U+") and not UNICODE_KEYNAMES:
            # workaround for MS Windows, try harder to find a valid key
            # see ticket #3417
            keymap = Gdk.Keymap.get_default()
            r = keymap.get_entries_for_keycode(event.hardware_keycode)
            if r[0]:
                for kc in r[2]:
                    keyname = Gdk.keyval_name(kc)
                    if not keyname.startswith("U+"):
                        break
        key_event = KeyEvent()
        # `mask_to_names` is owned by the `keyboard` subsystem (which may be absent):
        keyboard = self.get_subsystem("keyboard")
        key_event.modifiers = keyboard.mask_to_names(event.state) if keyboard else []
        key_event.keyname = keyname
        key_event.keyval = keyval or 0
        key_event.keycode = keycode
        key_event.group = event.group
        key_event.pressed = pressed
        key_event.string = ""
        try:
            # zero for the keys that have no character, ie: `Page_Up`:
            if codepoint := Gdk.keyval_to_unicode(keyval):
                key_event.string = chr(codepoint)
        except ValueError:
            log(f"failed to parse unicode string value of {event}", exc_info=True)
        if not key_event.string:
            # ie: `\r` for `KP_Enter`
            try:
                key_event.string = event.string or ""
            except UnicodeDecodeError as e:
                if first_time(f"key-{keycode}-{keyname}"):
                    log("parse_key_event(%s, %s)", event, pressed, exc_info=True)
                    log.warn("Warning: failed to parse string for key")
                    log.warn(f" {keyname=}, {keycode=}")
                    log.warn(f" {keyval=}, group={event.group}")
                    log.warn(" modifiers=%s", csv(key_event.modifiers))
                    log.warn(f" {e}")
        log("parse_key_event(%s, %s)=%s", event, pressed, key_event)
        return key_event

    def handle_key_press_event(self, _window, event) -> bool:
        # shortcuts may access the UI (menus, other windows, ...),
        # which crashes hard on some platforms (ie: macOS) if done off the main thread:
        check_main_thread()
        key_event = self.parse_key_event(event, True)
        if kb := self.get_subsystem("keyboard"):
            kb.handle_key_action(self, key_event)
        return True

    def handle_key_release_event(self, _window, event) -> bool:
        check_main_thread()
        key_event = self.parse_key_event(event, False)
        if kb := self.get_subsystem("keyboard"):
            kb.handle_key_action(self, key_event)
        return True

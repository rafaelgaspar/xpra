# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os.path
import signal
from typing import Any
from collections.abc import Callable

from xpra.server import features
from xpra.util.pid import load_pid
from xpra.util.env import envint
from xpra.util.parsing import str_to_bool
from xpra.scripts.session import load_session_file
from xpra.server.subsystem.stub import StubSubsystem
from xpra.log import Logger

log = Logger("dbus")

# how long `--dbus=wait` waits for the session bus, in seconds:
DBUS_WAIT = envint("XPRA_DBUS_WAIT", 30)


def reload_dbus_attributes(display_name: str) -> tuple[int, dict[str, str]]:
    session_dir = os.environ.get("XPRA_SESSION_DIR", "")
    dbus_pid = load_pid(os.path.join(session_dir, "dbus.pid"))
    try:
        dbus_env_data = load_session_file("dbus.env").decode("utf8")
        log(f"reload_dbus_attributes({display_name}) dbus_env_data={dbus_env_data}")
    except UnicodeDecodeError:
        log.error("Error decoding dbus.env file", exc_info=True)
        dbus_env_data = ""
    dbus_env = {}
    if dbus_env_data:
        for line in dbus_env_data.splitlines():
            if not line or line.startswith("#") or line.find("=") < 0:
                continue
            parts = line.split("=", 1)
            dbus_env[parts[0]] = parts[1]
    log(f"reload_dbus_attributes({display_name}) dbus_env={dbus_env}")
    dbus_address = dbus_env.get("DBUS_SESSION_BUS_ADDRESS")
    if not (dbus_pid and dbus_address):
        # less reliable: get it from the wminfo output:
        from xpra.scripts.display import exec_wminfo
        wminfo = exec_wminfo(display_name)
        if not dbus_pid:
            try:
                dbus_pid = int(wminfo.get("dbus-pid", 0))
            except ValueError:
                pass
        if not dbus_address:
            dbus_address = wminfo.get("dbus-address", "")
    if dbus_pid and os.path.exists("/proc") and not os.path.exists(f"/proc/{dbus_pid}"):
        log(f"dbus pid {dbus_pid} is no longer valid")
        dbus_pid = 0
    if dbus_pid:
        dbus_env["DBUS_SESSION_BUS_PID"] = str(dbus_pid)
    if dbus_address:
        dbus_env["DBUS_SESSION_BUS_ADDRESS"] = dbus_address
    if dbus_pid and dbus_address:
        log(f"retrieved dbus pid: {dbus_pid}, environment: {dbus_env}")
    return dbus_pid, dbus_env


def save_dbus_x11_properties(dbus_env: dict):
    # now we can save values on the display
    # (we cannot access bindings until dbus has started up)
    from xpra.x11.xroot_props import root_set

    def _save_int(prop_name, intval) -> None:
        root_set(prop_name, "u32", intval)

    def _save_str(prop_name, strval) -> None:
        root_set(prop_name, "latin1", strval)

    # DBUS_SESSION_BUS_ADDRESS=unix:abstract=/tmp/dbus-B8CDeWmam9,guid=b77f682bd8b57a5cc02f870556cbe9e9
    # DBUS_SESSION_BUS_PID=11406
    # DBUS_SESSION_BUS_WINDOWID=50331649
    attributes: list[tuple[str, type, Callable[[str, int | str], None]]] = [
        ("ADDRESS", str, _save_str),
        ("PID", int, _save_int),
        ("WINDOW_ID", int, _save_int),
    ]
    for name, conv, save in attributes:
        k = f"DBUS_SESSION_BUS_{name}"
        v = dbus_env.get(k, "")
        if not v:
            continue
        try:
            tv = conv(v)
            save(k, tv)
        except Exception as e:
            log("save_dbus_env(%s)", dbus_env, exc_info=True)
            log.error(f"Error: failed to save dbus environment variable {k!r}")
            log.error(f" with value {v!r}")
            log.estr(e)


class DbusManager(StubSubsystem):
    """
    Mixin for servers that have a dbus server associated with them
    """
    __slots__ = ("control", "enabled", "env", "launch", "pid", "service", "wait")
    PREFIX = "dbus"

    def __init__(self, server=None):
        StubSubsystem.__init__(self, server)
        self.enabled = False
        self.launch = "dbus-launch --sh-syntax --close-stderr"
        self.pid: int = 0
        self.env: dict[str, str] = {}
        self.control: bool = False
        self.service = None
        self.wait = False

    def init(self, opts) -> None:
        self.enabled = str_to_bool(opts.dbus)
        # use a session bus started by someone else, don't launch one:
        self.wait = str(opts.dbus).lower() == "wait"
        self.launch = opts.dbus_launch
        self.control = opts.dbus_control

    def early_setup(self) -> None:
        # the session bus must create its socket before confinement:
        if self.enabled:
            self.init_dbus_env()

    def setup(self) -> None:
        if self.enabled:
            # save the properties here rather than in `init_dbus_env`:
            # the X11 display connection is only opened by the preceding X11 subsystem's `setup`,
            # and this also updates them when the environment was reloaded from the session files
            if features.x11 and self.env:
                save_dbus_x11_properties(self.env)
            if self.control:
                from xpra.dbus.common import find_session_bus_address, DBUS_AUTOLAUNCH
                if find_session_bus_address() or DBUS_AUTOLAUNCH:
                    self.init_dbus_server()
                else:
                    log.info("no dbus session bus, the dbus control interface is not available")

    def init_dbus_env(self) -> None:
        log("init_dbus_env()")
        if not self.wait:
            display_name = os.environ.get("DISPLAY", "")
            self.pid, self.env = reload_dbus_attributes(display_name)
            if self.pid and self.env:
                os.environ.update(self.env)
                return
        try:
            from xpra.server.dbus.start import start_dbus, wait_for_dbus
        except ImportError as e:
            log("dbus components are not installed: %s", e)
            return
        if self.wait:
            # we don't own this bus: no pid and no session files, so we never stop it
            self.env = wait_for_dbus(DBUS_WAIT)
            os.environ.update(self.env)
            return
        self.pid, self.env = start_dbus(self.launch)
        if not self.env:
            return
        log(f"started new dbus instance: {self.env}")
        dbus_env_data = "\n".join(f"{k}={v}" for k, v in self.env.items()) + "\n"
        if sf := self.get_subsystem("session-files"):
            sf.write_session_file("dbus.pid", f"{self.pid}")
            sf.write_session_file("dbus.env", dbus_env_data.encode("utf8"))
            sf.session_files.extend(("dbus.pid", "dbus.env"))
        os.environ.update(self.env)

    def init_dbus_server(self) -> None:
        log("init_dbus_server() env: %s", {k: v for k, v in os.environ.items() if k.startswith("DBUS_")})
        # variant servers (e.g. ProxyServer) may override `make_dbus_server`
        # to return a server-specific DBus instance:
        make = getattr(self.server, "make_dbus_server", self.make_dbus_server)
        try:
            from xpra.server.dbus.common import dbus_exception_wrap
            self.service = dbus_exception_wrap(make, "setting up server dbus instance")
        except Exception as e:
            log("init_dbus_server()", exc_info=True)
            log.error("Error: cannot load dbus server:")
            log.estr(e)
            self.service = None

    def cleanup(self) -> None:
        ds = self.service
        log(f"cleanup() dbus_server={ds}")
        if ds:
            self.service = None
            ds.cleanup()

    def late_cleanup(self, stop=True) -> None:
        if stop:
            self.stop_dbus_server()

    def stop_dbus_server(self) -> None:
        log("stop_dbus_server() dbus_pid=%s", self.pid)
        if not self.pid:
            return
        try:
            os.kill(self.pid, signal.SIGINT)
        except ProcessLookupError:
            log("os.kill(%i, SIGINT)", self.pid, exc_info=True)
            log.warn(f"Warning: dbus process not found (pid={self.pid})")
        except Exception as e:
            log("os.kill(%i, SIGINT)", self.pid, exc_info=True)
            log.warn(f"Warning: error trying to stop dbus with pid {self.pid}:")
            log.warn(" %s", e)

    def make_dbus_server(self):  # pylint: disable=useless-return
        log(f"make_dbus_server() no dbus server for {self}")
        return None

    def get_info(self, _proto) -> dict[str, Any]:
        if not self.env:
            return {}
        info: dict[str, Any] = {"env": self.env}
        if self.pid:
            info["pid"] = self.pid
        return {DbusManager.PREFIX: info}

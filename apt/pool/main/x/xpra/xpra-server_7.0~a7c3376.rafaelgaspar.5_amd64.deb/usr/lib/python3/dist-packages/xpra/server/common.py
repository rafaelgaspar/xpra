# This file is part of Xpra.
# Copyright (C) 2026 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from typing import Final
from collections.abc import Sequence
from xpra.net.compression import Compressed

from xpra.common import noop
from xpra.net.common import BACKWARDS_COMPATIBLE
from xpra.util.env import envbool
from xpra.util.objects import typedict

GET_SOURCES_BY_TYPE: Final[str] = "get_sources_by_type"

SSH_AGENT_DISPATCH: bool = envbool("XPRA_SSH_AGENT_DISPATCH", os.name == "posix")


def wants_windows(caps: typedict) -> bool:
    """
    Whether the client wants window forwarding.
    Modern clients declare it in their `window` capabilities,
    older ones use a plural `windows` flag outside it
    (which the offscreen recorder used to send as a dictionary).
    """
    if window := caps.dictget("window"):
        return typedict(window).boolget("enabled", True)
    return BACKWARDS_COMPATIBLE and caps.boolget("windows")


def validate_rgb_formats(rgb_formats: Sequence[str], encodings: Sequence[str]) -> Sequence[str]:
    if not rgb_formats and any(e.startswith("rgb") for e in encodings):
        from xpra.log import Logger
        log = Logger("encoding")
        log.warn("Warning: client claims RGB encoding support")
        log.warn(" but no RGB pixel formats are available!")
        log.warn(" using RGBX as a fallback")
        return ("RGBX", )
    return rgb_formats


def get_sources_by_type(server, subsystem_type=object, exclude=None) -> Sequence:
    fn = getattr(server, GET_SOURCES_BY_TYPE, noop)
    if fn == noop:
        from xpra.log import Logger
        Logger("server").error("Error: no %r in %s", GET_SOURCES_BY_TYPE, server)
        return ()
    # noinspection none-function-assignment
    return fn(subsystem_type, exclude)


def may_update_bandwidth_limits(server) -> None:
    # this method is only available when the NetworkState mixin is enabled:
    update_bandwidth_limits = getattr(server, "update_bandwidth_limits", noop)
    update_bandwidth_limits()


def find_session_icon_filename(server) -> str:
    """Look up a desktop icon by the server's session name (POSIX only)."""
    if not server.session_name:
        return ""
    try:
        from xpra.platform.posix.menu_helper import find_icon
    except ImportError:
        return ""
    return find_icon(server.session_name) or ""


def make_icon_packet(*names: str) -> tuple[str, int, int, str, int, Compressed]:
    from xpra.codecs.image import to_png
    from xpra.platform.paths import get_icon_filename
    from xpra.util.io import load_binary_file
    from xpra.codecs.pillow.decoder import open_only
    from xpra.net.packet_type import DISPLAY_ICON
    for icon_name in names:
        if not icon_name:
            continue
        if os.path.isabs(icon_name) and os.path.exists(icon_name):
            filename = icon_name
        else:
            filename = get_icon_filename(icon_name)
            if not os.path.exists(filename):
                continue
        fdata = load_binary_file(filename)
        if not fdata:
            continue
        img = open_only(fdata)
        w, h = img.size
        data = to_png(img)
        return DISPLAY_ICON, w, h, "png", w*4, Compressed("png", data)
    raise RuntimeError("failed to locate any icons")

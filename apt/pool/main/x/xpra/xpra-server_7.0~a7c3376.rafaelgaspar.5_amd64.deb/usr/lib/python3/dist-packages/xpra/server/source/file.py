# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any

from xpra.util.objects import typedict
from xpra.net.common import BACKWARDS_COMPATIBLE
from xpra.net.file_transfer import FileTransferHandler
from xpra.server.source.stub import StubClientConnection


class FileConnection(FileTransferHandler, StubClientConnection):

    def __init__(self):
        FileTransferHandler.__init__(self)
        StubClientConnection.__init__(self)

    @classmethod
    def is_needed(cls, caps: typedict) -> bool:
        if "file" in caps:
            return True
        # printer forwarding shares this subsystem's state and packet handlers,
        # so this mixin is also required whenever `PrinterConnection` is:
        if caps.dictget("printer"):
            return True
        return bool(BACKWARDS_COMPATIBLE and (caps.boolget("file-transfer") or caps.boolget("printing")))

    def parse_client_caps(self, c: typedict) -> None:
        FileTransferHandler.parse_file_transfer_caps(self, c)

    def get_info(self) -> dict[str, Any]:
        return {
            "file-transfers": FileTransferHandler.get_info(self),
        }

    def init_from(self, _protocol, server) -> None:
        # (`__init__` has just called `init_attributes()` to reset the defaults)
        # `FileServer` is the standalone subsystem instance:
        file_transfer = server.subsystems["file"].file_transfer
        # copy attributes
        for x in (
                "file_transfer", "file_transfer_ask", "file_size_limit", "file_chunks",
                "open_files", "open_files_ask",
                "open_url", "open_url_ask",
                "file_ask_timeout", "open_command",
        ):
            setattr(self, x, getattr(file_transfer, x))

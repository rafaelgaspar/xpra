# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any
from collections.abc import Sequence

from xpra.net.common import BACKWARDS_COMPATIBLE
from xpra.net.packet_type import KEYBOARD_RECORD
from xpra.util.str_fn import Ellipsizer
from xpra.server.source.stub import StubClientConnection, is_recording_allowed
from xpra.keyboard.mask import DEFAULT_MODIFIER_MEANINGS
from xpra.util.objects import typedict
from xpra.log import Logger

log = Logger("keyboard")
ibuslog = Logger("ibus")


class KeyboardConnection(StubClientConnection):
    """
    Manage keyboard input
    """

    @classmethod
    def is_needed(cls, caps: typedict) -> bool:
        if caps.boolget("keyboard"):
            return True
        if BACKWARDS_COMPATIBLE:
            return bool(caps.get("xkbmap_keycodes"))  # legacy clients
        return False

    def init_state(self) -> None:
        self.keyboard_config = None
        self.keyboard_input = True
        self.ibus = False
        self.keyboard_record = False
        # how many key events this client has sent:
        # a client which never pressed a key cannot have left one pressed
        self.key_events = 0

    def cleanup(self) -> None:
        self.keyboard_config = None

    def requires_sharing(self) -> bool:
        return not self.keyboard_record

    def parse_client_caps(self, c: typedict) -> None:
        self.ibus = c.boolget("ibus")
        ibuslog(f"client ibus support: {self.ibus}")
        self.keyboard_input = c.boolget("keyboard.input", True)
        keyboard = c.get("keyboard")
        if isinstance(keyboard, dict) and typedict(keyboard).boolget("record", False):
            self.keyboard_record = is_recording_allowed(self, "keyboard")

    def get_info(self) -> dict[str, Any]:
        info: dict[str, Any] = {}
        kci = {
            "ibus": self.ibus,
            "input": self.keyboard_input,
            "record": self.keyboard_record,
            "key-events": self.key_events,
        }
        if kc := self.keyboard_config:
            kci.update(kc.get_info())
        info["keyboard"] = kci
        return info

    def get_caps(self) -> dict[str, Any]:
        caps: dict[str, Any] = {}
        # expose the "modifier_client_keycodes" defined in the X11 server keyboard config object,
        # so clients can figure out which modifiers map to which keys:
        mck = getattr(self.keyboard_config, "modifier_client_keycodes", None)
        if mck:
            caps["modifier_keycodes"] = mck
        modifiers = getattr(self.keyboard_config, "keynames_for_mod", {})
        if modifiers:
            caps["modifiers-keynames"] = modifiers
        return caps

    def send_ibus_layouts(self, ibus_layouts: dict) -> None:
        ibuslog(f"send_ibus_layouts(%s) {self.ibus=}", Ellipsizer(ibus_layouts))
        if self.ibus and ibus_layouts:
            self.send_setting_change("ibus-layouts", ibus_layouts)

    def set_layout(self, layout: str, variant: str, options) -> bool:
        if not self.keyboard_config:
            return False
        return self.keyboard_config.set_layout(layout, variant, options)

    def keys_changed(self) -> None:
        if kc := self.keyboard_config:
            kc.keys_changed()
        log("keys_changed() updated keyboard config=%s", self.keyboard_config)

    def make_keymask_match(self, modifiers: Sequence[str], ignored_modifier_keycode=0, ignored_modifier_keynames=None) -> None:
        kc = self.keyboard_config
        if kc and kc.enabled:
            kc.make_keymask_match(modifiers, ignored_modifier_keycode, ignored_modifier_keynames)

    def set_default_keymap(self):
        log("set_default_keymap() keyboard_config=%s", self.keyboard_config)
        if kc := self.keyboard_config:
            kc.set_default_keymap()
        return kc

    def is_modifier(self, keyname: str, keycode: int) -> bool:
        if keyname in DEFAULT_MODIFIER_MEANINGS:
            return True
        # keyboard config should always exist if we are here?
        if kc := self.keyboard_config:
            return kc.is_modifier(keycode)
        return False

    def set_keymap(self, current_keyboard_config, current_id: str, keys_pressed, force: bool = False,
                   translate_only: bool = False) -> None:
        kc = self.keyboard_config
        log("set_keymap%s keyboard_config=%s",
            (current_keyboard_config, current_id, keys_pressed, force, translate_only), kc)
        if kc and kc.enabled:
            keymap_id = kc.get_hash()
            log("current keyboard id=%s, new keyboard id=%s", current_id, keymap_id)
            if force or not current_id or keymap_id != current_id:
                kc.keys_pressed = keys_pressed
                kc.apply(translate_only)
                kc.owner = self.uuid
            else:
                log.info("keyboard mapping already configured (skipped)")
                self.keyboard_config = current_keyboard_config

    def get_keycode(self, client_keycode: int, keyname: str, pressed: bool,
                    modifiers: list[str], keyval, keystr: str, group: int) -> tuple[int, int]:
        kc = self.keyboard_config
        if kc is None:
            log.info("ignoring client key %s / %s since keyboard is not configured", client_keycode, keyname)
            return -1, 0
        return kc.get_keycode(client_keycode, keyname, pressed, modifiers, keyval, keystr, group)

    def record_key(self, wid: int, press: bool, name: str,
                   keyval: int, keycode: int, modifiers: Sequence[str], is_mod: bool, sync: bool) -> None:
        self.send_async(KEYBOARD_RECORD, wid, {
            "press": press,
            "name": name,
            "keyval": keyval,
            "keycode": keycode,
            "modifiers": modifiers,
            "is-modifier": is_mod,
            "sync": sync,
        })

# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any

from xpra.server.subsystem.stub import StubSubsystem
from xpra.util.thread import start_thread
from xpra.util.version import get_platform_info


class PlatformServer(StubSubsystem):
    """
    Exposes platform info, populates the cache during threaded initialization.
    """
    __slots__ = ()
    PREFIX = "platform"

    def setup(self) -> None:
        start_thread(get_platform_info, "get-platform-info", daemon=True)

    def get_info(self, _proto) -> dict[str, Any]:
        return {
            PlatformServer.PREFIX: get_platform_info(),
        }

    def get_caps(self, _source) -> dict[str, Any]:
        return self.get_info(None)

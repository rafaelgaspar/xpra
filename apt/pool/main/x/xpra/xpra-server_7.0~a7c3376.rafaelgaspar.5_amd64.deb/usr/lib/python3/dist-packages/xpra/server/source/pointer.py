# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from math import copysign
from typing import Any

from xpra.net.common import BACKWARDS_COMPATIBLE
from xpra.server.source.stub import StubClientConnection, PointerSource, is_sync_allowed
from xpra.util.objects import typedict
from xpra.log import Logger

log = Logger("pointer")


class PointerConnection(StubClientConnection, PointerSource):
    """
    Manage pointer devices (mouse, etc)
    """

    @classmethod
    def is_needed(cls, caps: typedict) -> bool:
        if caps.boolget("pointer"):
            return True
        return BACKWARDS_COMPATIBLE and (caps.boolget("mouse") or caps.boolget("mouse.show"))

    def init_state(self) -> None:
        self.double_click_time: int = -1
        self.double_click_distance: tuple[int, int] | None = None
        # mouse echo:
        self.mouse_last_position: tuple[int, int] = (0, 0)
        self.mouse_last_relative_position: tuple[int, int] | None = None
        # send the pointer events of the other clients to this client?
        # (used by the recording client, and by clients using `sharing=sync`)
        self.pointer_sync = False
        # wheel emulation: the fraction of a click left over
        # from the events already emulated, per wheel axis - see `wheel_steps`:
        self.wheel_remainder: dict[int, float] = {}

    def requires_sharing(self) -> bool:
        return not self.pointer_sync

    def parse_client_caps(self, c: typedict) -> None:
        pointer = typedict(c.dictget("pointer"))
        # `record` is the legacy name for `sync`:
        sync = pointer.boolget("sync", pointer.boolget("record", False))
        self.pointer_sync = sync and is_sync_allowed(self, "pointer")
        log(f"parse_client_caps(..) {pointer=}")
        dc = typedict(pointer.dictget("double_click"))
        if dc or "initial-position" in pointer or not BACKWARDS_COMPATIBLE:
            self.double_click_time = dc.intget("time", -1)
            self.double_click_distance = dc.intpair("distance", (-1, -1))
            self.mouse_last_position = pointer.intpair("initial-position")
        else:
            # try top-level:
            dc = typedict(c.dictget("double_click"))
            if dc:
                self.double_click_time = dc.intget("time", -1)
                self.double_click_distance = dc.intpair("distance", (-1, -1))
            else:
                self.double_click_time = c.intget("double_click.time", -1)
                self.double_click_distance = c.intpair("double_click.distance", (-1, -1))
            self.mouse_last_position = c.intpair("mouse.initial-position")
        log("parse_client_caps(..) double-click=%s, position=%s",
            (self.double_click_time, self.double_click_distance), self.mouse_last_position)

    def get_info(self) -> dict[str, Any]:
        dc_info: dict[str, Any] = {}
        if dct := self.double_click_time:
            dc_info["time"] = dct
        if dcd := self.double_click_distance:
            dc_info["distance"] = dcd
        info: dict[str, Any] = {"sync": self.pointer_sync}
        if dc_info:
            info["double-click"] = dc_info
        return info

    def wheel_steps(self, button: int, distance: float) -> int:
        """
        How many discrete wheel clicks this fractional `distance` is worth,
        carrying whatever is left over to the next event.
        `distance` is the value the client has already scaled to wheel clicks
        using its own scroll speed settings (the `scaled-distance` property).
        What is carried over is always less than half a click, so a fraction
        owed in the other direction can only ever shorten the next scroll,
        never reverse it - which is why the button never needs flipping.
        """
        # buttons 4 and 5 are the two directions of the same axis, as are 6 and 7, etc:
        axis = max(0, button - 4) // 2
        total = distance + self.wheel_remainder.get(axis, 0)
        steps = round(abs(total))
        self.wheel_remainder[axis] = total - copysign(steps, total)
        log("wheel_steps(%i, %.3f)=%i clicks, remainder=%.3f",
            button, distance, steps, self.wheel_remainder[axis])
        return steps

    def update_mouse(self, wid: int, x: int, y: int, rx: int, ry: int) -> None:
        log("update_mouse(%s, %i, %i, %i, %i) current=%s, client=%i",
            wid, x, y, rx, ry, self.mouse_last_position, self.counter)
        # `sharing=combine`: the pointer position is absolute,
        # so it must be translated to this client's area of the virtual display
        # (`rx`, `ry` are relative to the window and need no adjustment):
        if to_client_position := getattr(self, "to_client_position", None):
            # noinspection calling-non-callable
            x, y = to_client_position(x, y)
        if self.mouse_last_position != (x, y) or self.mouse_last_relative_position != (rx, ry):
            self.mouse_last_position = (x, y)
            self.mouse_last_relative_position = (rx, ry)
            self.send_async("pointer-position", wid, x, y, rx, ry)

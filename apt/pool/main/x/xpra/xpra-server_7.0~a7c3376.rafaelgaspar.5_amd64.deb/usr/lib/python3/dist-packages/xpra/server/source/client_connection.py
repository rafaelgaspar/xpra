# This file is part of Xpra.
# Copyright (C) 2011 Serviware (Arthur Huillet, <ahuillet@serviware.com>)
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any, TypeAlias
from collections.abc import Callable, Sequence
from time import sleep, monotonic
from threading import Event, Lock
from collections import deque
from queue import SimpleQueue

from xpra.net.packet_type import INFO_RESPONSE
from xpra.util.thread import start_thread
from xpra.util.objects import AtomicInteger, notypedict
from xpra.util.env import envbool
from xpra.net.common import Packet, PacketElement, FULL_INFO
from xpra.net.compression import compressed_wrapper, Compressed, LevelCompressed
from xpra.server.source.source_stats import GlobalPerformanceStatistics
from xpra.server.source.stub import StubClientConnection
from xpra.log import Logger

log = Logger("server")
notifylog = Logger("notify")

YIELD = envbool("XPRA_YIELD", False)

counter = AtomicInteger()

ENCODE_WORK_ITEM_TUPLE = tuple[Callable, Sequence[Any]]
ENCODE_WORK_ITEM: TypeAlias = ENCODE_WORK_ITEM_TUPLE | None


class ClientConnection(StubClientConnection):
    """
    This class mediates between the server class
    (which only knows about actual window objects and display server events)
    and the client specific WindowSource instances (which only know about window ids
    and manage window pixel compression).
    It sends messages to the client via its 'protocol' instance (the network connection),
    directly for a number of cases (cursor, audio, notifications, etc.)
    or on behalf of the window sources for pixel data.

    Strategy: if we have 'ordinary_packets' to send, send those.
    When we don't, then send packets from the 'packet_queue'. (compressed pixels or clipboard data)
    See 'next_packet'.

    The UI thread calls damage(), which goes into WindowSource and eventually (batching may be involved)
    adds the damage pixels ready for processing to the encode_work_queue,
    items are picked off by the separate 'encode' thread (see 'encode_loop')
    and added to the damage_packet_queue.
    """
    # fired by the `suspend` server subsystem directly on this connection object:
    __signals__ = ["suspend", "resume"]

    def __init__(self, protocol, disconnect_cb: Callable, setting_changed: Callable[[str, Any], None]):
        StubClientConnection.__init__(self)
        self.counter = counter.increase()
        self.protocol = protocol
        self.connection_time = monotonic()
        self.close_event = Event()
        self.disconnect = disconnect_cb

        # holds actual packets ready for sending (already encoded)
        # these packets are picked off by the "protocol" via 'next_packet()'
        # format: packet, wid, pixels, start_send_cb, end_send_cb
        # (only packet is required - the rest can be 0/None for clipboard packets)
        self.packet_queue = deque[tuple[Packet, int, int, bool]]()
        # the encode work queue is used by subsystem that need to encode data before sending it,
        # ie: encodings and clipboard
        # this queue will hold functions to call to compress data (pixels, clipboard)
        # items placed in this queue are picked off by the "encode" thread,
        # the functions should add the packets they generate to the 'packet_queue'
        self.encode_work_queue: SimpleQueue[ENCODE_WORK_ITEM] = SimpleQueue()
        self.encode_thread = None
        self.encode_thread_lock = Lock()
        # functions to call from the encode thread when closing,
        # once every subsystem has queued the encoding work it needed:
        self.encode_at_end: list[tuple[Callable, Sequence[Any]]] = []
        self.ordinary_packets: list[tuple[Packet, bool, bool]] = []

        self.suspended = False
        self.client_packet_types = ()
        self.setting_changed = setting_changed
        self.queue_encode: Callable[[ENCODE_WORK_ITEM], None] = self.start_queue_encode

        def suspend() -> None:
            self.suspended = True

        def resume() -> None:
            self.suspended = False

        self.connect("suspend", suspend)
        self.connect("resume", resume)

    def enable_connection(self) -> None:
        # ready for processing:
        self.protocol.set_packet_source(self.next_packet)

    def __repr__(self) -> str:
        classname = type(self).__name__
        return f"{classname}({self.counter} : {self.protocol})"

    def init_state(self) -> None:
        self.hello_sent = 0.0
        self.wants = ["encodings", "versions", "features", "display", "packet-types"]
        # these statistics are shared by all WindowSource instances:
        self.statistics = GlobalPerformanceStatistics()

    def is_closed(self) -> bool:
        return self.close_event.is_set()

    def cleanup(self) -> None:
        log("%s.cleanup()", self)
        self.close_event.set()
        self.stop_encode_thread()
        self.protocol = None
        self.statistics.reset(0)

    def compressed_wrapper(self, datatype, data, **kwargs) -> Compressed | LevelCompressed:
        # set compression flags based on self.lz4:
        kw = {"lz4": getattr(self, "lz4", False)}
        kw.update(kwargs)
        return compressed_wrapper(datatype, data, can_inline=False, **kw)

    def startup_complete(self) -> None:
        log("startup_complete()")
        self.send("startup-complete")

    # The encode thread loop management:
    #
    def start_queue_encode(self, item: ENCODE_WORK_ITEM) -> None:
        # start the encode work queue:
        # holds functions to call to compress data (pixels, clipboard)
        # items placed in this queue are picked off by the "encode" thread,
        # the functions should add the packets they generate to the 'packet_queue'
        # this can be called concurrently from more than one thread,
        # and we must only ever start a single encode thread:
        # threads that got here with a stale `queue_encode` reference
        # just queue their item, in the order in which they acquire the lock
        put = self.encode_work_queue.put
        with self.encode_thread_lock:
            if not self.encode_thread:
                self.encode_thread = start_thread(self.encode_loop, "encode")
                self.queue_encode = put
            put(item)

    def encode_queue_size(self) -> int:
        return self.encode_work_queue.qsize()

    def call_in_encode_thread(self, fn: Callable, *args) -> None:
        """
            This is used by WindowSource to queue damage processing to be done in the 'encode' thread.
            The 'encode_and_send_cb' will then add the resulting packet to the 'packet_queue' via 'queue_packet'.
            Every item queued here is guaranteed to be called, even when closing:
            the callbacks own the resources they are given (images, encoders, etc)
            and are responsible for checking if the work is still needed - see `is_cancelled`.
        """
        self.statistics.compression_work_qsizes.append((monotonic(), self.encode_queue_size()))
        self.queue_encode((fn, args))

    def call_in_encode_thread_at_end(self, fn: Callable, *args) -> None:
        """
            Queue a function to be called from the 'encode' thread when this connection is closed,
            after every subsystem has been cleaned up and has queued all of its encoding work.
            This is how the resources shared with the encoders are released:
            the cuda context and the mmap areas can only be freed
            once the encode thread has finished using them.
        """
        self.encode_at_end.append((fn, args))

    def stop_encode_thread(self) -> None:
        # this subsystem is always the first one in `CC_BASES` and the subsystems
        # are cleaned up in reverse order, so we get here last:
        # all the other subsystems have queued the encoding work they needed,
        # which makes it safe to run the deferred cleanups and to add the end of queue marker
        at_end = self.encode_at_end
        self.encode_at_end = []
        for fn, args in at_end:
            self.queue_encode((False, fn, args))
        self.queue_encode(None)

    def queue_packet(self, packet: Packet, wid=0, pixels=0,
                     wait_for_more=False) -> None:
        """
            Add a new 'draw' packet to the 'packet_queue'.
            Note: this code runs in the non-ui thread
        """
        now = monotonic()
        self.statistics.packet_qsizes.append((now, len(self.packet_queue)))
        if wid > 0:
            self.statistics.damage_packet_qpixels.append(
                (now, wid, sum(x[2] for x in tuple(self.packet_queue) if x[1] == wid))
            )
        self.packet_queue.append((packet, wid, pixels, wait_for_more))
        if p := self.protocol:
            p.source_has_more()

    def encode_loop(self) -> None:
        """
            This runs in a separate thread and calls all the function callbacks
            which are added to the 'encode_work_queue'.
            Must run until we hit the end of queue marker,
            to ensure all the queued items get called:
            the callbacks are the ones deciding if the work is still needed,
            since they are the ones owning the resources that must be released.
        """
        while True:
            item = self.encode_work_queue.get(True)
            if item is None:
                return  # empty marker
            fn, args = item
            try:
                fn(*args)
            except Exception as e:
                if self.is_closed():
                    log("ignoring encoding error calling %s because the source is already closed:", item)
                    log(" %s", e)
                else:
                    log.error("Error during encoding:", exc_info=True)
                del e
            if YIELD:
                sleep(0)

    ######################################################################
    # network:
    def next_packet(self) -> tuple[Packet, bool, bool]:
        """ Called by protocol.py when it is ready to send the next packet """
        if self.is_closed():
            return Packet("closed"), False, False
        synchronous = True
        more = False
        if self.ordinary_packets:
            packet, synchronous, more = self.ordinary_packets.pop(0)
        elif self.packet_queue:
            packet, _, _, more = self.packet_queue.popleft()
        else:
            packet = Packet("none")
        if not more:
            more = bool(packet) and bool(self.ordinary_packets or self.packet_queue)
        return packet, synchronous, more

    def send(self, packet_type: str, *parts: PacketElement, **kwargs) -> None:
        """ This method queues non-damage packets (higher priority) """
        synchronous = bool(kwargs.get("synchronous", True))
        will_have_more = bool(kwargs.get("will_have_more", not synchronous))
        if p := self.protocol:
            packet = Packet(packet_type, *parts)
            self.ordinary_packets.append((packet, synchronous, will_have_more))
            p.source_has_more()

    def send_more(self, packet_type: str, *parts: PacketElement, **kwargs) -> None:
        kwargs["will_have_more"] = True
        self.send(packet_type, *parts, **kwargs)

    def send_async(self, packet_type: str, *parts: PacketElement, **kwargs) -> None:
        kwargs["synchronous"] = False
        kwargs["will_have_more"] = False
        self.send(packet_type, *parts, **kwargs)

    ######################################################################
    # info:
    def get_info(self) -> dict[str, Any]:
        if not FULL_INFO:
            return {"protocol": "xpra"}
        info = {
            "protocol": "xpra",
            "connection_time": int(self.connection_time),
            "elapsed_time": int(monotonic() - self.connection_time),
            "counter": self.counter,
            "hello-sent": bool(self.hello_sent),
            "packet-types": self.client_packet_types,
        }
        if p := self.protocol:
            info["connection"] = p.get_info()
        return info

    def send_info_response(self, info: dict) -> None:
        self.send_async(INFO_RESPONSE, notypedict(info))

    def send_setting_change(self, setting: str, value: PacketElement) -> None:
        self.send_more("setting-change", setting, value)

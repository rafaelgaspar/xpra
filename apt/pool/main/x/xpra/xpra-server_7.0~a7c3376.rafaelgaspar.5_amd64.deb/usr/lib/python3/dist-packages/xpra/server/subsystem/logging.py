# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.
# pylint: disable-msg=E1101

import sys
import logging
import traceback
from time import monotonic
from threading import Lock
from typing import Any
from collections.abc import Callable

from xpra.common import noop
from xpra.net.packet_type import LOGGING_EVENT
from xpra.util.str_fn import repr_ellipsized, memoryview_to_bytes, single_line
from xpra.net.common import Packet, BACKWARDS_COMPATIBLE
from xpra.util.parsing import TRUE_OPTIONS, FALSE_OPTIONS
from xpra.server.subsystem.stub import StubSubsystem
from xpra.log import Logger, set_global_logging_handler, get_info as get_log_info

log = Logger("server")


def decode(v) -> str:
    if isinstance(v, str):
        return v
    return memoryview_to_bytes(v).decode("utf8")


class LoggingManager(StubSubsystem):
    """
    Mixin for servers that can receive and send logging packets
    """
    __slots__ = ("both", "clients", "in_handler", "local_handler", "lock", "receive", "send")
    PREFIX = "logging"

    def __init__(self, server=None):
        StubSubsystem.__init__(self, server)
        self.send: bool = False
        self.receive: bool = False
        self.lock: Lock = Lock()
        self.both: bool = False
        self.in_handler: bool = False
        self.local_handler: Callable = noop
        self.clients: dict[Any, float] = {}

    def init(self, opts) -> None:
        self.both = (opts.remote_logging or "").lower() == "both"
        if opts.remote_logging.lower() not in FALSE_OPTIONS:
            self.send = opts.remote_logging.lower() in ("allow", "send", "both")
            # "yes" is here for backwards compatibility:
            self.receive = opts.remote_logging.lower() in ["allow", "receive", "both"] + list(
                TRUE_OPTIONS)

    def setup(self) -> None:
        self.add_log_control_commands()

    def add_log_control_commands(self) -> None:
        from xpra.net.control.common import add_control_command
        from xpra.net.control.debug import DebugControl
        add_control_command(self, "debug", DebugControl())

    def cleanup(self) -> None:
        self.stop_capturing_logging()

    def get_server_features(self, _source=None) -> dict[str, Any]:
        return {"remote-logging": self._features()}

    def _features(self) -> dict[str, Any]:
        return {
            "receive": self.receive,
            "send": self.send,
        }

    def get_info(self, _proto) -> dict[str, Any]:
        info = get_log_info()
        info.update(self._features())
        return {
            LoggingManager.PREFIX: info,
        }

    def cleanup_protocol(self, protocol) -> None:
        if protocol in self.clients:
            del self.clients[protocol]

    def remove_logging_client(self, protocol) -> None:
        if self.clients.pop(protocol, None) is None:
            log.warn("Warning: logging was not enabled for '%r'", protocol)
        if not self.clients:
            self.stop_capturing_logging()

    def add_logging_client(self, protocol) -> None:
        n = len(self.clients)
        if protocol in self.clients:
            log.warn("Warning: logging already enabled for client %s", protocol)
            return
        log.info("sending log output to %s", protocol)
        self.clients[protocol] = monotonic()
        if n == 0:
            self.start_capturing_logging()

    def start_capturing_logging(self) -> None:
        if self.local_handler == noop:
            self.local_handler = set_global_logging_handler(self.remote_logging_handler)

    def stop_capturing_logging(self) -> None:
        ll = self.local_handler
        if ll != noop:
            self.local_handler = noop
            set_global_logging_handler(ll)

    def local_err(self, message: str, exc, level: int, msg: str, args, kwargs) -> None:
        ll = self.local_handler
        if self.server._closing or ll == noop:
            return

        def local_warn(*args) -> None:
            ll(log, logging.WARNING, *args)
        local_warn("Warning: %s:", message)
        if exc:
            local_warn(" %s", exc)
        local_warn(" original unformatted message: %s", msg)
        if args:
            local_warn(" %i arguments: %s", len(args), args)
        else:
            local_warn(" (no arguments)")
        try:
            if ll:
                ll(log, level, msg, *args, **kwargs)
        except Exception:
            pass
        try:
            exc_info = sys.exc_info()
            for x in traceback.format_tb(exc_info[2]):
                for v in x.splitlines():
                    local_warn(v)
        except Exception:
            pass

    def remote_logging_handler(self, log, level: int, msg, *args, **kwargs) -> None:
        # prevent loops (if our send call ends up firing another logging call):
        if self.in_handler:
            return
        ll = self.local_handler
        self.in_handler = True

        def local_warn(message: str, *args) -> None:
            ll(log, logging.WARNING, message, *args)

        try:
            if not kwargs.pop("remote", True):
                if ll:
                    try:
                        ll(log, level, msg, *args, **kwargs)
                    except Exception as e:
                        local_warn("Warning: failed to log message locally")
                        local_warn(" %s", e)
                        local_warn(" %s", msg)
                return
            try:
                if args:
                    data = msg % args
                else:
                    data = msg
            except Exception as e:
                self.local_err("failed to format log message", e, level, msg, args, kwargs)
                return
            for proto, start_time in self.clients.items():
                source = self.get_server_source(proto)
                if not source:
                    continue
                try:
                    dtime = int(1000 * (monotonic() - start_time))
                    if len(data) >= 32:
                        try:
                            data = source.compressed_wrapper("text", data.encode("utf8"), level=1)
                        except Exception:
                            pass
                    source.send(LOGGING_EVENT, level, data, dtime)
                    exc_info = kwargs.get("exc_info")
                    # noinspection PySimplifyBooleanCheck
                    if exc_info is True:
                        exc_info = sys.exc_info()
                    if exc_info and exc_info[0]:
                        for x in traceback.format_tb(exc_info[2]):
                            source.send(LOGGING_EVENT, level, x, dtime)
                        try:
                            etypeinfo = exc_info[0].__name__
                        except AttributeError:
                            etypeinfo = str(exc_info[0])
                        source.send(LOGGING_EVENT, level, "%s: %s" % (etypeinfo, exc_info[1]), dtime)
                except Exception as e:
                    if self.server._closing:
                        return
                    if ll:
                        local_warn("Warning: failed to send log message to %s: %s", source, e)
            if self.both and ll:
                try:
                    ll(log, level, msg, *args, **kwargs)
                except Exception:
                    pass
        finally:
            self.in_handler = False

    def _process_control(self, proto, packet: Packet) -> None:
        action = packet.get_str(1)
        if action == "start":
            self.add_logging_client(proto)
        elif action == "stop":
            self.remove_logging_client(proto)
        else:
            log.warn("Warning: unknown logging-control action '%r'", action)

    def _process_logging(self, proto, packet: Packet) -> None:
        assert BACKWARDS_COMPATIBLE
        self._process_event(proto, packet)

    def _process_event(self, proto, packet: Packet) -> None:
        assert self.receive
        ss = self.get_server_source(proto)
        if ss is None:
            return
        level = packet.get_u8(1)
        if BACKWARDS_COMPATIBLE:
            msg = packet[2]
            if isinstance(msg, (tuple, list)):
                dmsg = " ".join(decode(x) for x in msg)
            else:
                dmsg = decode(msg)
        else:
            dmsg = decode(packet.get_buffer(2))
        prefix = "client "
        counter = getattr(ss, "counter", 0)
        if counter > 0:
            prefix += "%3i " % counter
        if len(packet) >= 4:
            dtime = packet.get_u64(3)
            prefix += "@%02i.%03i " % ((dtime // 1000) % 60, dtime % 1000)
        try:
            # strip the control characters, ie: terminal escape sequences:
            for line in dmsg.splitlines():
                self.do_log(level, prefix + single_line(line))
        except Exception as e:
            log("log message decoding error", exc_info=True)
            log.error("Error: failed to parse logging message:")
            log.error(" %s", repr_ellipsized(dmsg))
            log.estr(e)

    def do_log(self, level, line) -> None:
        with self.lock:
            log.log(level, line)

    def init_packet_handlers(self) -> None:
        if self.receive:
            self.add_packets("logging-event")
            self.add_legacy_alias("logging", "logging-event")
        if self.send:
            self.add_packets("logging-control")

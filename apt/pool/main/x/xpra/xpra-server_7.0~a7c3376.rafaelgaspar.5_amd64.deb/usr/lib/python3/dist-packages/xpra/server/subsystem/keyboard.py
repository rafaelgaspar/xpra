# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.
# pylint: disable-msg=E1101

from typing import Any
from time import monotonic

from xpra.net.constants import ConnectionMessage
from xpra.server.source.keyboard import KeyboardConnection
from xpra.util.env import envbool
from xpra.util.str_fn import Ellipsizer, csv
from xpra.util.objects import typedict
from xpra.common import noerr
from xpra.net.common import Packet, BACKWARDS_COMPATIBLE
from xpra.server.subsystem.stub import StubSubsystem
from xpra.log import Logger

log = Logger("keyboard")

# Keyboard-as-scroll heuristic: certain keypresses (PageDown, arrow keys, etc.)
# almost always cause the focused window's content to scroll vertically.
# Treat their press as a scroll event for downstream consumers (chiefly image
# filters that want to learn about scrolls beyond wheel events).
# Auto-repeat naturally re-emits while the key is held.
#
#   XPRA_KEYBOARD_SCROLL_ENABLED  master switch
#
# Conservative key set: avoids Space (typing collisions) and Left/Right
# (rare for vertical scrolling, common in text editing).
KEYBOARD_SCROLL_ENABLED = envbool("XPRA_KEYBOARD_SCROLL_ENABLED", False)
KEYBOARD_SCROLL_KEYNAMES: frozenset[str] = frozenset({
    "Page_Up", "Page_Down", "Prior", "Next",
    "Home", "End",
    "Up", "Down",
})


class KeyboardManager(StubSubsystem):
    """
    Mixin for servers that handle keyboards
    """
    __slots__ = (
        "config", "config_hash", "device", "key_repeat_delay", "key_repeat_interval", "key_repeat_timer",
        "keymap_changing_timer", "keymap_options", "keys_pressed", "keys_timedout", "mod_meanings",
    )
    PREFIX = "keyboard"
    BACKEND = ""

    def __init__(self, server=None):
        StubSubsystem.__init__(self, server)
        self.keymap_options: dict[str, Any] = {}
        self.mod_meanings = {}
        self.device = None
        self.config = None
        # the hash of `config` as it was when it was applied:
        # (`config` is mutable and may have been modified since, so we cannot hash it again to find out)
        self.config_hash = ""
        self.keymap_changing_timer = 0  # to ignore events when we know we are changing the configuration
        # ugly: we're duplicating the value pair from "key_repeat" here:
        self.key_repeat_delay = -1
        self.key_repeat_interval = -1
        # store list of currently pressed keys
        # (using a dict only so we can display their names in debug messages)
        self.keys_pressed: dict[int, str] = {}
        self.keys_timedout: dict[int, float] = {}
        # timers for cancelling key repeat when we get jitter
        self.key_repeat_timer = 0
        self.keys_pressed: dict[int, Any] = {}

    def init(self, opts) -> None:
        for option in ("sync", "layout", "layouts", "variant", "variants", "options"):
            v = getattr(opts, f"keyboard_{option}", None)
            if v is not None:
                self.keymap_options[option] = v

    def setup(self) -> None:
        self.device = self.make_keyboard_device()
        if not self.device:
            log.warn("Warning: keyboard device not available, using NoKeyboardDevice")
            from xpra.keyboard.nokeyboard import NoKeyboardDevice
            self.device = NoKeyboardDevice()
        log("keyboard_device=%s", self.device)

        self.set_current_config(self.get_keyboard_config({"keymap": self.keymap_options}))
        self.server.connect("client-exited", self.client_exited)
        self.server.connect("setting-changed", self.setting_changed_handler)
        self.add_keyboard_control_commands()

    def add_keyboard_control_commands(self) -> None:
        self.args_control("key", "press or unpress a key", min_args=1, max_args=2)

    def make_keyboard_device(self):
        from xpra.platform.keyboard import get_keyboard_device
        return get_keyboard_device()

    def set_current_config(self, config) -> None:
        """ record the keyboard config currently applied, together with the hash it had at that point """
        self.config = config
        self.config_hash = config.get_hash() if (config and config.enabled) else ""
        log("set_current_config(%s) hash=%s", config, self.config_hash)

    def cleanup(self) -> None:
        self.stop_keymap_timer()
        noerr(self.clear_keys_pressed)
        self.config = None
        self.config_hash = ""

    def keymap_changed(self, *_args) -> None:
        if self.keymap_changing_timer:
            return
        self.keymap_changing_timer = self.timeout_add(500, self.do_keymap_changed)

    def do_keymap_changed(self) -> None:
        self.keymap_changing_timer = 0
        self._keys_changed()

    def stop_keymap_timer(self) -> None:
        if kct := self.keymap_changing_timer:
            self.keymap_changing_timer = 0
            self.source_remove(kct)

    def get_ui_info(self, _proto, **kwargs) -> dict[str, Any]:
        info = self.get_keyboard_info()
        device = self.device
        if not self.server.readonly and device:
            info["state"] = {
                "keys_pressed": tuple(self.keys_pressed.keys()),
                "keycodes-down": device.get_keycodes_down(),
                "layout-group": device.get_layout_group(),
                "key-repeat": {
                    "delay": self.key_repeat_delay,
                    "interval": self.key_repeat_interval,
                }
            }
        return {"keyboard": info}

    def get_server_features(self, _source=None) -> dict[str, Any]:
        return {
            "keyboard": True,
        }

    def get_caps(self, _source) -> dict[str, Any]:
        caps: dict[str, Any] = {
            "key_repeat": (self.key_repeat_delay, self.key_repeat_interval),
        }
        if self.BACKEND:
            caps["backend"] = self.BACKEND
        if BACKWARDS_COMPATIBLE:
            caps["key_repeat_modifiers"] = True
            caps["keyboard.fast-switching"] = True
        return caps

    def parse_hello(self, ss, caps: typedict) -> str | ConnectionMessage:
        self.parse_hello_ui_keyboard(ss, caps)
        return ""

    def watch_keymap_changes(self) -> None:
        """ GTK servers will start listening for the 'keys-changed' signal """

    def parse_hello_ui_keyboard(self, ss, c: typedict) -> None:
        if not getattr(ss, "keyboard_input", False):
            return
        keyboard_clients = self.get_sources_by_type(KeyboardConnection, ss)
        ss.keyboard_config = self.get_keyboard_config(c)  # pylint: disable=assignment-from-none

        delay, interval = (500, 30)
        if not any(source.keyboard_input for source in keyboard_clients):
            # so only activate this feature afterwards:
            delay, interval = c.intpair("key_repeat", (500, 30))
            # always clear modifiers before setting a new keymap
            ss.make_keymask_match(c.strtupleget("modifiers"))
        self.set_keyboard_repeat(delay, interval)
        if not typedict(c.dictget("keymap")).boolget("delay"):
            # this client is not going to send its keyboard config separately,
            # (ie: clients older than v6.5, or with `XPRA_DELAY_KEYBOARD_DATA=0`)
            # so the hello packet is all the keyboard data we are ever going to get:
            self.set_keymap(ss)

    def get_keyboard_info(self) -> dict[str, Any]:
        start = monotonic()
        info = {
            "repeat": {
                "delay": self.key_repeat_delay,
                "interval": self.key_repeat_interval,
            },
            "keys_pressed": tuple(self.keys_pressed.values()),
            "modifiers": self.mod_meanings,
        }
        if kc := self.config:
            info.update(kc.get_info())
        log("get_keyboard_info took %ims", (monotonic() - start) * 1000)
        return info

    def _process_layout_changed(self, proto, packet: Packet) -> None:
        assert BACKWARDS_COMPATIBLE
        log(f"layout-changed: {packet}")
        if self.is_readonly(proto):
            return
        ss = self.get_server_source(proto)
        if not ss:
            return
        layout = packet.get_str(1)
        variant = packet.get_str(2)
        options = backend = name = ""
        if len(packet) >= 4:
            options = packet.get_str(3)
        if len(packet) >= 6:
            backend = packet.get_str(4)
            name = packet.get_str(5)
        self.set_backend(ss, backend, name)
        if ss.set_layout(layout, variant, options):
            self.set_keymap(ss, force=True)

    def set_backend(self, ss, backend: str, name: str) -> None:
        """ overriden in X11 keyboard module """

    def _process_keymap_changed(self, proto, packet: Packet) -> None:
        assert BACKWARDS_COMPATIBLE
        if self.is_readonly(proto):
            return
        props = typedict(packet.get_dict(1))
        force = True
        if len(packet) > 2:
            force = packet.get_bool(2)
        ss = self.get_server_source(proto)
        if ss is None:
            return
        log("received new keymap from client: %s", Ellipsizer(packet, limit=200))
        kc = getattr(ss, "keyboard_config", None)
        if not kc or not kc.enabled:
            return
        if kc.parse_options(props) or force:
            ss.make_keymask_match([])
            self.set_keymap(ss, force)
        if "modifiers" in props:
            ss.make_keymask_match(props.strtupleget("modifiers"))

    def _process_config(self, proto, packet: Packet) -> None:
        if self.is_readonly(proto):
            return
        props = typedict(packet.get_dict(1))
        ss = self.get_server_source(proto)
        if ss is None:
            return
        kc = getattr(ss, "keyboard_config", None)
        if not kc or not kc.enabled:
            return

        force = props.boolget("force", False)
        if kc.parse(props) or force:
            ss.make_keymask_match([])
            self.set_keymap(ss, force)
        if "modifiers" in props:
            ss.make_keymask_match(props.strtupleget("modifiers"))

    def _process_key_action(self, proto, packet: Packet) -> None:
        assert BACKWARDS_COMPATIBLE
        wid = packet.get_wid()
        keyname = packet.get_str(2)
        pressed = packet.get_bool(3)

        # `get_keycode` may have to change modifiers to match the key, so we need a mutable list:
        modifiers = list(packet.get_strs(4))
        keyval = packet.get_u32(5)
        keystr = packet.get_str(6)
        keycode = packet.get_u32(7)
        group = packet.get_u8(8)

        attrs = {
            "modifiers": modifiers,
            "keyval": keyval,
            "string": keystr,
            "keycode": keycode,
            "group": group,
        }
        self.do_process_keyboard_event(proto, wid, keyname, pressed, attrs)

    def _process_event(self, proto, packet: Packet) -> None:
        wid = packet.get_wid()
        keyname = packet.get_str(2)
        pressed = packet.get_bool(3)
        attrs = packet.get_dict(4)
        self.do_process_keyboard_event(proto, wid, keyname, pressed, attrs)

    def do_process_keyboard_event(self, proto, wid: int, keyname: str, pressed: bool, kattrs: dict) -> None:
        if self.is_readonly(proto):
            return
        attrs = typedict(kattrs)
        # `get_keycode` may have to change modifiers to match the key, so we need a mutable list:
        modifiers = list(attrs.strtupleget("modifiers", []))
        keyval = attrs.intget("keyval", 0)
        keystr = attrs.strget("string", "")
        client_keycode = attrs.intget("keycode", 0)
        group = attrs.intget("group", 0)
        ss = self.get_server_source(proto)
        keyboard_config = getattr(ss, "keyboard_config", None)
        log(f"keyboard event: {wid=}, {keyname=!r}, {pressed}, {attrs}, {keyboard_config=}")
        if not keyboard_config:
            return
        ss.key_events += 1
        self.server.set_ui_driver(ss)
        keycode, group = self.get_keycode(ss, client_keycode, keyname, pressed, modifiers, keyval, keystr, group)
        log("do_process_keyboard_event%s server keycode=%s, group=%i",
            (proto, wid, keyname, pressed, attrs), keycode, group)
        if group >= 0 and keycode >= 0:
            self.set_keyboard_layout_group(group)
        if window := self.get_subsystem("window"):
            window._focus(ss, wid, None)
        ss.make_keymask_match(modifiers, keycode, ignored_modifier_keynames=[keyname])
        # negative keycodes are used for key events without a real keypress/unpress
        # for example, used by win32 to send Caps_Lock/Num_Lock changes
        if keycode >= 0:
            try:
                is_mod = ss.is_modifier(keyname, keycode)
                self._handle_key(wid, pressed, keyname, keyval, keycode, modifiers, is_mod, ss.keyboard_config.sync)
            except Exception as e:
                log("process_key_action%s", (proto, wid, keyname, pressed, attrs), exc_info=True)
                log.error("Error: failed to %s key", ["unpress", "press"][pressed])
                log.estr(e)
                log.error(" for keyname=%s, keyval=%i, keycode=%i", keyname, keyval, keycode)
        ss.user_event("key-action")
        # Keyboard-as-scroll: notify window sources that the user just triggered
        # a scroll-equivalent keypress.
        if KEYBOARD_SCROLL_ENABLED and pressed and wid and keyname in KEYBOARD_SCROLL_KEYNAMES:
            log("keyboard-as-scroll: wid=%i keyname=%r", wid, keyname)
            try:
                window_sources = self.window_sources()
            except AttributeError:
                window_sources = ()
            for ws in window_sources:
                if rec := getattr(ws, "record_scroll_event", None):
                    # noinspection calling-non-callable
                    rec(wid)

    def get_keycode(self, ss, client_keycode: int, keyname: str,
                    pressed: bool, modifiers: list[str], keyval: int, keystr: str, group: int):
        return ss.get_keycode(client_keycode, keyname, pressed, modifiers, keyval, keystr, group)

    def fake_key(self, keycode: int, press: bool) -> None:
        log("fake_key(%s, %s)", keycode, press)
        if self.device:
            self.device.press_key(keycode, press)

    def _handle_key(self, wid: int, pressed: bool, name: str, keyval: int, keycode: int,
                    modifiers: list, is_mod: bool = False, sync: bool = True):
        """
            Does the actual press/unpress for keys
            Either from a packet (_process_key_action) or timeout (_key_repeat_timeout)
        """
        log("handle_key(%s)", (wid, pressed, name, keyval, keycode, modifiers, is_mod, sync))
        if pressed and wid:
            window = self.get_subsystem("window")
            if window is not None and not window.get_window(wid):
                log("window %s is gone, ignoring key press", wid)
                return
        if keycode < 0:
            log.warn("ignoring invalid keycode=%s", keycode)
            return
        if keycode in self.keys_timedout:
            del self.keys_timedout[keycode]

        keyboard_sources = self.get_sources_by_type(KeyboardConnection)
        record_connections = tuple(x for x in keyboard_sources if x.keyboard_record)

        def record(press: bool) -> None:
            for ss in record_connections:
                ss.record_key(wid, press, name, keyval, keycode, modifiers, is_mod, sync)

        def press() -> None:
            log("handle keycode pressing   %3i: key '%s'", keycode, name)
            record(True)
            self.keys_pressed[keycode] = name
            self.fake_key(keycode, True)

        def unpress() -> None:
            log("handle keycode unpressing %3i: key '%s'", keycode, name)
            if keycode in self.keys_pressed:
                del self.keys_pressed[keycode]
            record(False)
            self.fake_key(keycode, False)

        if pressed:
            if keycode not in self.keys_pressed:
                press()
                if not sync and not is_mod:
                    # keyboard is not synced: client manages repeat so unpress
                    # it immediately unless this is a modifier key
                    # (as modifiers are synced via many packets: key, focus and mouse events)
                    unpress()
            else:
                log("handle keycode %s: key %s was already pressed, ignoring", keycode, name)
        else:
            if keycode in self.keys_pressed:
                unpress()
            else:
                log("handle keycode %s: key %s was already unpressed, ignoring", keycode, name)
        if not is_mod and sync and self.key_repeat_delay > 0 and self.key_repeat_interval > 0:
            self._key_repeat(wid, pressed, name, keyval, keycode, modifiers, is_mod, self.key_repeat_delay)

    def cancel_key_repeat_timer(self) -> None:
        if krt := self.key_repeat_timer:
            self.key_repeat_timer = 0
            self.source_remove(krt)

    def _key_repeat(self, wid: int, pressed: bool, keyname: str, keyval: int, keycode: int,
                    modifiers: list, is_mod: bool, delay_ms: int = 0) -> None:
        """ Schedules/cancels the key repeat timeouts """
        self.cancel_key_repeat_timer()
        if pressed:
            delay_ms = min(2000, max(1000, delay_ms))
            log("scheduling key repeat timer with delay %s for %s / %s", delay_ms, keyname, keycode)
            now = monotonic()
            self.key_repeat_timer = self.timeout_add(delay_ms, self._key_repeat_timeout,
                                                     now, delay_ms, wid, keyname, keyval, keycode, modifiers, is_mod)

    def _key_repeat_timeout(self, when, delay_ms: int, wid: int, keyname: str, keyval: int, keycode: int,
                            modifiers: list, is_mod: bool) -> None:
        self.key_repeat_timer = 0
        now = monotonic()
        log("key repeat timeout for %s / '%s' - clearing it, now=%s, scheduled at %s with delay=%s",
            keyname, keycode, now, when, delay_ms)
        self._handle_key(wid, False, keyname, keyval, keycode, modifiers, is_mod, True)
        self.keys_timedout[keycode] = now

    def _process_key_repeat(self, _proto, _packet: Packet) -> None:
        assert BACKWARDS_COMPATIBLE

    def _process_sync(self, proto, packet: Packet) -> None:
        if self.is_readonly(proto):
            return
        ss = self.get_server_source(proto)
        if not hasattr(ss, "keyboard_config"):
            return
        kc = ss.keyboard_config
        if kc:
            kc.sync = packet.get_bool(1)
            log("toggled keyboard-sync to %s for %s", kc.sync, ss)

    def _keys_changed(self) -> None:
        log("input server: the keymap has been changed, keymap_changing_timer=%s", self.keymap_changing_timer)
        if not self.keymap_changing_timer:
            keyboard_sources = self.get_sources_by_type(KeyboardConnection)
            for ss in keyboard_sources:
                ss.keys_changed()

    @staticmethod
    def used_keyboard(ss) -> bool:
        """
        True if this client has sent us key events, so it may have left one pressed.
        The clients which only watch (ie: a `record` client) never send any,
        and the connections which have no keyboard at all cannot.
        """
        return isinstance(ss, KeyboardConnection) and bool(ss.key_events)

    def setting_changed_handler(self, _server, setting: str, value, ss=None) -> None:
        if setting != "readonly" or not value:
            return
        # a client which has just become readonly can no longer unpress
        # the keys it was holding down: its key events are dropped from now on
        if ss is not None and not self.used_keyboard(ss):
            return
        log("readonly enabled for %s, settling the keys pressed: %s", ss or "the server", self.keys_pressed)
        self.clear_keys_pressed()

    def client_exited(self, _server, ss) -> None:
        log("client_exited(%s) used keyboard=%s, keys pressed=%s", ss, self.used_keyboard(ss), self.keys_pressed)
        if self.used_keyboard(ss):
            # Client cleanup runs from the protocol reader thread.  The input
            # device may use X11/XTest, which must only be accessed by the
            # main thread.
            self.idle_add(self.clear_keys_pressed)

    def clear_keys_pressed(self, *args) -> None:
        """
        Release the keys we are still holding down.

        This runs even when the server is readonly, unlike `control_command_key`:
        these releases are not new input, they complete the presses we injected
        ourselves. Refusing them would not keep anything out of the session,
        it would leave a key stuck in it - and stuck for good, since `cleanup`
        and the `key` control command would then refuse to release it too.
        """
        log("clear_keys_pressed%s", args)
        # make sure the timer doesn't fire and interfere:
        self.cancel_key_repeat_timer()
        keycodes = tuple(self.keys_pressed.keys())
        self.device.clear_keys_pressed(keycodes)
        self.keys_pressed = {}

    def set_keyboard_layout_group(self, grp: int) -> None:
        """ overriden in x11 keyboard """

    def set_keyboard_repeat(self, delay: int, interval: int) -> None:
        self.key_repeat_delay = delay
        self.key_repeat_interval = interval
        device = self.device
        if not device:
            return
        device.set_repeat_rate(delay, interval)

    def get_keyboard_config(self, props=None) -> Any | None:
        log("get_keyboard_config(%s) is not implemented", props)
        return None

    def set_keymap(self, server_source, force=False) -> None:
        log("set_keymap(%s, %s)", server_source, force)

    def set_default_keymap(self, server_source) -> None:
        log("set_default_keymap(%s)", server_source)
        server_source.set_default_keymap()

    def init_packet_handlers(self) -> None:
        if BACKWARDS_COMPATIBLE:
            self.add_packets(
                # keyboard:
                "key-action", "key-repeat", "layout-changed", "keymap-changed",
                main_thread=True
            )
            self.add_packet_handler("set-keyboard-sync-enabled", self._process_sync, True)
            self.add_packet_handler("keyboard-sync-enabled-status", self._process_sync, True)

        self.add_packets(
            "keyboard-event", "keyboard-config", "keyboard-sync",
            main_thread=True
        )

    #########################################
    # Control Commands
    #########################################

    def control_command_key(self, keycode_str: str, press) -> str:
        if self.server.readonly:
            return "command key denied by readonly mode"
        from xpra.net.control.common import ControlError
        try:
            if keycode_str.startswith("0x"):
                keycode = int(keycode_str, 16)
            else:
                keycode = int(keycode_str)
        except ValueError:
            raise ControlError(f"invalid keycode specified: {keycode_str!r} (not a number)") from None
        if keycode <= 0 or keycode >= 255:
            raise ControlError(f"invalid keycode value: {keycode} (must be between 1 and 255)")
        if press is not True:
            if press in ("1", "press"):
                press = True
            elif press in ("0", "unpress"):
                press = False
            else:
                raise ControlError("if present, the press argument must be one of: " + csv(
                    ("1", "press", "0", "unpress")))
        self.fake_key(keycode, press)
        return ("pressed" if press else "unpressed") + f" {keycode}"

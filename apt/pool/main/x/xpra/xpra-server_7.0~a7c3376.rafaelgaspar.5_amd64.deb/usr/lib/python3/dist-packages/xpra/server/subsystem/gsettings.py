# This file is part of Xpra.
# Copyright (C) 2026 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

from typing import Any

from xpra.os_util import gi_import, OSX, WIN32
from xpra.util.str_fn import bytestostr
from xpra.net.common import Packet
from xpra.util.gsettings import (
    parse_gsettings_option, gsettings_match, parse_gsettings_key,
    parse_gsettings_value,
)
from xpra.server.subsystem.stub import StubSubsystem
from xpra.log import Logger

Gio = gi_import("Gio")

log = Logger("server", "gsettings")


class GSettingsServer(StubSubsystem):
    """
    Applies an allowlisted set of GSettings forwarded by a single connected client,
    layered on top of the server-side `defaults` baseline.

    The original value of every key we modify is saved and restored when the server
    shuts down. Client overrides are reverted (back to the baseline) whenever more than
    one client is connected, or when the last client disconnects - because the server
    session is shared and there is no sensible way to merge conflicting preferences.
    """
    __slots__ = ("allowlist", "defaults", "original", "sync_enabled")

    PREFIX = "gsettings"

    def __init__(self, server=None):
        super().__init__(server)
        self.sync_enabled = False
        # the (schema, key) regular expressions we are willing to accept from the client:
        self.allowlist: tuple[tuple[str, str], ...] = ()
        # server-side baseline applied for the server's lifetime,
        # variant servers may inject values here - {(schema, key): gvariant_text}:
        self.defaults: dict[tuple[str, str], str] = {}
        # the original value of every key we have modified - {(schema, key): GLib.Variant}:
        self.original: dict[tuple[str, str], Any] = {}

    def init(self, opts) -> None:
        # `auto` enables synchronization of the default allowlist
        # everywhere except MacOS and MS Windows,
        # selectors control client access while assignments define the
        # server-side baseline:
        self.allowlist, self.defaults = parse_gsettings_option(opts.gsettings_sync, not (OSX or WIN32))
        self.sync_enabled = bool(self.allowlist or self.defaults)
        log("gsettings_sync(%s)=%s, allowlist=%s, defaults=%s",
            opts.gsettings_sync, self.sync_enabled, self.allowlist, self.defaults)

    def setup(self) -> None:
        if self.sync_enabled:
            self.server.connect("setting-changed", self.setting_changed_handler)
            self.update_gsettings()

    def setting_changed_handler(self, _server, setting: str, _value, _ss=None) -> None:
        # a client which becomes readonly loses its overrides, and gets them back
        # when it stops being readonly (`setting-change` packets are not processed
        # in the main thread, and `Gio.Settings` must only be used from there):
        if setting == "readonly":
            self.idle_add(self.update_gsettings)

    def cleanup(self) -> None:
        # stop applying, then restore everything we touched to its original value:
        self.sync_enabled = False
        for sk, variant in tuple(self.original.items()):
            self._set(sk, variant)
        self.original = {}

    def get_caps(self, _source) -> dict[str, Any]:
        if self.allowlist:
            return {"gsettings": True}
        return {}

    def get_info(self, _proto) -> dict[str, Any]:
        return {
            "gsettings": {
                "enabled": self.sync_enabled,
                "defaults": {f"{schema}:{key}": value for (schema, key), value in self.defaults.items()},
                "allowlist": tuple(f"{schema}:{key}" for schema, key in self.allowlist),
            }
        }

    def init_packet_handlers(self) -> None:
        self.add_packets("gsettings-update", main_thread=True)

    def _process_update(self, proto, packet: Packet) -> None:
        if self.is_readonly(proto):
            log("ignoring gsettings update from readonly client %s", proto)
            return
        ss = self.get_server_source(proto)
        if not ss:
            return
        gsettings = getattr(ss, "gsettings", None)
        if gsettings is None:
            return
        settings = packet.get_dict(1)
        for name, value in settings.items():
            try:
                sk = parse_gsettings_key(bytestostr(name))
            except ValueError:
                continue
            if self.allowed(sk):
                gsettings[sk] = bytestostr(value)
            else:
                log("skipped %r - not found in allow list", sk)
        log("updated client gsettings: %s", gsettings)
        self.update_gsettings()

    def add_new_client(self, ss, c) -> None:
        self.update_gsettings()

    def cleanup_protocol(self, protocol) -> None:
        # the source has already been removed from the server at this point,
        # so we can re-evaluate which settings (if any) should be applied:
        self.update_gsettings()

    # --- core apply / restore logic ---

    def allowed(self, sk: tuple[str, str]) -> bool:
        return gsettings_match(self.allowlist, *sk)

    def desired(self) -> dict[tuple[str, str], str]:
        target = dict(self.defaults)
        sources = tuple(self.server._server_sources.values())
        # only honour client values when exactly one client is connected,
        # and that client is allowed to modify the session:
        if len(sources) == 1 and not self.source_readonly(sources[0]):
            for sk, value in getattr(sources[0], "gsettings", {}).items():
                if self.allowed(sk):
                    target[sk] = value
        return target

    def source_readonly(self, ss) -> bool:
        if getattr(self.server, "readonly", False):
            return True
        return bool(getattr(ss, "effective_readonly", lambda: False)())

    def update_gsettings(self) -> None:
        if not self.sync_enabled:
            return
        target = self.desired()
        log("update_gsettings() target=%s", target)
        for sk in target:
            self._ensure_original(sk)
        for sk, original in self.original.items():
            text = target.get(sk)
            if text is None:
                # key no longer targeted: revert to its original value
                self._set(sk, original)
                continue
            original = self.original.get(sk)
            expected_type = original.get_type_string() if original is not None else ""
            variant = parse_gsettings_value(text, expected_type)
            if variant is not None:
                self._set(sk, variant)

    @staticmethod
    def _get_settings(schema_id: str, key: str):
        # return a `Gio.Settings` only if the schema exists and contains the key
        # (calling `get_value` on a missing key would abort the process):
        source = Gio.SettingsSchemaSource.get_default()
        schema = source.lookup(schema_id, True)
        if not schema or not schema.has_key(key):
            return None
        return Gio.Settings.new(schema_id)

    def _ensure_original(self, sk: tuple[str, str]) -> None:
        if sk in self.original:
            return
        schema, key = sk
        try:
            s = self._get_settings(schema, key)
            if s is not None:
                self.original[sk] = s.get_value(key)
        except Exception as e:
            log("error reading gsettings %s:%s", schema, key, exc_info=True)
            log.error("Error reading GSettings %r / %r:", schema, key)
            log.estr(e)

    def _set(self, sk: tuple[str, str], variant) -> None:
        schema, key = sk
        try:
            s = self._get_settings(schema, key)
            if s is None:
                return
            current = s.get_value(key)
            if variant.get_type_string() != current.get_type_string():
                log("skipping gsettings %s:%s: type mismatch (%s vs %s)",
                    schema, key, variant.get_type_string(), current.get_type_string())
                return
            if current.equal(variant):
                return
            log("setting gsettings %s:%s=%s", schema, key, variant.print_(True))
            s.set_value(key, variant)
        except Exception as e:
            log("error setting gsettings %s:%s=%s", schema, key, variant, exc_info=True)
            log.error("Error setting GSettings %r / %r:", schema, key)
            log.estr(e)

# This file is part of Xpra.
# Copyright (C) 2020 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.
# pylint: disable-msg=E1101

from collections import deque
from typing import Any

from xpra.server.subsystem.stub import StubSubsystem
from xpra.net.common import Packet


class ShellServer(StubSubsystem):
    """
    Mixin for adding `shell` support
    """
    __slots__ = ("commands", "counter")
    PREFIX = "shell"

    def __init__(self, server=None):
        StubSubsystem.__init__(self, server)
        self.counter = 0
        self.commands: deque[str] = deque(maxlen=10)

    def get_info(self, _source=None) -> dict[str, Any]:
        return {
            ShellServer.PREFIX: {
                "counter": self.counter,
                "last-commands": list(self.commands),
            },
        }

    def get_server_features(self, _source) -> dict[str, Any]:
        return {
            ShellServer.PREFIX: True,
        }

    def _process_exec(self, proto, packet: Packet) -> None:
        code = packet.get_str(1)
        if ss := self.get_server_source(proto):
            self.counter += 1
            self.commands.append(code)
            ss.shell_exec(code)

    def init_packet_handlers(self) -> None:
        self.add_packets("shell-exec")

# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.
# pylint: disable-msg=E1101

from typing import Any

from xpra.server.subsystem.stub import StubSubsystem
from xpra.util.objects import typedict
from xpra.util.parsing import parse_with_unit
from xpra.util.stats import std_unit
from xpra.net.common import Packet, BACKWARDS_COMPATIBLE
from xpra.util.env import envint
from xpra.log import Logger

log = Logger("network", "bandwidth")

MIN_BANDWIDTH_LIMIT = envint("XPRA_MIN_BANDWIDTH_LIMIT", 1024 * 1024)
MAX_BANDWIDTH_LIMIT = envint("XPRA_MAX_BANDWIDTH_LIMIT", 10 * 1024 * 1024 * 1024)


class BandwidthManager(StubSubsystem):
    """
    Adds bandwidth management
    """
    __slots__ = ("detection", "limit")
    PREFIX = "bandwidth"

    @classmethod
    def is_needed(cls, caps: typedict) -> bool:
        if BACKWARDS_COMPATIBLE and caps.boolget("network-state"):
            return True
        return caps.boolget("bandwidth")

    def __init__(self, server=None):
        StubSubsystem.__init__(self, server)
        self.limit = 0
        self.detection = False

    def init(self, opts) -> None:
        self.limit = parse_with_unit("bandwidth-limit", opts.bandwidth_limit) or 0
        self.detection = opts.bandwidth_detection
        log("bandwidth-limit(%s)=%s", opts.bandwidth_limit, self.limit)

    def get_info(self, _source=None) -> dict[str, Any]:
        info = {
            "limit": self.limit or 0,
            "detection": self.detection,
        }
        return {BandwidthManager.PREFIX: info}

    def get_server_features(self, source=None) -> dict[str, Any]:
        caps = BandwidthManager.get_info(self, source)
        if BACKWARDS_COMPATIBLE:
            caps["network"] = {
                "bandwidth-limit": self.limit or 0,
                "bandwidth-detection": self.detection
            }
        return caps

    def _process_status(self, proto, packet: Packet) -> None:
        if ss := self.get_server_source(proto):
            ss.update_connection_data(packet.get_dict(1))

    def _process_limit(self, proto, packet: Packet) -> None:
        log("_process_limit(%s, %s)", proto, packet)
        ss = self.get_server_source(proto)
        if not ss:
            return
        bandwidth_limit = packet.get_u64(1)
        if (self.limit and bandwidth_limit >= self.limit) or bandwidth_limit <= 0:
            bandwidth_limit = self.limit or 0
        if ss.bandwidth_limit == bandwidth_limit:
            # unchanged
            log("bandwidth limit unchanged: %s", std_unit(bandwidth_limit))
            return
        if bandwidth_limit < MIN_BANDWIDTH_LIMIT:
            log.warn("Warning: bandwidth limit requested is too low (%s)", std_unit(bandwidth_limit))
            bandwidth_limit = MIN_BANDWIDTH_LIMIT
        if bandwidth_limit >= MAX_BANDWIDTH_LIMIT:
            log("bandwidth limit over maximum, using no-limit instead")
            bandwidth_limit = 0
        ss.bandwidth_limit = bandwidth_limit
        # we can't assume to have a full ClientConnection object:
        client_id = getattr(ss, "counter", "")
        if bandwidth_limit == 0:
            log.info("bandwidth-limit restrictions removed for client %s", client_id)
        else:
            log.info("bandwidth-limit changed to %sbps for client %s", std_unit(bandwidth_limit), client_id)

    def init_packet_handlers(self) -> None:
        self.add_packets("bandwidth-status", "bandwidth-limit")
        if BACKWARDS_COMPATIBLE:
            self.add_legacy_alias("connection-data", "bandwidth-status")

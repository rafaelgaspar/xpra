# This file is part of Xpra.
# Copyright (C) 2011 Serviware (Arthur Huillet, <ahuillet@serviware.com>)
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from typing import Any
from threading import Event, Lock
from collections.abc import Sequence

from xpra.codecs.constants import preforder, STREAM_ENCODINGS, VIDEO_LEVELS
from xpra.codecs.loader import load_codec, codec_versions, has_codec, get_codec, unload_codecs
from xpra.codecs.video import getVideoHelper
from xpra.util.parsing import parse_bool_or_int
from xpra.common import noop
from xpra.client.gui.window.backing import VIDEO_MAX_SIZE
from xpra.net.common import Packet, FULL_INFO, BACKWARDS_COMPATIBLE
from xpra.net import compression
from xpra.util.objects import typedict
from xpra.util.str_fn import csv
from xpra.util.env import envint, envbool
from xpra.client.base.stub import StubClientSubsystem
from xpra.log import Logger
from xpra.util.thread import start_thread

log = Logger("client", "encoding")

# the hardware decoders disabled under seccomp, which would load their libraries on the decode thread:
SECCOMP_HARDWARE_DECODERS: dict[str, str] = {
    "nvdec": "xpra.codecs.nvidia.nvdec.decoder",
    "nvjpeg": "xpra.codecs.nvidia.nvjpeg.decoder",
    "vpl": "xpra.codecs.vpl.decoder",
}

CODEC_LOAD_TIMEOUT = envint("XPRA_CODEC_LOAD_TIMEOUT", 30)
B_FRAMES = envbool("XPRA_B_FRAMES", True)
PAINT_FLUSH = envbool("XPRA_PAINT_FLUSH", True)
MAX_SOFT_EXPIRED = envint("XPRA_MAX_SOFT_EXPIRED", 5)
SEND_TIMESTAMPS = envbool("XPRA_SEND_TIMESTAMPS", False)
SCROLL_ENCODING = envbool("XPRA_SCROLL_ENCODING", True)

# we assume that any server will support at least those:
DEFAULT_ENCODINGS = os.environ.get("XPRA_DEFAULT_ENCODINGS", "rgb32,rgb24,jpeg,png").split(",")


def get_core_encodings() -> Sequence[str]:
    """
        This method returns the actual encodings supported.
        ie: ["rgb24", "vp8", "webp", "png", "png/L", "png/P", "jpeg", "h264", "vpx"]
        It is often overridden in the actual client class implementations,
        where extra encodings can be added (generally just 'rgb32' for transparency),
        or removed if the toolkit implementation class is more limited.
    """
    # we always support rgb:
    core_encodings = ["rgb24", "rgb32"]
    for codec in ("dec_pillow", "dec_webp", "dec_jpeg", "dec_nvjpeg", "dec_avif", "dec_jph"):
        if has_codec(codec):
            c = get_codec(codec)
            encs = c.get_encodings()
            log("%s.get_encodings()=%s", codec, encs)
            for e in encs:
                if e not in core_encodings:
                    core_encodings.append(e)
    if SCROLL_ENCODING:
        core_encodings.append("scroll")
    # we enable all the video decoders we know about,
    # but what will actually get used by the server will still depend
    # on the csc modes supported by the client
    video_decodings = getVideoHelper().get_decodings()
    log("video_decodings=%s", video_decodings)
    for encoding in video_decodings:
        if encoding not in core_encodings:
            core_encodings.append(encoding)
    # remove duplicates and use preferred encoding order:
    return preforder(core_encodings)


def get_batch_caps() -> dict[str, Any]:
    # batch options:
    caps = {}
    for bprop in ("always", "min_delay", "max_delay", "delay", "max_events", "max_pixels", "time_unit"):
        evalue = os.environ.get(f"XPRA_BATCH_{bprop.upper()}")
        if evalue:
            try:
                caps[f"batch.{bprop}"] = int(evalue)
            except ValueError:
                log.error("Error: invalid environment value for %s: %s", bprop, evalue)
    log("get_batch_caps()=%s", caps)
    return caps


class Encodings(StubClientSubsystem):
    """
    Mixin for adding encodings to a client
    """
    __slots__ = (
        "_codecs_loaded", "_codecs_lock", "allowed_encodings", "auto_refresh_delay", "csc_modules", "encoding", "encoding_defaults",
        "min_quality", "min_speed", "quality", "server_core_encodings", "server_encodings",
        "server_encodings_with_lossless_mode", "server_encodings_with_quality", "server_encodings_with_speed",
        "speed", "video_decoders", "video_max_size", "video_scaling",
    )
    PREFIX = "encoding"

    def __init__(self, client=None):
        StubClientSubsystem.__init__(self, client)
        # Codec initialization is owned by the decode thread whenever one exists (it
        # must load the codecs before installing its seccomp filter): the decode thread
        # calls `load_all_codecs`, every other consumer calls `ensure_codecs_loaded`
        # and waits on this completion event. The lock keeps the load itself atomic:
        self._codecs_lock = Lock()
        self._codecs_loaded = Event()
        self.allowed_encodings: Sequence[str] = ()
        # in seconds:
        self.auto_refresh_delay: float = 0
        self.encoding = ""
        self.quality = -1
        self.min_quality = 0
        self.speed = 0
        self.min_speed = -1
        self.video_scaling = None
        self.video_max_size = VIDEO_MAX_SIZE
        self.csc_modules: Sequence[str] = ()
        self.video_decoders: Sequence[str] = ()

        self.server_encodings: Sequence[str] = ()
        self.server_core_encodings: Sequence[str] = ()
        self.server_encodings_with_speed: Sequence[str] = ()
        self.server_encodings_with_quality: Sequence[str] = ()
        self.server_encodings_with_lossless_mode: Sequence[str] = ()

        # what we told the server about our encoding defaults:
        self.encoding_defaults = {}

    def init(self, opts) -> None:
        self.allowed_encodings = opts.encodings
        self.auto_refresh_delay = opts.auto_refresh_delay
        self.encoding = opts.encoding
        if opts.video_scaling.lower() in ("auto", "on"):
            self.video_scaling = None
        else:
            self.video_scaling = parse_bool_or_int("video-scaling", opts.video_scaling)
        self.quality = opts.quality
        self.min_quality = opts.min_quality
        self.speed = opts.speed
        self.min_speed = opts.min_speed
        self.csc_modules = opts.csc_modules
        self.video_decoders = opts.video_decoders

    def load(self) -> None:
        # in backwards-compatible mode the hello carries the full encoding caps, so the
        # codecs must be loaded before it is built. When a decode thread exists it owns
        # that loading and `get_caps` waits for it (see `ensure_codecs_loaded`); the
        # `load` phase runs before the decode thread starts, so only load here when there
        # is no decode thread to defer to (otherwise we would deadlock waiting for it):
        if BACKWARDS_COMPATIBLE and not self.has_decode_thread():
            self.load_all_codecs()

    def run(self) -> None:
        if not BACKWARDS_COMPATIBLE:
            def load() -> None:
                self.ensure_codecs_loaded()
                self.client.after_handshake(self.send_encoding_config)
            start_thread(load, "encoding-config", daemon=True)

    def has_decode_thread(self) -> bool:
        # the `decode` subsystem is the thread that owns codec initialization
        # (see `xpra/client/subsystem/decode.py`):
        return bool(self.get_subsystem("decode"))

    def ensure_codecs_loaded(self) -> None:
        # enforce the invariant that, when a decode thread exists, it is the only thread
        # that initializes the codecs: every other consumer waits for it here rather
        # than loading (which would run codec imports / `dlopen` off the decode thread,
        # possibly after its seccomp filter is installed - see `docs/Usage/Seccomp.md`):
        if self._codecs_loaded.is_set():
            return
        if self.has_decode_thread():
            if not self._codecs_loaded.wait(CODEC_LOAD_TIMEOUT):
                log.warn("Warning: timed out waiting for the decode thread to load the codecs")
                # last-resort fallback so we never hang the handshake:
                self.load_all_codecs()
            return
        # no decode thread to defer to: load them ourselves
        self.load_all_codecs()

    def filter_video_decoder_options(self) -> tuple[str, ...]:
        video_decoders = tuple(self.video_decoders)
        try:
            from xpra import seccomp
        except ImportError:
            return video_decoders
        if not seccomp.is_enabled():
            return video_decoders
        disabled = ("no-vpl", "no-nvdec")
        filtered = [entry for entry in video_decoders if entry not in disabled]
        # Keep the explicit exclusions so "all" cannot re-enable them.
        for entry in disabled:
            if entry not in filtered:
                filtered.append(entry)
        return tuple(filtered)

    def load_all_codecs(self) -> None:
        # the actual, idempotent loader: called by the decode thread (which owns codec
        # initialization when it exists), or by `ensure_codecs_loaded` when there is no
        # decode thread. It must load the codecs exactly once, and the decode thread relies
        # on it completing before it installs its seccomp filter (which blocks the file
        # access that codec imports / `dlopen` / self-tests need - see
        # `docs/Usage/Seccomp.md`):
        with self._codecs_lock:
            if self._codecs_loaded.is_set():
                return
            self.do_load_all_codecs()
            self._codecs_loaded.set()

    def log_seccomp_hardware_decoders(self) -> None:
        # tell users which of their hardware decoders the seccomp filters are disabling:
        from importlib.util import find_spec
        disabled = []
        for name, module in SECCOMP_HARDWARE_DECODERS.items():
            if f"no-{name}" in self.video_decoders:
                # already excluded by the user
                continue
            try:
                if find_spec(module):
                    disabled.append(name)
            except ImportError:
                pass
        if disabled:
            log.info("hardware decoders disabled by seccomp: %s", csv(disabled))
            log.info(" use '--seccomp=no' to enable them")

    def do_load_all_codecs(self) -> None:
        log("load_all_codecs()")
        ae = self.allowed_encodings
        try:
            from xpra import seccomp
            video_decoders = self.filter_video_decoder_options()
            allow_hardware_jpeg = not seccomp.is_enabled()
        except ImportError:
            video_decoders = tuple(self.video_decoders)
            allow_hardware_jpeg = True
        if not allow_hardware_jpeg:
            self.log_seccomp_hardware_decoders()
        if {"png", "webp", "jpeg"}.intersection(ae):
            load_codec("dec_pillow")
        if "jpeg" in ae:
            # try to load the fast jpeg decoders:
            load_codec("dec_jpeg")
            if allow_hardware_jpeg:
                load_codec("dec_nvjpeg")
                load_codec("nvdec")
        if "webp" in ae:
            # try to load the fast webp decoder:
            load_codec("dec_webp")
        if "avif" in ae:
            load_codec("dec_avif")
        if "jph" in ae:
            load_codec("dec_jph")
        vh = getVideoHelper()
        vh.set_modules(video_decoders=video_decoders, csc_modules=self.csc_modules)
        vh.init()

    def cleanup(self) -> None:
        with log.trap_error("Error during video helper cleanup"):
            getVideoHelper().cleanup()
        unload_codecs()

    def init_authenticated_packet_handlers(self) -> None:
        self.add_packets(f"{Encodings.PREFIX}-set")
        self.add_legacy_alias("encodings", f"{Encodings.PREFIX}-set")

    def _process_set(self, packet: Packet) -> None:
        caps = typedict(packet.get_dict(1))
        Encodings._parse_server_capabilities(self, caps)
        # fire setting change event for the system-tray:
        ssc = getattr(self.client, "server_setting_changed", noop)
        ssc("encoding", caps)

    def get_info(self) -> dict[str, Any]:
        einfo = {
            "core": self.get_core_encodings(),
            "window-icon": self.get_window_icon_encodings(),
            "quality": self.quality,
            "min-quality": self.min_quality,
            "speed": self.speed,
            "min-speed": self.min_speed,
            "encoding": self.encoding or "auto",
            "video-scaling": self.video_scaling if self.video_scaling is not None else "auto",
        }
        if BACKWARDS_COMPATIBLE:
            einfo["cursor"] = self.get_cursor_encodings()
        return {
            "encodings": einfo,
            "server-encodings": self.server_core_encodings,
        }

    def send_encoding_config(self) -> None:
        caps = self.get_encodings_caps()
        log("send_encoding_config() caps=%s", caps)
        self.send("encoding-config", caps)

    def get_caps(self) -> dict[str, Any]:
        if not BACKWARDS_COMPATIBLE:
            return {"encoding": self.get_encodings_caps()}
        # the backwards-compatible hello advertises the full encoding caps, so make sure
        # the codecs are loaded first - waiting for the decode thread when it owns that
        # (this runs on the main loop, after the decode thread has been started):
        self.ensure_codecs_loaded()
        ecaps = self.get_encodings_caps()
        return {
            "encoding": ecaps,
            # servers older than v8 only read it from the top level:
            "auto_refresh_delay": ecaps["auto_refresh_delay"],
            "cursor.encodings": self.get_cursor_encodings(),
            "batch": get_batch_caps(),
            "encodings": {
                "": self.get_encodings(),
                "all": self.get_encodings(),
                "core": self.get_core_encodings(),
                "packet": True,
            }
        }

    def parse_server_capabilities(self, c: typedict) -> bool:
        self._parse_server_capabilities(c)
        return True

    def _parse_server_capabilities(self, c) -> None:
        self.server_encodings = c.strtupleget("encodings", DEFAULT_ENCODINGS)
        self.server_core_encodings = c.strtupleget("encodings.core", self.server_encodings)
        log("server_encodings=%s", self.server_encodings)
        log("server_core_encodings=%s", self.server_core_encodings)
        # old servers only supported x264:
        self.server_encodings_with_speed = c.strtupleget("encodings.with_speed", ("h264",))
        self.server_encodings_with_quality = c.strtupleget("encodings.with_quality", ("jpeg", "webp", "h264"))
        self.server_encodings_with_lossless_mode = c.strtupleget("encodings.with_lossless_mode", ())
        e = c.strget("encoding")
        if e and not c.boolget("encodings.delayed"):
            if self.encoding and e != self.encoding:
                if self.encoding not in self.server_core_encodings:
                    log.warn("server does not support %s encoding and has switched to %s", self.encoding, e)
                else:
                    log.info("server is using %s encoding instead of %s", e, self.encoding)
            self.encoding = e

    def get_encodings_caps(self) -> dict[str, Any]:
        video_b_frames: list[str] = []
        if B_FRAMES:
            video_b_frames.append("h264")  # only tested with dec_avcodec2
        caps: dict[str, Any] = {
            "options": self.get_encodings(),
            "core": self.get_core_encodings(),
            "window-icon": self.get_window_icon_encodings(),
            "video_b_frames": video_b_frames,
            "video_max_size": self.video_max_size,
            "max-soft-expired": MAX_SOFT_EXPIRED,
            "send-timestamps": SEND_TIMESTAMPS,
            "eos": True,
            # in milliseconds, 0 disables the lossless auto-refresh:
            "auto_refresh_delay": int(self.auto_refresh_delay * 1000),
        }
        if self.video_scaling is not None:
            caps["scaling.control"] = self.video_scaling
        if self.encoding:
            caps[""] = self.encoding
            # since v6.3:
            caps["setting"] = self.encoding
        if FULL_INFO > 1:
            for k, v in codec_versions.items():
                caps[f"{k}.version"] = v
        if self.quality > 0:
            caps["quality"] = self.quality
        if self.min_quality > 0:
            caps["min-quality"] = self.min_quality
        if self.speed >= 0:
            caps["speed"] = self.speed
        if self.min_speed >= 0:
            caps["min-speed"] = self.min_speed

        # generic rgb compression flags:
        if compression.use("lz4"):
            caps["rgb_lz4"] = True
        if compression.use("zstd"):
            caps["rgb_zstd"] = True
        # these are the defaults - when we instantiate a window,
        # we send the RGB modes its backing can really paint with, as part of the map event.
        # until then, stick to the formats every backing supports:
        rgb_formats = ["BGRX", "BGRA", "RGBX", "RGBA"]
        caps["rgb_formats"] = rgb_formats
        # figure out which CSC modes (usually YUV) can give us those RGB modes:
        full_csc_modes = getVideoHelper().get_server_full_csc_modes_for_rgb(*rgb_formats)
        if has_codec("dec_webp"):
            gl = self.get_subsystem("opengl")
            opengl_enabled = bool(gl and gl.enabled)
            full_csc_modes["webp"] = ["BGRX", "BGRA", "RGBX", "RGBA"] if opengl_enabled else ["BGRX", "BGRA"]
        if has_codec("dec_jpeg") or has_codec("dec_pillow"):
            full_csc_modes["jpeg"] = ["BGRX", "BGRA", "YUV420P"]
        if has_codec("dec_jpeg"):
            full_csc_modes["jpega"] = ["BGRA", "RGBA"]
        if has_codec("dec_jph"):
            full_csc_modes["jph"] = ["BGRX"]
        log("supported full csc_modes=%s", full_csc_modes)
        caps["full_csc_modes"] = full_csc_modes

        if "h264" in self.get_core_encodings():
            # some profile options: "baseline", "main", "high", "high10", ...
            # set the default to "high10" for YUV420P
            # as the python client always supports all the profiles
            # whereas on the server side, the default is baseline to accommodate less capable clients.
            # YUV422P requires high422, and
            # YUV444P requires high444,
            # so we don't bother specifying anything for those two.
            h264_caps = {}
            for csc_name, default_profile in (
                    ("YUV420P", "high"),
                    ("YUV422P", ""),
                    ("YUV444P", ""),
            ):
                profile = os.environ.get(f"XPRA_H264_{csc_name}_PROFILE", default_profile)
                if profile:
                    h264_caps[f"{csc_name}.profile"] = profile
            h264_caps["fast-decode"] = envbool("XPRA_X264_FAST_DECODE", False)
            # openh264 holds on to the Main and High profile frames of streams that use `pic_order_cnt_type` 0,
            # even when there are no B frames to reorder, until it runs out of pictures and fails to decode:
            # ask for streams that say their output order is the decoding order instead.
            # (servers assume that this is needed when the option is missing)
            h264_caps["poc-type-2"] = envbool("XPRA_H264_POC_TYPE_2", True)
            log("x264 encoding options: %s", h264_caps)
            caps["h264"] = h264_caps
        # the level caps a stream's resolution, framerate and bitrate,
        # so a client with a constrained decoder (hardware or otherwise)
        # can ask every video encoder for one it is able to keep up with.
        # we have no way of knowing what our decoders can do, so this is opt-in:
        for encoding in VIDEO_LEVELS:
            if encoding not in self.get_core_encodings():
                continue
            level = os.environ.get(f"XPRA_{encoding.upper()}_LEVEL", "")
            if level:
                enc_caps = caps.setdefault(encoding, {})
                enc_caps["level"] = level
                log("%s encoding level: %s", encoding, level)
        caps["batch"] = get_batch_caps()
        log("encoding capabilities: %s", caps)
        return caps

    def get_encodings(self) -> Sequence[str]:
        """
            Unlike get_core_encodings(), this method returns "rgb" for both "rgb24" and "rgb32".
            That's because although we may support both, the encoding chosen is plain "rgb",
            and the actual encoding used ("rgb24" or "rgb32") depends on the window's bit depth.
            ("rgb32" if there is an alpha channel, and if the client supports it)
        """
        cenc = [{"rgb32": "rgb", "rgb24": "rgb"}.get(x, x) for x in self.get_core_encodings()]
        if "grayscale" not in cenc and "png/L" in cenc:
            cenc.append("grayscale")
        if any(x in cenc for x in STREAM_ENCODINGS):
            cenc.append("stream")
        return preforder(cenc)

    def get_cursor_encodings(self) -> list[str]:
        assert BACKWARDS_COMPATIBLE
        e = ["raw", "default"]
        if "png" in self.get_core_encodings():
            e.append("png")
        return e

    def get_window_icon_encodings(self) -> list[str]:
        e = ["BGRA", "default"]
        if "png" in self.get_core_encodings():
            e.append("png")
        return e

    def get_core_encodings(self) -> list[str]:
        core = get_core_encodings()
        r = [x for x in core if x in self.allowed_encodings]
        log(f"get_core_encodings()={r} (core={core}, allowed={self.allowed_encodings})")
        return r

    def set_encoding(self, encoding: str) -> None:
        log("set_encoding(%s)", encoding)
        if encoding != "auto":
            encodings = self.get_encodings()
            if encoding not in encodings:
                raise ValueError(f"encoding {encoding} is not supported - only {csv(encodings)!r}")
            if encoding not in self.server_encodings:
                log.error(f"Error: encoding {encoding} is not supported by the server")
                log.error(" the only encodings allowed are:")
                log.error(" " + csv(self.server_encodings))
                return
        self.encoding = encoding
        packet_type = "encoding" if BACKWARDS_COMPATIBLE else f"{Encodings.PREFIX}-set"
        self.send(packet_type, self.encoding)

    def send_encoding_option(self, option: str, value: int) -> None:
        if self.legacy_server():
            self.send(option, value)
        else:
            self.send(f"{Encodings.PREFIX}-options", {option: value})

    def send_quality(self) -> None:
        q = self.quality
        log("send_quality() quality=%s", q)
        if q != -1 and (q < 0 or q > 100):
            raise ValueError(f"invalid quality: {q}")
        self.send_encoding_option("quality", q)

    def send_min_quality(self) -> None:
        q = self.min_quality
        log("send_min_quality() min-quality=%s", q)
        if q != -1 and (q < 0 or q > 100):
            raise ValueError(f"invalid min-quality: {q}")
        self.send_encoding_option("min-quality", q)

    def send_speed(self) -> None:
        s = self.speed
        log("send_speed() min-speed=%s", s)
        if s != -1 and (s < 0 or s > 100):
            raise ValueError(f"invalid speed: {s}")
        self.send_encoding_option("speed", s)

    def send_min_speed(self) -> None:
        s = self.min_speed
        log("send_min_speed() min-speed=%s", s)
        if s != -1 and (s < 0 or s > 100):
            raise ValueError(f"invalid min-speed: {s}")
        self.send_encoding_option("min-speed", s)

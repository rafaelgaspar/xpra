# This file is part of Xpra.
# Copyright (C) 2010 Antoine Martin <antoine@xpra.org>
# Copyright (C) 2008 Nathaniel Smith <njs@pobox.com>
# Xpra is released under the terms of the GNU GPL v2, or, at your option, any
# later version. See the file COPYING for details.

import os
from time import monotonic
from typing import Any
from collections.abc import Callable, Sequence

from xpra.net.packet_type import (
    WINDOW_RESTACK, WINDOW_RAISE, WINDOW_INITIATE_MOVERESIZE, WINDOW_DESTROY, WINDOW_RESIZED,
    WINDOW_MOVE_RESIZE, WINDOW_METADATA, WINDOW_BELL, WINDOW_GRAB, WINDOW_UNGRAB, WINDOW_STACKING,
)
from xpra.os_util import gi_import
from xpra.server.common import may_update_bandwidth_limits, wants_windows
from xpra.server.source.stub import StubClientConnection, is_recording_allowed, is_sync_allowed
from xpra.server.window.metadata import make_window_metadata, DEFAULT_VALUES
from xpra.server.window.filters import get_window_filter
from xpra.util.objects import typedict
from xpra.util.env import envint
from xpra.common import may_notify_client, force_size_constraint
from xpra.net.common import BACKWARDS_COMPATIBLE
from xpra.constants import NotificationID, DEFAULT_METADATA_SUPPORTED
from xpra.log import Logger

GLib = gi_import("GLib")

log = Logger("server")
focuslog = Logger("focus")
metalog = Logger("metadata")
bandwidthlog = Logger("bandwidth")
eventslog = Logger("events")
filterslog = Logger("filter")
sharinglog = Logger("sharing")

# the metadata we override for windows that are outside a client's display area
# when using `sharing=combine`: the client keeps the window, but does not show it
HIDDEN_METADATA: Sequence[str] = ("iconic", "skip-taskbar", "skip-pager")

CONGESTION_WARNING_EVENT_COUNT = envint("XPRA_CONGESTION_WARNING_EVENT_COUNT", 10)
CONGESTION_REPEAT_DELAY = envint("XPRA_CONGESTION_REPEAT_DELAY", 60)
MIN_BANDWIDTH = envint("XPRA_MIN_BANDWIDTH", 5 * 1024 * 1024)

PROPERTIES_DEBUG = [x.strip() for x in os.environ.get("XPRA_WINDOW_PROPERTIES_DEBUG", "").split(",")]


def noid(_window) -> int:
    return 0


class WindowsConnection(StubClientConnection):
    """
    Handle window forwarding:
    - damage
    - geometry
    - events
    etc
    """
    PREFIX = "window"
    __signals__ = ["new-window-source", "remove-window-source", "suspend", "resume"]

    @classmethod
    def is_needed(cls, caps: typedict) -> bool:
        return wants_windows(caps)

    def __init__(self):
        super().__init__()
        self.get_focus: Callable | None = None
        self.get_server_geometry: Callable | None = None
        self.window_filters = []
        self.readonly = False
        # duplicated from encodings:
        self.global_batch_config = None
        # duplicated from clientconnection:
        self.statistics = None
        self.connect("suspend", self.suspend_window_sources)
        self.connect("resume", self.resume_window_sources)

    def init_from(self, _protocol, server) -> None:
        # `WindowServer` is the standalone subsystem instance:
        window = server.subsystems["window"]
        self.get_focus = window.get_focus
        self.get_server_geometry = window.get_window_geometry
        self.window_filters = window.window_filters
        self.readonly = server.readonly

    def init_state(self) -> None:
        # WindowSource for each Window ID
        self.window_sources: dict[int, Any] = {}
        # Per-subsurface WindowSource, kept separate so they're not treated
        # as toplevels by bandwidth/cancel/info logic.
        self.subsurface_sources: dict[int, Any] = {}
        self.window_frame_sizes: dict = {}
        self.window_bell = False
        self.window_enabled = True
        self.window_min_size: tuple[int, int] = (0, 0)
        self.window_max_size: tuple[int, int] = (0, 0)
        self.window_restack = False
        # `sharing=sync`: move and resize the windows
        # when another client modifies their geometry
        self.window_sync_position = False
        # `sharing=sync`: raise the windows focused by another client
        self.window_sync_focus = False
        # receive the complete stacking order reported by another client
        self.window_sync_stacking = False
        self.window_metadata_supported: Sequence[str] = ()
        self.window_grabs = False
        self.system_tray = False
        # for handling resize synchronization between client and server (this is not xsync!):
        self.window_configure_time = 0.0
        self.window_record = False
        # `sharing=combine`: the windows that fall outside this client's display area,
        # which are sent to it but not shown (see `HIDDEN_METADATA`)
        self.hidden_windows: set = set()

    def cleanup(self) -> None:
        for window_source in self.all_window_sources():
            window_source.cleanup()
        self.window_sources = {}
        self.hidden_windows = set()
        for ws in tuple(self.subsurface_sources.values()):
            ws.cleanup()
        self.subsurface_sources = {}

    def all_window_sources(self) -> tuple:
        return tuple(self.window_sources.values())

    def cleanup_video_encoders(self) -> None:
        for ws in self.all_window_sources():
            ws.video_context_clean()
        for ws in tuple(self.subsurface_sources.values()):
            ws.video_context_clean()

    def suspend_window_sources(self) -> None:
        for ws in self.window_sources.values():
            ws.suspend()

    def resume_window_sources(self) -> None:
        for ws in self.window_sources.values():
            ws.resume()

    def go_idle(self) -> None:
        # usually fires from the server's idle_grace_timeout_cb
        if self.idle:
            return
        self.idle = True
        for window_source in self.all_window_sources():
            window_source.go_idle()

    def no_idle(self) -> None:
        # on user event, we stop being idle
        if not self.idle:
            return
        self.idle = False
        for window_source in self.all_window_sources():
            window_source.no_idle()

    def requires_sharing(self) -> bool:
        return not self.window_record

    def parse_client_caps(self, c: typedict) -> None:
        ui_client = c.boolget("ui_client", True) or not BACKWARDS_COMPATIBLE
        wcaps = typedict(c.dictget("window") or {})
        if BACKWARDS_COMPATIBLE and not wcaps:
            legacy = c.get("windows")
            if isinstance(legacy, dict):
                # the offscreen recorder used to send its options in the plural namespace:
                wcaps = typedict(legacy)
        self.window_enabled = ui_client and wants_windows(c)
        self.window_grabs = c.boolget("window.grabs")
        if BACKWARDS_COMPATIBLE and not self.window_grabs:
            # older clients advertise grabs in the `pointer` namespace:
            self.window_grabs = c.boolget("pointer.grabs")
        self.window_bell = c.boolget("bell")
        self.system_tray = c.boolget("system_tray")
        default_metadata_supported = DEFAULT_METADATA_SUPPORTED
        if BACKWARDS_COMPATIBLE:
            default_metadata_supported += ("content-type", )
        self.window_metadata_supported = c.strtupleget("metadata.supported", default_metadata_supported)
        log("metadata supported=%s", self.window_metadata_supported)
        self.window_frame_sizes = wcaps.dictget("frame_sizes")
        self.window_min_size = wcaps.inttupleget("min-size", (0, 0))
        self.window_max_size = wcaps.inttupleget("max-size", (0, 0))
        self.window_restack = wcaps.boolget("restack", False)
        # window filters:
        try:
            for object_name, property_name, operator, value in c.tupleget("window-filters"):
                self.add_window_filter(object_name, property_name, operator, value)
        except Exception as e:
            filterslog.error("Error parsing window-filters: %s", e)
        window_record_requested = wcaps.boolget("record")
        self.window_record = window_record_requested and is_recording_allowed(self, "windows")
        self.window_sync_position = wcaps.boolget("sync-position", self.window_record) and is_sync_allowed(self, "position")
        self.window_sync_focus = wcaps.boolget("sync-focus", self.window_record) and is_sync_allowed(self, "focus")
        # Stacking updates are harmless window-manager state. Unlike the other
        # recording and synchronization streams, they do not need a socket option.
        self.window_sync_stacking = window_record_requested or wcaps.boolget("sync-stacking")

    def get_caps(self) -> dict[str, Any]:
        return {}

    ######################################################################
    # info:
    def get_info(self) -> dict[str, Any]:
        info: dict[str, Any] = {
            "enabled": self.window_enabled,
            "bell": self.window_bell,
            "system-tray": self.system_tray,
            "restack": self.window_restack,
            "grabs": self.window_grabs,
            "sync-position": self.window_sync_position,
            "sync-focus": self.window_sync_focus,
            "sync-stacking": self.window_sync_stacking,
        }
        if self.hidden_windows:
            # `sharing=combine`: the windows outside this client's area of the display
            info["hidden"] = len(self.hidden_windows)
        wsize: dict[str, Any] = {
            "min": self.window_min_size,
            "max": self.window_max_size,
        }
        if self.window_frame_sizes:
            wsize["frame-sizes"] = self.window_frame_sizes
        info["size"] = wsize
        info.update(self.get_window_info())
        return {"window": info}

    def get_window_info(self) -> dict[str, Any]:
        """
        Adds encoding and window specific information
        """
        # pylint: disable=import-outside-toplevel
        from xpra.util.stats import get_list_stats
        pqpixels = [x[2] for x in tuple(self.packet_queue)]
        pqpi = get_list_stats(pqpixels)
        if pqpixels:
            pqpi["current"] = pqpixels[-1]
        info: dict[str, Any] = {
            "damage": {
                "compression_queue": {"size": {"current": self.encode_queue_size()}},
                "packet_queue": {"size": {"current": len(self.packet_queue)}},
                "packet_queue_pixels": pqpi,
            },
        }
        if gbc := self.global_batch_config:
            info["batch"] = gbc.get_info()
        if s := self.statistics:
            info.update(s.get_info())
        if self.window_sources:
            total_pixels = 0
            total_time = 0.0
            in_latencies, out_latencies = [], []
            winfo: dict[int, Any] = {}
            # group subsurface sources by parent wid for the parent's "subsurfaces" entry
            subs_by_parent: dict[int, list[dict[str, Any]]] = {}
            for sub_wid, sub_ws in self.subsurface_sources.items():
                entry: dict[str, Any] = {
                    "wid": sub_wid,
                    "offset": (sub_ws.offset_x, sub_ws.offset_y),
                    "info": sub_ws.get_info(),
                }
                subs_by_parent.setdefault(sub_ws.parent_wid, []).append(entry)
            for wid, ws in list(self.window_sources.items()):
                # per-window source stats:
                winfo[wid] = ws.get_info()
                if subs := subs_by_parent.get(wid):
                    winfo[wid]["subsurfaces"] = subs
                # collect stats for global averages:
                for _, _, pixels, _, _, encoding_time in tuple(ws.statistics.encoding_stats):
                    total_pixels += pixels
                    total_time += encoding_time
                in_latencies += [x * 1000 for _, _, _, x in tuple(ws.statistics.damage_in_latency)]
                out_latencies += [x * 1000 for _, _, _, x in tuple(ws.statistics.damage_out_latency)]
            info["windows"] = winfo
            v = 0
            if total_time > 0:
                v = int(total_pixels / total_time)
            info.setdefault("encoding", {})["pixels_encoded_per_second"] = v
            dinfo = info.setdefault("damage", {})
            dinfo["in_latency"] = get_list_stats(in_latencies, show_percentile=(9,))
            dinfo["out_latency"] = get_list_stats(out_latencies, show_percentile=(9,))
        return info

    ######################################################################
    # grabs:
    def window_grab(self, wid) -> None:
        if self.window_grabs and self.hello_sent:
            self.send(WINDOW_GRAB, wid)

    def window_ungrab(self, wid) -> None:
        if self.window_grabs and self.hello_sent:
            self.send(WINDOW_UNGRAB, wid)

    def send_window_stacking(self, stacking: Sequence[int]) -> None:
        focuslog("send_window_stacking(%s)", stacking)
        self.send(WINDOW_STACKING, list(stacking))

    def bell(self, wid: int, device: int, percent: int, pitch: int, duration: int,
             bell_class, bell_id: int, bell_name: str) -> None:
        if not self.window_bell or self.suspended or not self.hello_sent:
            return
        self.send_async(WINDOW_BELL, wid, device, percent, pitch, duration, bell_class, bell_id, bell_name)

    ######################################################################
    # window filters:
    def reset_window_filters(self) -> None:
        self.window_filters = [(uuid, f) for uuid, f in self.window_filters if uuid != self.uuid]

    def get_all_window_filters(self) -> list:
        return [f for uuid, f in self.window_filters if uuid == self.uuid]

    def add_window_filter(self, object_name: str, property_name: str, operator: str, value: Any) -> None:
        window_filter = get_window_filter(object_name, property_name, operator, value)
        assert window_filter
        self.do_add_window_filter(window_filter)

    def do_add_window_filter(self, window_filter) -> None:
        # (reminder: filters are shared between all sources)
        self.window_filters.append((self.uuid, window_filter))

    def can_send_window(self, window) -> bool:
        if not self.hello_sent or not (self.window_enabled or self.system_tray):
            return False
        # we could also allow filtering for system tray windows?
        if self.window_filters and self.window_enabled and not window.is_tray():
            for uuid, window_filter in self.window_filters:
                filterslog("can_send_window(%s) checking %s for uuid=%s (client uuid=%s)",
                           window, window_filter, uuid, self.uuid)
                if window_filter.matches(window):
                    v = uuid in ("*", self.uuid)
                    filterslog("can_send_window(%s)=%s", window, v)
                    return v
        if self.window_enabled and self.system_tray:
            # common case shortcut
            v = True
        elif window.is_tray():
            v = self.system_tray
        else:
            v = self.window_enabled
        filterslog("can_send_window(%s)=%s", window, v)
        return v

    ######################################################################
    # display area: with `sharing=combine`, this client only occupies a part
    # of the server's virtual display, so the coordinates we send it are
    # relative to that area, and the windows outside of it are hidden.
    # (`display_area` is provided by the `DisplayConnection` subsystem,
    #  it is `None` for every other sharing mode, which makes all of this a no-op)
    def get_window_origin(self) -> tuple[int, int]:
        area = getattr(self, "display_area", None)
        if not area:
            return 0, 0
        return area.x, area.y

    def to_client_position(self, x: int, y: int) -> tuple[int, int]:
        """ translate a position on the server's virtual display to this client's coordinate space """
        ox, oy = self.get_window_origin()
        return x - ox, y - oy

    def follows_window_positions(self) -> bool:
        """
        Should this client be told when another client moves a window?
        Either because it asked for it (`sync-position`),
        or because it shares the virtual display with the other clients (`sharing=combine`),
        and the window may be moving in or out of its own area.
        """
        return self.window_sync_position or getattr(self, "display_area", None) is not None

    def is_window_visible(self, window, geometry: Sequence[int] = ()) -> bool:
        """ does this window intersect this client's area of the virtual display? """
        area = getattr(self, "display_area", None)
        if not area:
            return True
        if window.is_tray():
            # trays are not placed on the desktop
            return True
        if not geometry or len(geometry) != 4:
            if not self.get_server_geometry:
                return True
            geometry = self.get_server_geometry(window)
        x, y, w, h = geometry
        if w <= 0 or h <= 0:
            return True
        visible = bool(area.intersects(x, y, w, h))
        sharinglog("is_window_visible(%s, %s)=%s (area=%s)", window, geometry, visible, area)
        return visible

    def is_window_hidden(self, window) -> bool:
        """ is this window outside this client's area of the virtual display? """
        return window in self.hidden_windows

    def get_hidden_metadata(self, window, hidden: bool) -> dict[str, Any]:
        """ the `HIDDEN_METADATA` values to send for a window entering or leaving this client's area """
        metadata: dict[str, Any] = {}
        for prop in HIDDEN_METADATA:
            if prop not in self.window_metadata_supported:
                continue
            if hidden:
                metadata[prop] = True
            elif prop in window.get_property_names():
                metadata.update(make_window_metadata(window, prop))
            else:
                # ie: wayland windows have no "skip-taskbar" or "skip-pager",
                # but we still have to undo the value we forced on the client:
                metadata[prop] = DEFAULT_VALUES[prop]
        return metadata

    def update_window_visibility(self, wid: int, window, geometry: Sequence[int] = (),
                                 force=False, notify=True) -> bool:
        """
        Hide or show this window for this client, depending on whether it
        intersects this client's area of the virtual display.
        `notify` can be disabled when the caller is about to send the metadata itself.
        Returns `True` if the window is hidden from this client.
        """
        hidden = not self.is_window_visible(window, geometry)
        was_hidden = self.is_window_hidden(window)
        if hidden == was_hidden and not force:
            return hidden
        if hidden == was_hidden:
            sharinglog("re-asserting %s state of window %#x for %s",
                       "hidden" if hidden else "visible", wid, self)
        else:
            sharinglog("window %#x is now %s for %s",
                       wid, "hidden" if hidden else "visible", self)
        if hidden:
            self.hidden_windows.add(window)
        else:
            self.hidden_windows.discard(window)
        if not self.can_send_window(window):
            return hidden
        if notify and (metadata := self.get_hidden_metadata(window, hidden)):
            sharinglog("sending %s for window %#x", metadata, wid)
            self.send(WINDOW_METADATA, wid, metadata)
        # a hidden window is unmapped as far as this client is concerned,
        # so we can stop sending it any pixels:
        if ws := self.window_sources.get(wid):
            if hidden:
                ws.unmap()
            else:
                if self.get_server_geometry:
                    # `mapped_at` is in server coordinates, as recorded by `_window_mapped_at`
                    # (the client will correct it when it maps the window again):
                    ws.map(self.get_server_geometry(window)[:2])
                # it may have changed a lot since we stopped sending it:
                self.refresh(wid, window, {})
        return hidden

    ######################################################################
    # windows:
    def initiate_moveresize(self, wid: int, window, x_root: int, y_root: int,
                            direction: int, button: int, source_indication: int) -> None:
        if not self.can_send_window(window):
            return
        log("initiate_moveresize sending to %s", self)
        x_root, y_root = self.to_client_position(x_root, y_root)
        self.send(WINDOW_INITIATE_MOVERESIZE, wid, x_root, y_root, direction, button, source_indication)

    def or_window_geometry(self, wid: int, window, x: int, y: int, w: int, h: int) -> None:
        if not self.can_send_window(window):
            return
        self.update_window_visibility(wid, window, (x, y, w, h))
        packet_type = "configure-override-redirect" if BACKWARDS_COMPATIBLE else WINDOW_MOVE_RESIZE
        x, y = self.to_client_position(x, y)
        self.send(packet_type, wid, x, y, w, h)

    def window_metadata(self, wid: int, window, prop: str) -> None:
        if not self.can_send_window(window):
            return
        if prop == "icons":
            self.send_window_icon(wid, window)
        else:
            metadata = self._make_metadata(window, prop)
            if prop in PROPERTIES_DEBUG:
                metalog.info("make_metadata(%#x, %s, %r)=%s", wid, window, prop, metadata)
            else:
                metalog("make_metadata(%#x, %s, %r)=%s", wid, window, prop, metadata)
            if metadata:
                self.send(WINDOW_METADATA, wid, metadata)

    # Takes the name of a WindowModel property, and returns a dictionary of
    # xpra window metadata values that depend on that property
    def _make_metadata(self, window, propname: str, skip_defaults=False) -> dict[str, Any]:
        if propname not in self.window_metadata_supported:
            metalog("make_metadata: client does not support %r", propname)
            return {}
        if propname in HIDDEN_METADATA and self.is_window_hidden(window):
            # this window is outside this client's area of the virtual display,
            # tell it to keep the window out of the way:
            # (unconditionally, since `skip_defaults` would drop the `False` default)
            sharinglog("forcing %s=True for hidden window %s", propname, window)
            return {propname: True}
        metadata = make_window_metadata(window, propname, skip_defaults=skip_defaults)
        pos = metadata.get("requested-position")
        if pos and len(pos) == 2:
            # this is a position on the virtual display, just like the window's geometry:
            metadata["requested-position"] = self.to_client_position(*pos)
        if getattr(self, "effective_readonly", lambda: self.readonly)():
            metalog("overriding size-constraints for readonly mode")
            size = window.get_dimensions()
            metadata.update(force_size_constraint(*size))
        return metadata

    def new_tray(self, wid: int, window, w: int, h: int) -> None:
        assert window.is_tray()
        if not self.can_send_window(window):
            return
        metadata = {}
        for propname in list(window.get_property_names()):
            metadata.update(self._make_metadata(window, propname, skip_defaults=True))
        self.send_async("new-tray", wid, w, h, metadata)

    def new_window(self, packet_type: str, wid: int, window, x: int, y: int, w: int, h: int,
                   client_properties: dict) -> None:
        if not self.can_send_window(window):
            return
        # decide if this window belongs on this client's area before making the metadata,
        # so that `_make_metadata` can override it - no need to notify separately:
        # (the geometry we are given may have been adjusted for this client,
        #  the visibility must be decided from the position on the server's display)
        hidden = self.update_window_visibility(wid, window, notify=False)
        x, y = self.to_client_position(x, y)
        send_props = list(window.get_property_names())
        metalog("new window properties: %r", send_props)
        send_raw_icon = "icons" in send_props
        if send_raw_icon:
            send_props.remove("icons")
        metadata = {}
        for prop in send_props:
            v = self._make_metadata(window, prop, skip_defaults=True)
            if prop in PROPERTIES_DEBUG:
                metalog.info("make_metadata(%#x, %s, %r)=%s", wid, window, prop, v)
            else:
                metalog("make_metadata(%#x, %s, %r)=%s", wid, window, prop, v)
            metadata.update(v)
        log("new_window(%s, %#x, %s, %i, %i, %i, %i, %s) metadata(%s)=%s",
            packet_type, wid, window, x, y, w, h, client_properties, send_props, metadata)
        self.send_async(packet_type, wid, x, y, w, h, metadata, client_properties or {})
        if hidden and (hidden_metadata := self.get_hidden_metadata(window, True)):
            # showing a new window usually de-iconifies it,
            # so we have to ask for it to be hidden again once it exists:
            self.send(WINDOW_METADATA, wid, hidden_metadata)
        if send_raw_icon:
            self.send_window_icon(wid, window)

    def send_window_icon(self, wid: int, window) -> None:
        if not self.can_send_window(window):
            return
        # we may need to make a new source at this point:
        ws = self.make_window_source(wid, window)
        ws.send_window_icon()

    def lost_window(self, wid: int, _window) -> None:
        self.send(WINDOW_DESTROY, wid)

    def move_resize_window(self, wid: int, window, x: int, y: int, ww: int, wh: int, resize_counter: int = 0) -> None:
        """
        The server detected that the application window has been moved and/or resized,
        we forward it if the client supports this type of event.
        """
        if not self.can_send_window(window):
            return
        self.update_window_visibility(wid, window, (x, y, ww, wh))
        x, y = self.to_client_position(x, y)
        self.send(WINDOW_MOVE_RESIZE, wid, x, y, ww, wh, resize_counter)

    def resize_window(self, wid: int, window, ww: int, wh: int, resize_counter: int = 0) -> None:
        if not self.can_send_window(window):
            return
        self.update_window_visibility(wid, window)
        self.send(WINDOW_RESIZED, wid, ww, wh, resize_counter)

    def cancel_damage(self, wid: int) -> None:
        """
        Use this method to cancel all currently pending and ongoing
        damage requests for a window.
        """
        if ws := self.window_sources.get(wid):
            ws.cancel_damage()

    def record_scroll_event(self, wid: int) -> None:
        if ws := self.window_sources.get(wid):
            ws.record_scroll_event()

    def reinit_encoders(self) -> None:
        for ws in tuple(self.window_sources.values()):
            ws.init_encoders()

    def map_window(self, wid: int, window, coords=None) -> None:
        ws = self.make_window_source(wid, window)
        ws.map(coords)

    def unmap_window(self, wid: int, _window) -> None:
        if ws := self.window_sources.get(wid):
            ws.unmap()

    def restack_window(self, wid: int, window, detail: int, sibling: int) -> None:
        focuslog("restack_window(%#x, %s, %i, %i)", wid, window, detail, sibling)
        if not self.can_send_window(window):
            return
        if not self.window_restack:
            # older clients can only handle "raise-window"
            if detail != 0:
                return
            self.send_async(WINDOW_RAISE, wid)
            return
        self.send_async(WINDOW_RESTACK, wid, detail, sibling)

    def raise_window(self, wid: int, window) -> None:
        if not self.can_send_window(window):
            return
        self.send_async(WINDOW_RAISE, wid)

    def remove_window(self, wid: int, window) -> None:
        """ The given window is gone, ensure we free all the related resources """
        self.hidden_windows.discard(window)
        if not self.can_send_window(window):
            return
        if ws := self.window_sources.pop(wid, None):
            self.emit("remove-window-source", ws)
            ws.cleanup()
        self.calculate_window_pixels.pop(wid, None)

    def refresh(self, wid: int, window, opts) -> None:
        if not self.can_send_window(window):
            return
        self.cancel_damage(wid)
        w, h = window.get_dimensions()
        self.damage(wid, window, 0, 0, w, h, opts)

    def update_batch(self, wid: int, window, batch_props: typedict) -> None:
        if ws := self.window_sources.get(wid):
            if "reset" in batch_props:
                ws.batch_config = self.make_batch_config(wid, window)
            for x in ("always", "locked"):
                if x in batch_props:
                    setattr(ws.batch_config, x, batch_props.boolget(x))
            for x in ("min_delay", "max_delay", "timeout_delay", "delay"):
                if x in batch_props:
                    setattr(ws.batch_config, x, batch_props.intget(x))
            log("batch config updated for window %#x: %s", wid, ws.batch_config)

    def set_client_properties(self, wid: int, window, new_client_properties: typedict) -> None:
        assert self.window_enabled
        ws = self.make_window_source(wid, window)
        ws.set_client_properties(new_client_properties)

    def get_window_source(self, wid: int):
        return self.window_sources.get(wid)

    def make_window_source(self, wid: int, window):
        if ws := self.window_sources.get(wid):
            return ws
        batch_config = self.make_batch_config(wid, window)
        ww, wh = window.get_dimensions()
        mmap_write_area = getattr(self, "mmap_write_area", None)
        if mmap_write_area and mmap_write_area.enabled:
            bandwidth_limit = 0
        else:
            mmap_write_area = None
            bandwidth_limit = getattr(self, "bandwidth_limit", 0)
        av_sync = getattr(self, "av_sync", False)
        av_sync_delay = getattr(self, "av_sync_delay", 0)
        conn = getattr(self.protocol, "_conn", None)
        socktype = getattr(conn, "socktype_wrapped", "")
        jitter = getattr(conn, "jitter", 0)
        datagram = 1350 if socktype == "quic" else 0
        log(f"datagram({socktype=})={datagram}")
        # pylint: disable=import-outside-toplevel
        from xpra.server.window.video_compress import WindowVideoSource
        ws = WindowVideoSource(
            ww, wh,
            self.record_congestion_event, self.encode_queue_size,
            self.call_in_encode_thread, self.queue_packet,
            self.statistics,
            wid, window, batch_config, self.auto_refresh_delay,
            av_sync, av_sync_delay,
            self.video_helper,
            self.cuda_device_context,
            self.server_core_encodings,
            self.encoding, self.encodings, self.core_encodings,
            self.window_icon_encodings, self.encoding_options, self.icons_encoding_options,
            self.rgb_formats,
            self.default_encoding_options,
            mmap_write_area, bandwidth_limit, jitter, datagram)
        self.window_sources[wid] = ws
        if len(self.window_sources) > 1:
            # re-distribute bandwidth:
            may_update_bandwidth_limits(self)
        ws.init_encoders()
        self.emit("new-window-source", ws)
        return ws

    def make_subsurface_source(self, wid: int, parent_wid: int, offset_x: int, offset_y: int, window,
                               logical_width: int, logical_height: int, native_width: int, native_height: int):
        if ws := self.subsurface_sources.get(wid):
            ws.update_geometry(parent_wid, offset_x, offset_y,
                               logical_width, logical_height, native_width, native_height)
            return ws
        batch_config = self.make_batch_config(wid, window)
        ww, wh = window.get_dimensions()
        mmap_write_area = getattr(self, "mmap_write_area", None)
        if mmap_write_area and mmap_write_area.enabled:
            bandwidth_limit = 0
        else:
            mmap_write_area = None
            bandwidth_limit = getattr(self, "bandwidth_limit", 0)
        av_sync = getattr(self, "av_sync", False)
        av_sync_delay = getattr(self, "av_sync_delay", 0)
        conn = getattr(self.protocol, "_conn", None)
        socktype = getattr(conn, "socktype_wrapped", "")
        jitter = getattr(conn, "jitter", 0)
        datagram = 1350 if socktype == "quic" else 0
        # pylint: disable=import-outside-toplevel
        from xpra.server.window.subsurface_source import SubsurfaceWindowSource
        ws = SubsurfaceWindowSource(
            ww, wh,
            self.record_congestion_event, self.encode_queue_size,
            self.call_in_encode_thread, self.queue_packet,
            self.statistics,
            wid, window, batch_config, self.auto_refresh_delay,
            av_sync, av_sync_delay,
            self.video_helper,
            self.cuda_device_context,
            self.server_core_encodings,
            self.encoding, self.encodings, self.core_encodings,
            self.window_icon_encodings, self.encoding_options, self.icons_encoding_options,
            self.rgb_formats,
            self.default_encoding_options,
            mmap_write_area, bandwidth_limit, jitter, datagram,
            parent_wid=parent_wid, offset_x=offset_x, offset_y=offset_y,
            logical_width=logical_width, logical_height=logical_height,
            native_width=native_width, native_height=native_height,
        )
        self.subsurface_sources[wid] = ws
        ws.init_encoders()
        return ws

    def cleanup_subsurface_source(self, wid: int) -> None:
        if ws := self.subsurface_sources.pop(wid, None):
            ws.cleanup()

    def damage(self, wid: int, window, x: int, y: int, w: int, h: int, options=None) -> None:
        """
            Main entry point from the window manager,
            we dispatch to the WindowSource for this window id
            (creating a new one if needed)
        """
        if not self.can_send_window(window):
            return
        if self.is_window_hidden(window):
            # `sharing=combine`: this window is not on this client's area of the display,
            # it is minimized there, so there is no point in sending it any pixels
            sharinglog("damage(%s) ignored: hidden from %s", window, self)
            return
        assert window is not None
        if options:
            damage_options = options.copy()
        else:
            damage_options = {}
        if s := self.statistics:
            s.damage_last_events.append((wid, monotonic(), w * h))
        ws = self.make_window_source(wid, window)
        ws.damage(x, y, w, h, damage_options)

    def client_ack_damage(self, damage_packet_sequence: int, wid: int,
                          width: int, height: int, decode_time: int, message: str) -> None:
        """
            The client is acknowledging a damage packet,
            we record the 'client decode time' (which is provided by the client)
            and WindowSource will calculate and record the "client latency".
            (since it knows when the "draw" packet was sent)
        """
        if not self.window_enabled:
            log.error("Error: draw ack received for window %#x, but it is not enabled!")
            return
        if decode_time > 0:
            self.statistics.client_decode_time.append((wid, monotonic(), width * height, decode_time))
        if ws := self.window_sources.get(wid):
            ws.damage_packet_acked(damage_packet_sequence, width, height, decode_time, message)
            self.may_recalculate(wid, width * height)

    #
    # Methods used by WindowSource:
    #
    def record_congestion_event(self, source, late_pct: int = 0, send_speed: int = 0) -> None:
        if not getattr(self, "bandwidth_detection", False):
            return
        gs = self.statistics
        if not gs:
            # window cleaned up?
            return
        now = monotonic()
        elapsed = now - self.bandwidth_warning_time
        bandwidthlog("record_congestion_event(%s, %i, %i) bandwidth_warnings=%s, elapsed time=%i",
                     source, late_pct, send_speed, self.bandwidth_warnings, elapsed)
        gs.last_congestion_time = now
        gs.congestion_send_speed.append((now, late_pct, send_speed))
        if self.bandwidth_warnings and elapsed > CONGESTION_REPEAT_DELAY:
            # enough congestion events?
            T = 10
            min_time = now - T
            count = sum(int(x[0] > min_time) for x in gs.congestion_send_speed)
            bandwidthlog("record_congestion_event: %i events in the last %i seconds (warnings after %i)",
                         count, T, CONGESTION_WARNING_EVENT_COUNT)
            if count > CONGESTION_WARNING_EVENT_COUNT:
                self.bandwidth_warning_time = now
                nid = NotificationID.BANDWIDTH
                summary = "Network Performance Issue"
                body = "\n".join((
                    "Your network connection is struggling to keep up,",
                    "consider lowering the bandwidth limit,",
                    "or turning off automatic network congestion management.",
                    "Choosing 'ignore' will silence all further warnings.",
                ))
                actions = []
                if self.bandwidth_limit == 0 or self.bandwidth_limit > MIN_BANDWIDTH:
                    actions += ["lower-bandwidth", "Lower bandwidth limit"]
                actions += ["bandwidth-off", "Turn off"]
                # if self.default_min_quality>10:
                #    actions += ["lower-quality", "Lower quality"]
                actions += ["ignore", "Ignore"]
                hints = {}
                may_notify_client(self, nid, summary, body, actions, hints,
                                  icon_name="connect", user_callback=self.congestion_notification_callback)

    def congestion_notification_callback(self, nid: int, action_id: str) -> None:
        bandwidthlog("congestion_notification_callback(%i, %s)", nid, action_id)
        if action_id == "lower-bandwidth":
            bandwidth_limit = 50 * 1024 * 1024
            if self.bandwidth_limit > 256 * 1024:
                bandwidth_limit = self.bandwidth_limit // 2
            css = 50 * 1024 * 1024
            if self.statistics.avg_congestion_send_speed > 256 * 1024:
                # round up:
                css = int(self.statistics.avg_congestion_send_speed // 16 / 1024) * 16 * 1024
            self.bandwidth_limit = max(MIN_BANDWIDTH, min(bandwidth_limit, css))
            self.setting_changed("bandwidth-limit", self.bandwidth_limit)
        # elif action_id=="lower-quality":
        #    self.default_min_quality = max(1, self.default_min_quality-15)
        #    self.set_min_quality(self.default_min_quality)
        #    self.setting_changed("min-quality", self.default_min_quality)
        elif action_id == "bandwidth-off":
            self.bandwidth_detection = False
        elif action_id == "ignore":
            self.bandwidth_warnings = False
